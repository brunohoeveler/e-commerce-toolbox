import asyncio
import json
import os
import time
from pathlib import Path
from typing import Annotated, List
from zipfile import ZipFile

from celery.result import AsyncResult
from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask
from starlette.responses import JSONResponse, StreamingResponse

from app.core.config import settings
from app.core.logger import logger
from app.schemas.dynamic_model import build_dynamic_model
from app.tasks.celery_worker import celery_app
from app.tasks.data_conversion_registry import DataConversionRegistry
from app.tasks.process_task import process_data_conversion_task, process_tool_task
from app.tasks.tool_registry import ToolRegistry
from app.utils.file_utils import save_upload_file

router = APIRouter()


@router.post("/data-conversion/process")
async def process_data_conversion_endpoint(
    data_conversion: Annotated[str, Form()],
    conversion: Annotated[str, Form()],
    user_id: Annotated[str, Form()],
    user_name: Annotated[str, Form()],
    user_email: Annotated[str, Form()],
    files: Annotated[List[UploadFile] | None, File()] = None,
    parameters: Annotated[str | None, Form()] = None,
):
    logger.info(f"🔄 Starting data conversion: {data_conversion}/{conversion} (user: {user_id})")

    # Load conversion entry
    try:
        registry_entry = DataConversionRegistry.get_metadata(data_conversion, conversion)
        input_type = registry_entry.get("input_type", {})
    except Exception as e:
        logger.error(f"❌ Conversion not found: {e}")
        raise HTTPException(status_code=400, detail="Conversion not found")

    # Parse parameters JSON
    try:
        parameters_dict = json.loads(parameters or "{}")
    except Exception as e:
        logger.error(f"❌ Invalid parameters JSON: {e}")
        raise HTTPException(status_code=400, detail="Invalid JSON in parameters")

    # Build + validate the dynamic model
    try:
        DynamicModel = build_dynamic_model(input_type, model_name=f"{data_conversion}_{conversion}_Params")
        validated = DynamicModel(files=files, **parameters_dict)
    except Exception as e:
        logger.error(f"❌ Validation error: {e}")
        raise HTTPException(status_code=422, detail=f"Validation error: {str(e)}")

    # Save uploaded files
    saved_paths = []
    if validated.files:
        user_dir = Path(settings.UPLOAD_DIR) / data_conversion / conversion / user_id
        user_dir.mkdir(parents=True, exist_ok=True)

        for file in validated.files:
            upload_path = save_upload_file(user_dir, file)
            saved_paths.append(str(upload_path))

    # Assemble payload
    payload = {
        "files": saved_paths,
        **validated.model_dump(exclude={"files"}),
    }

    logger.debug(f"🚀 Dispatching task with payload: {payload}")

    # Trigger Celery task
    task = process_data_conversion_task.apply_async(args=[data_conversion, conversion, payload], headers={"user_id": user_id, "user_name": user_name, "user_email": user_email})

    return JSONResponse(
        content={"task_id": task.id, "status": "submitted"},
        headers={"Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "POST, GET, OPTIONS"},
    )


@router.post("/tool/process")
async def process_tool_endpoint(
    tool: Annotated[str, Form()],
    variant: Annotated[str, Form()],
    user_id: Annotated[str, Form()],
    user_name: Annotated[str, Form()],
    user_email: Annotated[str, Form()],
    files: Annotated[List[UploadFile] | None, File()] = None,
    parameters: Annotated[str | None, Form()] = None,
):
    logger.info(f"🔄 Starting tool: {tool}/{variant} (user: {user_id})")

    # Load conversion entry
    try:
        registry_entry = ToolRegistry.get_metadata(tool, variant)
        input_type = registry_entry.get("input_type", {})
    except Exception as e:
        logger.error(f"❌ Variant not found: {e}")
        raise HTTPException(status_code=400, detail="Variant not found")

    # Parse parameters JSON
    try:
        parameters_dict = json.loads(parameters or "{}")
    except Exception as e:
        logger.error(f"❌ Invalid parameters JSON: {e}")
        raise HTTPException(status_code=400, detail="Invalid JSON in parameters")

    # Build + validate the dynamic model
    try:
        DynamicModel = build_dynamic_model(input_type, model_name=f"{tool}_{variant}_Params")
        validated = DynamicModel(files=files, **parameters_dict)
    except Exception as e:
        logger.error(f"❌ Validation error: {e}")
        raise HTTPException(status_code=422, detail=f"Validation error: {str(e)}")

    # Save uploaded files
    saved_paths = []
    # check if validated has the files attribute
    if hasattr(validated, "files") and validated.files:
        user_dir = Path(settings.UPLOAD_DIR) / tool / variant / user_id
        user_dir.mkdir(parents=True, exist_ok=True)

        for file in validated.files:
            upload_path = save_upload_file(user_dir, file)
            saved_paths.append(str(upload_path))

        # Assemble payload with files
        payload = {
            "files": saved_paths,
            **validated.model_dump(exclude={"files"}),
        }
    else:
        # Assemble payload
        payload = {
            **validated.model_dump(),
        }

    logger.debug(f"🚀 Dispatching task with payload: {payload}")

    # Trigger Celery task
    task = process_tool_task.apply_async(args=[tool, variant, payload], headers={"user_id": user_id, "user_name": user_name, "user_email": user_email})

    return JSONResponse(
        content={"task_id": task.id, "status": "submitted"},
        headers={"Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "POST, GET, OPTIONS"},
    )


@router.get("/task/{task_id}")
def get_task_status(task_id: str):
    task_result = AsyncResult(task_id, app=celery_app)

    response = {
        "task_id": task_result.id,
        "status": task_result.status,
    }

    if task_result.status == "SUCCESS":
        response["result"] = task_result.result

    elif task_result.status == "FAILURE":
        response["error"] = task_result.result

    return response


@router.get("/tasks/{task_id}/stream")
def stream_task_updates(task_id: str):
    async def event_stream():
        start_time = time.time()
        timeout = 120.0  # seconds
        polling_interval = 1.0
        max_interval = 5.0

        task_result = AsyncResult(task_id, app=celery_app)

        # Initial push
        def make_payload(tr: AsyncResult):
            return {
                "status": tr.status,  # or tr.state
                "task_id": tr.id,
                "timestamp": time.time(),
            }

        data = make_payload(task_result)

        # If it's already done, return once
        if task_result.ready():
            if task_result.successful():
                data["result"] = task_result.result
            elif task_result.failed():
                data["error"] = str(task_result.result)
            yield f"data: {json.dumps(data)}\n\n"
            return

        # Send initial status
        yield f"data: {json.dumps(data)}\n\n"

        while not task_result.ready():
            if time.time() - start_time > timeout:
                yield "data: " + json.dumps({"status": "TIMEOUT", "task_id": task_id, "timestamp": time.time(), "error": f"Task streaming timed out after {int(timeout)} seconds"}) + "\n\n"
                return

            await asyncio.sleep(polling_interval)
            polling_interval = min(polling_interval * 1.2, max_interval)

            task_result = AsyncResult(task_id, app=celery_app)

            if task_result.ready():
                final = make_payload(task_result)
                if task_result.successful():
                    final["result"] = task_result.result
                elif task_result.failed():
                    final["error"] = str(task_result.result)
                final["final"] = True
                yield f"data: {json.dumps(final)}\n\n"
                return

            # Still not ready? it's a progress tick
            yield f"data: {json.dumps(make_payload(task_result))}\n\n"

        # Final push
        final = make_payload(task_result)
        if task_result.successful():
            final["result"] = task_result.result
        elif task_result.failed():
            final["error"] = str(task_result.result)
        yield f"data: {json.dumps(final)}\n\n"

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",  # important
        headers={
            "Cache-Control": "no-cache",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, OPTIONS",
        },
    )


@router.get("/tasks/{user_id}/{task_id}/download")
def download_result_file(
    task_id: str,
    user_id: str,
):
    result = AsyncResult(task_id, app=celery_app)

    if not result.state == "SUCCESS":
        raise HTTPException(status_code=400, detail="Task not finished yet")

    if not result.result["user_id"] == user_id:
        raise HTTPException(status_code=403, detail="Unauthorized")

    if not result.result:
        raise HTTPException(status_code=404, detail="File not found")

    return FileResponse(
        path=result.result["file_path"],
        filename=result.result["file_name"],
        media_type="application/octet-stream",
        headers={"Access-Control-Expose-Headers": "Content-Disposition", "filename": result.result["file_name"]},
    )


@router.get("/errors/{task_id}")
def download_error_inputs(
    task_id: str,
):
    result = AsyncResult(task_id, app=celery_app)

    if not result.args[2] or not result.args[2].get("files"):
        raise HTTPException(status_code=400, detail="No files to download")
    if not result.state == "FAILURE":
        raise HTTPException(status_code=400, detail="Task not finished yet")

    inputs = result.args[2]["files"]

    with ZipFile(os.path.join(settings.ERROR_DIR, task_id + ".zip"), "w") as zf:
        for file in inputs:
            zf.write(file, os.path.basename(file))

    return FileResponse(
        path=os.path.join(settings.ERROR_DIR, task_id + ".zip"),
        filename=f"{task_id}.zip",
        media_type="application/zip",
        headers={"Access-Control-Expose-Headers": "Content-Disposition", "filename": f"{task_id}.zip"},
        background=BackgroundTask(lambda: os.remove(os.path.join(settings.ERROR_DIR, task_id + ".zip"))),
    )


@router.get("/data-conversions")
def list_registered_data_conversions():
    print("🔄 Listing registered data conversions")
    return DataConversionRegistry.get_all()


@router.get("/tools")
def list_registered_tools():
    print("🔧 Listing registered tools")
    return ToolRegistry.get_all()
