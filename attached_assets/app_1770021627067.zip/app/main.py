from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI

from app.api.endpoints import router as api_router
from app.core.config import settings
from app.core.logger import logger


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 FastAPI app is starting up...")
    Path("logs").mkdir(exist_ok=True)
    Path(settings.UPLOAD_DIR).mkdir(parents=True, exist_ok=True)
    Path(settings.RESULT_DIR).mkdir(parents=True, exist_ok=True)
    yield
    logger.info("👋 FastAPI app is shutting down...")


app = FastAPI(title=settings.PROJECT_NAME, lifespan=lifespan)
app.include_router(api_router)
