from typing import Any, Dict, Type, Union, get_args, get_origin

from pydantic import Field, create_model

from app.schemas.validators import (
    build_allowed_validator,
    build_extension_validator,
    build_regex_validator,
)


def is_optional_type(t):
    return get_origin(t) is Union and type(None) in get_args(t)


def build_dynamic_model(input_type: Dict[str, Any], model_name: str = "DynamicInput") -> Type:
    fields = {}
    validators = {}

    for field_name, field_def in input_type.items():
        # Parse type + metadata
        if isinstance(field_def, tuple):
            field_type, meta = field_def
            meta = meta if isinstance(meta, dict) else {"description": meta}
        else:
            field_type, meta = field_def, {}

        optional = is_optional_type(field_type)
        default = None if optional else ...

        # Base field kwargs
        field_kwargs = {
            "description": meta.get("description"),
        }

        # Add numeric min/max
        if isinstance(field_type, type) and issubclass(field_type, (int, float)):
            if "min" in meta:
                field_kwargs["ge"] = meta["min"]
            if "max" in meta:
                field_kwargs["le"] = meta["max"]

        # Add list min/max (for files or multi-selects)
        if get_origin(field_type) is list:
            if "min_files" in meta:
                field_kwargs["min_items"] = meta["min_files"]
            if "max_files" in meta:
                field_kwargs["max_items"] = meta["max_files"]

        fields[field_name] = (
            field_type,
            Field(default, **{k: v for k, v in field_kwargs.items() if v is not None}),
        )

        # Dynamically attach validators
        if "regex" in meta:
            validators[f"validate_{field_name}_regex"] = build_regex_validator(field_name, meta["regex"])

        if "allowed" in meta:
            validators[f"validate_{field_name}_allowed"] = build_allowed_validator(field_name, meta["allowed"])

        if "extensions" in meta:
            validators[f"validate_{field_name}_extensions"] = build_extension_validator(field_name, meta["extensions"])

    return create_model(
        model_name,
        **fields,
        __validators__=validators,
    )
