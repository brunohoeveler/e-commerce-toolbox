import re
from typing import List

from pydantic import field_validator
from pydantic_core.core_schema import ValidationInfo


def build_regex_validator(field: str, pattern: str):
    @field_validator(field, mode="before")
    def _validator(cls, v, info: ValidationInfo):
        if v is not None and not re.match(pattern, v):
            raise ValueError(f"Value does not match pattern: {pattern}")
        return v

    return _validator


def build_allowed_validator(field: str, allowed: List[str]):
    @field_validator(field, mode="before")
    def _validator(cls, v, info: ValidationInfo):
        if v is not None and v not in allowed:
            raise ValueError(f"Value '{v}' not allowed. Must be one of: {', '.join(map(str, allowed))}")
        return v

    return _validator


def build_extension_validator(field: str, extensions: List[str]):
    exts = [ext.lower() for ext in extensions]

    @field_validator(field, mode="before")
    def _validator(cls, v, info: ValidationInfo):
        invalid = [f.filename for f in v or [] if f.filename.split(".")[-1].lower() not in exts]
        if invalid:
            raise ValueError(f"Invalid file extension(s): {', '.join(invalid)}. Allowed: {', '.join(exts)}")
        return v

    return _validator
