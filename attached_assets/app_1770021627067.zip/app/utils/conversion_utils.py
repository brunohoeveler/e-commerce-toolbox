import os
import subprocess
from pathlib import Path


def convert_xlsx_to_pdf(input_xlsx_path: Path, keep_original: bool = False) -> Path:
    """
    Converts an Excel (.xlsx) file to a PDF using LibreOffice.

    This function runs LibreOffice in headless mode to convert an Excel file to a PDF format.
    It constructs and executes a shell command to perform the conversion.

    Args:
        input_xlsx_path (Path): The path to the input Excel (.xlsx) file.
        keep_original (bool, optional): Whether to keep the original .xlsx file after conversion.
                                        Defaults to False (Delete the original file).

    Returns:
        Path: The path to the generated PDF file if successful.

    Raises:
        Exception: If the conversion process fails, an exception is raised with an error message.

    Example:
        >>> convert_xlsx_to_pdf(Path("/path/to/excel_file.xlsx"), keep_original=False)
        "/path/to/excel_file.pdf"
    """
    try:
        output_pdf_path = input_xlsx_path.with_suffix(".pdf")
        command = f'libreoffice --headless --convert-to pdf "{input_xlsx_path}" --outdir "{output_pdf_path.parent}"'
        subprocess.run(command, check=True, shell=True)

        # Delete the original file if keep_original is False
        if not keep_original and os.path.exists(input_xlsx_path):
            os.remove(input_xlsx_path)

        return output_pdf_path
    except subprocess.CalledProcessError as e:
        raise Exception(f"Error during PDF conversion: {str(e)}")
