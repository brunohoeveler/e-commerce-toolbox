import calendar

import pandas as pd
import polars as pl

from app.core.config import settings

global monthlast
global monthx


def datev_format(df, bernr, mdtnr, skl, skr, year: int, month: int, text):
    pattern = settings.RESOURCE_DIR / "pattern_datev.csv"
    df_pattern = pd.read_csv(pattern, sep=";", dtype=str, encoding="latin_1")
    df_export = pd.concat([df_pattern, df])
    data_header = df_export.columns.to_list()

    if month == 1:
        monthlast = "31"
        monthx = "01"
    elif month == 2:
        monthlast = "28"
        monthx = "02"
    elif month == 3:
        monthlast = "31"
        monthx = "03"
    elif month == 4:
        monthlast = "30"
        monthx = "04"
    elif month == 5:
        monthlast = "31"
        monthx = "05"
    elif month == 6:
        monthlast = "30"
        monthx = "06"
    elif month == 7:
        monthlast = "31"
        monthx = "07"
    elif month == 8:
        monthlast = "31"
        monthx = "08"
    elif month == 9:
        monthlast = "30"
        monthx = "09"
    elif month == 10:
        monthlast = "31"
        monthx = "10"
    elif month == 11:
        monthlast = "30"
        monthx = "11"
    elif month == 12:
        monthlast = "31"
        monthx = "12"

    startyear = str(year) + "0101"
    startmonth = str(year) + monthx + "01"
    endmonth = str(year) + monthx + monthlast
    description = text + " " + str(year) + " " + monthx

    df_export.reset_index(drop=True, inplace=True)
    df_export.loc[-1] = df_export.loc[0]
    df_export.loc[0] = data_header
    df_export.columns.values[0:5] = ["DTVF", "700", "21", "Buchungsstapel", "12"]
    df_export.columns.values[5:10] = ""
    df_export.columns.values[10:17] = [
        bernr,
        mdtnr,
        startyear,
        skl,
        startmonth,
        endmonth,
        description,
    ]
    df_export.columns.values[17] = ""
    df_export.columns.values[18:22] = ["1", "0", "0", "EUR"]
    df_export.columns.values[22:26] = ""
    df_export.columns.values[26] = skr
    df_export.columns.values[27:124] = ""

    return df_export


def get_month_info(month: int, year: int) -> tuple[str, str]:
    month_info = {
        1: ("Januar", "31"),
        2: ("Februar", calendar.isleap(year) and "29" or "28"),
        3: ("März", "31"),
        4: ("April", "30"),
        5: ("Mai", "31"),
        6: ("Juni", "30"),
        7: ("Juli", "31"),
        8: ("August", "31"),
        9: ("September", "30"),
        10: ("Oktober", "31"),
        11: ("November", "30"),
        12: ("Dezember", "31"),
    }

    month_name, days = month_info[month]

    return month_name, days


def export_csv(df, sep, path):
    csv_content = df.write_csv(separator=sep)
    csv_content_latin1 = csv_content.encode("iso-8859-1", errors="replace")
    path.write(csv_content_latin1)


def datev_export_polars(df, buffer, bernr, mdtnr, year: int, month: int, skl, skr, text):
    pattern = settings.RESOURCE_DIR / "pattern_datev.csv"
    df_pattern = pl.read_csv(pattern, separator=";", infer_schema_length=0)
    df_export = pl.concat([df_pattern, df], how="align")
    df_export = df_export.sort(pl.col("datum"))

    month_name, days = get_month_info(month, year)

    description = f"{text} {year} {month:02d}"

    datev_line = f"DTVF;700;21;Buchungsstapel;12;;;;;;{bernr};{mdtnr};{year}0101;{skl};{year}{month:02d}01;{year}{month:02d}{days};{description};;1;0;0;EUR;;;;;{skr}\n"

    export_csv(df=df_export, sep=";", path=buffer)

    buffer.seek(0)

    buffer.write(datev_line.encode("iso-8859-1") + buffer.getvalue())

    buffer.seek(0)

    return buffer

def datev_export_polars_year(df, buffer, bernr, mdtnr, year, month, skl, skr):
    pattern = settings.RESOURCE_DIR / "pattern_datev.csv"
    df_pattern = pl.read_csv(pattern,
                             separator=';', infer_schema_length=0)
    df_export = pl.concat([df_pattern, df], how='align')
    df_export = df_export.sort(pl.col('datum'))

    datev_line = ("DTVF;700;21;Buchungsstapel;12;;;;;;" + bernr + ";" + mdtnr + ";" + year + "0101;" + skl + ";"
                  + year + month + "01;" + year + "12" + "31" + ";" + "Import" +
                  ";;1;0;0;EUR;;;;;" + skr + "\n")

    export_csv(df=df_export, sep=";", path=buffer)

    buffer.seek(0)

    buffer.write(datev_line.encode('iso-8859-1') + buffer.getvalue())

    buffer.seek(0)

    return buffer