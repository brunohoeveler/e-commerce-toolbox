import io
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.shared import Inches, Pt, RGBColor
import plotly.graph_objects as go

def replace_table(docu, df, placeholder):
    for paragraph in docu.paragraphs:
        if placeholder in paragraph.text:
            # Delete Placeholder
            paragraph.clear()

            # Table
            table = docu.add_table(rows=1, cols=len(df.columns))
            table.style = 'Table Grid'

            # Header
            hdr_cells = table.rows[0].cells
            for i, column_name in enumerate(df.columns):
                hdr_cells[i].text = column_name
                run = hdr_cells[i].paragraphs[0].runs[0]
                run.font.bold = True
                if placeholder == "[table_raus_grund]":
                    run.font.size = Pt(12)

            # DataSets
            for row in df.iter_rows(named=True):
                row_cells = table.add_row().cells
                for i, (column_name, value) in enumerate(row.items()):
                    row_cells[i].text = str(value)
                    run = row_cells[i].paragraphs[0].runs[0]
                    if placeholder == "[table_raus_grund]":
                        run.font.size = Pt(9)  # Set data font size
                    if row_cells[i].text == 'Extern:':
                        run.font.bold = True  # Make "Extern:" bold
                    if row_cells[i].text == 'None':
                        row_cells[i].text = "0"
                if "Abteilung" in df.columns:
                    # Styling row with "Durchschnitt" in "Abteilung"
                    abteilung_index = df.columns.index("Abteilung")  # Find the index of the "Abteilung" column
                    abteilung_cell = row_cells[abteilung_index]
                    if abteilung_cell.text == "Durchschnitt":
                        # Make the "Durchschnitt" row bold and red
                        for cell in row_cells:
                            for run in cell.paragraphs[0].runs:
                                run.font.bold = True
                                run.font.color.rgb = RGBColor(255, 0, 0)  # Red text

                        # Style "Krankheitsquote" in the same row (red and underlined)
                        krankheitsquote_index = df.columns.index("Krankheitsquote")  # Find the index of the "Krankheitsquote" column
                        krankheitsquote_cell = row_cells[krankheitsquote_index]
                        for run in krankheitsquote_cell.paragraphs[0].runs:
                            run.font.color.rgb = RGBColor(255, 0, 0)  # Red text
                            run.font.underline = True  # Underlined

            # Positioning
            paragraph._element.addnext(table._element)

            # Remove the original paragraph that contained the placeholder
            p = paragraph._element
            p.getparent().remove(p)
            p._p = p._element = None


def replace_two_pie_charts_with_table(docu, values1, labels1, values2, labels2, placeholder):
    # Create the first pie chart
    fig1 = go.Figure(data=[go.Pie(labels=labels1, values=values1)])

    # Create the second pie chart
    fig2 = go.Figure(data=[go.Pie(labels=labels2, values=values2)])

    # Save the figures to in-memory file-like objects
    image_stream1 = io.BytesIO()
    fig1.write_image(image_stream1, format="png")  # Save the first chart as an image

    image_stream2 = io.BytesIO()
    fig2.write_image(image_stream2, format="png")  # Save the second chart as an image

    # Rewind to the beginning of the image streams
    image_stream1.seek(0)
    image_stream2.seek(0)

    # Loop through paragraphs and find the placeholder
    for paragraph in docu.paragraphs:
        if placeholder in paragraph.text:
            # Delete the placeholder text
            paragraph.text = ""

            # Insert a 1x2 table (1 row, 2 columns)
            table = docu.add_table(rows=1, cols=2)
            # table.style = 'No Border'

            # Insert the first pie chart into the left cell (first column)
            cell1 = table.cell(0, 0)
            paragraph1 = cell1.paragraphs[0]
            paragraph1.alignment = WD_PARAGRAPH_ALIGNMENT.LEFT
            run1 = paragraph1.add_run()
            run1.add_picture(image_stream1, width=Inches(2.5), height=Inches(2))  # Adjust the size as needed

            # Insert the second pie chart into the right cell (second column)
            cell2 = table.cell(0, 1)
            paragraph2 = cell2.paragraphs[0]
            paragraph2.alignment = WD_PARAGRAPH_ALIGNMENT.RIGHT
            run2 = paragraph2.add_run()
            run2.add_picture(image_stream2, width=Inches(2.5), height=Inches(2))  # Adjust the size as needed

            paragraph._element.addnext(table._element)

    return docu


def replace_pie_chart(docu, values, labels, placeholder):
    fig = go.Figure(data=[go.Pie(labels=labels, values=values, textinfo='value')])

    # Save the figure to an in-memory file-like object
    image_stream = io.BytesIO()
    fig.write_image(image_stream, format="png")  # Ensure kaleido is installed

    image_stream.seek(0)  # Rewind to the beginning

    # Open the Word document

    # Replace placeholder with the image
    for paragraph in docu.paragraphs:
        if placeholder in paragraph.text:
            # Replace placeholder text with an empty run
            paragraph.text = ""

            # Center align the paragraph
            paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
            height = 3.0
            width = height * 1.4
            # Add the image to the paragraph
            run = paragraph.add_run()
            run.add_picture(image_stream, width=Inches(width), height=Inches(height))  # Maintain aspect ratio

    return docu


def replace_bar_chart(docu, values, labels, placeholder):
    fig = go.Figure(data=[go.Bar(
        x=labels, y=values,
        text=values,
        textposition='auto',
    )])
    fig.update_traces(marker_color='#d32743')
    # Save the figure to an in-memory file-like object
    image_stream = io.BytesIO()
    fig.write_image(image_stream, format="png")  # Ensure kaleido is installed
    image_stream.seek(0)  # Rewind to the beginning

    # Open the Word document

    # Replace placeholder with the image
    for paragraph in docu.paragraphs:
        if placeholder in paragraph.text:
            # Replace placeholder text with an empty run
            paragraph.text = ""

            # Center align the paragraph
            paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
            height = 3.0
            width = height * 1.4
            # Add the image to the paragraph
            run = paragraph.add_run()
            run.add_picture(image_stream, width=Inches(width), height=Inches(height))  # Maintain aspect ratio

    return docu


def replace_value(docu, value, placeholder):
    for paragraph in docu.paragraphs:
        if placeholder in paragraph.text:
            paragraph.text = paragraph.text.replace(placeholder, str(value))
    return docu


def replace_title(docu, value, placeholder):
    for paragraph in docu.paragraphs:
        if placeholder in paragraph.text:
            # Rebuild the paragraph text from runs
            full_text = ''.join(run.text for run in paragraph.runs)
            updated_text = full_text.replace(placeholder, value)

            # Clear the runs and recreate them
            for run in paragraph.runs:
                run.text = ''  # Clear existing run text

            # Add updated text back with formatting
            new_run = paragraph.add_run(updated_text)
            new_run.font.size = Pt(18)
            new_run.font.color.rgb = RGBColor(206, 20, 51)  # Red color
    return docu
