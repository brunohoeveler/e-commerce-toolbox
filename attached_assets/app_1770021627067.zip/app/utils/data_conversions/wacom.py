import re
import pdfplumber
import polars as pl
from datetime import datetime

targets = [
    "WACOM##BULLETIN##",
    "Salaire de base",
    "Sous total Salaire de base",
    "Total des cotisations et contributions",
    "Indemnité Home office",
    "Allocation Forfaitaire Télé-Travail",
    "Impôt sur le revenu prélevé à",
    "Net payé",
    "Complément salaire de référence",
]


def extract_last_number(line: str) -> float:
    pattern = r"[-+]?\d{1,3}(?:\s\d{3})*(?:\.\d+)?|[-+]?\d+(?:\.\d+)?"
    matches = re.findall(pattern, line)
    if not matches:
        raise ValueError(f"Keine Zahl gefunden in: {line!r}")
    return float(matches[-1].replace(" ", ""))


def extract_two_numbers(line: str):
    pattern = r"[-+]?\d{1,3}(?:\s\d{3})*(?:\.\d+)?|[-+]?\d+(?:\.\d+)?"
    matches = re.findall(pattern, line)
    if len(matches) < 2:
        raise ValueError(f"Nicht genügend Zahlen gefunden in: {line!r}")
    return float(matches[0].replace(" ", "")), float(matches[1].replace(" ", ""))


# --------------------------
# PDF Parser
# --------------------------
def parse_pdf(pdf_path):
    filtered_lines = []

    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            if not text:
                continue
            for line in text.split("\n"):
                for target in targets:
                    if line.strip().startswith(target):
                        if "Sous total Salaire de base" in line.strip():
                            filtered_lines.append(line.strip())
                            break
                        if "Salaire de base" in line.strip() and "Sous total Salaire de base" not in [f_line.strip() for f_line in filtered_lines]:
                            filtered_lines.append(line.strip())
                            break
                        if target not in ["Sous total Salaire de base", "Salaire de base"]:
                            filtered_lines.append(line.strip())
                            break

    result = {
        "vorname": None,
        "nachname": None,
        "base_salary": None,
        "refund": None,
        "homeoffice": 0.0,
        "soc_sec_employer": None,
        "soc_sec_employee": None,
        "income_tax": None,
        "net_salary": None,
    }

    for raw_line in filtered_lines:
        line = raw_line.strip().strip('"').strip()

        if line.startswith("WACOM##BULLETIN##"):
            parts = line.split("##")
            if len(parts) >= 6:
                result["nachname"] = parts[4]
                result["vorname"] = parts[5]
            continue

        if "salaire de base" in line.lower() or "sous total salaire de base" in line.lower():
            try:
                result["base_salary"] = extract_last_number(line)
            except ValueError:
                pass
            continue

        if "indemnité home office" in line.lower():
            try:
                result["homeoffice"] += extract_last_number(line)
            except ValueError:
                pass
            continue

        if "allocation forfaitaire télé-travail" in line.lower():
            try:
                result["homeoffice"] += extract_last_number(line)
            except ValueError:
                pass
            continue

        if line.lower().startswith("impôt sur le revenu prélevé à"):
            try:
                result["income_tax"] = extract_last_number(line)
            except ValueError:
                pass
            continue

        if line.lower().startswith("net payé"):
            try:
                result["net_salary"] = extract_last_number(line)
            except ValueError:
                pass
            continue

        if line.lower().startswith("total des cotisations et contributions"):
            try:
                soc_sec_employee, soc_sec_employer = extract_two_numbers(line)
                result["soc_sec_employee"] = soc_sec_employee
                result["soc_sec_employer"] = soc_sec_employer
            except ValueError:
                pass
            continue

        if line.lower().startswith("complément salaire de référence"):
            try:
                result["refund"] = extract_last_number(line)
            except ValueError:
                pass
            continue

    return result


def wacom_sap_converter(df, currency):
    today = datetime.now().strftime("%m%d%Y")

    df = df.with_columns(pl.lit('FG').alias('doc'),
                         pl.lit('1020').alias('company'),
                         pl.lit('1').alias('serial'),
                         pl.lit(currency).alias('currency'),
                         pl.lit(f'{today}').alias('date1'),
                         pl.lit(f'{today}').alias('date2'))

    df_sap = pl.DataFrame(
        {'serial': [''], 'company': [''], 'empty1': [''], 'doc': [''], 'date1': [''], 'date2': [''], 'currency': [''],
         'empty2': [''], 'empty3': [''], 'empty4': [''], 'header': [''], 'empty5': [''], 'sh': [''], 'empty6': [''],
         'account': [''], 'empty7': [''], 'empty8': [''], 'costcenter': [''], 'empty9': [''], 'empty10': [''],
         'amount': [''], 'empty11': [''], 'empty12': [''], 'empty13': [''], 'empty14': [''], 'empty15': [''],
         'empty16': [''], 'text': ['']})

    df_sap = pl.concat([df_sap, df], how='align')
    df_sap = df_sap.slice(1)

    return df_sap