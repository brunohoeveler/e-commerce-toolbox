import os
from email.message import EmailMessage

from aiosmtplib import SMTP


async def send_email(emails: list[EmailMessage]):
    smtp = SMTP(hostname=os.environ["EMAIL_HOST"], port=465, use_tls=True)
    try:
        await smtp.connect()
        await smtp.login(os.environ["EMAIL_HOST_LOGIN"], os.environ["EMAIL_HOST_PASSWORD"])

        for email in emails:
            await smtp.send_message(email)

    finally:
        await smtp.quit()

    return
