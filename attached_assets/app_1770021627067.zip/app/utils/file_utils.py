import re
from pathlib import Path
from typing import Optional
from uuid import uuid4

from fastapi import UploadFile

from app.core.config import settings


def generate_unique_filename(original_filename: str) -> str:
    return f"{uuid4().hex}_{original_filename}"


def sanitize_filename(name: str) -> str:
    name = Path(name).name  # drop any path info
    name = re.sub(r"[^\w.\-]", "_", name)  # allow alphanum, dot, dash, underscore
    return name


def save_upload_file(upload_dir: Path, file: UploadFile) -> Path:
    upload_dir.mkdir(parents=True, exist_ok=True)
    safe_name = sanitize_filename(file.filename)
    unique_name = generate_unique_filename(safe_name)

    file_path = upload_dir / unique_name

    with open(file_path, "wb") as f:
        content = file.file.read()
        f.write(content)

    return file_path


def get_safe_path(base: Path, *paths: str) -> Path:
    full_path = (base / Path(*paths)).resolve()
    if not str(full_path).startswith(str(base.resolve())):
        raise ValueError("Unsafe path access attempt")
    return full_path


def strip_hex_prefix(name: str) -> str:
    """
    Strips the UUID prefix and optional task suffix.
    Example: abc123_report_processed_xyz123.xlsx → report.xlsx
    """
    name = Path(name).name
    name = re.sub(r"^[a-f0-9]{32}_", "", name)  # remove UUID prefix
    name = re.sub(r"_processed_[a-f0-9\-]+(?=\.\w+$)", "", name)  # remove task ID
    return name


def strip_task_id(name: str) -> str:
    """
    Strips the task ID (UUIDv4) suffix from the filename.
    Example: report_12345678-1234-5678-1234-567812345678.xlsx → report.xlsx
    """
    name = Path(name).name
    name = re.sub(r"_[a-f0-9\-]{36}(?=\.\w+$)", "", name)  # remove task ID
    return name


def generate_output_path(
    user_id: str,
    data_conversion: str,
    conversion: str,
    task_id: str,
    extension: str,
    datev: bool = False,
    year: Optional[int] = None,
    month: Optional[int] = None,
) -> Path:
    output_dir = Path(settings.RESULT_DIR) / user_id / data_conversion / conversion

    if datev:
        output_filename = f"DTVF_{data_conversion}_{conversion}_{year}_{month}_{task_id}.{extension}"
    elif month is not None and year is not None:
        output_filename = f"{data_conversion}_{conversion}_{year}_{month}_{task_id}.{extension}"
    elif month is not None:
        output_filename = f"{data_conversion}_{conversion}_{month}_{task_id}.{extension}"
    elif year is not None:
        output_filename = f"{data_conversion}_{conversion}_{year}_{task_id}.{extension}"
    else:
        output_filename = f"{data_conversion}_{conversion}_{task_id}.{extension}"

    return output_dir / output_filename


def generate_tool_output_path(user_id: str, tool: str, variant: str, task_id: str, extension: str, filename: Optional[str] = None) -> Path:
    output_dir = Path(settings.RESULT_DIR) / user_id / tool / variant

    if filename is not None:
        sanitized_name = sanitize_filename(filename)
        output_filename = f"{sanitized_name}_{task_id}.{extension}"
    else:
        output_filename = f"{tool}_{variant}_{task_id}.{extension}"

    return output_dir / output_filename


def generate_output_path_datev(
    user_id: str,
    data_conversion: str,
    conversion: str,
    year: int,
    month: int,
    task_id: str,
    extension: str,
) -> Path:
    output_dir = Path(settings.RESULT_DIR) / user_id / data_conversion / conversion
    output_filename = f"DTVF_{data_conversion}_{conversion}_{year}_{month}_{task_id}.{extension}"

    return output_dir / output_filename


def ensure_output_folder(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)


def delete_input_files(paths: list[Path]):
    for p in paths:
        try:
            Path(p).unlink(missing_ok=True)
        except Exception as e:
            print(f"Failed to delete {p}: {e}")
