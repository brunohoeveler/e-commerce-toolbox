from celery import Celery

from app.core.config import settings

celery_app = Celery("worker", broker=settings.CELERY_BROKER_URL, backend=settings.CELERY_RESULT_BACKEND)

celery_app.conf.update(
    task_track_started=True,
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    result_extended=True,
    result_expires=60 * 60 * 24 * 365,  # 1 year
    broker_connection_retry_on_startup=True,
    broker_transport_options={"global_keyprefix": "celery:"},
    result_backend_transport_options={"global_keyprefix": "celery:"},
    include=["app.core.signals"],
)

# Load task modules
import app.tasks.process_task  # noqa
