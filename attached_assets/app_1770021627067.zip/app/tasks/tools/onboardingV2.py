"""
Onboarding V2 Processor
-----------------------
Verarbeitet die FormData vom Onboarding-Tool und erstellt ein strukturiertes
Word-Dokument, das per E-Mail versendet wird.
"""

import asyncio
import json
import os
import tempfile
from datetime import datetime
from email.message import EmailMessage
from typing import Any

from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

from app.core.logger import logger
from app.tasks.tool_registry import register_tool
from app.utils.email_utils import send_email


# ==================== KONFIGURATION ====================

# E-Mail-Empfänger (für Tests: julian.michalak@ecovis-kso.com)
RECIPIENT_EMAIL = "julian.michalak@ecovis-kso.com"

# Mapping von FormData-Keys zu lesbaren deutschen Labels
FIELD_LABELS: dict[str, str] = {
    # Mandantendaten
    "mandantName": "Mandantenname",
    "mandantId": "Mandantennummer",
    "mandantGroup": "Mandantengruppe",
    "mandantAddress": "Adresse",
    "mandantSwitch": "Mandant ist Verbraucher",
    
    # Ansprechpartner
    "contactPerson1Name": "Name Ansprechpartner 1",
    "contactPerson1Email": "E-Mail Ansprechpartner 1",
    "contactPerson1Mobilnummer": "Mobilnummer Ansprechpartner 1",
    "contactPerson2Name": "Name Ansprechpartner 2",
    "contactPerson2Email": "E-Mail Ansprechpartner 2",
    "contactPerson2Mobilnummer": "Mobilnummer Ansprechpartner 2",
    "contactPerson3Name": "Name Ansprechpartner 3",
    "contactPerson3Email": "E-Mail Ansprechpartner 3",
    "contactPerson3Mobilnummer": "Mobilnummer Ansprechpartner 3",
    "contactPerson4Name": "Name Ansprechpartner 4",
    "contactPerson4Email": "E-Mail Ansprechpartner 4",
    "contactPerson4Mobilnummer": "Mobilnummer Ansprechpartner 4",
    "contactPerson5Name": "Name Ansprechpartner 5",
    "contactPerson5Email": "E-Mail Ansprechpartner 5",
    "contactPerson5Mobilnummer": "Mobilnummer Ansprechpartner 5",
    
    # Sprachen
    "vDeutsch": "Vergütungsvereinbarung: Deutsch",
    "vEnglisch": "Vergütungsvereinbarung: Englisch",
    "vChinesisch": "Vergütungsvereinbarung: Chinesisch",
    "aDeutsch": "Auftragsanlage: Deutsch",
    "aEnglisch": "Auftragsanlage: Englisch",
    
    # Compliance
    "isInternationalCompliance": "Internationales Compliance-Mandat",
    "isInternationalOrigin": "Internationale Mandatsherkunft",
    "herkunftsland": "Herkunftsland",
    "kanzlei": "Kanzlei",
    
    # Global Fee
    "isGlobalFee": "Gesamtpauschale vereinbart",
    "isGlobalFeeFibu": "Finanzbuchführung in Gesamtpauschale",
    "isGlobalFeeLobu": "Lohnbuchhaltung in Gesamtpauschale",
    "isGlobalFeeJa": "Jahresabschluss in Gesamtpauschale",
    "isGlobalFeeOperationalTaxes": "Betriebliche Steuererklärungen in Gesamtpauschale",
    "isGlobalFeeIncomeTax": "Einkommensteuer in Gesamtpauschale",
    "isGlobalFeeTaxConsulting": "Steuerliche Beratung in Gesamtpauschale",
    "isGlobalFeeLegalAdvice": "Rechtsberatung in Gesamtpauschale",
    "gobalFee": "Gesamtpauschalbetrag",
    
    # Finanzbuchführung
    "fibuVJ": "Fibu: Ab VJ",
    "fibuMonth": "Fibu: Monat",
    "fibuRythm": "Fibu: Abrechnungsrhythmus",
    "fibuArt": "Fibu: Abrechnungsart",
    "fibuHonorar": "Fibu: Honorar",
    "fibuSatz": "Fibu: Satz in Zehntel",
    
    # Lohnbuchhaltung
    "lobuVJ": "Lobu: Ab VJ",
    "lobuMonth": "Lobu: Monat",
    "lobuRythm": "Lobu: Abrechnungsrhythmus",
    "lobuArt": "Lobu: Abrechnungsart",
    "lobuHonorar": "Lobu: Honorar",
    
    # Jahresabschluss
    "jaVJ": "JA: Ab VJ",
    "jaRythm": "JA: Abrechnungsrhythmus",
    "jaArt": "JA: Abrechnungsart",
    "jaPlanumsatz": "JA: Planumsatz",
    "jaPlanstunden": "JA: Planstunden pro Jahr",
    "jaHonorar": "JA: Honorar",
    "isEuer": "EÜR statt Jahresabschluss",
    
    # Betriebliche Steuererklärungen
    "bseVJ": "BSE: Ab VJ",
    "bseArt": "BSE: Abrechnungsart",
    "bsePlanumsatz": "BSE: Planumsatz",
    "bsePlanstunden": "BSE: Planstunden pro Jahr",
    "bseHonorar": "BSE: Honorar",
    
    # Einkommensteuer
    "hasPartnerInfo": "Angaben zum Ehe-/Lebenspartner",
    "partnerName": "Name Ehe-/Lebenspartner",
    "partnerMobil": "Mobilnummer Partner",
    "partnerEmail": "E-Mail Partner",
    "estVJ": "ESt: Ab VJ",
    "estArt": "ESt: Abrechnungsart",
    "estPlanumsatz": "ESt: Planumsatz",
    "estPlanstunden": "ESt: Planstunden pro Jahr",
    "estHonorar": "ESt: Honorar",
    
    # Steuerliche Beratung
    "sbVJ": "SB: Ab VJ",
    "sbRythm": "SB: Abrechnungsrhythmus",
    "sbArt": "SB: Abrechnungsart",
    "sbPlanumsatz": "SB: Planumsatz",
    "sbPlanstunden": "SB: Planstunden pro Jahr",
    "sbHonorar": "SB: Honorar",
    
    # Rechtsberatung
    "isEinzelfall": "Konkreter Einzelfall",
    "rbEinzelfallBeschreibung": "Beschreibung Einzelfall",
    "hasVollmacht": "DocuSign-Vollmacht",
    "vollmachtName": "Vollmacht: Name",
    "vollmachtBeschreibung": "Mandatsgegenstand",
    "rbVJ": "RB: Ab VJ",
    "rbRythm": "RB: Abrechnungsrhythmus",
    "rbArt": "RB: Abrechnungsart",
    "rbHonorar": "RB: Honorar",
    
    # Betreuungspauschale
    "bpVJ": "BP: Ab VJ",
    "bpMonat": "BP: Monat",
    "bpHonorar": "BP: Honorar",
    
    # Akontozahlungen
    "hasAkonto": "Akontozahlungen vereinbart",
    "akonto_ab_monat": "Akonto: Ab Monat",
    "akonto_betrag": "Akonto: Betrag",
    "ja_hasAkonto": "JA: Monatliche Akontozahlung",
    "ja_akonto_ab_monat": "JA Akonto: Ab Monat",
    "ja_akonto_betrag": "JA Akonto: Betrag",
    "ja_ablehnungsgrund": "JA Akonto: Ablehnungsgrund",
    
    # Onboarding-Pauschale
    "hasOnboardingFee": "Onboarding-Pauschale",
    "onboarding_type": "Onboarding-Pauschale Typ",
    "onboarding_custom": "Individuelle Onboarding-Pauschale",
    
    # Auslagen
    "auslagen_option": "Auslagen für Post/Telekommunikation",
    
    # Zuständigkeiten
    "niederlassung": "Zuständige Niederlassung",
    "zustaendig_partner": "Zuständig: Partner",
    "zustaendig_mandatsverantwortlichkeit": "Zuständig: Mandatsverantwortlichkeit",
    "zustaendig_finanzbuchfuehrung": "Zuständig: Finanzbuchführung",
    "zustaendig_lohnbuchhaltung": "Zuständig: Lohnbuchhaltung",
    "zustaendig_jahresabschluss": "Zuständig: Jahresabschluss",
    "zustaendig_betriebliche_steuererklaerungen": "Zuständig: Betriebliche Steuererklärungen",
    "zustaendig_einkommensteuer": "Zuständig: Einkommensteuer",
    "zustaendig_steuerliche_beratung": "Zuständig: Steuerliche Beratung",
    "zustaendig_betreuungspauschale": "Zuständig: Betreuungspauschale",
    "zustaendig_rechtsberatung": "Zuständig: Rechtsberatung",
    "zustaendig_beratungspakete": "Zuständig: Beratungspakete",
    
    # Spezielle Beratung
    "hasSpezielleBeratung": "Spezielle Beratung",
    "spezielle_beratung_auftrag": "Spezielle Beratung: Auftrag",
    "spezielle_beratung_zustaendigkeit": "Spezielle Beratung: Zuständigkeit",
    
    # Sonstiges
    "sonstige_hinweise": "Sonstige Hinweise",
}

# Kategorien für die Gruppierung der Felder im Dokument
FIELD_CATEGORIES: dict[str, list[str]] = {
    "Mandantendaten": [
        "mandantName", "mandantId", "mandantGroup", "mandantAddress", "mandantSwitch"
    ],
    "Ansprechpartner": [
        "contactPerson1Name", "contactPerson1Email", "contactPerson1Mobilnummer",
        "contactPerson2Name", "contactPerson2Email", "contactPerson2Mobilnummer",
        "contactPerson3Name", "contactPerson3Email", "contactPerson3Mobilnummer",
        "contactPerson4Name", "contactPerson4Email", "contactPerson4Mobilnummer",
        "contactPerson5Name", "contactPerson5Email", "contactPerson5Mobilnummer",
    ],
    "Sprachen": [
        "vDeutsch", "vEnglisch", "vChinesisch", "aDeutsch", "aEnglisch"
    ],
    "Compliance & Mandatsherkunft": [
        "isInternationalCompliance", "isInternationalOrigin", "herkunftsland", "kanzlei"
    ],
    "Gesamtpauschale": [
        "isGlobalFee", "isGlobalFeeFibu", "isGlobalFeeLobu", "isGlobalFeeJa",
        "isGlobalFeeOperationalTaxes", "isGlobalFeeIncomeTax", "isGlobalFeeTaxConsulting",
        "isGlobalFeeLegalAdvice", "gobalFee"
    ],
    "Finanzbuchführung": [
        "fibuVJ", "fibuMonth", "fibuRythm", "fibuArt", "fibuHonorar", "fibuSatz"
    ],
    "Lohnbuchhaltung": [
        "lobuVJ", "lobuMonth", "lobuRythm", "lobuArt", "lobuHonorar"
    ],
    "Jahresabschluss": [
        "jaVJ", "jaRythm", "jaArt", "jaPlanumsatz", "jaPlanstunden", "jaHonorar", "isEuer"
    ],
    "Betriebliche Steuererklärungen": [
        "bseVJ", "bseArt", "bsePlanumsatz", "bsePlanstunden", "bseHonorar"
    ],
    "Einkommensteuer": [
        "hasPartnerInfo", "partnerName", "partnerMobil", "partnerEmail",
        "estVJ", "estArt", "estPlanumsatz", "estPlanstunden", "estHonorar"
    ],
    "Steuerliche Beratung": [
        "sbVJ", "sbRythm", "sbArt", "sbPlanumsatz", "sbPlanstunden", "sbHonorar"
    ],
    "Rechtsberatung": [
        "isEinzelfall", "rbEinzelfallBeschreibung", "hasVollmacht", "vollmachtName",
        "vollmachtBeschreibung", "rbVJ", "rbRythm", "rbArt", "rbHonorar"
    ],
    "Betreuungspauschale": [
        "bpVJ", "bpMonat", "bpHonorar"
    ],
    "Akontozahlungen": [
        "hasAkonto", "akonto_ab_monat", "akonto_betrag",
        "ja_hasAkonto", "ja_akonto_ab_monat", "ja_akonto_betrag", "ja_ablehnungsgrund"
    ],
    "Onboarding-Pauschale": [
        "hasOnboardingFee", "onboarding_type", "onboarding_custom"
    ],
    "Auslagen": [
        "auslagen_option"
    ],
    "Zuständigkeiten": [
        "niederlassung", "zustaendig_partner", "zustaendig_mandatsverantwortlichkeit",
        "zustaendig_finanzbuchfuehrung", "zustaendig_lohnbuchhaltung", "zustaendig_jahresabschluss",
        "zustaendig_betriebliche_steuererklaerungen", "zustaendig_einkommensteuer",
        "zustaendig_steuerliche_beratung", "zustaendig_betreuungspauschale",
        "zustaendig_rechtsberatung", "zustaendig_beratungspakete"
    ],
    "Spezielle Beratung": [
        "hasSpezielleBeratung", "spezielle_beratung_auftrag", "spezielle_beratung_zustaendigkeit"
    ],
    "Sonstige Hinweise": [
        "sonstige_hinweise"
    ],
}


# ==================== HELPER FUNCTIONS ====================

def format_value(value: Any) -> str:
    """Formatiert einen Wert für die Anzeige im Dokument."""
    if value is None:
        return "-"
    if isinstance(value, bool):
        return "Ja" if value else "Nein"
    if isinstance(value, list):
        return ", ".join(str(v) for v in value)
    return str(value)


def get_label(key: str) -> str:
    """Gibt das deutsche Label für einen Key zurück."""
    if key in FIELD_LABELS:
        return FIELD_LABELS[key]
    
    # Dynamische Keys (z.B. Service-Inputs)
    prefixes = {
        "lobuServiceInputs_": "Lobu-Service: ",
        "jaStandardServiceInputs_": "JA-Service: ",
        "jaGwServiceInputs_": "JA-GW-Service: ",
        "euerServiceInputs_": "EÜR-Service: ",
        "bseGwServiceInputs_": "BSE-Service: ",
        "estGwServiceInputs_": "ESt-Service: ",
        "sbZeitServiceInputs_": "SB-Stundensatz: ",
        "rbZeitServiceInputs_": "RB-Stundensatz: ",
        "beratungspaket_": "Beratungspaket: ",
    }
    
    for prefix, label_prefix in prefixes.items():
        if key.startswith(prefix):
            return label_prefix + key.replace(prefix, "")
    
    return key


def categorize_form_data(form_data: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Kategorisiert die FormData in Sektionen."""
    categorized: dict[str, dict[str, Any]] = {}
    processed_keys: set[str] = set()
    
    # Bekannte Kategorien durchgehen
    for category, keys in FIELD_CATEGORIES.items():
        category_data: dict[str, Any] = {}
        for key in keys:
            if key in form_data and form_data[key] not in [None, "", [], False]:
                category_data[key] = form_data[key]
                processed_keys.add(key)
        if category_data:
            categorized[category] = category_data
    
    # Service-Inputs dynamisch kategorisieren
    service_categories = {
        "Lohnbuchhaltung - Leistungen": "lobuServiceInputs_",
        "Jahresabschluss - Standard-Leistungen": "jaStandardServiceInputs_",
        "Jahresabschluss - GW-Leistungen": "jaGwServiceInputs_",
        "EÜR - Leistungen": "euerServiceInputs_",
        "Betriebliche Steuererklärungen - Leistungen": "bseGwServiceInputs_",
        "Einkommensteuer - Leistungen": "estGwServiceInputs_",
        "Steuerliche Beratung - Stundensätze": "sbZeitServiceInputs_",
        "Rechtsberatung - Stundensätze": "rbZeitServiceInputs_",
    }
    
    for category_name, prefix in service_categories.items():
        category_data = {}
        for key, value in form_data.items():
            if key.startswith(prefix) and value not in [None, "", []]:
                category_data[key] = value
                processed_keys.add(key)
        if category_data:
            categorized[category_name] = category_data
    
    # Beratungspakete
    beratungspakete_data = {}
    for key, value in form_data.items():
        if key.startswith("beratungspaket_") and value not in [None, "", []]:
            beratungspakete_data[key] = value
            processed_keys.add(key)
    if beratungspakete_data:
        categorized["Beratungspakete"] = beratungspakete_data
    
    # Nicht kategorisierte Felder
    uncategorized = {}
    for key, value in form_data.items():
        if key not in processed_keys and value not in [None, "", [], False]:
            uncategorized[key] = value
    if uncategorized:
        categorized["Weitere Angaben"] = uncategorized
    
    return categorized


# ==================== DOCUMENT CREATION ====================

def create_word_document(data: dict[str, Any]) -> str:
    """
    Erstellt ein Word-Dokument aus den FormData.
    
    Returns:
        Pfad zur erstellten Word-Datei
    """
    form_data = data.get("formData", {})
    orders = data.get("orders", [])
    services = data.get("services", {})
    
    doc = Document()
    
    # Styles anpassen
    title_style = doc.styles['Title']
    title_style.font.size = Pt(24)
    title_style.font.bold = True
    title_style.font.color.rgb = RGBColor(0, 51, 102)
    
    heading1_style = doc.styles['Heading 1']
    heading1_style.font.size = Pt(16)
    heading1_style.font.bold = True
    heading1_style.font.color.rgb = RGBColor(0, 102, 153)
    
    heading2_style = doc.styles['Heading 2']
    heading2_style.font.size = Pt(12)
    heading2_style.font.bold = True
    heading2_style.font.color.rgb = RGBColor(51, 51, 51)
    
    # Titel
    title = doc.add_heading('Onboarding-Dokumentation', 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # Datum und Mandanteninfo
    doc.add_paragraph()
    info_para = doc.add_paragraph()
    info_para.add_run(f"Erstellt am: {datetime.now().strftime('%d.%m.%Y um %H:%M Uhr')}")
    info_para.add_run("\n")
    
    mandant_name = form_data.get("mandantName", "Unbekannt")
    mandant_id = form_data.get("mandantId", "-")
    info_para.add_run(f"Mandant: {mandant_name} (Nr. {mandant_id})")
    
    doc.add_paragraph()
    
    # Ausgewählte Aufträge
    if orders:
        doc.add_heading("Ausgewählte Aufträge", level=1)
        orders_para = doc.add_paragraph()
        for order in orders:
            orders_para.add_run(f"• {order}\n")
    
    doc.add_paragraph()
    
    # Kategorisierte FormData
    categorized = categorize_form_data(form_data)
    
    for category, fields in categorized.items():
        if not fields:
            continue
            
        doc.add_heading(category, level=1)
        
        table = doc.add_table(rows=1, cols=2)
        table.style = 'Table Grid'
        
        header_cells = table.rows[0].cells
        header_cells[0].text = "Feld"
        header_cells[1].text = "Wert"
        
        for cell in header_cells:
            for paragraph in cell.paragraphs:
                for run in paragraph.runs:
                    run.bold = True
        
        for key, value in fields.items():
            row = table.add_row()
            row.cells[0].text = get_label(key)
            row.cells[1].text = format_value(value)
        
        doc.add_paragraph()
    
    # Ausgewählte Services
    if services:
        doc.add_heading("Ausgewählte Leistungen", level=1)
        
        service_name_map = {
            "lobuServices": "Lohnbuchhaltung",
            "jaStandardServices": "Jahresabschluss - Standard",
            "jaGwServices": "Jahresabschluss - Gegenstandswert",
            "euerServices": "EÜR",
            "bseGwServices": "Betriebliche Steuererklärungen",
            "estGwServices": "Einkommensteuer",
            "sbZeitServices": "Steuerliche Beratung",
            "rbZeitServices": "Rechtsberatung",
        }
        
        for service_key, service_list in services.items():
            if not service_list:
                continue
            
            service_title = service_name_map.get(service_key, service_key)
            doc.add_heading(service_title, level=2)
            
            services_para = doc.add_paragraph()
            for service in service_list:
                services_para.add_run(f"• {service}\n")
    
    # Speichern
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    mandant_clean = "".join(c for c in mandant_name if c.isalnum() or c in " -_")[:30]
    filename = f"Onboarding_{mandant_clean}_{timestamp}.docx"
    
    temp_dir = tempfile.gettempdir()
    filepath = os.path.join(temp_dir, filename)
    
    doc.save(filepath)
    logger.info(f"📄 Word-Dokument erstellt: {filepath}")
    
    return filepath


# ==================== EMAIL CREATION ====================

def create_onboarding_email(data: dict[str, Any], attachment_path: str) -> EmailMessage:
    """Erstellt die E-Mail an das Onboarding-Team mit Anhang."""
    form_data = data.get("formData", {})
    orders = data.get("orders", [])
    
    mandant_name = form_data.get("mandantName", "Unbekannt")
    mandant_id = form_data.get("mandantId", "-")
    niederlassung = form_data.get("niederlassung", "-")
    
    orders_html = "".join(f"<li>{order}</li>" for order in orders)
    
    html_body = f"""
    <html>
    <head>
        <style>
            body {{ font-family: Arial, sans-serif; color: #333; }}
            .header {{ background-color: #003366; color: white; padding: 20px; }}
            .content {{ padding: 20px; }}
            .info-box {{ background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin: 10px 0; }}
            .orders-list {{ list-style-type: none; padding: 0; }}
            .orders-list li {{ padding: 5px 0; }}
            .orders-list li:before {{ content: "✓ "; color: #006633; }}
            .footer {{ background-color: #f0f0f0; padding: 15px; font-size: 12px; color: #666; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>Neues Onboarding-Formular eingegangen</h1>
        </div>
        <div class="content">
            <div class="info-box">
                <h2>Mandanteninformationen</h2>
                <p><strong>Mandant:</strong> {mandant_name}</p>
                <p><strong>Mandantennummer:</strong> {mandant_id}</p>
                <p><strong>Niederlassung:</strong> {niederlassung}</p>
            </div>
            <h2>Ausgewählte Aufträge</h2>
            <ul class="orders-list">{orders_html}</ul>
            <p>Die vollständigen Details finden Sie im angehängten Word-Dokument.</p>
        </div>
        <div class="footer">
            <p>Diese E-Mail wurde automatisch vom Onboarding-Tool generiert.</p>
        </div>
    </body>
    </html>
    """
    
    email_msg = EmailMessage()
    email_msg["From"] = os.environ["EMAIL_SENDER"]
    email_msg["To"] = RECIPIENT_EMAIL
    email_msg["Subject"] = f"Neues Onboarding: {mandant_name} (Nr. {mandant_id}) - {datetime.now().strftime('%d.%m.%Y')}"
    
    email_msg.set_content(f"Neues Onboarding für {mandant_name} (Nr. {mandant_id})")
    email_msg.add_alternative(html_body, subtype="html")
    
    # Anhang hinzufügen
    if os.path.exists(attachment_path):
        with open(attachment_path, 'rb') as f:
            file_data = f.read()
            email_msg.add_attachment(
                file_data,
                maintype='application',
                subtype='vnd.openxmlformats-officedocument.wordprocessingml.document',
                filename=os.path.basename(attachment_path)
            )
    
    return email_msg


def create_confirmation_email(data: dict[str, Any], user_name: str, user_email: str, attachment_path: str) -> EmailMessage:
    """Erstellt die Bestätigungs-E-Mail für den Absender."""
    form_data = data.get("formData", {})
    orders = data.get("orders", [])
    
    mandant_name = form_data.get("mandantName", "Unbekannt")
    mandant_id = form_data.get("mandantId", "-")
    orders_html = "".join(f"<li>{order}</li>" for order in orders)
    
    # Extrahiere Vornamen aus user_name (Format: "Nachname, Vorname")
    name_parts = user_name.split(",", 1)
    display_name = name_parts[1].strip() if len(name_parts) > 1 else user_name
    
    html_body = f"""
    <html>
    <head>
        <style>
            body {{ font-family: Arial, sans-serif; color: #333; }}
            .header {{ background-color: #006633; color: white; padding: 20px; }}
            .content {{ padding: 20px; }}
            .success-box {{ background-color: #e8f5e9; padding: 15px; border-radius: 5px; 
                           border-left: 4px solid #4caf50; margin: 10px 0; }}
            .info-box {{ background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin: 10px 0; }}
            .footer {{ background-color: #f0f0f0; padding: 15px; font-size: 12px; color: #666; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>✓ Onboarding erfolgreich übermittelt</h1>
        </div>
        <div class="content">
            <div class="success-box">
                <p>Hallo {display_name},</p>
                <p>Dein Onboarding-Formular wurde erfolgreich an das Onboarding-Team übermittelt.</p>
            </div>
            <div class="info-box">
                <h2>Zusammenfassung</h2>
                <p><strong>Mandant:</strong> {mandant_name}</p>
                <p><strong>Mandantennummer:</strong> {mandant_id}</p>
                <p><strong>Übermittelt am:</strong> {datetime.now().strftime('%d.%m.%Y um %H:%M Uhr')}</p>
            </div>
            <h3>Ausgewählte Aufträge</h3>
            <ul>{orders_html}</ul>
            <p>Das vollständige Dokument findest du im Anhang dieser E-Mail.</p>
        </div>
        <div class="footer">
            <p>Bei Fragen: onboarding@ecovis-kso.com</p>
        </div>
    </body>
    </html>
    """
    
    email_msg = EmailMessage()
    email_msg["From"] = os.environ["EMAIL_SENDER"]
    email_msg["To"] = user_email
    email_msg["Subject"] = f"Bestätigung: Onboarding {mandant_name} übermittelt"
    
    email_msg.set_content(f"Bestätigung: Onboarding für {mandant_name} wurde übermittelt.")
    email_msg.add_alternative(html_body, subtype="html")
    
    # Anhang hinzufügen
    if os.path.exists(attachment_path):
        with open(attachment_path, 'rb') as f:
            file_data = f.read()
            email_msg.add_attachment(
                file_data,
                maintype='application',
                subtype='vnd.openxmlformats-officedocument.wordprocessingml.document',
                filename=os.path.basename(attachment_path)
            )
    
    return email_msg


# ==================== MAIN TOOL FUNCTION ====================

@register_tool(
    tool="onboarding_v2",
    variant="default",
    description="Onboarding V2 - Verarbeitet Onboarding-Formulardaten und sendet E-Mail mit Word-Dokument",
    input_type={
        "json_data": str,
    },
    output_type="email",
)
def onboarding_v2(task, json_data: str):
    """
    Hauptfunktion zur Verarbeitung der Onboarding-Daten.
    Wird automatisch aufgerufen, wenn das Frontend einen Submit sendet.
    
    Args:
        task: Celery Task mit Request-Headers (user_id, user_name, user_email)
        json_data: JSON-String mit formData, orders und services
        
    Returns:
        Dictionary mit Status und Informationen
    """
    user_id = task.request.headers.get("user_id")
    user_name = task.request.headers.get("user_name", "")
    user_email = task.request.headers.get("user_email", "")
    
    try:
        data = json.loads(json_data)
        
        logger.info(f"📋 Onboarding V2 - Daten empfangen:")
        logger.info(f"  - Aufträge: {data.get('orders', [])}")
        logger.info(f"  - FormData-Keys: {len(data.get('formData', {}))}")
        logger.info(f"  - User: {user_name} ({user_email})")
        
        # Word-Dokument erstellen
        doc_path = create_word_document(data)
        
        # E-Mails erstellen
        emails_to_send = []
        
        # E-Mail an Onboarding-Team (julian.michalak@ecovis-kso.com für Tests)
        onboarding_email = create_onboarding_email(data, doc_path)
        emails_to_send.append(onboarding_email)
        
        # Bestätigungs-E-Mail an Absender
        if user_email:
            confirm_email = create_confirmation_email(data, user_name, user_email, doc_path)
            emails_to_send.append(confirm_email)
        
        # E-Mails senden
        logger.info(f"📧 Sende E-Mail an {RECIPIENT_EMAIL}")
        asyncio.run(send_email(emails_to_send))
        
        mandant_name = data.get("formData", {}).get("mandantName", "Unbekannt")
        mandant_id = data.get("formData", {}).get("mandantId", "-")
        
        logger.info(f"✅ Onboarding V2 erfolgreich verarbeitet für {mandant_name}")
        
        return {
            "message": "Onboarding erfolgreich verarbeitet",
            "file_name": f"{mandant_name}_{mandant_id}",
            "user_id": user_id
        }
        
    except Exception as e:
        logger.exception(f"❌ Fehler bei Onboarding V2 Verarbeitung: {e}")
        raise e
