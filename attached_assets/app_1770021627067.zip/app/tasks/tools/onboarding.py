import asyncio
import json
import os
from email.message import EmailMessage
from pathlib import Path

import docx
import docx.oxml as oxml
from lxml import etree

from app.core.config import settings
from app.core.logger import logger
from app.tasks.tool_registry import register_tool
from app.utils.email_utils import send_email
from app.utils.file_utils import ensure_output_folder, generate_tool_output_path, strip_task_id


def mache_abfrage(frage, geblockt) -> str:
    if geblockt:
        return "//"
    return str(input(frage))


def waehle_auftrag(frage):
    a = input(frage.lower())
    if a == "ja":
        return True
    if a == "nein":
        return False
    if a == "j":
        return True
    if a == "n":
        return False


def create_email(
    attachment: Path,
    cc: str,
    name: str,

) -> EmailMessage:
    email_message_user = EmailMessage()
    email_message_user["From"] = os.environ["EMAIL_SENDER"]
    email_message_user["To"] = [os.environ["EMAIL_RECEIVER_ONBOARDING"]]
    email_message_user["Cc"] = [cc]
    subject = "Onboarding-Fragebogen " + name
    body = "Hi,\n\nanbei befindet sich der ausgefüllte Onboarding-Fragebogen.\n\nViele Grüße\nTeam Software-Solutions"
    email_message_user["Subject"] = subject
    html_body = html_body = f"""
    <html>
      <head>
        <style>
          body {{
            font-family: Calibri, sans-serif;
            font-size: 11pt;
          }}
        </style>
      </head>
      <body>
        <p>Hi,<br><br>
        
        anbei befindet sich der ausgefüllte Onboarding-Fragebogen.<br><br>
        
        <b style="color:red;">Diese Mail wird automatisch erstellt. Bitte nicht auf diese Mail antworten! <br></b>
        Bei Fragen, Anmerkungen und Ergänzungen bitte direkt an das Onboarding-Team wenden: 
        
        Viele Grüße<br>
        Team Software-Solutions
        </p>
      </body>
    </html>
    """
    email_message_user.set_content(body)
    email_message_user.add_alternative(html_body, subtype="html")

    with open(attachment, "rb") as file:
        email_message_user.add_attachment(
            file.read(),
            maintype="application",
            subtype="docx",
            filename=subject + ".docx",
        )

    return email_message_user


def create_confirm_mail(recipient: str, data: dict) -> EmailMessage:
    email_message_confirm = EmailMessage()
    email_message_confirm["From"] = os.environ["EMAIL_SENDER"]
    email_message_confirm["To"] = [recipient]
    auftrag = f"{data["mandant_name"], data["mandant_nr"]}"
    subject = f"Onboarding-Tool Auftragsanlage: {auftrag}"
    email_message_confirm["Subject"] = subject

    content_fallback = (
        f"Hallo,\n\nder Auftrag: {auftrag} wurde über das Onboarding-Tool angelegt.\n"
    )

    if data["0"]["isChecked"]: #Fibu
        fibu = (f"<b>Fibu Auftrag</b> {data["FibuRythmus"]}, ab: {data["fibu_monat"]} {data["fibu_jahr"]}\n"
                   )
    else:
        fibu = "Keine Auftragsanlage für Fibu ausgewählt."


    if data["1"]["isChecked"]: #Lobu
        lobu = (f"<b>Lohn Auftrag</b> {data["LobuRythmus"]}, ab: {data["lobu_monat"]} {data["lobu_jahr"]}\n"
                )
    else:
        lobu = "Keine Auftragsanlage für Lohn ausgewählt."


    content = f"""
    <html>
      <body>
        <p>Hallo,</p>

        <p>
          der Auftrag: <strong>{auftrag}</strong> wurde über das Onboarding-Tool angelegt.
          <br>
        </p>
        <br>
        <br>
        <p>
        <strong>Mandant: </strong>{data["mandant_name"]}
        <br>
        <strong>Mandantennummer: </strong>{data["mandant_nr"]}
        <br>
        <strong>Mandant: </strong>{data["mandant_name"]}
        <br>
        <strong>Email: </strong>{data["email_ansprechpartner"]}
        <br>
        <strong>Telefon: </strong>{data["mobilnr_docusign"]} 
        </p>
        <br>
        <br>
        {fibu}
        <br>
        <br>
        {lobu}
                <p>
          <em>Viele Grüße<br></em>
          <em>Team Softwareentwicklung</em>

        </p>
      </body>
    </html>
    """

    email_message_confirm.set_content(content_fallback)
    email_message_confirm.add_alternative(content, subtype="html")

    return email_message_confirm


@register_tool(
    tool="Onboarding",
    variant="default",
    description="Onboarding default conversion",
    input_type={
        "json_data": str,
    },
    output_type="docx",
)
def onboarding(task, json_data: str):
    user_id = task.request.headers.get("user_id")
    user_email = task.request.headers.get("user_email")
    data = json.loads(json_data)

    # -----------------------------------------Input Dictionaries ---------------------------------------------------

    auswahl_auftraege = {
        "fibu": data["0"]["isChecked"],
        "lobu": data["1"]["isChecked"],
        "jahresabschluss": data["2"]["isChecked"],
        "betr_steuern": data["3"]["isChecked"],
        "ek_steuer": data["4"]["isChecked"],
        "steuerliche_beratung": data["5"]["isChecked"],
        "Betreuungspauschale": data["6"]["isChecked"],
        "rechtsberatung": data["7"]["isChecked"],
    }

    if not data["6"]["isChecked"]:
        data["betreuung_jahr"] = "//"
        data["betreuung_monat"] = "//"
        data["betreuung_honorar"] = "//"


    checkbox_beschreibungen = {
        "spezielle_beratung_beschreibung": {"[[spezielle_beratung_beschreibung]]": data["spezielle_beratung_beschreibung"]},
        "herkunft": {"[[ecovis_international_herkunft]]": data["ecovis_international_herkunft"], "[[ecovis_international_kanzlei]]": data["ecovis_international_kanzlei"]},
        "akonto": {"[[akonto_ablehnungsgrund]]": data["akonto_ablehnungsgrund"], "[[akonto_monat]]": data["akonto_monat"], "[[akonto_betrag]]": data["akonto_betrag"]},
        "rechtliche_beratung": {"[[rechtliche_beratung_beschreibung]]": data["rechtliche_beratung_beschreibung"]},
        "docusign_rechtliche_beratung": {
            "[[rechtliche_beratung_anwaltsvollmacht_name]]": data["rechtliche_beratung_anwaltsvollmacht_name"],
            "[[rechtliche_beratung_anwaltsvollmacht_mandatsgegenstand]]": data["rechtliche_beratung_anwaltsvollmacht_mandatsgegenstand"],
        },
        "spezielle_beratung_notwendig": {
            "[[spezielle_beratung_auftrag]]": data["spezielle_beratung_auftrag"],
            "[[spezielle_beratung_zustaendigkeit]]": data["spezielle_beratung_zustaendigkeit"],
        },
    }

    antworten_kontaktdaten = {
        "[[mandant_name]]": data["mandant_name"],
        "[[mandant_nr]]": data["mandant_nr"],
        "[[mandantengruppe]]": data["mandantengruppe"],
        "[[adresse]]": data["adresse"],
        "[[mandant_ansprechpartner]]": data["mandant_ansprechpartner"],
        "[[email_ansprechpartner]]": data["email_ansprechpartner"],
        "[[mobilnr_docusign]]": data["mobilnr_docusign"],
    }
    mandant_verbraucher = data["mandant_gleich_verbraucher_ja"]

    antworten_checkbox_sprache = {
        "[[v_deutsch]]": data["v_deutsch"],
        "[[v_englisch]]": data["v_englisch"],
        "[[v_chinesisch]]": data["v_chinesisch"],
        "[[a_deutsch]]": data["a_deutsch"],
        "[[a_englisch]]": data["a_englisch"],
    }

    international = data["international_ja"]

    antworten_auftragsanlage_abrechnungsgrundlage = {
        "[[fibu_jahr]]": data["fibu_jahr"],
        "[[fibu_monat]]": data["fibu_monat"],
        "[[FibuRythmus]]": data["FibuRythmus"],
        "[[FibuArt]]": data["FibuArt"],
        "[[fibu_honorar]]": data["fibu_honorar"],
        "[[fibu_p_umsatz]]": data["fibu_p_umsatz"],
        "[[fibu_p_stunden]]": data["fibu_p_stunden"],
        "[[lobu_jahr]]": data["lobu_jahr"],
        "[[lobu_monat]]": data["lobu_monat"],
        "[[LobuRythmus]]": data["LobuRythmus"],
        "[[LobuArt]]": data["LobuArt"],
        "[[lobu_honorar]]": data["lobu_honorar"],
        "[[lobu_p_umsatz]]": data["lobu_p_umsatz"],
        "[[lobu_p_stunden]]": data["lobu_p_stunden"],
        "[[jahresabschluss]]": data["jahresabschluss"],
        "[[JahresabschlussRythmus]]": data["JahresabschlussRythmus"],
        "[[JahresabschlussArt]]": data["JahresabschlussArt"],
        "[[jahresabschluss_honorar]]": data["jahresabschluss_honorar"],
        "[[jahresabschluss_p_umsatz]]": data["jahresabschluss_p_umsatz"],
        "[[jahresabschluss_p_stunden]]": data["jahresabschluss_p_stunden"],
        "[[betr_steuern]]": data["betr_steuern"],
        "[[BetrSteuernRythmus]]": data["BetrSteuernRythmus"],
        "[[BetrSteuernArt]]": data["BetrSteuernArt"],
        "[[betr_steuern_honorar]]": data["betr_steuern_honorar"],
        "[[betr_steuern_p_umsatz]]": data["betr_steuern_p_umsatz"],
        "[[betr_steuern_p_stunden]]": data["betr_steuern_p_stunden"],
        "[[ek_steuer]]": data["ek_steuer"],
        "[[EinkommensteuerRythmus]]": data["EinkommensteuerRythmus"],
        "[[EinkommensteuerArt]]": data["EinkommensteuerArt"],
        "[[ek_steuer_honorar]]": data["ek_steuer_honorar"],
        "[[ek_steuer_p_umsatz]]": data["ek_steuer_p_umsatz"],
        "[[ek_steuer_p_stunden]]": data["ek_steuer_p_stunden"],
        "[[steuerliche_beratung]]": data["steuerliche_beratung"],
        "[[SteuerlicheBeratungRythmus]]": data["SteuerlicheBeratungRythmus"],
        "[[SteuerlicheBeratungArt]]": data["SteuerlicheBeratungArt"],
        "[[steuerliche_beratung_honorar]]": data["steuerliche_beratung_honorar"],
        "[[rechtsberatung_jahr]]": data["rechtsberatung_jahr"],
        "[[RechtsberatungRythmus]]": data["RechtsberatungRythmus"],
        "[[betreuung_jahr]]": data["betreuung_jahr"],
        "[[betreuung_monat]]": data["betreuung_monat"],
        "[[betreuung_honorar]]": data["betreuung_honorar"],
        "[[RechtsberatungArt]]": data["RechtsberatungArt"],
        "[[rechtsberatung_honorar]]": data["rechtsberatung_honorar"],
        "[[rechtsberatung_p_umsatz]]": data["rechtsberatung_p_umsatz"],
        "[[rechtsberatung_p_stunden]]": data["rechtsberatung_p_stunden"],
    }

    akonto = data["akonto_ja"]

    rechtliche_beratung = data["rechtliche_beratung_ja"]

    docusign = data["docusign_ja"]

    antworten_zustaendigkeiten = {
        "[[z_partner]]": data["z_partner"],
        "[[z_mandatsverantwortlicher]]": data["z_mandatsverantwortlicher"],
        "[[z_fibu]]": data["z_fibu"],
        "[[z_lobu]]": data["z_lobu"],
        "[[z_jahresabschluss]]": data["z_jahresabschluss"],
        "[[z_betr_steuern]]": data["z_betr_steuern"],
        "[[z_ek_steuer]]": data["z_ek_steuer"],
        "[[z_steuerliche_beratung]]": data["z_steuerliche_beratung"],
        "[[z_rechtliche_beratung]]": data["z_rechtliche_beratung"],
        "[[z_niederlassung]]": data["z_niederlassung"]
    }

    spez_beratung = data["spezielle_beratung_ja"]

    antworten_checkbox_ja_nein = {
        "[[mandant_gleich_verbraucher_ja]]": mandant_verbraucher,
        "[[mandant_gleich_verbraucher_nein]]": not mandant_verbraucher,
        "[[international_ja]]": international,
        "[[international_nein]]": not international,
        "[[akonto_ja]]": akonto,
        "[[akonto_nein]]": not akonto,
        "[[rechtliche_beratung_ja]]": rechtliche_beratung,
        "[[rechtliche_beratung_nein]]": not rechtliche_beratung,
        "[[docusign_ja]]": docusign,
        "[[docusign_nein]]": not docusign,
        "[[spezielle_beratung_ja]]": spez_beratung,
        "[[spezielle_beratung_nein]]": not spez_beratung,
    }

    chosen = data["chosen"]

    if chosen:
        chosenStr = "Onboarding Pauschale vereinbart"
    else:
        chosenStr = "Keine Onboarding Pauschale"

    fibuAkonto = data["fibu_akonto_ja"]


    if fibuAkonto:
        fibuAkontoStr = "Ja."
    else:
        fibuAkontoStr = "Nein."



    additional_data = {
        "[[einzelfall_antwort]]": data["einzelfall_antwort"],
        "[[chosen]]": chosenStr,
        "[[onboarding_pauschale]]": data["onboarding_pauschale"],
        "[[pauschalbetrag]]": data["pauschalbetrag"],
        "[[fibu_satz]]": data["fibu_satz"],
        "[[steuer_partner]]": data["steuer_partner"],
        "[[steuer_berater]]": data["steuer_berater"],
        "[[steuer_fachwirt]]": data["steuer_fachwirt"],
        "[[steuer_fachangestellt]]": data["steuer_fachangestellt"],
        "[[it_spezialist]]": data["it_spezialist"],
        "[[gw_ja]]": data["gw_ja"],
        "[[anhang]]": data["anhang"],
        "[[anlagenbuchhaltung]]": data["anlagenbuchhaltung"],
        "[[koerperschaftserklaerung]]": data["koerperschaftserklaerung"],
        "[[besteuerungsgrundlagen]]": data["besteuerungsgrundlagen"],
        "[[gewerbesteuer]]": data["gewerbesteuer"],
        "[[umsatzsteuer]]": data["umsatzsteuer"],
        "[[offenlegung_ja]]": data["offenlegung_ja"],
        "[[e_bilanz]]": data["e_bilanz"],
        "[[finanzamt]]": data["finanzamt"],
        "[[finanzamt_betrieblich": data["finanzamt_betrieblich"],
        "[[bescheidpruefung]]": data["bescheidpruefung"],
        "[[lohnkonten_4an]]": data["lohnkonten_4an"],
        "[[lohnkonten_ab5]]": data["lohnkonten_ab5"],
        "[[wiederholungsabrechnungen]]": data["wiederholungsabrechnungen"],
        "[[neueinrichtung]]": data["neueinrichtung"],
        "[[austritt]]": data["austritt"],
        "[[antrag_mutterschaft]]": data["antrag_mutterschaft"],
        "[[a1_bescheinigung]]": data["a1_bescheinigung"],
        "[[ecovis_cloud]]": data["ecovis_cloud"],
        "[[eau]]": data["eau"],
        "[[weiterer_unterzeichner]]": data["weiterer_unterzeichner"],
        "[[email_weiterer_unterzeichner]]": data["email_weiterer_unterzeichner"],
        "[[mobil_weiterer_unterzeichner]]": data["mobil_weiterer_unterzeichner"],
        "[[an_range]]": data["an_range"],
        "[[name2]]": data["name2"],
        "[[email2]]": data["email2"],
        "[[name3]]": data["name3"],
        "[[email3]]": data["email3"],
        "[[name4]]": data["name4"],
        "[[email4]]": data["email4"],
        "[[name5]]": data["name5"],
        "[[email5]]": data["email5"],
        "[[auslagen]]": data["auslagen"],
        "[[mobil2]]": data["mobil2"],
        "[[mobil3]]": data["mobil3"],
        "[[mobil4]]": data["mobil4"],
        "[[mobil5]]": data["mobil5"],
        "[[fibu_akonto_ja]]": fibuAkontoStr,
        "[[fibu_akonto_betrag]]": data["fibu_akonto_betrag"],
        "[[fibu_akonto_monat]]": data["fibu_akonto_monat"],
        "[[recht_partner]]": data["recht_partner"],
        "[[ra]]": data["ra"],
        "[[ra_fachangestellt]]": data["ra_fachangestellt"],
        "[[azubi]]": data["azubi"],
        "[[wissenschaftliche]]": data["wissenschaftliche"],
        "[[gesamtpauschale_monat]]": data["gesamtpauschale_monat"],
        "[[gesamtpauschalbetrag]]": data["gesamtpauschalbetrag"],
        "[[gesamtpauschale_sonstiges]]": data["gesamtpauschale_sonstiges"],

        "[[mantelbogen]]": data["mantelbogen"],
        "[[nicht_selbststaendig]]": data["nicht_selbststaendig"],
        "[[kapitalvermoegen]]": data["kapitalvermoegen"],
        "[[vermietung-verpachtung]]": data["vermietung_verpachtung"],
        "[[sonstige_einkuenfte]]": data["sonstige_einkuenfte"],
        "[[gw_eur]]": data["gw_eur"],
    }

    # ------------------------------------------------------------------------------------------------------------

    doc = docx.Document(settings.RESOURCE_DIR / "fragebogen.docx")
    docx_xml = doc._element.xml
    root = etree.fromstring(docx_xml)

    # Namespace-Definition
    namespaces = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main", "w14": "http://schemas.microsoft.com/office/word/2010/wordml"}

    # XPath-Abfrage, um alle Checkboxen zu finden
    root.xpath("//w:sdt//w14:checkbox", namespaces=namespaces)

    def add_input_checkbox_content_control(paragraph, checked):
        paragraph_tag = paragraph._element
        sdt = oxml.shared.OxmlElement("w:sdt")
        sdt_props = oxml.shared.OxmlElement("w:sdtPr")

        w_checkbox = oxml.shared.OxmlElement("w14:checkbox")
        w_checked = oxml.shared.OxmlElement("w14:checked")
        w_checked.set(oxml.ns.qn("w14:val"), "1" if checked else "0")
        w_checked_state = oxml.shared.OxmlElement("w14:checkedState")
        w_checked_state.set(oxml.ns.qn("w14:font"), "MS Gothic")
        w_checked_state.set(oxml.ns.qn("w14:val"), "2612")  # unicode value for box with x in it

        w_unchecked_state = oxml.shared.OxmlElement("w14:uncheckedState")
        w_unchecked_state.set(oxml.ns.qn("w14:font"), "MS Gothic")
        w_unchecked_state.set(oxml.ns.qn("w14:val"), "2610")  # unicode value for empty box

        w_checkbox.append(w_checked)
        w_checkbox.append(w_checked_state)
        w_checkbox.append(w_unchecked_state)
        sdt_props.append(w_checkbox)

        sdt_content = oxml.shared.OxmlElement("w:sdtContent")
        sdt_content_run = oxml.OxmlElement("w:r")
        # the box doesn't appear until clicked, so a default unicode box will need to be set as a placeholder
        sdt_content_run.text = "\u2612" if checked else "\u2610"
        sdt_content.append(sdt_content_run)

        sdt.append(sdt_props)
        sdt.append(sdt_content)
        paragraph_tag.append(sdt)

    def ersetze_zellen(eingaben):
        for platzhalter, antwort in eingaben.items():
            if platzhalter in cell.text:
                cell.text = cell.text.replace(platzhalter, antwort)

    def ersetze_text(eingaben, zusatzeingabe):
        for platzhalter, antwort in eingaben.items():
            if platzhalter in p.text:
                p.text = p.text.replace(platzhalter, zusatzeingabe + antwort)

    def ersetze_durch_leer_wenn_keine_antwort_notwendig(eingaben):
        for auftrag, auswahl_getaetigt in auswahl_auftraege.items():
            if not auswahl_getaetigt:
                for platzhalter in eingaben.keys():
                    if auftrag in platzhalter:
                        eingaben[platzhalter] = "//"

                        print(platzhalter, eingaben[platzhalter])

    ersetze_durch_leer_wenn_keine_antwort_notwendig(antworten_auftragsanlage_abrechnungsgrundlage)
    ersetze_durch_leer_wenn_keine_antwort_notwendig(antworten_zustaendigkeiten)

    def ersetze_checkbox_beschreibungen(eingabe_dict, beschreibung_notwendig, GETSTRING):
        for platzhalter, antwort in eingabe_dict.items():
            if "beschreibung" in platzhalter and antwort != "//" and not beschreibung_notwendig:
                eingabe_dict[platzhalter] = "//"
            if "beschreibung" in platzhalter and beschreibung_notwendig:
                eingabe_dict[platzhalter] = GETSTRING

    if antworten_checkbox_ja_nein["[[international_nein]]"]:
        checkbox_beschreibungen["herkunft"]["[[ecovis_international_herkunft]]"] = "//"
        checkbox_beschreibungen["herkunft"]["[[ecovis_international_kanzlei]]"] = "//"

    if antworten_checkbox_ja_nein["[[international_ja]]"]:
        checkbox_beschreibungen["herkunft"]["[[ecovis_international_herkunft]]"] = data["ecovis_international_herkunft"]  # GET
        checkbox_beschreibungen["herkunft"]["[[ecovis_international_kanzlei]]"] = data["ecovis_international_kanzlei"]  # GET
    if antworten_checkbox_ja_nein["[[rechtliche_beratung_nein]]"]:
        antworten_zustaendigkeiten["[[z_rechtliche_beratung]]"] = "//"
        ersetze_checkbox_beschreibungen(checkbox_beschreibungen["rechtliche_beratung"], False, "")
        checkbox_beschreibungen["docusign_rechtliche_beratung"]["[[rechtliche_beratung_anwaltsvollmacht_name]]"] = "//"
        checkbox_beschreibungen["docusign_rechtliche_beratung"]["[[rechtliche_beratung_anwaltsvollmacht_mandatsgegenstand]]"] = "//"

    if antworten_checkbox_ja_nein["[[rechtliche_beratung_ja]]"]:
        ersetze_checkbox_beschreibungen(checkbox_beschreibungen["rechtliche_beratung"], True, "")
    if antworten_checkbox_ja_nein["[[docusign_ja]]"]:
        checkbox_beschreibungen["docusign_rechtliche_beratung"]["[[rechtliche_beratung_anwaltsvollmacht_name]]"] = data["rechtliche_beratung_anwaltsvollmacht_name"]  # GET
        checkbox_beschreibungen["docusign_rechtliche_beratung"]["[[rechtliche_beratung_anwaltsvollmacht_mandatsgegenstand]]"] = data["rechtliche_beratung_anwaltsvollmacht_mandatsgegenstand"]  # GET
    if antworten_checkbox_ja_nein["[[docusign_nein]]"]:
        checkbox_beschreibungen["docusign_rechtliche_beratung"]["[[rechtliche_beratung_anwaltsvollmacht_name]]"] = "//"
        checkbox_beschreibungen["docusign_rechtliche_beratung"]["[[rechtliche_beratung_anwaltsvollmacht_mandatsgegenstand]]"] = "//"
    if antworten_checkbox_ja_nein["[[spezielle_beratung_nein]]"]:
        checkbox_beschreibungen["spezielle_beratung_notwendig"]["[[spezielle_beratung_auftrag]]"] = "//"
        checkbox_beschreibungen["spezielle_beratung_notwendig"]["[[spezielle_beratung_zustaendigkeit]]"] = "//"
        ersetze_checkbox_beschreibungen(checkbox_beschreibungen["spezielle_beratung_notwendig"], False, "Lorem")
    if antworten_checkbox_ja_nein["[[spezielle_beratung_ja]]"]:
        checkbox_beschreibungen["spezielle_beratung_notwendig"]["[[spezielle_beratung_auftrag]]"] = data["spezielle_beratung_auftrag"]
        checkbox_beschreibungen["spezielle_beratung_notwendig"]["[[spezielle_beratung_zustaendigkeit]]"] = data["spezielle_beratung_zustaendigkeit"]
        ersetze_checkbox_beschreibungen(checkbox_beschreibungen["spezielle_beratung_notwendig"], True, "Lorem")

    if antworten_checkbox_ja_nein["[[akonto_nein]]"]:
        checkbox_beschreibungen["akonto"]["[[akonto_ablehnungsgrund]]"] = data["akonto_ablehnungsgrund"]  # GET FUNKTION EINGABE
        checkbox_beschreibungen["akonto"]["[[akonto_monat]]"] = "//"
        checkbox_beschreibungen["akonto"]["[[akonto_betrag]]"] = "//"

    if antworten_checkbox_ja_nein["[[akonto_ja]]"]:
        checkbox_beschreibungen["akonto"]["[[akonto_ablehnungsgrund]]"] = "//"
        checkbox_beschreibungen["akonto"]["[[akonto_monat]]"] = data["akonto_monat"]  # GET
        checkbox_beschreibungen["akonto"]["[[akonto_betrag]]"] = data["akonto_betrag"]  # GET4

    for p in doc.paragraphs:
        ersetze_text(checkbox_beschreibungen["akonto"], "*Begründung: ")
        ersetze_text(antworten_kontaktdaten, "")
        ersetze_text(additional_data, "")
        ersetze_text(checkbox_beschreibungen["rechtliche_beratung"], "")
        ersetze_text(checkbox_beschreibungen["spezielle_beratung_beschreibung"], "")
        ersetze_text(checkbox_beschreibungen["spezielle_beratung_notwendig"], "")
        ersetze_text(checkbox_beschreibungen["docusign_rechtliche_beratung"], "")

    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                ersetze_zellen(antworten_kontaktdaten)
                ersetze_zellen(antworten_zustaendigkeiten)
                ersetze_zellen(antworten_auftragsanlage_abrechnungsgrundlage)
                ersetze_zellen(checkbox_beschreibungen["spezielle_beratung_notwendig"])
                ersetze_zellen(checkbox_beschreibungen["akonto"])
                ersetze_zellen(checkbox_beschreibungen["herkunft"])

    def check_checkboxen(platzhalter1, a_ja, platzhalter2, a_nein):
        if platzhalter1 in p.text:
            # Text in Abschnitte aufteilen
            parts = p.text.split(platzhalter1)
            p.text = parts[0]  # Erster Teil ohne Platzhalter

            # Checkbox für "Ja" hinzufügen
            add_input_checkbox_content_control(p, a_ja)
            p.add_run(" Ja")  # Text "Ja" hinter der ersten Checkbox hinzufügen

            # Überprüfen, ob weiterer Text oder der zweite Platzhalter existiert
            if len(parts) > 1:
                remaining_text = parts[1].split(platzhalter2)
                if len(remaining_text) > 0:
                    p.add_run(" " + remaining_text[0])  # Text vor der nächsten Checkbox

                # Checkbox für "Nein" hinzufügen
                add_input_checkbox_content_control(p, a_nein)
                p.add_run(" Nein")  # Text "Nein" hinter der zweiten Checkbox hinzufügen

                if len(remaining_text) > 1:
                    p.add_run(" " + remaining_text[1])  # Restlichen Text hinzufügen

    checkbox_indizes = list(antworten_checkbox_ja_nein.keys())
    for p in doc.paragraphs:
        for i in range(0, len(checkbox_indizes)):
            if i % 2 == 0:
                key1 = checkbox_indizes[i]
                key2 = checkbox_indizes[i + 1]
                antwort1 = antworten_checkbox_ja_nein.get(key1)
                antwort2 = antworten_checkbox_ja_nein.get(key2)
                check_checkboxen(key1, antwort1, key2, antwort2)

        # ------- Checkboxen mit anderen Antwortoptionen als Ja und Nein
        if "[[a_deutsch]]" in p.text:
            parts = p.text.split("[[a_deutsch]]")
            p.text = parts[0]

            add_input_checkbox_content_control(p, antworten_checkbox_sprache["[[a_deutsch]]"])
            p.add_run(" deutsch")

            if len(parts) > 1:
                remaining_text = parts[1].split("[[a_englisch]]")
                if len(remaining_text) > 0:
                    p.add_run(" " + remaining_text[0])

                add_input_checkbox_content_control(p, antworten_checkbox_sprache["[[a_englisch]]"])
                p.add_run(" englisch")

                if len(remaining_text) > 1:
                    p.add_run(" " + remaining_text[1])

        if "[[v_deutsch]]" in p.text:
            parts = p.text.split("[[v_deutsch]]")
            p.text = parts[0]

            add_input_checkbox_content_control(p, antworten_checkbox_sprache["[[v_deutsch]]"])
            p.add_run(" deutsch")

            if len(parts) > 1:
                remaining_text = parts[1].split("[[v_englisch]]")
                p.add_run(" " + remaining_text[0])

                add_input_checkbox_content_control(p, antworten_checkbox_sprache["[[v_englisch]]"])
                p.add_run(" englisch")

                if len(remaining_text) > 1:
                    final_text = remaining_text[1].split("[[v_chinesisch]]")
                    p.add_run(" " + final_text[0])

                    add_input_checkbox_content_control(p, antworten_checkbox_sprache["[[v_chinesisch]]"])
                    p.add_run(" chinesisch")

                    if len(final_text) > 1:
                        p.add_run(" " + final_text[1])

    # Übernimm das XML zurück in das docx-Element und speichere
    doc._element = root

    # Build output path
    output_path = generate_tool_output_path(
        user_id=user_id,
        tool="Onboarding",
        variant="default",
        task_id=task.request.id,
        extension="docx",
    )

    ensure_output_folder(output_path)

    doc.save(output_path.__str__())

    try:
        logger.info("📧 Sending email to onboarding-kso@ecovis.com")
        email_user = create_email(
            attachment=output_path,
            cc=user_email,
            name=data["mandant_name"],
        )
        #if data["0"]["isChecked"] or data["1"]["isChecked"]:
            #   confirm_email_user = create_confirm_mail(recipient="kso-rechnung@ecovis-kso.com", data=data)
            #   asyncio.run(send_email([email_user, confirm_email_user]))
            #   return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
        #else:
        asyncio.run(send_email([email_user]))
        return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
    except Exception as e:
        logger.exception(f"❌ Failed to send email to {data['email_ansprechpartner']} - Error: {e}")
        raise e


