import asyncio
import os
import tempfile
from email.message import EmailMessage
from pathlib import Path
from typing import Optional

import fitz
from dotenv import load_dotenv
from fastapi import UploadFile
from PyPDF2 import PdfMerger

from app.core.config import settings
from app.core.logger import logger
from app.tasks.tool_registry import register_tool
from app.utils.email_utils import send_email
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_tool_output_path, strip_task_id

load_dotenv()


def create_email(
    attachment: Path,
    user_email: str,
    teamleader: str,
) -> tuple[EmailMessage, EmailMessage]:
    """
    Create email messages for the user and HR department.
    :param attachment: Path to the attachment file.
    :param user_email: Email address of the user.
    :param teamleader: Name of the team leader.
    :return: Tuple of EmailMessage objects for the user and HR department.
    """
    email_message_user = EmailMessage()
    email_message_user["From"] = os.environ["EMAIL_SENDER"]
    email_message_user["To"] = [user_email]
    subject = "Kostenerstattungsantrag Kopie"
    body = "Guten Tag,\n\nanbei ist eine Kopie des abgesendeten Kostenerstattungsantrag.\n\nMit freundlichen Grüßen,\nIhre Ecovis KSO"
    email_message_user["Subject"] = subject
    email_message_user.set_content(body)

    # Add attachment
    with open(attachment, "rb") as file:
        email_message_user.add_attachment(
            file.read(),
            maintype="application",
            subtype="pdf",
            filename="Kostenerstattungsantrag_Kopie.pdf",
        )
    email_hr = os.environ["EMAIL_RECEIVER_HR"]
    email_message_hr = EmailMessage()
    email_message_hr["From"] = os.environ["EMAIL_SENDER"]
    email_message_hr["To"] = [email_hr]
    subject = "Neuer Kostenerstattungsantrag"
    body = (
        "Guten Tag,\n\nanbei finden Sie einen neu gestellten Kostenerstattungsantrag. \n"
        "Der Name der Teamleitung, welche die Erstattung genehmigen muss, lautet:\n" + teamleader + "\n\nMit freundlichen Grüßen,\nIhre Ecovis KSO"
    )
    email_message_hr["Subject"] = subject
    email_message_hr.set_content(body)

    # Add attachment
    with open(attachment, "rb") as file:
        email_message_hr.add_attachment(
            file.read(),
            maintype="application",
            subtype="pdf",
            filename="Kostenerstattungsantrag.pdf",
        )

    return email_message_user, email_message_hr


@register_tool(
    tool="Kostenerstattung",
    variant="default",
    description="Default Kostenerstattung",
    input_type={
        "name": (str, {"description": "Name of the user"}),
        "teamleader": (str, {"description": "Name of the team leader"}),
        "reason": (str, {"description": "Reason for the request"}),
        "amount": (str, {"description": "Amount in EUR"}),
        "mail": (str, {"description": "Email address"}),
        "employee_number": (str, {"description": "Employee number"}),
        "other": (Optional[str], {"description": "Other information"}),
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "extensions": ["pdf"],
            },
        ),
    },
    output_type="pdf",
)
def kostenerstattung(
    task,
    name: str,
    teamleader: str,
    reason: str,
    amount: str,
    mail: str,
    employee_number: str,
    other: Optional[str],
    files: list[Path],
):
    user_id = task.request.headers.get("user_id")
    user_email = task.request.headers.get("user_email")

    formdata = {
        "NAME": name,
        "TL_NAME": teamleader,
        "REASON": reason,
        "AMOUNT": amount,
        "MAIL": mail,
        "USER_NUMBER": employee_number,
        "OTHER": other,
    }

    # Load the PDF document
    pdf_document = fitz.open(settings.RESOURCE_DIR / "Kostenerstattungsantrag_Muster.pdf")

    # Replace placeholders in the document
    for page_num in range(pdf_document.page_count):
        page = pdf_document[page_num]
        for placeholder, replacement in formdata.items():
            search_text = f"[{placeholder}]"
            search_text_instances = page.search_for(search_text)
            for inst in search_text_instances:
                # Use the bounding box of the placeholder to overwrite the text
                bbox = inst[:4]  # Get the bounding box of the text
                # Draw a white rectangle to hide the placeholder
                page.draw_rect(bbox, color=(1, 1, 1), fill=(1, 1, 1))
                # Insert the replacement text at the same location

                final_text = []

                # Split replacement into multiple lines if necessary
                max_chars_per_line = 70
                if replacement:
                    while len(replacement) > max_chars_per_line:
                        split_index = replacement.rfind(" ", 0, max_chars_per_line)
                        if split_index == -1:
                            split_index = max_chars_per_line
                        final_text.append(replacement[:split_index])
                        replacement = replacement[split_index:].lstrip()
                    final_text.append(replacement)  # Append the remaining text

                line_height = 12  # Adjust line height as needed
                for i, line in enumerate(final_text):
                    text_position = (bbox[0], bbox[1] + i * line_height)
                    page.insert_text(text_position, line, fontsize=11)

    temp_pdf = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf").name

    # Combine all the PDFs
    pdf_document.save(temp_pdf)
    pdf_document.close()
    merger = PdfMerger()
    merger.append(temp_pdf)
    for file in files:
        merger.append(file)

    # Clean up
    for temp_file in [temp_pdf]:
        if os.path.exists(temp_file):
            os.remove(temp_file)

    output_path = generate_tool_output_path(
        user_id=user_id,
        filename=f"Kostenerstattungsantrag_{name}.pdf",
        tool="Kostenerstattung",
        variant="default",
        task_id=task.request.id,
        extension="pdf",
    )

    ensure_output_folder(output_path)

    # Save the merged PDF to the output path
    merger.write(output_path)
    merger.close()

    delete_input_files(files)

    try:
        logger.info(f"📧 Sending email to {user_email}")
        email_user, email_hr = create_email(
            attachment=output_path,
            user_email=user_email,
            teamleader=teamleader,
        )
        asyncio.run(send_email([email_user, email_hr]))
        return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
    except Exception as e:
        logger.exception(f"❌ Failed to send email to {user_email} - Error: {e}")
        raise e
