import io
import re
import zipfile
from datetime import datetime
from pathlib import Path

import fitz
from fastapi import UploadFile

from app.tasks.tool_registry import register_tool
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_tool_output_path, strip_task_id


@register_tool(
    tool="Rechnung-Umbenennung",
    variant="default",
    description="Default Rechnung-Umbenennung",
    input_type={
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "extensions": ["pdf"],
            },
        ),
    },
    output_type="zip",
)
def recruiting(task, files: list[Path]):
    user_id = task.request.headers.get("user_id")

    def extract_info_for_rename(text):
        lines = text.splitlines()
        for i, line in enumerate(lines):
            if line.strip() == "RECHNUNG" and i + 1 < len(lines):
                next_line = lines[i + 1].strip()
                if next_line:
                    if next_line[0].isdigit():
                        next_line = "NR-" + next_line
                    return next_line.replace(" ", "-") + ".pdf"

            if line.strip().startswith("Rechnung") and i + 1 < len(lines):
                match = re.search(r"rechnung\s+(\d+)", line, re.IGNORECASE)
                if match:
                    next_line = lines[i + 1].strip()
                    return "NR-" + match.group(1) + "-" + next_line + ".pdf"

        # Fallback if nothing is found
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"Rechnung_{timestamp}.pdf"

    zip_buffer = io.BytesIO()

    with zipfile.ZipFile(zip_buffer, "w") as zipf:
        for file in files:
            if not file.name.lower().endswith(".pdf"):
                raise ValueError(f"File {file.name} is not a PDF.")

            try:
                doc = fitz.open(file)
                first_page_text = doc[0].get_text()
                new_name = extract_info_for_rename(first_page_text)
                pdf_bytes = doc.write()
                zipf.writestr(new_name, pdf_bytes)
                doc.close()
            except Exception as e:
                print(f"Failed to process {file}: {e}")

    zip_buffer.seek(0)

    # ========================== SAVE ZIP TO DISK ==========================
    output_path = generate_tool_output_path(
        user_id=user_id,
        filename="Rechnungen_Umbenannt",
        tool="Rechnung-Umbenennung",
        variant="default",
        task_id=task.request.id,
        extension="zip",
    )

    ensure_output_folder(output_path)

    with open(output_path, "wb") as f:
        f.write(zip_buffer.getvalue())

    # Clean up input files
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
