import asyncio
import os
from datetime import datetime
from email.message import EmailMessage
from pathlib import Path

import pymupdf
from fastapi import UploadFile

from app.core.logger import logger
from app.tasks.tool_registry import register_tool
from app.utils.conversion_utils import convert_xlsx_to_pdf
from app.utils.email_utils import send_email
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_tool_output_path, strip_task_id


def create_email(
    attachment: Path,
    user_email: str,
    teamleader: str,
) -> tuple[EmailMessage, EmailMessage]:
    """
    Create email messages for the user and HR department.
    :param attachment: Path to the attachment file.
    :param user_email: Email address of the user.
    :param teamleader: Name of the team leader.
    :return: Tuple of EmailMessage objects for the user and HR department.
    """
    email_message_user = EmailMessage()
    email_message_user["From"] = os.environ["EMAIL_SENDER"]
    email_message_user["To"] = [user_email]
    subject = "Reisekostenerstattungsantrag Kopie"
    body = "Guten Tag,\n\nanbei ist eine Kopie des abgesendeten Reisekostenerstattungsantrag.\n\nMit freundlichen Grüßen,\nIhre Ecovis KSO"
    email_message_user["Subject"] = subject
    email_message_user.set_content(body)

    # Add attachment
    with open(attachment, "rb") as file:
        email_message_user.add_attachment(
            file.read(),
            maintype="application",
            subtype="pdf",
            filename="Reisekostenerstattungsantrag_Kopie.pdf",
        )
    email_hr = os.environ["EMAIL_RECEIVER_HR"]
    email_message_hr = EmailMessage()
    email_message_hr["From"] = os.environ["EMAIL_SENDER"]
    email_message_hr["To"] = [email_hr]
    subject = "Neuer Reisekostenerstattungsantrag"
    body = (
        "Guten Tag,\n\nanbei finden Sie einen neu gestellten Reisekostenerstattungsantrag. \n"
        "Der Name der Teamleitung, welche die Erstattung genehmigen muss, lautet:\n" + teamleader + "\n\nMit freundlichen Grüßen,\nIhre Ecovis KSO"
    )
    email_message_hr["Subject"] = subject
    email_message_hr.set_content(body)

    # Add attachment
    with open(attachment, "rb") as file:
        email_message_hr.add_attachment(
            file.read(),
            maintype="application",
            subtype="pdf",
            filename="Reisekostenerstattungsantrag.pdf",
        )

    return email_message_user, email_message_hr


@register_tool(
    tool="Reisekostenerstattung",
    variant="default",
    description="Default Reisekostenerstattung",
    input_type={
        "teamleader": (str, {"description": "Name of the team leader"}),
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "extensions": ["pdf", "xlsx"],
            },
        ),
    },
    output_type="pdf",
)
def reisekosten(task, teamleader: str, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    user_email = task.request.headers.get("user_email")
    template_xlsx = files[0]
    documents = files[1:]

    # Convert Excel to PDF
    template_pdf = convert_xlsx_to_pdf(template_xlsx, keep_original=False)

    # Create new PDF file
    output_pdf = pymupdf.open()

    # Open the PDF file
    doc = pymupdf.open(template_pdf)

    # extract second page from the PDF and add it to the new PDF file
    output_pdf.insert_pdf(doc, from_page=1, to_page=1)

    # Close the PDF file
    doc.close()

    # Append other pdf files in dictionary
    if documents:
        for pdf in documents:
            doc = pymupdf.open(pdf)
            output_pdf.insert_pdf(doc)
            doc.close()
            if os.path.exists(pdf):
                os.remove(pdf)

    # ========================== SAVE ==========================
    output_path = generate_tool_output_path(
        user_id=user_id,
        filename=f"Reisekostenabrechnung_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        tool="Reisekosten",
        variant="default",
        task_id=task.request.id,
        extension="pdf",
    )

    ensure_output_folder(output_path)

    output_pdf.save(output_path)

    delete_input_files(files)

    try:
        logger.info(f"📧 Sending email to {user_email}")
        email_user, email_hr = create_email(
            attachment=output_path,
            user_email=user_email,
            teamleader=teamleader,
        )
        asyncio.run(send_email([email_user, email_hr]))
        return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
    except Exception as e:
        logger.exception(f"❌ Failed to send email to {user_email} - Error: {e}")
        raise e
