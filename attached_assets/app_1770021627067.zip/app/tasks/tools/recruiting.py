import calendar
from datetime import date, datetime
from pathlib import Path

import polars as pl
from fastapi import UploadFile
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.utils.dataframe import dataframe_to_rows

from app.tasks.tool_registry import register_tool
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_tool_output_path, strip_task_id


@register_tool(
    tool="Recruiting",
    variant="default",
    description="Default Recruiting",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
                list[UploadFile],
                {
                    "min_files": 3,
                    "max_files": 3,
                    "extensions": ["csv", "xlsx", "xls"],
                },
        ),
    },
    output_type="xlsx",
)
def recruiting(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]
    file3 = files[2]

    try:
        df_import = pl.read_csv(file1, separator=";", infer_schema=False, ignore_errors=True).drop(
            pl.col(["Bewerbenden-ID"]))
        assert df_import.width == 9
    except FileNotFoundError as e:
        raise Exception("Die Datei für dieses Jahr wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception(
            "Die Struktur der Datei für dieses Jahr ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    try:
        df_import_old = pl.read_csv(file2, separator=";", infer_schema=False, ignore_errors=True).drop(
            pl.col(["Bewerbenden-ID"]))
        assert df_import.width == 9
    except FileNotFoundError as e:
        raise Exception("Die Datei für letztes Jahr wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception(
            "Die Struktur der Datei für dieses Jahr ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    try:
        wb = load_workbook(file3)
        ws = wb["Recruiting-Kennzahlen"]
    except FileNotFoundError as e:
        raise Exception("Die Excel-Vorlage wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except KeyError as e:
        raise Exception('Das Arbeitsblatt "Recruiting-Kennzahlen" wurde nicht in der Vorlage gefunden.') from e

    applicant_amount = len(df_import)

    df_import = df_import.with_columns(
        pl.when(pl.col("Bewerbungskanal").str.to_lowercase() == "direktansprache xing")
        .then(pl.lit("Xing Direktansprache"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "direktansprache linkedin")
        .then(pl.lit("LinkedIn Direktansprache"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "empfehlung ma")
        .then(pl.lit("MA werben MA"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "empfehlung gf")
        .then(pl.lit("Empfehlung von Partnern/GF"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "steuerberaterkammer")
        .then(pl.lit("Steuerberaterkammer/Rechtsanwaltskammer"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "rechtsanwaltskammer")
        .then(pl.lit("Steuerberaterkammer/Rechtsanwaltskammer"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "ecovis karriereseite")
        .then(pl.lit("Karriereseite (ECOVIS KSO)"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "personio karriereseite")
        .then(pl.lit("Personio Karriereseite (Indeed, StepStone, sonstige Jobportale)"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "indeed")
        .then(pl.lit("Karriereseite (ECOVIS KSO)"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "hochschule/uni")
        .then(pl.lit("Hochschule/Unis"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "linkedin")
        .then(pl.lit("LinkedIn Jobslots"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "linkedin - organic")
        .then(pl.lit("LinkedIn Jobslots"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "messe")
        .then(pl.lit("Messen"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "schulveranstaltungen")
        .then(pl.lit("Schulveranstaltungen"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "hochschulmarketing / hochschul-jobbörse (jobteaser)")
        .then(pl.lit("Hochschule/Unis"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "wiederbewerbung (z.b. ehem. praktikanten etc.)")
        .then(pl.lit("Wiederbewerbung (z. B. ehem. Praktikanten etc.)"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "personaldienstleister")
        .then(pl.lit("Personalvermittler"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "stepstone")
        .then(pl.lit("Karriereseite (ECOVIS KSO)"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "xing")
        .then(pl.lit("Xing Website"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "join")
        .then(pl.lit("Join"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "indeedapply - organic")
        .then(pl.lit("Karriereseite (ECOVIS KSO)"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "empfehlung kooperationspartner")
        .then(pl.lit("Empfehlung Kooperationspartner"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "sonstiges")
        .then(pl.lit("Karriereseite (ECOVIS KSO)"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "unbekannt")
        .then(pl.lit("Karriereseite (ECOVIS KSO)"))
        .when(pl.col("Bewerbungskanal").is_null())
        .then(pl.lit("Karriereseite (ECOVIS KSO)"))
        .otherwise(pl.col("Bewerbungskanal"))
        .alias("Bewerbungskanal")
    )

    df_all_channels = pl.DataFrame({
        "Bewerbungskanal": [
            "Karriereseite (ECOVIS KSO)",
            "Ecovis Deutschland",
            "Personio Karriereseite (Indeed, StepStone, sonstige Jobportale)",
            "Wiederbewerbung (z. B. ehem. Praktikanten etc.)",
            "Xing Direktansprache",
            "LinkedIn Direktansprache",
            "MA werben MA",
            "Empfehlung von Partnern/GF",
            "Empfehlung Kooperationspartner",
            "Xing Website",
            "LinkedIn Jobslots",
            "Messen",
            "Schulveranstaltungen",
            "Hochschule/Unis",
            "Steuerberaterkammer/Rechtsanwaltskammer",
            "Join",
            "Personalvermittler",
        ]
    })
    df_import = df_all_channels.join(df_import, on="Bewerbungskanal", how="right").fill_null(0).sort(
        by=["Bewerbungskanal"])
    df_channel = df_import.clone()

    df_channel = df_channel.filter(
        pl.col("Bewerbungsdatum").is_not_null()
    ).select(
        pl.col("Bewerbungskanal").value_counts()
    ).unnest("Bewerbungskanal")

    df_channel = df_all_channels.join(
        df_channel, on="Bewerbungskanal", how="left"
    ).with_columns(
        pl.col("count").fill_null(0)
    ).drop("Bewerbungskanal")

    df_location = df_import.clone()

    df_location = (df_location.with_columns([
        pl.when(
            (pl.col("Standort").is_null()) |
            (pl.col("Standort") == "Unbekannt") |
            (pl.col("Standort") == "Mehrere Standorte möglich")
        ).then(pl.lit("Mehrere Standorte möglich/Unbekannt"))
        .otherwise(pl.col("Standort"))
        .alias("Standort")
    ]))

    df_location = df_location.select(
        pl.col("Standort").value_counts()
    ).unnest("Standort")

    all_locations = [
        "Düsseldorf", "Köln", "Langenfeld", "Oberhausen", "Wuppertal",
        "Bad Oeynhausen", "Bielefeld", "Berlin", "Mülheim", "Essen",
        "Hannover", "100% remote", "Mehrere Standorte möglich/Unbekannt"
    ]

    # 1) create helper df with all possible locations
    df_all = pl.DataFrame({"Standort": all_locations})

    # 2) full outer join: ensures all Standort are included
    df_location = df_all.join(df_location, on="Standort", how="left").fill_null(0)

    # 3) add order as before
    df_location = df_location.with_columns(
        pl.when(pl.col("Standort") == "Düsseldorf").then(0)
        .when(pl.col("Standort") == "Köln").then(1)
        .when(pl.col("Standort") == "Langenfeld").then(2)
        .when(pl.col("Standort") == "Oberhausen").then(3)
        .when(pl.col("Standort") == "Wuppertal").then(4)
        .when(pl.col("Standort") == "Bad Oeynhausen").then(5)
        .when(pl.col("Standort") == "Bielefeld").then(6)
        .when(pl.col("Standort") == "Berlin").then(7)
        .when(pl.col("Standort") == "Mülheim").then(8)
        .when(pl.col("Standort") == "Essen").then(9)
        .when(pl.col("Standort") == "Hannover").then(10)
        .when(pl.col("Standort") == "100% remote").then(11)
        .when(pl.col("Standort") == "Mehrere Standorte möglich/Unbekannt").then(12)
        .otherwise(99)
        .alias("order")
    ).sort("order").drop("order").drop("Standort")

    df_scheduled_ti = df_import.clone()

    df_scheduled_ti = df_scheduled_ti.group_by("Bewerbungskanal").agg([
        pl.col("Telefoninterview")
        .is_not_null()
        .cast(pl.Int64)
        .sum()
        .alias("count")
    ])
    df_scheduled_ti = (df_scheduled_ti.with_columns(
        pl.when(pl.col("Bewerbungskanal") == "Karriereseite (ECOVIS KSO)")
        .then(pl.lit("Intern Online"))
        .when(pl.col("Bewerbungskanal") == "Ecovis Deutschland")
        .then(pl.lit("Intern Online"))
        .when(pl.col("Bewerbungskanal") == "Personio Karriereseite (Indeed, StepStone, sonstige Jobportale)")
        .then(pl.lit("Intern Online"))
        .when(pl.col("Bewerbungskanal") == "Wiederbewerbung (z. B. ehem. Praktikanten etc.)")
        .then(pl.lit("Intern Online"))
        .when(pl.col("Bewerbungskanal") == "Xing Direktansprache")
        .then(pl.lit("Direktansprache Xing"))
        .when(pl.col("Bewerbungskanal") == "LinkedIn Direktansprache")
        .then(pl.lit("Direktansprache LinkedIn"))
        .when(pl.col("Bewerbungskanal") == "Hochschule/Unis")
        .then(pl.lit("Extern Online"))
        .when(pl.col("Bewerbungskanal") == "Messen")
        .then(pl.lit("Recruiting-Veranstaltungen"))
        .when(pl.col("Bewerbungskanal") == "Schulveranstaltungen")
        .then(pl.lit("Recruiting-Veranstaltungen"))
        .when(pl.col("Bewerbungskanal") == "Steuerberaterkammer/Rechtsanwaltskammer")
        .then(pl.lit("Extern Online"))
        .when(pl.col("Bewerbungskanal") == "Join")
        .then(pl.lit("Extern Online"))
        .when(pl.col("Bewerbungskanal") == "Personalvermittler")
        .then(pl.lit("Extern Online"))
        .when(pl.col("Bewerbungskanal") == "LinkedIn Jobslots")
        .then(pl.lit("Jobslots LinkedIn"))
        .when(pl.col("Bewerbungskanal") == "Empfehlung von Partnern/GF")
        .then(pl.lit("Empfehlungen"))
        .when(pl.col("Bewerbungskanal") == "MA werben MA")
        .then(pl.lit("Empfehlungen"))
        .otherwise(pl.col("Bewerbungskanal"))
        .alias("Bewerbungskanal")
    ).group_by("Bewerbungskanal").agg(pl.col(df_scheduled_ti.columns[1]).sum().alias("count")))

    df_all_channels_2 = pl.DataFrame({
        "Bewerbungskanal": [
            "Intern Online",
            "Empfehlungen",
            "Direktansprache Xing",
            "Xing Website",
            "Direktansprache LinkedIn",
            "Jobslots LinkedIn",
            "Recruiting-Veranstaltungen",
            "Extern Online",
        ]
    })

    df_scheduled_ti = df_all_channels_2.join(df_scheduled_ti, on="Bewerbungskanal", how="left").fill_null(0).sort(
        by=["Bewerbungskanal"])

    df_scheduled_ti = df_scheduled_ti.with_columns(
        pl.when(pl.col("Bewerbungskanal") == "Intern Online").then(0)
        .when(pl.col("Bewerbungskanal") == "Empfehlungen").then(1)
        .when(pl.col("Bewerbungskanal") == "Direktansprache Xing").then(2)
        .when(pl.col("Bewerbungskanal") == "Xing Website").then(3)
        .when(pl.col("Bewerbungskanal") == "Direktansprache LinkedIn").then(4)
        .when(pl.col("Bewerbungskanal") == "Jobslots LinkedIn").then(5)
        .when(pl.col("Bewerbungskanal") == "Recruiting-Veranstaltungen").then(6)
        .when(pl.col("Bewerbungskanal") == "Extern Online").then(7)
        .otherwise(99)
        .alias("order")
    ).sort("order").drop("order").drop("Bewerbungskanal")

    scheduled_ti_amount = df_scheduled_ti.select(pl.col("count").sum()).item()

    df_scheduled_vg = df_import.clone()

    df_scheduled_vg = df_scheduled_vg.with_columns([
        pl.coalesce([
            pl.col("1. Gespräch persönlich"),
            pl.col("1. Gespräch virtuell")
        ]).alias("Gespräch")
    ])

    df_scheduled_vg = df_scheduled_vg.group_by("Bewerbungskanal").agg([
        pl.col("Gespräch")
        .is_not_null()
        .cast(pl.Int64)
        .sum()
        .alias("count")
    ])

    df_scheduled_vg = df_scheduled_vg.with_columns(
        pl.when(pl.col("Bewerbungskanal") == "Karriereseite (ECOVIS KSO)")
        .then(pl.lit("Intern Online"))
        .when(pl.col("Bewerbungskanal") == "Ecovis Deutschland")
        .then(pl.lit("Intern Online"))
        .when(pl.col("Bewerbungskanal") == "Personio Karriereseite (Indeed, StepStone, sonstige Jobportale)")
        .then(pl.lit("Intern Online"))
        .when(pl.col("Bewerbungskanal") == "Wiederbewerbung (z. B. ehem. Praktikanten etc.)")
        .then(pl.lit("Intern Online"))
        .when(pl.col("Bewerbungskanal") == "Xing Direktansprache")
        .then(pl.lit("Direktansprache Xing"))
        .when(pl.col("Bewerbungskanal") == "LinkedIn Direktansprache")
        .then(pl.lit("Direktansprache LinkedIn"))
        .when(pl.col("Bewerbungskanal") == "Hochschule/Unis")
        .then(pl.lit("Extern Online"))
        .when(pl.col("Bewerbungskanal") == "Messen")
        .then(pl.lit("Recruiting-Veranstaltungen"))
        .when(pl.col("Bewerbungskanal") == "Schulveranstaltungen")
        .then(pl.lit("Recruiting-Veranstaltungen"))
        .when(pl.col("Bewerbungskanal") == "Steuerberaterkammer/Rechtsanwaltskammer")
        .then(pl.lit("Extern Online"))
        .when(pl.col("Bewerbungskanal") == "Join")
        .then(pl.lit("Extern Online"))
        .when(pl.col("Bewerbungskanal") == "Personalvermittler")
        .then(pl.lit("Extern Online"))
        .when(pl.col("Bewerbungskanal") == "LinkedIn Jobslots")
        .then(pl.lit("Jobslots LinkedIn"))
        .when(pl.col("Bewerbungskanal") == "Empfehlung von Partnern/GF")
        .then(pl.lit("Empfehlungen"))
        .when(pl.col("Bewerbungskanal") == "MA werben MA")
        .then(pl.lit("Empfehlungen"))
        .otherwise(pl.col("Bewerbungskanal"))
        .alias("Bewerbungskanal")
    ).group_by("Bewerbungskanal").agg(pl.col(df_scheduled_vg.columns[1]).sum().alias("count"))

    df_scheduled_vg = df_all_channels_2.join(df_scheduled_vg, on="Bewerbungskanal", how="left").fill_null(0).sort(
        by=["Bewerbungskanal"])

    df_scheduled_vg = df_scheduled_vg.with_columns(
        pl.when(pl.col("Bewerbungskanal") == "Intern Online").then(0)
        .when(pl.col("Bewerbungskanal") == "Empfehlungen").then(1)
        .when(pl.col("Bewerbungskanal") == "Direktansprache Xing").then(2)
        .when(pl.col("Bewerbungskanal") == "Xing Website").then(3)
        .when(pl.col("Bewerbungskanal") == "Direktansprache LinkedIn").then(4)
        .when(pl.col("Bewerbungskanal") == "Jobslots LinkedIn").then(5)
        .when(pl.col("Bewerbungskanal") == "Recruiting-Veranstaltungen").then(6)
        .when(pl.col("Bewerbungskanal") == "Extern Online").then(7)
        .otherwise(99)
        .alias("order")
    ).sort("order").drop("order").drop("Bewerbungskanal")

    scheduled_vg_amount = df_scheduled_vg.select(pl.col("count").sum()).item()

    try:
        df_import_old = (pl.read_csv(file2, separator=';', infer_schema=False, ignore_errors=True).drop(
            pl.col(["Bewerbenden-ID"])))
    except FileNotFoundError as e:
        raise Exception("Die Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e

    applicant_amount_old = len(df_import_old)

    df_import_old = df_import_old.with_columns(
        pl.when(pl.col("Bewerbungskanal").str.to_lowercase() == "direktansprache xing")
        .then(pl.lit("Xing Direktansprache"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "direktansprache linkedin")
        .then(pl.lit("LinkedIn Direktansprache"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "empfehlung ma")
        .then(pl.lit("MA werben MA"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "empfehlung gf")
        .then(pl.lit("Empfehlung von Partnern/GF"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "steuerberaterkammer")
        .then(pl.lit("Steuerberaterkammer/Rechtsanwaltskammer"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "rechtsanwaltskammer")
        .then(pl.lit("Steuerberaterkammer/Rechtsanwaltskammer"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "ecovis karriereseite")
        .then(pl.lit("Karriereseite (ECOVIS KSO)"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "personio karriereseite")
        .then(pl.lit("Personio Karriereseite (Indeed, StepStone, sonstige Jobportale)"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "indeed")
        .then(pl.lit("Karriereseite (ECOVIS KSO)"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "hochschule/uni")
        .then(pl.lit("Hochschule/Unis"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "linkedin")
        .then(pl.lit("LinkedIn Jobslots"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "linkedin - organic")
        .then(pl.lit("LinkedIn Jobslots"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "messe")
        .then(pl.lit("Messen"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "schulveranstaltungen")
        .then(pl.lit("Schulveranstaltungen"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "hochschulmarketing / hochschul-jobbörse (jobteaser)")
        .then(pl.lit("Hochschule/Unis"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "wiederbewerbung (z.b. ehem. praktikanten etc.)")
        .then(pl.lit("Wiederbewerbung (z. B. ehem. Praktikanten etc.)"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "personaldienstleister")
        .then(pl.lit("Personalvermittler"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "stepstone")
        .then(pl.lit("Karriereseite (ECOVIS KSO)"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "xing")
        .then(pl.lit("Xing Website"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "join")
        .then(pl.lit("Join"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "indeedapply - organic")
        .then(pl.lit("Karriereseite (ECOVIS KSO)"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "empfehlung kooperationspartner")
        .then(pl.lit("Empfehlung Kooperationspartner"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "sonstiges")
        .then(pl.lit("Karriereseite (ECOVIS KSO)"))
        .when(pl.col("Bewerbungskanal").str.to_lowercase() == "unbekannt")
        .then(pl.lit("Karriereseite (ECOVIS KSO)"))
        .when(pl.col("Bewerbungskanal").is_null())
        .then(pl.lit("Karriereseite (ECOVIS KSO)"))
        .otherwise(pl.col("Bewerbungskanal"))
        .alias("Bewerbungskanal")
    )
    df_all_channels = pl.DataFrame({
        "Bewerbungskanal": [
            "Karriereseite (ECOVIS KSO)",
            "Ecovis Deutschland",
            "Personio Karriereseite (Indeed, StepStone, sonstige Jobportale)",
            "Wiederbewerbung (z. B. ehem. Praktikanten etc.)",
            "Xing Direktansprache",
            "LinkedIn Direktansprache",
            "MA werben MA",
            "Empfehlung von Partnern/GF",
            "Empfehlung Kooperationspartner",
            "Xing Website",
            "LinkedIn Jobslots",
            "Messen",
            "Schulveranstaltungen",
            "Hochschule/Unis",
            "Steuerberaterkammer/Rechtsanwaltskammer",
            "Join",
            "Personalvermittler",
        ]
    })
    df_import_old = df_all_channels.join(df_import_old, on="Bewerbungskanal", how="left").fill_null(0).sort(
        by=["Bewerbungskanal"])

    df_channel_old = df_import_old.clone()
    df_channel_old = df_channel_old.filter(
        pl.col("Bewerbungsdatum").is_not_null()
    ).select(
        pl.col("Bewerbungskanal").value_counts()
    ).unnest("Bewerbungskanal")

    df_channel_old = df_all_channels.join(
        df_channel_old, on="Bewerbungskanal", how="left"
    ).with_columns(
        pl.col("count").fill_null(0)
    ).drop("Bewerbungskanal")

    df_location_old = df_import_old.clone()

    df_location_old = (df_location_old.with_columns([
        pl.when(
            (pl.col("Standort").is_null()) |
            (pl.col("Standort") == "Unbekannt") |
            (pl.col("Standort") == "Mehrere Standorte möglich")
        ).then(pl.lit("Mehrere Standorte möglich/Unbekannt"))
        .otherwise(pl.col("Standort"))
        .alias("Standort")
    ]))

    df_location_old = df_location_old.select(
        pl.col("Standort").value_counts()
    ).unnest("Standort")

    df_location_old = df_location_old.with_columns(
        pl.when(pl.col("Standort") == "Düsseldorf").then(0)
        .when(pl.col("Standort") == "Köln").then(1)
        .when(pl.col("Standort") == "Langenfeld").then(2)
        .when(pl.col("Standort") == "Oberhausen").then(3)
        .when(pl.col("Standort") == "Wuppertal").then(4)
        .when(pl.col("Standort") == "Bad Oeynhausen").then(5)
        .when(pl.col("Standort") == "Bielefeld").then(6)
        .when(pl.col("Standort") == "Berlin").then(7)
        .when(pl.col("Standort") == "Mülheim").then(8)
        .when(pl.col("Standort") == "Essen").then(9)
        .when(pl.col("Standort") == "Hannover").then(10)
        .when(pl.col("Standort") == "100% remote").then(11)
        .when(pl.col("Standort") == "Mehrere Standorte möglich/Unbekannt").then(12)
        .otherwise(99)
        .alias("order")
    ).sort("order").drop("order").drop("Standort")

    df_scheduled_ti_old = df_import_old.clone()

    df_scheduled_ti_old = df_scheduled_ti_old.group_by("Bewerbungskanal").agg([
        pl.col("Telefoninterview")
        .is_not_null()
        .cast(pl.Int64)
        .sum()
        .alias("count")
    ])
    df_scheduled_ti_old = df_scheduled_ti_old.with_columns(
        pl.when(pl.col("Bewerbungskanal") == "Karriereseite (ECOVIS KSO)")
        .then(pl.lit("Intern Online"))
        .when(pl.col("Bewerbungskanal") == "Ecovis Deutschland")
        .then(pl.lit("Intern Online"))
        .when(pl.col("Bewerbungskanal") == "Personio Karriereseite (Indeed, StepStone, sonstige Jobportale)")
        .then(pl.lit("Intern Online"))
        .when(pl.col("Bewerbungskanal") == "Wiederbewerbung (z. B. ehem. Praktikanten etc.)")
        .then(pl.lit("Intern Online"))
        .when(pl.col("Bewerbungskanal") == "Xing Direktansprache")
        .then(pl.lit("Direktansprache Xing"))
        .when(pl.col("Bewerbungskanal") == "LinkedIn Direktansprache")
        .then(pl.lit("Direktansprache LinkedIn"))
        .when(pl.col("Bewerbungskanal") == "Hochschule/Unis")
        .then(pl.lit("Extern Online"))
        .when(pl.col("Bewerbungskanal") == "Messen")
        .then(pl.lit("Recruiting-Veranstaltungen"))
        .when(pl.col("Bewerbungskanal") == "Schulveranstaltungen")
        .then(pl.lit("Recruiting-Veranstaltungen"))
        .when(pl.col("Bewerbungskanal") == "Steuerberaterkammer/Rechtsanwaltskammer")
        .then(pl.lit("Extern Online"))
        .when(pl.col("Bewerbungskanal") == "Join")
        .then(pl.lit("Extern Online"))
        .when(pl.col("Bewerbungskanal") == "Personalvermittler")
        .then(pl.lit("Extern Online"))
        .when(pl.col("Bewerbungskanal") == "LinkedIn Jobslots")
        .then(pl.lit("Jobslots LinkedIn"))
        .when(pl.col("Bewerbungskanal") == "Empfehlung von Partnern/GF")
        .then(pl.lit("Empfehlungen"))
        .when(pl.col("Bewerbungskanal") == "MA werben MA")
        .then(pl.lit("Empfehlungen"))
        .otherwise(pl.col("Bewerbungskanal"))
        .alias("Bewerbungskanal")
    ).group_by("Bewerbungskanal").agg(pl.col(df_scheduled_ti_old.columns[1]).sum().alias("count"))

    df_scheduled_ti_old = df_all_channels_2.join(df_scheduled_ti_old, on="Bewerbungskanal", how="left").fill_null(
        0).sort(
        by=["Bewerbungskanal"])

    df_scheduled_ti_old = df_scheduled_ti_old.with_columns(
        pl.when(pl.col("Bewerbungskanal") == "Intern Online").then(0)
        .when(pl.col("Bewerbungskanal") == "Empfehlungen").then(1)
        .when(pl.col("Bewerbungskanal") == "Direktansprache Xing").then(2)
        .when(pl.col("Bewerbungskanal") == "Xing Website").then(3)
        .when(pl.col("Bewerbungskanal") == "Direktansprache LinkedIn").then(4)
        .when(pl.col("Bewerbungskanal") == "Jobslots LinkedIn").then(5)
        .when(pl.col("Bewerbungskanal") == "Recruiting-Veranstaltungen").then(6)
        .when(pl.col("Bewerbungskanal") == "Extern Online").then(7)
        .otherwise(99)
        .alias("order")
    ).sort("order").drop("order").drop("Bewerbungskanal")

    scheduled_ti_amount_old = df_scheduled_ti_old.select(pl.col("count").sum()).item()

    df_scheduled_vg_old = df_import_old.clone()

    df_scheduled_vg_old = df_scheduled_vg_old.with_columns([
        pl.coalesce([
            pl.col("1. Gespräch persönlich"),
            pl.col("1. Gespräch virtuell")
        ]).alias("Gespräch")
    ])

    df_scheduled_vg_old = df_scheduled_vg_old.group_by("Bewerbungskanal").agg([
        pl.col("Gespräch")
        .is_not_null()
        .cast(pl.Int64)
        .sum()
        .alias("count")
    ])

    df_scheduled_vg_old = df_scheduled_vg_old.with_columns(
        pl.when(pl.col("Bewerbungskanal") == "Karriereseite (ECOVIS KSO)")
        .then(pl.lit("Intern Online"))
        .when(pl.col("Bewerbungskanal") == "Ecovis Deutschland")
        .then(pl.lit("Intern Online"))
        .when(pl.col("Bewerbungskanal") == "Personio Karriereseite (Indeed, StepStone, sonstige Jobportale)")
        .then(pl.lit("Intern Online"))
        .when(pl.col("Bewerbungskanal") == "Wiederbewerbung (z. B. ehem. Praktikanten etc.)")
        .then(pl.lit("Intern Online"))
        .when(pl.col("Bewerbungskanal") == "Xing Direktansprache")
        .then(pl.lit("Direktansprache Xing"))
        .when(pl.col("Bewerbungskanal") == "LinkedIn Direktansprache")
        .then(pl.lit("Direktansprache LinkedIn"))
        .when(pl.col("Bewerbungskanal") == "Hochschule/Unis")
        .then(pl.lit("Extern Online"))
        .when(pl.col("Bewerbungskanal") == "Messen")
        .then(pl.lit("Recruiting-Veranstaltungen"))
        .when(pl.col("Bewerbungskanal") == "Schulveranstaltungen")
        .then(pl.lit("Recruiting-Veranstaltungen"))
        .when(pl.col("Bewerbungskanal") == "Steuerberaterkammer/Rechtsanwaltskammer")
        .then(pl.lit("Extern Online"))
        .when(pl.col("Bewerbungskanal") == "Join")
        .then(pl.lit("Extern Online"))
        .when(pl.col("Bewerbungskanal") == "Personalvermittler")
        .then(pl.lit("Extern Online"))
        .when(pl.col("Bewerbungskanal") == "LinkedIn Jobslots")
        .then(pl.lit("Jobslots LinkedIn"))
        .when(pl.col("Bewerbungskanal") == "Empfehlung von Partnern/GF")
        .then(pl.lit("Empfehlungen"))
        .when(pl.col("Bewerbungskanal") == "MA werben MA")
        .then(pl.lit("Empfehlungen"))
        .otherwise(pl.col("Bewerbungskanal"))
        .alias("Bewerbungskanal")
    ).group_by("Bewerbungskanal").agg(pl.col(df_scheduled_vg_old.columns[1]).sum().alias("count"))

    df_scheduled_vg_old = df_all_channels_2.join(df_scheduled_vg_old, on="Bewerbungskanal", how="left").fill_null(
        0).sort(
        by=["Bewerbungskanal"])

    df_scheduled_vg_old = df_scheduled_vg_old.with_columns(
        pl.when(pl.col("Bewerbungskanal") == "Intern Online").then(0)
        .when(pl.col("Bewerbungskanal") == "Empfehlungen").then(1)
        .when(pl.col("Bewerbungskanal") == "Direktansprache Xing").then(2)
        .when(pl.col("Bewerbungskanal") == "Xing Website").then(3)
        .when(pl.col("Bewerbungskanal") == "Direktansprache LinkedIn").then(4)
        .when(pl.col("Bewerbungskanal") == "Jobslots LinkedIn").then(5)
        .when(pl.col("Bewerbungskanal") == "Recruiting-Veranstaltungen").then(6)
        .when(pl.col("Bewerbungskanal") == "Extern Online").then(7)
        .otherwise(99)
        .alias("order")
    ).sort("order").drop("order").drop("Bewerbungskanal")

    scheduled_vg_amount_old = df_scheduled_vg_old.select(pl.col("count").sum()).item()

    # Convert Polars DataFrames to Pandas
    chanel_pandas = df_channel.to_pandas()
    location_pandas = df_location.to_pandas()
    scheduled_ti_pandas = df_scheduled_ti.to_pandas()
    scheduled_vg_pandas = df_scheduled_vg.to_pandas()

    chanel_pandas_old = df_channel_old.to_pandas()
    location_pandas_old = df_location_old.to_pandas()
    scheduled_ti_pandas_old = df_scheduled_ti_old.to_pandas()
    scheduled_vg_pandas_old = df_scheduled_vg_old.to_pandas()

    # Determine where to insert data
    prev_month = month - 1 if month > 1 else 12
    prev_month_name = calendar.month_name[prev_month].lower()
    current_year = year

    # Find target column with previous month
    target_col = None
    for row in ws.iter_rows(min_row=3, max_row=3):
        for cell in row:
            if (
                    isinstance(cell.value, datetime)
                    and calendar.month_name[cell.value.month].lower() == prev_month_name
                    and cell.value.year == current_year
            ):
                target_col = cell.column
                break
        if target_col:
            break

    if target_col is None:
        raise ValueError(f'"{prev_month_name}" not found in row 3')

    # -------------------------
    # Insert new (current) month
    # -------------------------

    insert_col = target_col + 2
    ws.insert_cols(insert_col)

    # Header cell (row 3)
    header_cell = ws.cell(row=3, column=insert_col, value=date(current_year, month, 1))
    header_cell.number_format = "MMM YY"
    header_cell.font = Font(bold=True)

    # Applicant summary (rows 4–5)
    ws.cell(row=4, column=insert_col, value=applicant_amount).font = Font(bold=True)
    ws.cell(row=5, column=insert_col, value="-")

    # Helper to write a DataFrame starting at a given row into the current-year column
    def write_df(df, start_row):
        for r_idx, row in enumerate(dataframe_to_rows(df, index=False, header=False), start=start_row):
            for c_idx, value in enumerate(row, start=insert_col):
                ws.cell(row=r_idx, column=c_idx, value=value)

    # 1) Channel data: 17 rows (row 6–22)
    channel_start_row = 6
    write_df(chanel_pandas, start_row=channel_start_row)
    channel_end_row = channel_start_row + len(chanel_pandas) - 1  # should be 22

    # 2) Special 3-row block directly under channels
    #    - move value from last channel row down by 1
    #    - set last channel row and row+2 to "-"
    copy_src_row = channel_end_row  # e.g. 22
    copy_dst_row = channel_end_row + 1  # 23
    blank_row_above = channel_end_row  # 22
    blank_row_below = channel_end_row + 2  # 24

    ws.cell(row=copy_dst_row, column=insert_col,
            value=ws.cell(row=copy_src_row, column=insert_col).value)
    ws.cell(row=blank_row_above, column=insert_col, value="-")
    ws.cell(row=blank_row_below, column=insert_col, value="-")

    # 3) Location data starts 3 rows below last channel row (row 25)
    location_start_row = channel_end_row + 3  # 25
    write_df(location_pandas, start_row=location_start_row)

    # 4) Blank row after locations: fixed to row 38 (template row)
    ws.cell(row=38, column=insert_col, value="-")

    # 5) Scheduled TI
    #    - Header (sum) at row 43
    #    - Breakdown table from row 44
    ws.cell(row=43, column=insert_col, value=scheduled_ti_amount).font = Font(bold=True)
    write_df(scheduled_ti_pandas, start_row=44)

    # 6) Scheduled VG
    #    - Header (sum) at row 52
    #    - Breakdown table from row 53
    ws.cell(row=52, column=insert_col, value=scheduled_vg_amount).font = Font(bold=True)
    write_df(scheduled_vg_pandas, start_row=53)

    # ----------------------------
    # Styling for the current-year column
    # ----------------------------

    thin_border = Border(
        left=Side(style="thin"),
        right=Side(style="thin"),
        top=Side(style="thin"),
        bottom=Side(style="thin"),
    )
    right_align = Alignment(horizontal="right")
    gray_fill = PatternFill(start_color="E7E6E6", end_color="E7E6E6", fill_type="solid")

    max_length = 0
    for row in range(3, 75):  # extended because content moved down
        cell = ws.cell(row=row, column=insert_col)
        cell.border = thin_border
        cell.alignment = right_align
        cell.fill = gray_fill
        if cell.value is not None:
            max_length = max(max_length, len(str(cell.value)))

    # Auto-fit column width
    col_letter = get_column_letter(insert_col)
    ws.column_dimensions[col_letter].width = max_length + 2

    # ---------------------------------------------
    # Insert "one year older" column immediately after
    # ---------------------------------------------

    prev_year = current_year - 1
    insert_col_old = insert_col + 1
    ws.insert_cols(insert_col_old)

    # Header cell (row 3)
    header_cell_old = ws.cell(row=3, column=insert_col_old, value=date(prev_year, month, 1))
    header_cell_old.number_format = "MMM YY"
    header_cell_old.font = Font(bold=True)

    # Applicant summary (rows 4–5)
    ws.cell(row=4, column=insert_col_old, value=applicant_amount_old).font = Font(bold=True)
    ws.cell(row=5, column=insert_col_old, value="-")

    # Helper to write "old" DataFrames into the old-year column
    def write_old_df(df, start_row):
        for r_idx, row in enumerate(dataframe_to_rows(df, index=False, header=False), start=start_row):
            for c_idx, value in enumerate(row, start=insert_col_old):
                ws.cell(row=r_idx, column=c_idx, value=value)

    # 1) Channel data (row 6–22)
    write_old_df(chanel_pandas_old, start_row=channel_start_row)
    channel_end_row_old = channel_start_row + len(chanel_pandas_old) - 1  # should also be 22

    # 2) Special 3-row block under channels (mirrors the current-year block)
    copy_src_row_old = channel_end_row_old  # 22
    copy_dst_row_old = channel_end_row_old + 1  # 23
    blank_row_above_old = channel_end_row_old  # 22
    blank_row_below_old = channel_end_row_old + 2  # 24

    ws.cell(row=copy_dst_row_old, column=insert_col_old,
            value=ws.cell(row=copy_src_row_old, column=insert_col_old).value)
    ws.cell(row=blank_row_above_old, column=insert_col_old, value="-")
    ws.cell(row=blank_row_below_old, column=insert_col_old, value="-")

    # 3) Location data (expected 13 rows max), starting at row 25
    location_start_row_old = channel_end_row_old + 3  # 25
    expected_locations = 13

    if len(location_pandas_old) == expected_locations:
        write_old_df(location_pandas_old, start_row=location_start_row_old)
    else:
        # Fill with "-" if the length doesn’t match the template
        for r in range(location_start_row_old, location_start_row_old + expected_locations):
            ws.cell(row=r, column=insert_col_old, value="-")

    # 4) Blank row after locations: row 38
    ws.cell(row=38, column=insert_col_old, value="-")

    # 5) Scheduled TI (old year)
    ws.cell(row=43, column=insert_col_old, value=scheduled_ti_amount_old).font = Font(bold=True)
    write_old_df(scheduled_ti_pandas_old, start_row=44)

    # 6) Scheduled VG (old year)
    ws.cell(row=52, column=insert_col_old, value=scheduled_vg_amount_old).font = Font(bold=True)
    write_old_df(scheduled_vg_pandas_old, start_row=53)

    # ----------------------------
    # Styling for the old-year column
    # ----------------------------

    max_length_old = 0
    for row in range(3, 75):
        cell = ws.cell(row=row, column=insert_col_old)
        cell.border = thin_border
        cell.alignment = right_align
        if cell.value is not None:
            max_length_old = max(max_length_old, len(str(cell.value)))

    col_letter_old = get_column_letter(insert_col_old)
    ws.column_dimensions[col_letter_old].width = max_length_old + 2

    # ========================== SAVE ==========================
    output_path = generate_tool_output_path(
        user_id=user_id,
        filename="Recruiting_Auswertung",
        tool="Recruiting",
        variant="default",
        task_id=task.request.id,
        extension="xlsx",
    )

    ensure_output_folder(output_path)

    wb.save(output_path)

    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
