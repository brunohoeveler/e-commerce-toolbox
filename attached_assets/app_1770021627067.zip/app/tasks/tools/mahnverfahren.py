from datetime import datetime
from pathlib import Path

import pandas as pd
from fastapi import UploadFile

from app.tasks.tool_registry import register_tool
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_tool_output_path, strip_task_id


@register_tool(
    tool="Mahnverfahren",
    variant="default",
    description="Default Mahnverfahren",
    input_type={
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "extensions": ["csv", "xlsx", "xls"],
            },
        ),
    },
    output_type="pdf",
)
def mahnverfahren(task, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]

    df_datev = pd.read_csv(file1, sep=";", dtype=str, encoding="latin_1")
    df_rechnungen = pd.read_excel(file2, dtype=str)

    df_datev = df_datev[["Zentr. Mandant", "Kanzleileitung / Partner (Name)"]]
    df_datev.columns.values[0:2] = ["mdtnr", "Partner"]

    df_rechnungen["Mandantennummer"] = df_rechnungen["Mandantennummer"].str[:5]
    df_rechnungen = df_rechnungen.drop(df_rechnungen.columns[[4, 7, 10, 11, 12, 14, 15]], axis=1)
    df_rechnungen["R.-Betrag"] = df_rechnungen["R.-Betrag"].str.replace(".", ",")
    df_rechnungen["R.-Betrag offen"] = df_rechnungen["R.-Betrag offen"].str.replace(".", ",")
    df_rechnungen["Ankauf-Betrag offen"] = df_rechnungen["Ankauf-Betrag offen"].str.replace(".", ",")
    df_rechnungen.loc[df_rechnungen["Rechtsverfolgung"] == "0", "Rechtsverfolgung"] = ""
    df_rechnungen = df_rechnungen[df_rechnungen["Mahnstufe"].isin(["1", "2"])]

    df_merge = pd.merge(df_rechnungen, df_datev, left_on="Mandantennummer", right_on="mdtnr", how="left")
    del df_merge["mdtnr"]
    df_merge.loc[df_merge["Partner"].isnull(), "Partner"] = "-- KEIN PARTNER IN DATEV --"
    df_merge.sort_values(by=["Partner", "Mandantennummer"], ascending=True, inplace=True)

    # ========================== SPEICHERN ==========================
    output_path = generate_tool_output_path(
        user_id=user_id,
        filename=f"Mahnverfahren_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        tool="Mahnverfahren",
        variant="default",
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    df_merge.to_csv(output_path, sep=";", index=False)

    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
