import os
import sys
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path

import country_converter as coco
import pandas as pd
from fastapi import UploadFile
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils.dataframe import dataframe_to_rows
from verify_vat_number.ares import get_from_cz_ares
from verify_vat_number.exceptions import (
    UnsupportedCountryCode,
    VatNotFound,
    VerifyVatException,
)
from verify_vat_number.vies import get_from_eu_vies

from app.tasks.tool_registry import register_tool
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_tool_output_path, strip_task_id


@contextmanager
def suppress_output():
    original_stdout = sys.stdout
    original_stderr = sys.stderr
    try:
        sys.stdout = open(os.devnull, "w")
        sys.stderr = open(os.devnull, "w")
        yield
    finally:
        sys.stdout.close()
        sys.stderr.close()
        sys.stdout = original_stdout
        sys.stderr = original_stderr


@register_tool(
    tool="VAT",
    variant="default",
    description="Default VAT Tool",
    input_type={
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["xlsx", "xls"],
            },
        ),
    },
    output_type="xlsx",
)
def vat(task, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]

    with suppress_output():
        df = pd.read_excel(file1)
        # Filter out the rows where the specified column is not empty
        non_empty_rows = df["Unnamed: 11"].notnull()

        # Extract and # print the non-empty values from the specified column
        non_empty_values = df["Unnamed: 11"][non_empty_rows].tolist()

        del non_empty_values[0]
        # print(non_empty_values)

        # Substring to exclude
        substring_to_exclude = "DE"

        # List comprehension to filter elements not containing the substring
        filtered_list = [element for element in non_empty_values if substring_to_exclude not in element]

        # # print the filtered list
        # print(filtered_list)

        df2 = pd.DataFrame(
            columns=[
                "VAT_Number",
                "Status",
                "Company_Name",
                "Status_of_Company_name",
                "Street_and_Num",
                "Status_of_Street_and_Num",
                "City",
                "Status_of_City",
                "Postal_Code",
                "Status_of_Postal_Code",
                "District",
                "Country",
            ]
        )
        VAT_Number = []
        Status = []
        Company_Name = []
        Address = []
        Street_and_Num = []
        City = []
        Postal_Code = []
        District = []
        Country_Code = []

        def dump_reg(vat):
            # print('\nVAT-REG-NUM:', vat)
            try:
                data = get_from_eu_vies(vat)
                VAT_Number.append(vat)
                Status.append("Verified")
                Company_Name.append(data.company_name)
                if data.address:
                    Address.append(data.address.replace("\n", ", "))
                else:
                    Address.append(None)
                Street_and_Num.append(data.street_and_num)
                City.append(data.city)
                Postal_Code.append(data.postal_code)
                District.append(data.district)
                Country_Code.append(data.country_code)

            except VatNotFound:
                # print("VAT not found for", vat)
                VAT_Number.append(vat)
                Status.append("Invalid VAT")
                Company_Name.append(None)
                Address.append(None)
                Street_and_Num.append(None)
                City.append(None)
                Postal_Code.append(None)
                District.append(None)
                Country_Code.append(None)
            except UnsupportedCountryCode:
                # print("Unsupported country code:", err)
                pass
            except VerifyVatException:
                # print(err)
                # print(err.source)
                pass

        def dump_vid(ic):
            # print('\nVAT-ID-NUM:', ic)
            try:
                get_from_cz_ares(ic)
            except VatNotFound:
                print("VAT not found for", ic)
            except VerifyVatException:
                print("Unsupported country code:", ic)

        for vat in filtered_list:
            dump_reg(vat)

        for ic in ("67985726", "67985728", "456456456"):
            dump_vid(ic)

        df2["VAT_Number"] = pd.Series(VAT_Number, dtype=object)

        df2["Status"] = pd.Series(Status, dtype=object)
        # dfIT["employee"] = dfIT["employee"].drop_duplicates()
        df2["Company_Name"] = pd.Series(Company_Name, dtype=object)
        df2["Status_of_Company_name"] = pd.Series(Status, dtype=object)
        # df2["Address"]= pd.Series(Address,dtype=object)ba
        df2["Street_and_Num"] = pd.Series(Street_and_Num, dtype=object)
        df2["Status_of_Street_and_Num"] = pd.Series(Status, dtype=object)
        df2["City"] = pd.Series(City, dtype=object)
        df2["Status_of_City"] = pd.Series(Status, dtype=object)

        df2["Postal_Code"] = pd.Series(Postal_Code, dtype=object)
        df2["Status_of_Postal_Code"] = pd.Series(Status, dtype=object)
        df2["District"] = pd.Series(District, dtype=object)

        df2["Country"] = pd.Series(coco.convert(names=Country_Code, to="name_short"), dtype=object)
        df2["Country"] = df2["Country"].replace("not found", "")
        df2["Address"] = pd.Series(Address, dtype=object)
        # df2["Country"] = coco.convert(names=Country_Code, to='name_short')

        # df = pd.concat([dfFR, dfempty, dfEN, dfempty, dfNL, dfempty, dfIT, dfempty, dfES], ignore_index=True, axis=0)
        # print(df2.to_markdown())

        # Change the dataframe in excel

        # Create a new Excel workbook
        wb = Workbook()
        ws = wb.active

        # Append dataframe rows to the worksheet
        for row in dataframe_to_rows(df2, index=False, header=True):
            ws.append(row)

        # Add formatting to the header row
        # Modify the header formatting
        header_row = ws[1]
        for cell in header_row:
            cell.font = Font(underline="single", bold=True)
            # cell.font = new_font

        # Define the string you're looking for and the color you want to apply
        target_string = "Invalid"
        fill_color = "FF0000"  # red color

        # Loop through cells in the desired range and apply color to cells containing the target string
        for row in ws.iter_rows(min_row=1, max_row=ws.max_row, min_col=1, max_col=ws.max_column):
            for cell in row:
                if isinstance(cell.value, str) and target_string in cell.value:
                    cell.fill = PatternFill(start_color=fill_color, end_color=fill_color, fill_type="solid")

        # Define the string you're looking for and the color you want to apply
        target_string = "Verified"
        fill_color = "00FF00"  # green color

        # Loop through cells in the desired range and apply color to cells containing the target string
        for row in ws.iter_rows(min_row=1, max_row=ws.max_row, min_col=1, max_col=ws.max_column):
            for cell in row:
                if isinstance(cell.value, str) and target_string in cell.value:
                    cell.fill = PatternFill(start_color=fill_color, end_color=fill_color, fill_type="solid")
        # Save the modified workbook
        # workbook.save('modified_file.xlsx')

        # Iterate over the cells in the specified column and make them bold
        for cell in ws["A"]:
            if cell.value is not None and str(cell.value).strip() != "":
                cell.font = Font(bold=True)

        # Set the column widths based on the content length
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                if cell.value:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(cell.value)
                    except TypeError:
                        print(f"Error processing cell value: {cell.value}")
            adjusted_width = (max_length + 2) * 1.2
            ws.column_dimensions[column_letter].width = adjusted_width

        output_path = generate_tool_output_path(
            user_id=user_id,
            filename=f"VAT_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            tool="VAT",
            variant="default",
            task_id=task.request.id,
            extension="xlsx",
        )

        ensure_output_folder(output_path)

        wb.save(output_path)

        delete_input_files(files)

        return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
