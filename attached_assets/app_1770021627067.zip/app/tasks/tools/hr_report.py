from datetime import datetime
from pathlib import Path
import polars as pl
from dateutil.relativedelta import relativedelta
from docx import Document
from fastapi import UploadFile
from app.tasks.tool_registry import register_tool
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_tool_output_path, strip_task_id
from app.utils.tool_utils import replace_value, replace_table, replace_pie_chart, replace_bar_chart, replace_title

@register_tool(
    tool="HR-Report",
    variant="default",
    description="Quartal HR-Report",
    input_type={
        "quarter": (int, {"description": "Quarter in Q format", "min": 1, "max": 4}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
                list[UploadFile],
                {
                    "min_files": 5,
                    "max_files": 5,
                    "extensions": ["xlsx", "xls", "docx"],
                },
        ),
    },
    output_type="xlsx",
)

def hr_report(task, quarter: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]
    file3 = files[2]
    file4 = files[3]
    file5 = files[4]

    quartal = f"Q{quarter}"

    ALL_MONTHS = [
        f"1 — 31. Jan. {year}", f"1 — 28. Feb. {year}", f"1 — 31. März {year}",
        f"1 — 30. Apr. {year}", f"1 — 31. Mai {year}", f"1 — 30. Juni {year}",
        f"1 — 31. Juli {year}", f"1 — 31. Aug. {year}", f"1 — 30. Sept. {year}",
        f"1 — 31. Okt. {year}", f"1 — 30. Nov. {year}", f"1 — 31. Dez. {year}"
    ]

    months = ALL_MONTHS[(quarter - 1) * 3: (quarter - 1) * 3 + 3]

    # Mapping quarters to date ranges
    quarter_dates = {
        'Q1': (1, 3, 31),
        'Q2': (1, 6, 30),
        'Q3': (7, 9, 30),
        'Q4': (10, 12, 31)
    }

    # Get current quarter dates
    start_month, end_month, end_day = quarter_dates[quartal]

    # Determine previous quarter and year
    quarters = ['Q1', 'Q2', 'Q3', 'Q4']
    index = quarters.index(quartal)
    prev_quarter = quarters[index - 1] if index > 0 else 'Q4'
    prev_year = year if index > 0 else year - 1

    # Get previous quarter dates
    prev_start_month, prev_end_month, prev_end_day = quarter_dates[prev_quarter]
    # ========================== IMPORT DATEI ==========================
    quartal_wert = quartal + ' ' + str(year)
    start_date = datetime(year, end_month, 1)
    next_month_date = start_date + relativedelta(months=1)
    try:
        df_import = pl.read_excel(file1, infer_schema_length=0)
    except FileNotFoundError as e:
        raise Exception("Die Report Daten Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e


    df_import = df_import.rename(
        dict(zip(df_import.columns[0:], ['Vorname', 'Nachname', 'Mitarbeitende', 'Abteilung', 'Standort',
                                         'Geschlecht', 'Berufsträger', 'anstell', 'eintritt',
                                         'Austrittsdatum', 'Austrittsart', 'Austrittsgrund', 'krankheit', 'status',
                                         'supervisor', 'Wochenstunden', 'Mitteilungsdatum'])))

    df_import = df_import.with_columns(
        pl.col('Mitarbeitende').str.replace_all(r'\,', '.').alias('Mitarbeitende'))
    df_import = df_import.cast({'Mitarbeitende': pl.Float64})
    df_import = df_import.with_columns(
        pl.when(pl.col('Mitarbeitende') == 0.0)
        .then((pl.col('Wochenstunden').cast(pl.Float64) / 40).round(2))
        .otherwise(pl.col('Mitarbeitende'))
        .alias('Mitarbeitende')
    )
    df_import = df_import.filter(pl.col('Abteilung').is_not_null())
    df_import = df_import.filter(pl.col('Abteilung') != 'Test-Abteilung')
    df_import = df_import.filter(pl.col('Nachname') != 'Weihnachtsmann')
    df_import = df_import.filter(pl.col('Nachname') != 'Onboarding Day')

    df_import_prev_quartal = df_import.clone()
    df_import_prev_quartal = df_import_prev_quartal.with_columns([
        pl.col("anstell").str.strptime(pl.Datetime, "%Y-%m-%d %H:%M:%S").cast(pl.Datetime("us")).alias("anstell"),
        pl.col("eintritt").str.strptime(pl.Datetime, "%Y-%m-%d %H:%M:%S").cast(pl.Datetime("us")).alias("eintritt"),
        pl.col("Austrittsdatum").str.strptime(pl.Datetime, "%Y-%m-%d %H:%M:%S").cast(pl.Datetime("us")).alias(
            "Austrittsdatum")
    ]
    ).filter(pl.col("anstell") <= datetime(prev_year, prev_end_month, prev_end_day)).sort('anstell')
    df_prev_austritte = df_import_prev_quartal.clone()
    df_prev_austritte = df_prev_austritte.with_columns(pl.lit(1).alias('Mitarbeitende'))

    df_import = df_import.with_columns([
        pl.col("anstell").str.strptime(pl.Datetime, "%Y-%m-%d %H:%M:%S").cast(pl.Datetime("us")).alias("anstell"),
        pl.col("eintritt").str.strptime(pl.Datetime, "%Y-%m-%d %H:%M:%S").cast(pl.Datetime("us")).alias("eintritt"),
        pl.col("Austrittsdatum").str.strptime(pl.Datetime, "%Y-%m-%d %H:%M:%S").cast(pl.Datetime("us")).alias(
            "Austrittsdatum")
    ]
    ).filter(pl.col("anstell") <= datetime(year, end_month, end_day)).sort('anstell')
    fte_df = df_import.clone()
    fte_df_vorjahr = df_import.clone()
    df_import = df_import.with_columns(pl.lit(1).alias('Mitarbeitende'))
    df_vorjahr = df_import.clone()
    df_austritte = df_import.clone()
    df_zukunft = df_import.clone()
    df_quartal = df_import.clone()
    df_headcount = df_import.clone()
    df_import = df_import.filter(pl.col('status') == 'Aktiv')
    df_import = df_import.sort('Mitarbeitende')
    # ============================= Mitarbeitende ================================
    fte = fte_df
    fte = fte.filter(pl.col('status').is_in(['Auszeit','Aktiv']))
    fte = fte.filter(
        (pl.col('Austrittsdatum') > datetime(year, end_month, end_day)) | pl.col('Austrittsdatum').is_null())
    fte = fte.select(pl.sum('Mitarbeitende').round(2))
    fte = pl.select(fte.cast(pl.String)).item()

    # ============================= Vorherige Mitarbeitende ================================
    prev_fte = df_import_prev_quartal.clone()
    prev_fte = prev_fte.filter((pl.col('Austrittsdatum') > datetime(prev_year, prev_end_month, prev_end_day)) | pl.col(
        'Austrittsdatum').is_null())
    prev_fte = prev_fte.select(pl.sum('Mitarbeitende').round(2))
    prev_fte = pl.select(prev_fte.cast(pl.String)).item()

    # ============================= Headcount Mitarbeitende ================================
    df_headcount = df_headcount.filter(
        pl.col('anstell') <= datetime(year, end_month, end_day))
    df_headcount = df_headcount.filter(
        (pl.col('Austrittsdatum') >= datetime(year, end_month, end_day)) | (
            pl.col('Austrittsdatum').is_null())
    )
    headcount = df_headcount.select(pl.len()).item()

    # ============================= Mitarbeitende Vorjahr ================================
    fte_vorjahr = fte_df_vorjahr
    fte_vorjahr = fte_vorjahr.filter(pl.col('anstell') <= datetime(year - 1, end_month, end_day))
    fte_vorjahr = fte_vorjahr.filter(
        (pl.col('Austrittsdatum') > datetime(year, end_month, end_day)) | pl.col('Austrittsdatum').is_null())
    fte_vorjahr = fte_vorjahr.select(pl.sum('Mitarbeitende').round(2))
    fte_vorjahr = pl.select(fte_vorjahr.cast(pl.String)).item()

    # ============================= Headcount Mitarbeitende Prev Quartal ================================
    headcount_prev_quartal = df_import_prev_quartal.clone()
    active_employees_prev = headcount_prev_quartal.filter(pl.col('anstell') <= datetime(prev_year, prev_end_month, prev_end_day))
    active_employees_prev = active_employees_prev.filter(
        (pl.col('Austrittsdatum') >= datetime(prev_year, prev_end_month, prev_end_day)) | (pl.col('Austrittsdatum').is_null())
    )
    headcount_prev_quartal = active_employees_prev.select(pl.len()).item()

    # ============================= Headcount Mitarbeitende Vorjahr ================================
    headcount_vorjahr = df_vorjahr.clone()
    active_employees = headcount_vorjahr.filter(pl.col('anstell') <= datetime(year - 1, end_month, end_day))
    active_employees = active_employees.filter(
        (pl.col('Austrittsdatum') >= datetime(year - 1, end_month, end_day)) | (pl.col('Austrittsdatum').is_null())
    )
    headcount_vorjahr = active_employees.select(pl.len()).item()

    # ============================= Bestand ================================
    df_bestand = df_import.clone()
    df_bestand = df_bestand.select([
        col for i, col in enumerate(df_import.columns) if i in [2, 3, 4, 5, 6]])
    df_bestand = df_bestand.with_columns(pl.lit(1).alias('Mitarbeitende'))

    # ============================= Bestand Ablteilung ================================
    bestand_abteilung = df_bestand.group_by(['Abteilung']).agg(pl.col('Mitarbeitende').sum()).sort('Abteilung')

    # ============================= Bestand Geschlecht ================================
    bestand_geschlecht = df_bestand.group_by(['Geschlecht']).agg(pl.col('Mitarbeitende').sum()).sort("Geschlecht")

    # Replace the third column with "Diverse"
    bestand_geschlecht = bestand_geschlecht.with_columns(
        pl.when(pl.col("Geschlecht").is_in(["Männlich", "Weiblich"]))
        .then(pl.col("Geschlecht"))
        .otherwise(pl.lit("Diverse"))
        .alias("Geschlecht")
    )

    # ============================= Bestand Standort ================================
    bestand_standort = df_bestand.group_by(['Standort']).agg(pl.col('Mitarbeitende').sum()).sort("Standort")

    # ============================= Bestand Berufsträger ================================
    bestand_berufstr = df_bestand.group_by(['Berufsträger']).agg(pl.col('Mitarbeitende').sum()).filter(
        pl.col('Berufsträger') == 'ja').sort(
        "Berufsträger")
    bestand_berufstr = bestand_berufstr.select(pl.col('Mitarbeitende').cast(pl.String))
    bestand_berufstr = pl.select(bestand_berufstr.cast(pl.String)).item()

    # ============================= Neueintritte im Quartal ================================
    df_quartal = df_quartal.filter(pl.col('anstell') >= datetime(year, start_month, 1))
    df_quartal = df_quartal.with_columns(
        pl.col("Mitarbeitende").ceil().cast(pl.Int64)
    )
    quartal_fte = df_quartal.clone()
    quartal_fte = quartal_fte.select(pl.col('Mitarbeitende').len())
    quartal_fte = pl.select(quartal_fte.cast(pl.String)).item()

    # ============================= Neueintritte im Vorherigen Quartal ================================
    df_prev_quartal = df_import_prev_quartal.clone()
    df_prev_quartal = df_prev_quartal.with_columns(pl.lit(1).alias('Mitarbeitende'))
    df_prev_quartal = df_prev_quartal.filter(pl.col('anstell') >= datetime(prev_year, prev_start_month, 1))
    df_prev_quartal = df_prev_quartal.with_columns(
        pl.col("Mitarbeitende").ceil().cast(pl.Int64)
    )
    prev_quartal_fte = df_prev_quartal.clone()
    prev_quartal_fte = prev_quartal_fte.select(pl.col('Mitarbeitende').len())
    prev_quartal_fte = pl.select(prev_quartal_fte.cast(pl.String)).item()

    # ============================= Neueintritte nach Abteilung ================================
    quartal_abteilung = df_quartal.group_by(['Abteilung']).agg(pl.col('Mitarbeitende').sum()).sort('Abteilung')

    # ============================= Neueintritte nach Standort ================================
    quartal_standort = df_quartal.group_by(['Standort']).agg(pl.col('Mitarbeitende').sum()).sort('Standort')

    # ============================= Neueintritte als Quote ================================
    quartal_quote = float(quartal_fte) / float(headcount) * 100
    quartal_quote = round(quartal_quote, 2)
    quartal_quote = str(quartal_quote) + '%'

    # ============================= Vorherige Neueintritte als Quote ================================
    prev_quartal_quote = float(prev_quartal_fte) / float(headcount_prev_quartal) * 100
    prev_quartal_quote = round(prev_quartal_quote, 2)
    prev_quartal_quote = str(prev_quartal_quote) + '%'

    # ============================= Neueintritte Vorjahresvergleich ================================
    quartal_vorjahr_eintritt = df_vorjahr.filter(pl.col('anstell') >= datetime(year - 1, start_month, 1))
    quartal_vorjahr_eintritt = quartal_vorjahr_eintritt.filter(
        pl.col('anstell') <= datetime(year - 1, end_month, end_day))
    quartal_vorjahr_fte = quartal_vorjahr_eintritt.select(pl.sum('Mitarbeitende').round(2))
    quartal_vorjahr_fte = pl.select(quartal_vorjahr_fte.cast(pl.String)).item()

    quartal_vorjahr_eintritt_vergleich = pl.DataFrame({
        "Jahr": [f'{year - 1} in {quartal}', f'{year} in {quartal}'],
        "Mitarbeitende": [quartal_vorjahr_fte, quartal_fte]
    })

    # ============================= Austritte  ================================
    df_austritte = (df_austritte
                    .filter(pl.col('Austrittsdatum') >= datetime(year, start_month, 1)))
    df_austritte = df_austritte.filter(pl.col('Austrittsdatum') <= datetime(year, end_month, end_day))

    # ============================= Vorherige Austritte  ================================
    df_prev_austritte = (df_prev_austritte
                         .filter(pl.col('Austrittsdatum') >= datetime(prev_year, prev_start_month, 1)))
    df_prev_austritte = df_prev_austritte.filter(
        pl.col('Austrittsdatum') <= datetime(prev_year, prev_end_month, prev_end_day))

    # ============================= Austritte Gesammtzahl ================================
    df_gesamt_austritte = df_austritte.clone()
    df_gesamt_austritte = df_gesamt_austritte.select(pl.col('Austrittsdatum')).count()
    df_gesamt_austritte = pl.select(df_gesamt_austritte.cast(pl.String)).item()

    # ============================= Vorherige Austritte Gesammtzahl ================================
    df_prev_gesamt_austritte = df_prev_austritte.clone()
    df_prev_gesamt_austritte = df_prev_gesamt_austritte.select(pl.col('Austrittsdatum')).count()
    df_prev_gesamt_austritte = pl.select(df_prev_gesamt_austritte.cast(pl.String)).item()

    # ============================= Austritte nach Abteilung ================================
    df_austritte_abteilung = df_austritte.clone()
    df_austritte_abteilung = df_austritte_abteilung.group_by(['Abteilung']).agg(pl.len().alias('Anzahl Austritte')).sort(pl.col("Abteilung"))

    # ============================= Austritte nach Standort ================================
    df_austritte_standort = df_austritte.clone()
    df_austritte_standort = df_austritte_standort.group_by(['Standort']).agg(pl.len().alias('Anzahl Austritte')).sort(pl.col("Standort"))

    # ============================= Austritte als Quote ================================
    austritte_quote = float(df_gesamt_austritte) / float(headcount) * 100
    austritte_quote = round(austritte_quote, 2)
    austritte_quote = str(austritte_quote) + '%'

    # ============================= Vorherige Austritte als Quote ================================
    prev_austritte_quote = float(df_prev_gesamt_austritte) / float(headcount_prev_quartal) * 100
    prev_austritte_quote = round(prev_austritte_quote, 2)
    prev_austritte_quote = str(prev_austritte_quote) + '%'

    # ============================= Austritte Vorjahresvergleich ================================
    quartal_vorjahr_austritte = df_vorjahr.filter(pl.col('Austrittsdatum') >= datetime(year - 1, start_month, 1))
    quartal_vorjahr_austritte = quartal_vorjahr_austritte.filter(
        pl.col('Austrittsdatum') <= datetime(year - 1, end_month, end_day))
    quartal_vorjahr_austritte = quartal_vorjahr_austritte.select(pl.sum('Mitarbeitende').round(2))
    quartal_vorjahr_austritte = pl.select(quartal_vorjahr_austritte.cast(pl.String)).item()
    quartal_vorjahr_austritte_vergleich = pl.DataFrame({
        "Jahr": [f'{year - 1} in {quartal}', f'{year} in {quartal}'],
        "Mitarbeitende": [quartal_vorjahr_austritte, df_gesamt_austritte]
    })

    # ============================= Austritte Betriebszugehörigkeit ================================
    df_austritte_betriebs = df_austritte.clone()
    df_austritte_betriebs = df_austritte_betriebs.with_columns(
        pl.when(pl.col("anstell") >= (pl.col("Austrittsdatum") - pl.duration(weeks=26)))
        .then(pl.lit("Unter 6 Monate"))
        .when(pl.col("anstell") >= (pl.col("Austrittsdatum") - pl.duration(weeks=104)))
        .then(pl.lit("6 Monate bis 2 Jahre"))
        .when(pl.col("anstell") >= (pl.col("Austrittsdatum") - pl.duration(weeks=260)))
        .then(pl.lit("2 bis 5 Jahre"))
        .otherwise(pl.lit("Über 5 Jahre"))
        .alias("Betriebszugehörigkeit")
    )
    df_austritte_betriebs = (
        df_austritte_betriebs
        .group_by(["Abteilung", "Betriebszugehörigkeit"])
        .agg(pl.len().alias("Anzahl"))
        .pivot(
            values="Anzahl",
            index="Abteilung",
            on="Betriebszugehörigkeit",
            aggregate_function="first"
        )
        .fill_null(0)
    )
    all_columns = ["Unter 6 Monate", "6 Monate bis 2 Jahre", "2 bis 5 Jahre", "Über 5 Jahre"]
    df_austritte_betriebs = df_austritte_betriebs.with_columns(
        [
            pl.col(col).fill_null(0).alias(col) if col in df_austritte_betriebs.columns else pl.lit(0).alias(col)
            for col in all_columns
        ]
    ).select(["Abteilung"] + all_columns).sort(pl.col("Abteilung"))
    gesamt_row = (
        df_austritte_betriebs.select(all_columns)
        .sum()
        .with_columns(pl.lit("Gesamt").alias("Abteilung"))
    )
    df_austritte_betriebs = pl.concat([df_austritte_betriebs, gesamt_row], how="diagonal")

    # ============================= Austritte Grund ================================
    df_austritte_grund = df_austritte.clone()
    df_austritte_grund = df_austritte_grund.filter(
        (pl.col('Austrittsart').str.contains(r'[A-Za-z]')) |
        (pl.col('Austrittsgrund').str.contains(r'[A-Za-z]')) |
        (pl.col('Mitteilungsdatum').str.contains(r'[0-9]'))
    )
    df_austritte_grund = df_austritte_grund.with_columns(
        pl.col("Austrittsdatum")
        .dt.strftime("%d.%m.%Y")
        .alias("Austrittsdatum")
    )

    df_austritte_grund = df_austritte_grund.with_columns(
        pl.col("Mitteilungsdatum")
        .str.strptime(pl.Datetime, "%Y-%m-%d %H:%M:%S")
        .dt.strftime("%d.%m.%Y")
        .alias("Mitteilungsdatum")
    )
    df_austritte_grund = df_austritte_grund.with_columns(
        pl.when(pl.col('Austrittsart').str.contains(r'[A-Za-z]'))
        .then(pl.col("Austrittsart"))
        .otherwise(pl.lit("Keine Austrittsart vorhanden")),
    )
    df_austritte_grund = df_austritte_grund.with_columns(
        pl.when(pl.col('Austrittsgrund').str.contains(r'[A-Za-z]'))
        .then(pl.col("Austrittsgrund"))
        .otherwise(pl.lit("Kein Austrittsgrund vorhanden")),
    )
    df_austritte_grund = df_austritte_grund.with_columns(
        pl.when(pl.col('Mitteilungsdatum').str.contains(r'[0-9]'))
        .then(pl.col("Mitteilungsdatum"))
        .otherwise(pl.lit("Kein Datum vorhanden"))
    )
    df_austritte_grund = df_austritte_grund.select(
        ['Vorname', 'Nachname', 'Abteilung', 'Standort', 'Austrittsart', 'Austrittsgrund', 'Mitteilungsdatum',
         'Austrittsdatum']).sort(pl.col("Abteilung"))

    df_austritte_art_chart = df_austritte.clone()
    df_austritte_art_chart = df_austritte_art_chart.group_by(['Austrittsart']).agg(pl.len().alias('Anzahl Austritte'))

    df_austritte_gruende_chart = df_austritte.clone()
    df_austritte_gruende_chart = df_austritte_gruende_chart.group_by(['Austrittsgrund']).agg(
        pl.len().alias('Anzahl Austritte'))
    df_austritte_gruende_chart = df_austritte_gruende_chart.with_columns(
        pl.when(pl.col('Austrittsgrund').str.contains(r'[A-Za-z]'))
        .then(pl.col("Austrittsgrund"))
        .otherwise(pl.lit("Kein Austrittsgrund vorhanden"))
    ).group_by(['Austrittsgrund']).agg(pl.sum('Anzahl Austritte').alias('Anzahl Austritte'))

    # ============================= Austritte Zukunft ================================
    df_zukunft = df_zukunft.filter(pl.col('Austrittsdatum') >= next_month_date)
    df_zukunft = df_zukunft.filter(pl.col('Austrittsdatum') <= datetime(year + 1, end_month, end_day))

    # ============================= Austritte Zukunft Gesammtzahl ================================
    df_gesamt_zukunft = df_zukunft.clone()
    df_gesamt_zukunft = df_gesamt_zukunft.select(pl.col('Austrittsdatum')).count()
    df_gesamt_zukunft = pl.select(df_gesamt_zukunft.cast(pl.String)).item()

    # ============================= Austritte Zukunft nach Standort ================================
    df_austritte_abteilung_zukunft = df_zukunft.clone()
    df_austritte_abteilung_zukunft = df_austritte_abteilung_zukunft.group_by(['Abteilung']).agg(
        pl.len().alias('Anzahl Zukünftiger Austritte')).sort(pl.col("Abteilung"))

    # ============================= Austritte Zukunft nach Standort ================================
    df_austritte_standort_zukunft = df_zukunft.clone()
    df_austritte_standort_zukunft = df_austritte_standort_zukunft.group_by(['Standort']).agg(
        pl.len().alias('Anzahl Zukünftiger Austritte')).sort(pl.col("Standort"))

    # ============================= Austritte Zukunft als Quote ================================
    austritte_quote_zukunft = float(df_gesamt_zukunft) / float(fte) * 100
    austritte_quote_zukunft = round(austritte_quote_zukunft, 2)
    austritte_quote_zukunft = str(austritte_quote_zukunft) + '%'

    # ============================= Austritte Zukunft Betriebszugehörigkeit ================================
    df_austritte_zukunft_betriebs = df_zukunft.clone()
    df_austritte_zukunft_betriebs = df_austritte_zukunft_betriebs.with_columns(
        pl.when(pl.col("anstell") >= (pl.col("Austrittsdatum") - pl.duration(weeks=26)))
        .then(pl.lit("Unter 6 Monate"))
        .when(pl.col("anstell") >= (pl.col("Austrittsdatum") - pl.duration(weeks=104)))
        .then(pl.lit("6 Monate bis 2 Jahre"))
        .when(pl.col("anstell") >= (pl.col("Austrittsdatum") - pl.duration(weeks=260)))
        .then(pl.lit("2 bis 5 Jahre"))
        .otherwise(pl.lit("Über als 5 Jahre"))
        .alias("Betriebszugehörigkeit")
    )
    df_austritte_zukunft_betriebs = (
        df_austritte_zukunft_betriebs
        .group_by(["Abteilung", "Betriebszugehörigkeit"])
        .agg(pl.len().alias("Anzahl"))
        .pivot(
            values="Anzahl",
            index="Abteilung",
            on="Betriebszugehörigkeit",
            aggregate_function="first"
        )
        .fill_null(0)
    )
    all_columns = ["Unter 6 Monate", "6 Monate bis 2 Jahre", "2 bis 5 Jahre", "Über 5 Jahre"]
    df_austritte_zukunft_betriebs = df_austritte_zukunft_betriebs.with_columns(
        [pl.col(col).fill_null(0).alias(col) if col in df_austritte_zukunft_betriebs.columns else pl.lit(0).alias(col)
         for
         col in all_columns]
    ).select(["Abteilung"] + all_columns).sort(pl.col("Abteilung"))
    gesamt_row_future = (
        df_austritte_zukunft_betriebs.select(all_columns)
        .sum()
        .with_columns(pl.lit("Gesamt").alias("Abteilung"))
    )
    df_austritte_zukunft_betriebs = pl.concat([df_austritte_zukunft_betriebs, gesamt_row_future], how="diagonal")

    # ============================= Krankheit nach Abteilung ================================
    try:
        df_krankheit_abteilung = pl.read_excel(file2, infer_schema_length=0,
                                               has_header=True)
    except FileNotFoundError as e:
        raise Exception("Die Krankheitsquote nach Abteilung Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e

    krankheit_df = df_krankheit_abteilung.filter(
        pl.col("Abwesenheitsart") == "Krankheit"
    ).drop("Abwesenheitsart")

    krankheit_df = krankheit_df.with_columns([
        pl.col(col)
        .cast(str)
        .str.strip_chars()
        .replace("", None)
        .cast(pl.Float64)
        .fill_null(0.0)
        .alias(col)
        for col in months if col in krankheit_df.columns
    ])
    krankheit_df = krankheit_df.group_by("Abteilung").agg([
        pl.sum(col).alias(col) for col in months
    ])
    df_krankheit_abteilung = krankheit_df.with_columns([
        ((pl.sum_horizontal([pl.col(col) for col in months])) * 100).round(2).alias("Krankheitsquote")
    ]).drop(months)
    df_krankheit_abteilung = df_krankheit_abteilung.with_columns(
        (pl.col("Krankheitsquote") / 3).round(2).alias("Krankheitsquote")
    )
    average_quote = df_krankheit_abteilung["Krankheitsquote"].mean()
    durchschnitt_row = (
        pl.DataFrame({
            "Abteilung": ["Durchschnitt"],
            "Krankheitsquote": [average_quote]
        })
    )
    df_krankheit_abteilung = pl.concat([df_krankheit_abteilung, durchschnitt_row])
    df_krankheit_abteilung = df_krankheit_abteilung.with_columns(
        pl.col("Krankheitsquote").cast(pl.Float64)
    )
    df_krankheit_abteilung = df_krankheit_abteilung.sort(pl.col("Krankheitsquote"), descending=True)
    df_krankheit_abteilung = df_krankheit_abteilung.with_columns(
        df_krankheit_abteilung["Krankheitsquote"].map_elements(lambda x: f"{x:.2f}", return_dtype=pl.Utf8)
    )

    # ============================= Krankheit nach Standort ================================
    try:
        df_krankheit_standort = pl.read_excel(file3, infer_schema_length=0,
                                              has_header=True)
    except FileNotFoundError as e:
        raise Exception("Die Krankheitsquote nach Standort Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e

    # Calculate the average
    df_krankheit_standort = df_krankheit_standort.with_columns([
        pl.col(col)
        .cast(str)  # Cast to string to operate on text
        .str.strip_chars()  # Remove whitespace
        .replace("", None)  # replace "" with null
        .cast(pl.Float64)  # Convert to float
        .fill_null(0.0)  # Replace nulls with 0
        .alias(col)  # Rename the column
        for col in months if col in df_krankheit_standort.columns
    ])

    df_krankheit_standort = df_krankheit_standort.with_columns(
        [pl.sum_horizontal(([pl.col(col) for col in months]) * 100).round(2).alias("Krankheitsquote (Tage)")
         ]).drop(months).filter(pl.col("Standort") != "Test-Standort")
    df_krankheit_standort = (
        df_krankheit_standort
        .group_by("Standort")
        .agg(
            pl.col("Krankheitsquote (Tage)")
            .sum()
            .round(2)
            .alias("Krankheitsquote")
        )
        .sort("Standort")
    )

    df_krankheit_standort = df_krankheit_standort.with_columns(
        (pl.col("Krankheitsquote") / 3).round(2).alias("Krankheitsquote")
    )

    df_krankheit_standort_filtered = df_krankheit_standort.filter(pl.col("Krankheitsquote") != 0)

    df_krankheit_standort = df_krankheit_standort.with_columns(
        df_krankheit_standort["Krankheitsquote"].map_elements(lambda x: f"{x:.2f}", return_dtype=pl.Utf8)
    )

    # ============================= Krankheit nach Geschlecht ================================
    try:
        df_krankheit_geschlecht = pl.read_excel(file4, infer_schema_length=0,
                                              has_header=True)
    except FileNotFoundError as e:
        raise Exception("Die Krankheitsquote nach Geschlecht Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e

    df_krankheit_geschlecht = df_krankheit_geschlecht.with_columns([
        pl.col(col)
        .cast(str)  # Cast to string to operate on text
        .str.strip_chars()  # Remove whitespace
        .replace("", None)  # replace "" with null
        .cast(pl.Float64)  # Convert to float
        .fill_null(0.0)  # Replace nulls with 0
        .alias(col)  # Rename the column
        for col in months if col in df_krankheit_geschlecht.columns
    ])

    df_krankheit_geschlecht = df_krankheit_geschlecht.with_columns(
        [pl.sum_horizontal(([pl.col(col) for col in months]) * 100).round(2).alias("Krankheitsquote (Tage)")
         ]).drop(months)
    df_krankheit_geschlecht = (
        df_krankheit_geschlecht
        .group_by("Geschlecht")
        .agg(
            pl.col("Krankheitsquote (Tage)")
            .sum()
            .round(2)
            .alias("Krankheitsquote")
        )
        .sort("Geschlecht")
    )

    df_krankheit_geschlecht = df_krankheit_geschlecht.with_columns(
        (pl.col("Krankheitsquote") / 3).round(2).alias("Krankheitsquote")
    )

    df_krankheit_geschlecht = df_krankheit_geschlecht.with_columns(
        df_krankheit_geschlecht["Krankheitsquote"].map_elements(lambda x: f"{x:.2f}", return_dtype=pl.Utf8)
    )

    # ============================= Graphen erstellen ================================
    try:
        docu = Document(str(file5))
    except FileNotFoundError as e:
        raise Exception("Die Krankheitsquote nach Abteilung Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e

    replace_title(docu=docu, value=quartal_wert, placeholder='[quartal_wert]')

    # Dynamische Quartale
    replace_value(docu=docu, value=quartal, placeholder='[quartal]')

    # Personalbestand
    replace_value(docu=docu, value=fte, placeholder='[fte]')
    replace_value(docu=docu, value=headcount, placeholder='[value_bestand]')
    replace_value(docu=docu, value=headcount_vorjahr, placeholder='[table_bestand_vj]')
    replace_table(docu=docu, df=bestand_standort, placeholder='[table_locations]')
    replace_table(docu=docu, df=bestand_abteilung, placeholder='[table_abteilung]')
    replace_table(docu=docu, df=bestand_geschlecht, placeholder='[table_gender]')
    replace_value(docu=docu, value=bestand_berufstr, placeholder='[value_berufstr]')
    replace_bar_chart(docu=docu, values=[int(headcount_vorjahr), int(headcount)],
                      labels=['Vorjahr', 'aktueller Zeitraum'], placeholder='[bar_chart_bestand]')
    replace_pie_chart(docu=docu, values=bestand_geschlecht['Mitarbeitende'],
                      labels=bestand_geschlecht['Geschlecht'], placeholder='[pie_chart_gender]')
    # Neueintritte
    replace_value(docu=docu, value=quartal_fte, placeholder='[value_neu]')
    replace_table(docu=docu, df=quartal_vorjahr_eintritt_vergleich, placeholder='[table_neu_vj]')
    replace_bar_chart(docu=docu, values=[int(quartal_vorjahr_fte), int(quartal_fte)],
                      labels=['Vorjahr', 'aktueller Zeitraum'], placeholder='[bar_chart_neu]')
    replace_value(docu=docu, value=quartal_quote, placeholder='[quote_neu]')
    replace_value(docu=docu, value=prev_quartal_quote, placeholder='[quote_prev_neu]')
    replace_table(docu=docu, df=quartal_standort, placeholder='[table_neu_loc]')
    replace_table(docu=docu, df=quartal_abteilung, placeholder='[table_neu_abteilung]')

    # Austritte
    replace_value(docu=docu, value=df_gesamt_austritte, placeholder='[value_raus]')
    replace_table(docu=docu, df=quartal_vorjahr_austritte_vergleich, placeholder='[table_raus_vj]')
    replace_bar_chart(docu=docu, values=[int(quartal_vorjahr_austritte), int(df_gesamt_austritte)],
                      labels=['Vorjahr', 'aktueller Zeitraum'], placeholder='[bar_chart_raus]')
    replace_value(docu=docu, value=austritte_quote, placeholder='[quote_raus]')
    replace_value(docu=docu, value=prev_austritte_quote, placeholder='[quote_prev_raus]')
    replace_table(docu=docu, df=df_austritte_standort, placeholder='[table_raus_loc]')
    replace_table(docu=docu, df=df_austritte_abteilung, placeholder='[table_raus_abteilung]')
    replace_table(docu=docu, df=df_austritte_betriebs, placeholder='[table_raus_dauer]')
    replace_table(docu=docu, df=df_austritte_grund, placeholder='[table_raus_grund]')
    replace_pie_chart(docu=docu, values=df_austritte_art_chart['Anzahl Austritte'],
                      labels=df_austritte_art_chart['Austrittsart'], placeholder='[pie_chart_exit_type]')
    replace_pie_chart(docu=docu, values=df_austritte_gruende_chart['Anzahl Austritte'],
                      labels=df_austritte_gruende_chart['Austrittsgrund'], placeholder='[pie_chart_exit_reason]')

    # Austritte
    replace_value(docu=docu, value=df_gesamt_zukunft, placeholder='[forecast_raus]')
    replace_value(docu=docu, value=austritte_quote_zukunft, placeholder='[forecast_quote]')
    replace_table(docu=docu, df=df_austritte_standort_zukunft, placeholder='[forecast_raus_loc]')
    replace_table(docu=docu, df=df_austritte_abteilung_zukunft, placeholder='[forecast_raus_abteilung]')
    replace_table(docu=docu, df=df_austritte_zukunft_betriebs, placeholder='[forecast_raus_dauer]')

    # Krankheit
    replace_table(docu=docu, df=df_krankheit_standort, placeholder='[table_krank_loc]')

    replace_bar_chart(docu=docu, values=df_krankheit_standort_filtered['Krankheitsquote'],
                      labels=df_krankheit_standort_filtered['Standort'], placeholder='[pie_chart_krank_loc]')

    replace_table(docu=docu, df=df_krankheit_abteilung, placeholder='[table_krank_abteilung]')

    replace_table(docu=docu, df=df_krankheit_geschlecht, placeholder='[table_krank_geschlecht]')

    output_path = generate_tool_output_path(
        user_id=user_id,
        filename=f"HR_Reporting_{quartal}",
        tool="HR_Report",
        variant="default",
        task_id=task.request.id,
        extension="docx",
    )

    ensure_output_folder(output_path)

    docu.save(str(output_path))

    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
