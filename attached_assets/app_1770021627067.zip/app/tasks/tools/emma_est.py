import asyncio
import json
import os
from email.message import EmailMessage

from app.core.logger import logger
from app.tasks.tool_registry import register_tool
from app.utils.email_utils import send_email


def create_email(data: dict, cc: str) -> EmailMessage:
    email_message_user = EmailMessage()
    email_message_user["From"] = os.environ["EMAIL_SENDER"]
    email_message_user["To"] = os.environ["EMAIL_RECEIVER_EMMA"]
    if data.get("rechnung") and data.get("cc"):
        email_message_user["Cc"] = data["cc"]



    subject = f"***ESt {data['year']}, {data['mandantennummer']}_{data['mandant_nachname']}, {data['mandant_vorname']}"
    email_message_user["Subject"] = subject

    plain_body = (
        f"Liebes DocuSign-Team,\n\n"
        f"oben genannte Einkommensteuererklärung (#{data['mandantennummer']}) ist bereit zum Versand. Folgende Angaben sind für DocuSign zu berücksichtigen:"
        f"\n\nLinksunterzeichner der Bescheinigung: {data['linksunterzeichner_kso_nachname']}, {data['linksunterzeichner_kso_vorname']}"
        f"\n\nRechtsunterzeichner der Bescheinigung: {data['rechtsunterzeichner_kso_nachname']}, {data['rechtsunterzeichner_kso_vorname'] if data['anzahl_unterzeichner_kso'] == '2' else ''}"
        f"\n\nName des E-Mailabsenders: {data['absender']}"
        f"\n\nUNTERZEICHNER 1:"
        f"\nMandant-Unterzeichner (Steuerpflichtiger):"
        f"\n\nName1: {data['mandant_unterzeichner1']}"
        f"\nE-Mail1: {data['mandant_email1']}"
        f"\n\nSMS-Authentifizierung?"
        f"\n\n{'☒ Ja, die Mobilnummer lautet wie folgt: ' + data['mandant_mobil1'] if data['mandant_sms1'] else '☐ Ja, die Mobilnummer lautet wie folgt:'}"
        f"\n\n{'☒ Nein, das Mandantenpasswort lautet wie folgt: ' + data['mandant_pw1'] if not data['mandant_sms1'] else '☐ Nein, das Mandantenpasswort lautet wie folgt:'}"
        f"\n\nUNTERZEICHNER 2:"
        f"\nMandant-Unterzeichner (Ehegatte):"
        f"\n\nName2: {data['mandant_unterzeichner2']}"
        f"\nE-Mail2: {data['mandant_email2']}"
        f"\n\nSMS-Authentifizierung?"
        f"\n\n{'☒ Ja, die Mobilnummer lautet wie folgt: ' + data['mandant_mobil2'] if data['mandant_sms2'] else '☐ Ja, die Mobilnummer lautet wie folgt:'}"
        f"\n\n{'☒ Nein, das Mandantenpasswort lautet wie folgt: ' + data['mandant_pw2'] if not data['mandant_sms2'] else '☐ Nein, das Mandantenpasswort lautet wie folgt:'}"
        f"\n\nSoll eine Rechnung geschrieben werden?"
        f"\n\n{'Nein' if not data['rechnung'] else '☐ Nein'}"
        f"\n\n{'Ja' if data['rechnung'] else '☐ Ja'}"
    )

    # HTML-Version für besseres Format
    html_body = f"""
    <html>
      <head>
        <style>
          body {{
            font-family: Calibri, sans-serif;
            font-size: 11pt;
          }}
        </style>
      </head>
      <body>
        <p>Liebes DocuSign-Team,<br><br>
        oben genannte Einkommensteuererklärung (<b>#{data["mandantennummer"]}</b>) ist bereit zum Versand. Folgende Angaben sind für DocuSign zu berücksichtigen:<br><br>

        <b>Linksunterzeichner der Bescheinigung:</b> {data["linksunterzeichner_kso_nachname"]}, {data["linksunterzeichner_kso_vorname"]}<br>
        {f"<b>Rechtsunterzeichner der Bescheinigung:</b> {data['rechtsunterzeichner_kso_nachname']}, {data['rechtsunterzeichner_kso_vorname']}<br><br>" if data["anzahl_unterzeichner_kso"] == "2" else ""}<br>
        <b>Name des E-Mailabsenders:</b> {data["absender"]}<br><br>
        
        <b>Zur Freigabe an:</b> {data["freigabe"]}<br><br>

        <b>UNTERZEICHNER 1:</b><br>
        <b>Mandant-Unterzeichner Steuerpflichtiger:</b><br><br>
        Anrede: {data["mandant_geschlecht1"]}<br>
        Titel: {data["mandant_titel1"]}<br>
        Name: {data["mandant_unterzeichner1"]}<br>
        E-Mail: {data["mandant_email1"]}<br><br>

        <b>SMS-Authentifizierung?</b><br>
        {"☒ Ja, Mobilnummer: " + data["mandant_mobil1"] if data["mandant_sms1"] else "☐ Ja, Mobilnummer:"}<br>
        {"☒ Nein, Passwort: " + data["mandant_pw1"] if not data["mandant_sms1"] else "☐ Nein, Passwort:"}<br><br>


        {"<b>UNTERZEICHNER 2:</b><br>" if data["anzahl_unterzeichner_mandant"] == "2" else ""}
        {"<b>Mandant-Unterzeichner 2:</b><br><br>" if data["anzahl_unterzeichner_mandant"] == "2" else ""}
        {f"Anrede: {data['mandant_geschlecht2']}<br>" if data["anzahl_unterzeichner_mandant"] == "2" else ""}
        {f"Titel: {data['mandant_titel2']}<br>" if data["anzahl_unterzeichner_mandant"] == "2" else ""}
        {f"Name: {data['mandant_unterzeichner2']}<br>" if data["anzahl_unterzeichner_mandant"] == "2" else ""}
        {f"E-Mail: {data['mandant_email2']}<br><br>" if data["anzahl_unterzeichner_mandant"] == "2" else ""}


        {"<b>SMS-Authentifizierung?</b><br>" if data["anzahl_unterzeichner_mandant"] == "2" else ""}
        {f"{'☒ Ja, Mobilnummer: ' + data['mandant_mobil2'] if data['mandant_sms2'] else '☐ Ja, Mobilnummer:'}<br>" if data["anzahl_unterzeichner_mandant"] == "2" else ""}
        {f"{'☒ Nein, Passwort: ' + data['mandant_pw2'] if not data['mandant_sms2'] else '☐ Nein, Passwort:'}<br><br>" if data["anzahl_unterzeichner_mandant"] == "2" else ""}

        <br><br>
        <b>Anschreiben:</b> {data["anschreiben"]}<br><br>
        
        <b>Soll eine Rechnung geschrieben werden?</b><br>
        {"☒ Ja<br> ☐ Nein" if data["rechnung"] else "☒ Nein<br> ☐ Ja"}<br><br>

        <b>Soll die Steuererklärung nach Unterzeichnung des Mandanten vom DocuSign-Team übermittelt werden??</b><br>
        {"☒ Ja<br> ☐ Nein" if data["docusign"] else " ☐ Ja<br> ☒ Nein (In diesem Fall übernimmt der Sachbearbeiter die Übermittlung selbst.)"} <br><br>

        <b>Gibt es Besonderheiten, die bei dem Versand beachtet werden müssen?</b><br>
        {f"☒ Ja<br> ☐ Nein <br><br>Sonstige Hinweise: {data['hinweis_text']}" if data["hinweise"] else " ☐ Ja<br> ☒ Nein"}

        </p>
      </body>
    </html>
    """

    # Inhalte setzen
    email_message_user.set_content(plain_body)
    email_message_user.add_alternative(html_body, subtype="html")

    return email_message_user


def create_confirm_mail(recipient: str, user_name: str, data: dict) -> EmailMessage:
    email_message_confirm = EmailMessage()
    email_message_confirm["From"] = os.environ["EMAIL_SENDER"]
    email_message_confirm["To"] = [recipient]
    auftrag = f"***ESt {data['year']}, {data['mandantennummer']}_{data['mandant_nachname']}, {data['mandant_vorname']}"
    subject = f"Bestätigung deiner Übermittlung: {auftrag}"
    email_message_confirm["Subject"] = subject
    name = user_name.split(",", 1)[1]
    content_fallback = (
        f"Hallo {name},\n\nvielen Dank für die Übermittlung deines Auftrages: {auftrag}.\nDas DocuSign-Team kümmert sich nun um die weiteren Schritte.\n\n\nViele Grüße\nJulian Michalak | Softwareentwicklung\n"
    )

    content = f"""
    <html>
      <body>
        <p>Hallo {name},</p>

        <p>
          vielen Dank für die Übermittlung deines Auftrages:
          <strong>{auftrag}</strong>.
          <br>
          Das DocuSign-Team kümmert sich nun um die weiteren Schritte.
        </p>
        <br>
        <p>
          <em>Viele Grüße<br></em>
          <em>Julian Michalak | Softwareentwicklung</em>

        </p>
      </body>
    </html>
    """

    email_message_confirm.set_content(content_fallback)
    email_message_confirm.add_alternative(content, subtype="html")

    return email_message_confirm


@register_tool(
    tool="emma_est",
    variant="default",
    description="emma_est default conversion",
    input_type={
        "json_data": str,
    },
    output_type="email",
)
def emma_est(task, json_data):
    user_id = task.request.headers.get("user_id")
    user_name = task.request.headers.get("user_name")
    user_email = task.request.headers.get("user_email")

    data = json.loads(json_data)
    data["absender"] = user_name

    """
    Mail soll standardmäßig an emma.kso@ecovis-kso.com gesendet werden.
    """

    try:
        logger.info("📧 Sending email to emma.kso@ecovis-kso.com")
        email_emma = create_email(data=data, cc=user_email)
        confirm_email_user = create_confirm_mail(recipient=user_email, user_name=user_name, data=data)
        asyncio.run(send_email([email_emma, confirm_email_user]))
        return {"message": "Email sent successfully", "file_name": data["mandantennummer"], "user_id": user_id}
    except Exception as e:
        logger.exception(f"❌ Failed to send email to emma.kso@ecovis-kso.com - Error: {e}")
        raise e
