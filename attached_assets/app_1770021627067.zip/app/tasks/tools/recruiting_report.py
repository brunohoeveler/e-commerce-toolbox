from datetime import datetime
from pathlib import Path
import polars as pl
from docx import Document
from fastapi import UploadFile
from app.tasks.tool_registry import register_tool
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_tool_output_path, strip_task_id
from app.utils.tool_utils import replace_value, replace_table, replace_pie_chart, replace_bar_chart, replace_title


@register_tool(
    tool="Recruiting",
    variant="report_quartal",
    description="Quartal Recruiting-Report",
    input_type={
        "quarter": (int, {"description": "Quarter in Q format", "min": 1, "max": 4}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
                list[UploadFile],
                {
                    "min_files": 2,
                    "max_files": 2,
                    "extensions": ["xlsx", "xls", "docx"],
                },
        ),
    },
    output_type="xlsx",
)
def recruiting_report(task, quarter: int, year: int, files: list[Path]):
    def filter_by_quartal(quarter, year):
        months = [
            f"Januar {year}", f"Februar {year}", f"März {year}",
            f"April {year}", f"Mai {year}", f"Juni {year}",
            f"Juli {year}", f"August {year}", f"September {year}",
            f"Oktober {year}", f"November {year}", f"Dezember {year}"
        ]

        quartal_map = {
            'q1': months[0:3],  # Jan - Mär
            'q2': months[3:6],  # Apr - Juni
            'q3': months[6:9],  # Juli - Sep
            'q4': months[9:12]  # Okt - Dez
        }
        return quartal_map.get(quarter.lower(), [])

    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]
    quartal = f"Q{quarter}"

    quartal_wert = quartal + ' ' + str(year)
    quartal_months = filter_by_quartal(quartal, year)
    prev_year_quartal = filter_by_quartal(quartal, year - 1)

    # ========================== IMPORT DATEI ==========================
    try:
        df_import = pl.read_excel(file1, read_options={"header_row": None}).slice(2)
    except FileNotFoundError as e:
        raise Exception("Die Report Daten Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e

    raw_header = df_import.row(0)  # tuple
    cols = df_import.columns

    # 1) determine the last index for each usable header value (ignoring 'summe')
    last_idx = {}
    for i, h in enumerate(raw_header):
        if h is None:
            continue
        name = str(h).strip()
        if not name or "summe" in name.casefold():
            continue
        last_idx[name] = i  # overwrite -> last/rightmost wins

    # 2) drop earlier duplicates (same header value, not the last index)
    drop_cols = []
    for i, h in enumerate(raw_header):
        if h is None:
            continue
        name = str(h).strip()
        if not name or "summe" in name.casefold():
            continue
        if i != last_idx[name]:
            drop_cols.append(cols[i])

    if drop_cols:
        df_import = df_import.drop(drop_cols)

    # 3) rebuild header & columns after drop, then rename from remaining header row
    header = df_import.row(0)
    cols = df_import.columns

    rename_map = {}
    used_targets = set()
    for old, h in zip(cols, header):
        if h is None:
            continue
        name = str(h).strip()
        if not name or "summe" in name.casefold():
            continue
        # uniqueness guard (shouldn’t trigger after dropping earlier duplicates, but safe anyway)
        base, n, tgt = name, 1, name
        while tgt in used_targets:
            n += 1
            tgt = f"{base}_{n}"
        used_targets.add(tgt)
        rename_map[old] = tgt

    # drop the header row from the data and apply rename
    df_import = df_import.slice(1).rename(rename_map)

    # Optional: drop columns whose (final) name contains 'unnamed'
    df_import = df_import.drop([c for c in df_import.columns if "column" in c.casefold()])

    # 3) rename date-like columns AFTER the first → "Monat YYYY"
    GER_MONTHS = ["Januar", "Februar", "März", "April", "Mai", "Juni",
                  "Juli", "August", "September", "Oktober", "November", "Dezember"]

    def month_key(name: str):
        s = str(name).strip()
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
            try:
                d = datetime.strptime(s, fmt)
                return (d.year, d.month)
            except ValueError:
                pass
        try:
            d = datetime.fromisoformat(s)
            return (d.year, d.month)
        except Exception:
            return None

    # 1) last occurrence wins
    last_for_key = {}
    for c in df_import.columns[1:]:  # skip first column
        key = month_key(c)
        if key is not None:
            last_for_key[key] = c  # overwrite keeps the rightmost

    # 2) drop earlier duplicates
    keep_last = set(last_for_key.values())
    to_drop = [c for c in df_import.columns[1:] if month_key(c) is not None and c not in keep_last]
    if to_drop:
        df_import = df_import.drop(to_drop)

    # 3) rename remaining date-like columns → "Monat YYYY"
    date_renames = {col: f"{GER_MONTHS[m - 1]} {y}" for (y, m), col in last_for_key.items()}
    if date_renames:
        df_import = df_import.rename(date_renames)  # (no extra slice here)

    first = df_import.columns[0]
    df_import = df_import.filter(~pl.col(df_import.columns[0]).str.contains("Intern:"))

    ####################### df chanel #######################
    df_chanel = df_import.clone()
    keep = [first] + [c for c in df_chanel.columns[1:] if c in quartal_months]
    df_chanel = df_chanel.select(keep)
    df_chanel = df_chanel.slice(0, 17)
    df_chanel = df_chanel.rename({first: "Intern"})

    ####################### df chanel prev year #######################
    df_chanel_prev_year = df_import.clone()
    keep = [first] + [c for c in df_chanel_prev_year.columns[1:] if c in prev_year_quartal]
    df_chanel_prev_year = df_chanel_prev_year.select(keep)
    df_chanel_prev_year = df_chanel_prev_year.slice(0, 17)
    df_chanel_prev_year = df_chanel_prev_year.rename({first: "Intern"})

    ####################### df location #######################
    df_location = df_import.clone()
    keep = [first] + [c for c in df_location.columns[1:] if c in quartal_months]
    df_location = df_location.select(keep)
    df_location = df_location.slice(18, 12)
    df_location = df_location.rename({first: "Standort"})

    ####################### df location prev year #######################
    # df_location_prev_year = df_import.clone()
    # keep = [first] + [c for c in df_location_prev_year.columns[1:] if c in prev_year_quartal]
    # df_location_prev_year = df_location_prev_year.select(keep)
    # df_location_prev_year = df_location_prev_year.slice(17, 12)
    # df_location_prev_year = df_location_prev_year.rename({first: "Standort"})

    ####################### df direct approach #######################
    df_direct = df_import.clone()
    keep = [first] + [c for c in df_direct.columns[1:] if c in quartal_months]
    df_direct = df_direct.select(keep)
    df_direct = df_direct.slice(31, 2)
    df_direct = df_direct.rename({first: "Direktansprache"})
    df_direct = df_direct.with_columns(
        pl.Series("Direktansprache", ["LinkedIn", "XING"])
    )

    ####################### df direct approach prev year #######################
    df_direct_prev_year = df_import.clone()
    keep = [first] + [c for c in df_direct_prev_year.columns[1:] if c in prev_year_quartal]
    df_direct_prev_year = df_direct_prev_year.select(keep)
    df_direct_prev_year = df_direct_prev_year.slice(31, 2)
    df_direct_prev_year = df_direct_prev_year.rename({first: "Direktansprache"})
    df_direct_prev_year = df_direct_prev_year.with_columns(
        pl.Series("Direktansprache", ["LinkedIn", "XING"])
    )

    ####################### df ti #######################
    df_ti = df_import.clone()
    keep = [first] + [c for c in df_ti.columns[1:] if c in quartal_months]
    df_ti = df_ti.select(keep)
    df_ti = df_ti.slice(33, 9)
    df_ti = df_ti.rename({first: "Kanal"})
    df_ti = df_ti.with_columns(
        pl.when(pl.col("Kanal").str.contains("Intern Online")
                ).then(pl.lit("Intern Online"))
        .when(pl.col("Kanal").str.contains("Vereinbarte TIs")
              ).then(pl.lit("Gesamt"))
        .when(pl.col("Kanal").str.contains("Extern Online")
              ).then(pl.lit("Extern Online"))
        .otherwise(pl.col("Kanal")).alias("Kanal")
    )

    ####################### df ti approach prev year #######################
    df_ti_prev_year = df_import.clone()
    keep = [first] + [c for c in df_ti_prev_year.columns[1:] if c in prev_year_quartal]
    df_ti_prev_year = df_ti_prev_year.select(keep)
    df_ti_prev_year = df_ti_prev_year.slice(33, 9)
    df_ti_prev_year = df_ti_prev_year.rename({first: "Kanal"})
    df_ti_prev_year = df_ti_prev_year.with_columns(
        pl.when(pl.col("Kanal").str.contains("Intern Online")
                ).then(pl.lit("Intern Online"))
        .when(pl.col("Kanal").str.contains("Vereinbarte TIs")
              ).then(pl.lit("Gesamt"))
        .when(pl.col("Kanal").str.contains("Extern Online")
              ).then(pl.lit("Extern Online"))
        .otherwise(pl.col("Kanal")).alias("Kanal")
    )

    ####################### df vg #######################
    df_vg = df_import.clone()
    keep = [first] + [c for c in df_vg.columns[1:] if c in quartal_months]
    df_vg = df_vg.select(keep)
    df_vg = df_vg.slice(42, 9)
    df_vg = df_vg.rename({first: "Kanal"})
    df_vg = df_vg.with_columns(
        pl.when(pl.col("Kanal").str.contains("Intern Online")
                ).then(pl.lit("Intern Online"))
        .when(pl.col("Kanal").str.contains("Vereinbarte VGs")
              ).then(pl.lit("Gesamt"))
        .when(pl.col("Kanal").str.contains("Extern Online")
              ).then(pl.lit("Extern Online"))
        .otherwise(pl.col("Kanal")).alias("Kanal")
    )

    ####################### df vg approach prev year #######################
    df_vg_prev_year = df_import.clone()
    keep = [first] + [c for c in df_vg_prev_year.columns[1:] if c in prev_year_quartal]
    df_vg_prev_year = df_vg_prev_year.select(keep)
    df_vg_prev_year = df_vg_prev_year.slice(42, 9)
    df_vg_prev_year = df_vg_prev_year.rename({first: "Kanal"})
    df_vg_prev_year = df_vg_prev_year.with_columns(
        pl.when(pl.col("Kanal").str.contains("Intern Online")
                ).then(pl.lit("Intern Online"))
        .when(pl.col("Kanal").str.contains("Vereinbarte VGs")
              ).then(pl.lit("Gesamt"))
        .when(pl.col("Kanal").str.contains("Extern Online")
              ).then(pl.lit("Extern Online"))
        .otherwise(pl.col("Kanal")).alias("Kanal")
    )

    ####################### df av signed #######################
    df_av = df_import.clone()
    keep = [c for c in df_av.columns[1:] if c in quartal_months]
    df_av = df_av.select(keep)
    df_av = df_av.slice(51, 1)

    ####################### df av approach prev year #######################
    df_av_prev_year = df_import.clone()
    keep = [c for c in df_av_prev_year.columns[1:] if c in prev_year_quartal]
    df_av_prev_year = df_av_prev_year.select(keep)
    df_av_prev_year = df_av_prev_year.slice(51, 1)

    ####################### df av pulled #######################
    df_av_pulled = df_import.clone()
    keep = [c for c in df_av_pulled.columns[1:] if c in quartal_months]
    df_av_pulled = df_av_pulled.select(keep)
    df_av_pulled = df_av_pulled.slice(52, 1)

    ####################### df tto #######################
    df_tto = df_import.clone()
    keep = [c for c in df_tto.columns[1:] if c in quartal_months]
    df_tto = df_tto.select(keep)
    df_tto = df_tto.slice(53, 1)

    ####################### df tto prev year #######################
    df_tto_prev_year = df_import.clone()
    keep = [c for c in df_tto_prev_year.columns[1:] if c in prev_year_quartal]
    df_tto_prev_year = df_tto_prev_year.select(keep)
    df_tto_prev_year = df_tto_prev_year.slice(53, 1)

    ####################### df tth #######################
    df_tth = df_import.clone()
    keep = [c for c in df_tth.columns[1:] if c in quartal_months]
    df_tth = df_tth.select(keep)
    df_tth = df_tth.slice(54, 1)

    ####################### df tth prev year #######################
    df_tth_prev_year = df_import.clone()
    keep = [c for c in df_tth_prev_year.columns[1:] if c in prev_year_quartal]
    df_tth_prev_year = df_tth_prev_year.select(keep)
    df_tth_prev_year = df_tth_prev_year.slice(54, 1)

    # ============================= Graphen erstellen ================================
    try:
        docu = Document(str(file2))
    except FileNotFoundError as e:
        raise Exception(
            "Die Krankheitsquote nach Abteilung Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e

    replace_title(docu=docu, value=quartal_wert, placeholder='[quartal_wert]')

    # Dynamische Quartale
    replace_value(docu=docu, value=quartal, placeholder='[quartal]')

    replace_table(docu=docu, df=df_chanel, placeholder='[df_chanel]')
    replace_table(docu=docu, df=df_chanel_prev_year, placeholder='[df_chanel_prev_year]')
    replace_table(docu=docu, df=df_location, placeholder='[df_location]')
    # replace_table(docu=docu, df=df_location_prev_year, placeholder='[df_location_prev_year]')
    replace_table(docu=docu, df=df_direct, placeholder='[df_direct]')
    replace_table(docu=docu, df=df_direct_prev_year, placeholder='[df_direct_prev_year]')
    replace_table(docu=docu, df=df_ti, placeholder='[df_ti]')
    replace_table(docu=docu, df=df_ti_prev_year, placeholder='[df_ti_prev_year]')
    replace_table(docu=docu, df=df_vg, placeholder='[df_vg]')
    replace_table(docu=docu, df=df_vg_prev_year, placeholder='[df_vg_prev_year]')
    replace_table(docu=docu, df=df_av, placeholder='[df_av]')
    replace_table(docu=docu, df=df_av_prev_year, placeholder='[df_av_prev_year]')
    replace_table(docu=docu, df=df_av_pulled, placeholder='[df_av_pulled]')
    replace_table(docu=docu, df=df_tto, placeholder='[df_tto]')
    replace_table(docu=docu, df=df_tto_prev_year, placeholder='[df_tto_prev_year]')
    replace_table(docu=docu, df=df_tth, placeholder='[df_tth]')
    replace_table(docu=docu, df=df_tth_prev_year, placeholder='[df_tth_prev_year]')

    output_path = generate_tool_output_path(
        user_id=user_id,
        filename=f"Recruiting_Reporting_{quartal}",
        tool="Recruiting",
        variant="report_quartal",
        task_id=task.request.id,
        extension="docx",
    )

    ensure_output_folder(output_path)

    docu.save(str(output_path))

    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
