import json

from app.tasks.tool_registry import register_tool



@register_tool(
    tool="offboarding",
    variant="default",
    description="offboarding default conversion",
    input_type={
        "json_data": str,
    },
    output_type="email",
)
def offboarding(task, json_data):
    user_id = task.request.headers.get("user_id")
    user_name = task.request.headers.get("user_name")
    user_email = task.request.headers.get("user_email")

    data = json.loads(json_data)

    return data