import asyncio
import json
import os
from email.message import EmailMessage

from app.core.logger import logger
from app.tasks.tool_registry import register_tool
from app.utils.email_utils import send_email


def create_email(data: dict, cc: str) -> EmailMessage:


    # Erstellt den Textbereich der zu versendenden Dokumente anhand der jeweiligen Rechtsform
    output = f""
    rechtsform = data.get("rechtsform")

    # Dokumente bzgl. Steuererklärungen
    if rechtsform in ["Kapitalgesellschaften", "Personengesellschaften"]:

        output += f"{'☒ Körperschaftsteuererklärung' if data.get('koerperschaftsteuerklaerung_gewerbesteuer') else '☐ Körperschaftsteuererklärung'}<br>"
        output += f"{'☒ Gewerbesteuererklärung' if data.get('gewerbesteuer') else '☐ Gewerbesteuererklärung'}<br>"
        output += f"{'☒ Umsatzsteuererklärung' if data.get('umsatzsteuererklaerung') else '☐ Umsatzsteuererklärung'}<br>"

    elif rechtsform == "Einzelunternehmen":
        output += f"{'☒ Gewerbesteuererklärung' if data.get('gewerbesteuer') else '☐ Gewerbesteuererklärung'}<br>"
        output += f"{'☒ Umsatzsteuererklärung' if data.get('umsatzsteuererklaerung') else '☐ Umsatzsteuererklärung'}<br>"

    elif rechtsform == "Einzelunternehmen + ESt":
        output += f"{'☒ Einkommensteuererklärung' if data.get('einkommensteuererklaerung') else '☐ Einkommensteuererklärung'}<br>"
        output += f"{'☒ Gewerbesteuererklärung' if data.get('gewerbesteuer') else '☐ Gewerbesteuererklärung'}<br>"
        output += f"{'☒ Umsatzsteuererklärung' if data.get('umsatzsteuererklaerung') else '☐ Umsatzsteuererklärung'}<br>"

    output += "<br><b>Jahresabschluss:</b><br>"

    # Dokumente bzgl. Jahresabschluss
    if rechtsform in ["Kapitalgesellschaften", "Personengesellschaften", "Einzelunternehmen",
                      "Einzelunternehmen + ESt"]:
        output += f"{'☒ Jahresabschluss' if data.get('jahresabschluss') else '☐ Jahresabschluss'}<br>"

    if rechtsform in ["Kapitalgesellschaften", "Personengesellschaften"]:
        output += f"{'☒ E-Bilanz Vorschau' if data.get('e_bilanz') else '☐ E-Bilanz Vorschau'}<br>"
        output += f"{'☒ Offenlegung Vorschau' if data.get('offenlegung') else '☐ Offenlegung Vorschau'}<br>"
        output += f"{'☒ Gesellschafterprotokoll' if data.get('gesellschafterprotokoll') else '☐ Gesellschafterprotokoll'}<br>"

    if rechtsform == "Personengesellschaften":
        output += f"{'☒ Sonderbilanz(en)' if data.get('sonderbilanzen') else '☐ Sonderbilanz(en)'}<br>"
        output += f"{'☒ Ergänzungsbilanz(en)' if data.get('ergaenzungsbilanzen') else '☐ Ergänzungsbilanz(en)'}<br>"
        output += f"{'☒ Gesonderte Feststellungen' if data.get('gesonderte_feststellungen') else '☐ Gesonderte Feststellungen'}<br>"
        output += f"{'☒ Einheitliche Feststellungen' if data.get('einheitliche_feststellungen') else '☐ Einheitliche Feststellungen'}<br>"

    output += "<br>"

    # Bestimmt Textbereich für die weiteren Unterzeichner
    if data["anzahlWeitereUnterzeichner"] != "0":
        weitere_unterzeichner = data.get("weitereUnterzeichner", [])

        text_area_unterzeichner = ""

        for unterzeichner in weitere_unterzeichner:
            text_area_unterzeichner += (
                f"<b>Anrede:</b> {unterzeichner['geschlecht']}<br>"
                f"<b>Titel:</b> {unterzeichner['titel']}<br>"
                f"<b>Name:</b> {unterzeichner['name']}<br>"
                f"<b>E-Mail:</b> {unterzeichner['email']}<br><br>"

                f"<b>SMS-Authentifizierung?</b><br>"
                f"{'☒ Ja, Mobilnummer: ' + unterzeichner['mobil'] + '<br>☐ Nein, Passwort:' if unterzeichner['isDocusign'] else '☐ Ja, Mobilnummer: <br>☒ Nein, Passwort: ' + unterzeichner["password"]}<br><br>"

            )
    else:
        text_area_unterzeichner = "Keine weiteren Unterzeichner. <br><br>"

    email_message_user = EmailMessage()
    email_message_user["From"] = os.environ["EMAIL_SENDER"]
    email_message_user["To"] = os.environ["EMAIL_RECEIVER_EMMA"]
    #if data.get("rechnung") and data.get("cc"):
    #    email_message_user["Cc"] = data["cc"]

    email_message_user["Cc"] = cc

    subject = f"***Jahresabschluss {data['year']}, {data['mandantennummer']}_{data['auftraggeber']}"
    email_message_user["Subject"] = subject

    plain_body = (
        f"Liebes DocuSign-Team,\n\n"
        f"oben genannter Jahresabschluss (#{data['mandantennummer']}) ist bereit zum Versand. Folgende Angaben sind für DocuSign zu berücksichtigen:"
        f"\n\nLinksunterzeichner der Bescheinigung: {data['linksunterzeichner_kso_nachname']}, {data['linksunterzeichner_kso_vorname']}"
        f"\n\nRechtsunterzeichner der Bescheinigung: {data['rechtsunterzeichner_kso_nachname']}, {data['rechtsunterzeichner_kso_vorname']}"
        f"\n\nName des Sachbearbeiters Jahresabschluss: {data['sachbearbeiter']}"
        f"\n\nZu versendende Dokumente:"
        f"\n\nSteuererklärungen:"
        f"\n\n{'☒ Körperschaftsteuererklärung / Gewerbesteuererklärung' if data['koerperschaftsteuerklaerung_gewerbesteuer'] else '☐ Körperschaftsteuererklärung / Gewerbesteuererklärung'}"
        f"\n\n{'☒ Umsatzsteuererklärung' if data['umsatzsteuererklaerung'] else '☐ Umsatzsteuererklärung'}"
        f"\n\nJahresabschluss:"
        f"\n\n{'☒ Jahresabschluss' if data['jahresabschluss'] else '☐ Jahresabschluss'}"
        f"\n\n{'☒ E-Bilanz Vorschau' if data['e_bilanz'] else '☐ E-Bilanz Vorschau'}"
        f"\n\n{'☒ Offenlegung Vorschau' if data['offenlegung'] else '☐ Offenlegung Vorschau'}"
        f"\n\n{'☒ Gesellschafterprotokoll' if data['gesellschafterprotokoll'] else '☐ Gesellschafterprotokoll'}"
    )

    gesellschafter_anzahl = min(int(data.get("anzahl_gesellschafter", 0)), 14)

    html_tabelle = '<b>Gesellschafter:</b><br>'
    html_tabelle += '<table>'
    html_tabelle += '''
    <tr>
      <th>Anrede</th>
      <th>Titel</th>
      <th>Vorname</th>
      <th>Nachname</th>
      <th>E-Mailadresse</th>
      <th>Telefonnummer</th>
      <th>SMS</th>
      <th>Passwort</th>
    </tr>
    '''

    if data.get("gesellschafterprotokoll"):
        for i in range(1, gesellschafter_anzahl + 1):
            html_tabelle += f'''
    <tr>
      <td>{data.get(f'geschlecht_gesellschafter{i}', '')}</td>
      <td>{data.get(f'titel_gesellschafter{i}', '')}</td>
      <td>{data.get(f'v_gesellschafter{i}', '')}</td>
      <td>{data.get(f'n_gesellschafter{i}', '')}</td>
      <td>{data.get(f'e_gesellschafter{i}', '')}</td>
      <td>{data.get(f't_gesellschafter{i}', '')}</td>
      <td>{data.get(f'sms_gesellschafter{i}', '')}</td>
      <td>{data.get(f'passwort_gesellschafter{i}', '')}</td>
    </tr>
    '''

    html_tabelle += '</table><br><br>'

    # HTML-Version für besseres Format
    html_body = f"""
        <html>
      <head>
        <style>
          body {{
            font-family: Calibri, sans-serif;
            font-size: 11pt;
          }}
          table {{
            width: 100%;
            border-collapse: collapse;
          }}
          th, td {{
            padding: 8px;
            text-align: left;
            border: 1px solid #ddd;
          }}
          th {{
            background-color: #f2f2f2;
          }}
        </style>
      </head>
      <body>
        <p>Liebes DocuSign-Team,<br><br>
        oben genannter Jahresabschluss (<b>#{data["mandantennummer"]}</b>) ist bereit zum Versand. Folgende Angaben sind für DocuSign zu berücksichtigen:<br><br>


        <b>Name des Sachbearbeiters Jahresabschluss:</b> {data["sachbearbeiter"]}<br><br>
        
        
        
        <b>Linksunterzeichner der Bescheinigung:</b> {data["linksunterzeichner_kso_nachname"]}, {data["linksunterzeichner_kso_vorname"]}<br>
        {f"<b>Rechtsunterzeichner der Bescheinigung:</b> {data['rechtsunterzeichner_kso_nachname']}, {data['rechtsunterzeichner_kso_vorname']}<br><br>" if data["anzahl_unterzeichner_kso"] == "2" else ""}<br><br>


        <b>Zur Freigabe an:</b> {data["freigabe"]}<br><br>

        <b>Zu versendende Dokumente:</b><br><br>
        
        <b>Anschreiben:</b> {data["anschreiben"]}<br><br>

        <b>Steuererklärungen:</b><br>
        

        {output}<br><br>
        {"Mandantennummer(n) oder Dateipfad bei Sonder- bzw. Ergänzungsbilanzen: <br>" + data["sonderbilanzen_text"] if data["sonderbilanzen"] or data["ergaenzungsbilanzen"] else ""}

        <b>Auskunftspersonen Vollständigkeitserklärung:</b><br>
        <table>
          <tr>
            <th>Anrede</th>
            <th>Titel</th>
            <th>Vorname</th>
            <th>Nachname</th>
          </tr>
          {"<tr><td>" + data["geschlecht_auskunftsperson1"] + "</td><td>" + data["titel_auskunftsperson1"] + "</td><td>" + data["v_auskunftsperson1"] + "</td><td>" + data["n_auskunftsperson1"] + "</td></tr>" if data["anzahl_auskunftspersonen"] >= "1" else ""}
          {"<tr><td>" + data["geschlecht_auskunftsperson2"] + "</td><td>" + data["titel_auskunftsperson2"] + "</td><td>" + data["v_auskunftsperson2"] + "</td><td>" + data["n_auskunftsperson2"] + "</td></tr>" if data["anzahl_auskunftspersonen"] >= "2" else ""}
          {"<tr><td>" + data["geschlecht_auskunftsperson3"] + "</td><td>" + data["titel_auskunftsperson3"] + "</td><td>" + data["v_auskunftsperson3"] + "</td><td>" + data["n_auskunftsperson3"] + "</td></tr>" if data["anzahl_auskunftspersonen"] >= "3" else ""}
          {"<tr><td>" + data["geschlecht_auskunftsperson4"] + "</td><td>" + data["titel_auskunftsperson4"] + "</td><td>" + data["v_auskunftsperson4"] + "</td><td>" + data["n_auskunftsperson4"] + "</td></tr>" if data["anzahl_auskunftspersonen"] >= "4" else ""}

        </table><br><br>

        {html_tabelle}

        <b>UNTERZEICHNER 1:</b><br>
        Mandant-Unterzeichner (Steuerpflichtiger):<br><br>
        <b>Anrede:</b> {data["geschlecht_mandant1"]}<br>
        {"<b>Titel:</b> " + data["titel_mandant1"] + "<br>" if data["titel_mandant1"] != "" else ""}
        <b>Name1:</b> {data["mandant_unterzeichner1"]}<br>
        <b>E-Mail1:</b> {data["mandant_email1"]}<br><br>

        <b>SMS-Authentifizierung?</b><br>
        {"☒ Ja, Mobilnummer: " + data["mandant_mobil1"] if data["mandant_sms1"] else "☐ Ja, Mobilnummer:"}<br>
        {"☒ Nein, Passwort: " + data["mandant_pw1"] if not data["mandant_sms1"] else "☐ Nein, Passwort:"}<br><br>

        <b>Sollen weitere Personen in cc genommen werden?</b><br><br>
        {text_area_unterzeichner}



        <b>Soll eine Rechnung geschrieben werden?</b><br>
            {"☒ Ja <br> ☐ Nein" if data["rechnung"] else "☐ Ja <br>☒ Nein"}

            <br><br>
            
        
        <b>Soll der Jahresabschluss bzw. die Steuererklärung anschließend vom DocuSign-Team versendet werden?</b><br>
        {data["versand_text"]}
        
        <br><br>
        
        <b>Soll der Jahresabschluss bzw. die Steuererklärung anschließend vom DocuSign-Team an das Finanzamt übermittelt werden?</b><br>
        {"☒ Ja<br> ☐ " + data["uebermittlungstext"] if data["docusign"] else " ☐ Ja<br> ☒ " + data["uebermittlungstext"]}<br><br>
        
        <b>Sonstige Hinweise oder Ergänzungen:</b><br>
        {data["sonstiges"]}
        
        {"Mandantennummer(n) oder Dateipfad bei Sonder- bzw. Ergänzungsbilanzen: <br>" + data["sonderbilanzen_text"] if data["sonderbilanzen"] or data["ergaenzungsbilanzen"] else ""}

        </p>
      </body>
    </html>
        """

    # Inhalte setzen
    email_message_user.set_content(plain_body)
    email_message_user.add_alternative(html_body, subtype="html")

    return email_message_user


def create_confirm_mail(recipient: str, user_name: str, data: dict) -> EmailMessage:
    email_message_confirm = EmailMessage()
    email_message_confirm["From"] = os.environ["EMAIL_SENDER"]
    email_message_confirm["To"] = [recipient]
    auftrag = f"***Jahresabschluss {data['year']}, {data['mandantennummer']}_{data['auftraggeber']}"
    subject = f"Bestätigung deiner Übermittlung: {auftrag}"
    email_message_confirm["Subject"] = subject
    name = user_name.split(",", 1)[1]
    content_fallback = (
        f"Hallo {name},\n\nvielen Dank für die Übermittlung deines Auftrages: {auftrag}.\nDas DocuSign-Team kümmert sich nun um die weiteren Schritte.\n\n\nViele Grüße\nJulian Michalak | Softwareentwicklung\n"
    )

    if data["uebermittlungstext"] == "Nein, die Übermittlung soll zu einem späteren Zeitpunkt erfolgen":
        hinweis = ("<b>Bitte beachte: </b>Da die Übermittlung zu einem späteren Zeitpunkt erfolgen soll,\n"
                   "wird der Jahresabschluss bzw. die Steuererklärung in diesem Fall vom Sachbearbeiter übermittelt – nicht durch das DocuSign-Team.")
    else:
        hinweis = ""

    content = f"""
    <html>
      <body>
        <p>Hallo {name},</p>

        <p>
          vielen Dank für die Übermittlung deines Auftrages:
          <strong>{auftrag}</strong>.
          <br>
          Das DocuSign-Team kümmert sich nun um die weiteren Schritte.
        </p>
        <br>
        <p style="color:red;">{hinweis}</p>
        <br>
        <p>
          <em>Viele Grüße<br></em>
          <em>Julian Michalak | Softwareentwicklung</em>

        </p>
      </body>
    </html>
    """

    email_message_confirm.set_content(content_fallback)
    email_message_confirm.add_alternative(content, subtype="html")

    return email_message_confirm


@register_tool(
    tool="emma_jahresabschluss",
    variant="default",
    description="emma_jahresabschluss default conversion",
    input_type={
        "json_data": str,
    },
    output_type="email",
)
def emma_jahresabschluss(task, json_data):
    user_id = task.request.headers.get("user_id")
    user_name = task.request.headers.get("user_name")
    user_email = task.request.headers.get("user_email")

    data = json.loads(json_data)

    data["sachbearbeiter"] = user_name

    """
    Mail soll standardmäßig an emma.kso@ecovis-kso.com gesendet werden.
    """

    try:
        logger.info("📧 Sending email to emma.kso@ecovis-kso.com")
        email_emma = create_email(data=data, cc=user_email)
        confirm_email_user = create_confirm_mail(recipient=user_email, user_name=user_name, data=data)
        asyncio.run(send_email([email_emma, confirm_email_user]))
        return {"message": "Email sent successfully", "file_name": data["mandantennummer"], "user_id": user_id}
    except Exception as e:
        logger.exception(f"❌ Failed to send email to emma.kso@ecovis-kso.com - Error: {e}")
        raise e
