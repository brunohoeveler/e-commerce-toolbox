import io
import uuid
import zipfile
from datetime import datetime
from pathlib import Path
import xml.etree.ElementTree as ET
from fastapi import UploadFile
import polars as pl
from app.tasks.tool_registry import register_tool
from app.utils.datev_export import datev_export_polars_year
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_tool_output_path, strip_task_id


@register_tool(
    tool="Rechnung-Matcher",
    variant="default",
    description="Default Rechnung-Umbenennung",
    input_type={
        "bernr": (str, {"description": "Beraternummer"}),
        "mdtnr": (str, {"description": "Mandantennummer"}),
        "skl": (str, {"description": "SKL"}),
        "skr": (str, {"description": "SKR"}),
        "files": (
                list[UploadFile],
                {
                    "min_files": 1,
                    "max_files": 2,
                    "extensions": ["txt", "csv"],
                },
        ),
    },
    output_type="zip",
)
def invoice_matcher(task, bernr: str, mdtnr: str, skl: str, skr: str, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    dokumente = files[0]
    kontenlisten = files[1]
    df_kontenlisten = pl.read_csv(kontenlisten, separator=";", infer_schema_length=0,
                                  encoding="ISO-8859-1")

    def fix_scientific_string(s: str) -> str:
        try:
            s = s.replace(",", ".")

            return str(int(float(s))) if "e" in s.lower() else s
        except:
            return s

    df_kontenlisten = df_kontenlisten.with_columns(
        pl.col("Beleg").map_elements(fix_scientific_string, return_dtype=pl.Utf8,
                                     skip_nulls=False, )
    )

    month = df_kontenlisten["Beginn_WJ"].str.slice(3, 2).unique().to_list()[0]
    year = df_kontenlisten["Beginn_WJ"].str.slice(6, 4).unique().to_list()[0]

    df_doku = pl.read_csv(
        dokumente,
        has_header=False,
        new_columns=["Belegname"],
        encoding="utf8"
    )
    df_doku = df_doku.with_columns(
        pl.col("Belegname")
        .str.replace(r"\.pdf$", "", literal=False)
        .str.split("_")
        .list.get(-1)
        .str.slice(1)
        .alias("Nummer")
    )
    df_doku = df_doku.with_columns(
        pl.Series("guid", [str(uuid.uuid4()) for _ in range(len(df_doku))]),
    )

    archive = ET.Element(
        "archive",
        {
            "xmlns": "http://xml.datev.de/bedi/tps/document/v05.0",
            "xsi:schemaLocation": "http://xml.datev.de/bedi/tps/document/v05.0 Document_v050.xsd",
            "generatingSystem": "lexware.de",
            "version": "5.0"
        }
    )
    header = ET.SubElement(archive, "header")
    ET.SubElement(header, "date").text = datetime.now().replace(microsecond=0).isoformat()
    content = ET.SubElement(archive, "content")
    for row in df_doku.iter_rows(named=True):
        doc = ET.SubElement(content, "document", {"guid": row["guid"]})
        ET.SubElement(doc, "extension", {
            "name": f"{row['Belegname']}",
            "{http://www.w3.org/2001/XMLSchema-instance}type": "File"
        })
    tree = ET.ElementTree(archive)

    df_joined = df_doku.join(
        df_kontenlisten,
        left_on="Nummer",
        right_on="Nummer",
        how="left"
    )

    df_joined = df_joined.with_columns(
        pl.format('BEDI "{}"', pl.col("guid")).alias("Beleglink")
    ).drop(["guid", "Nummer"])

    df_joined = df_joined.with_columns(
        (pl.col("Datum").str.slice(0, 2) + pl.col("Datum").str.slice(3, 2)).alias("datum"))
    df_joined = df_joined.with_columns(
        pl.when(
            pl.col("Buchungsbetrag").str.contains("-")
        )
        .then(pl.lit("H"))
        .otherwise(pl.lit("S"))
        .alias("sh")
    )
    df_joined = df_joined.with_columns(
        pl.col("Buchungsbetrag")
        .str.replace(",", ".")
        .cast(pl.Float64)
        .abs()
        .alias("umsatz")
    )
    df_joined = df_joined.with_columns(
        pl.col("umsatz")
        .cast(pl.String)
        .str.replace(r"\.", ",", literal=False)  # regex version
        .alias("umsatz")
    )
    df_joined = df_joined.with_columns(
        pl.lit("").alias("Generalumkehr")
    )

    df_joined = df_joined.with_columns(
        pl.col("Kontonummer").cast(pl.Int64)
    )

    df_joined = (
        df_joined.group_by("Buchungssatz-Id")
        .last()
    ).sort("Datum")

    df_joined = df_joined.with_columns(
        pl.col("Kontonummer").cast(pl.String)
    )

    df_joined = df_joined.rename({
        "Kontonummer": "konto",
        "Gegen-Konto": "gegenkonto",
        "St-Satz": "bu",
        "Text": "buchungstext",
        "Beleg": "belegfeld",
    }).select(
        [
            "sh",
            "umsatz",
            "bu",
            "gegenkonto",
            "datum",
            "konto",
            "belegfeld",
            "buchungstext",
            "Beleglink",
            "Generalumkehr",
        ]
    )

    df_joined2 = df_joined.clone()
    df_joined2 = df_joined2.with_columns(
        pl.when(pl.col("sh") == "H")
        .then(pl.lit("S"))
        .otherwise(pl.lit("H"))
        .alias("sh")
    )
    df_joined2 = df_joined2.with_columns(
        pl.lit("1").alias("Generalumkehr")
    )
    df = pl.concat([df_joined, df_joined2], how="vertical")
    # ========================== SAVE ZIP TO DISK ==========================
    output_path = generate_tool_output_path(
        user_id=user_id,
        tool="Rechnung-Matcher",
        variant="default",
        task_id=task.request.id,
        extension="zip",
        filename=mdtnr
    )

    ensure_output_folder(output_path)
    xml_buffer = io.BytesIO()
    tree.write(xml_buffer, encoding="utf-8", xml_declaration=True)

    with io.BytesIO() as buffer:
        df_export = datev_export_polars_year(
            df=df,
            month=month,
            year=year,
            buffer=buffer,
            bernr=bernr,
            mdtnr=mdtnr,
            skl=skl,
            skr=skr,
        )

        with zipfile.ZipFile(output_path, "w") as zf:
            with zf.open(f"EXTF_Buchungsstapel_0101{year}_bis_3101{year}.csv", "w") as f:
                f.write(df_export.read())

            zf.writestr(f"document.xml", xml_buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}