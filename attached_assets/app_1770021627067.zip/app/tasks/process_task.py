import inspect
from pathlib import Path

from app.core.logger import logger
from app.tasks.celery_worker import celery_app
from app.tasks.data_conversion_registry import DataConversionRegistry
from app.tasks.tool_registry import ToolRegistry


@celery_app.task(bind=True, name="process_data_conversion_task")
def process_data_conversion_task(self, data_conversion: str, conversion: str, parameters: dict):
    logger.info(f"🛠️ Processing task - {data_conversion}/{conversion}")

    try:
        # Lookup registered function and its signature
        func = DataConversionRegistry.get_function(data_conversion, conversion)
        sig = DataConversionRegistry.get_signature(data_conversion, conversion)

        # Match parameters to function signature
        kwargs = {}
        for name, param in sig.parameters.items():
            if name == "task":
                continue
            if name in parameters:
                value = parameters[name]

                # 🌟 Auto-convert files (list[str]) → list[Path]
                if name == "files" and isinstance(value, list) and all(isinstance(v, str) for v in value):
                    value = [Path(v) for v in value]

                kwargs[name] = value
            elif param.default is inspect.Parameter.empty:
                raise ValueError(f"Missing required parameter: {name}")

        logger.debug(f"📦 Calling {func.__name__} with kwargs: {kwargs}")

        # Execute the actual data conversion function
        result = func(self, **kwargs)

        logger.info(f"✅ Task complete: {result}")
        return result

    except Exception as e:
        logger.exception(f"❌ Error in task: {e}")
        self.retry(exc=e, countdown=5, max_retries=3)
        raise


@celery_app.task(bind=True, name="process_tool_task")
def process_tool_task(self, tool: str, variant: str, parameters: dict):
    logger.info(f"🛠️ Processing task - {tool}/{variant}")

    try:
        # Lookup registered function and its signature
        func = ToolRegistry.get_function(tool, variant)
        sig = ToolRegistry.get_signature(tool, variant)

        # Match parameters to function signature
        kwargs = {}
        for name, param in sig.parameters.items():
            if name == "task":
                continue
            if name in parameters:
                value = parameters[name]

                # 🌟 Auto-convert files (list[str]) → list[Path]
                if name == "files" and isinstance(value, list) and all(isinstance(v, str) for v in value):
                    value = [Path(v) for v in value]

                kwargs[name] = value
            elif param.default is inspect.Parameter.empty:
                raise ValueError(f"Missing required parameter: {name}")

        logger.debug(f"📦 Calling {func.__name__} with kwargs: {kwargs}")

        # Execute the actual tool function
        result = func(self, **kwargs)

        logger.info(f"✅ Task complete: {result}")
        return result

    except Exception as e:
        logger.exception(f"❌ Error in task: {e}")
        self.retry(exc=e, countdown=5, max_retries=3)
        raise
