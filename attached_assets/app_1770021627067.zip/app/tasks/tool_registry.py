import inspect
from typing import Any, Callable, Dict


class ToolRegistry:
    _registry: Dict[str, Dict[str, Dict[str, Any]]] = {}

    @classmethod
    def register(
        cls,
        tool: str,
        variant: str,
        func: Callable,
        description: str,
        input_type: Dict[str, Any],
        output_type: str,
    ) -> None:
        cls._registry.setdefault(tool, {})[variant] = {
            "function": func,
            "signature": inspect.signature(func),
            "metadata": {
                "description": description,
                "input_type": input_type,
                "output_type": output_type,
                "input_schema": cls._build_input_schema(input_type),
            },
        }

    @staticmethod
    def _build_input_schema(input_type: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
        schema = {}
        for key, val in input_type.items():
            if isinstance(val, tuple):
                type_, desc = val
            else:
                type_, desc = val, None

            schema[key] = {
                "type": getattr(type_, "__name__", str(type_)),
                "description": desc,
            }
        return schema

    @classmethod
    def get_function(cls, tool: str, variant: str) -> Callable:
        return cls._registry[tool][variant]["function"]

    @classmethod
    def get_signature(cls, tool: str, variant: str):
        return cls._registry[tool][variant]["signature"]

    @classmethod
    def get_metadata(cls, tool: str, variant: str) -> Dict[str, Any]:
        return cls._registry[tool][variant]["metadata"]

    @classmethod
    def get_all(cls) -> Dict[str, Dict[str, Any]]:
        return {
            tool: {
                conv: {
                    "description": meta["metadata"]["description"],
                    "input_schema": meta["metadata"].get("input_schema", {}),
                    "output_type": meta["metadata"].get("output_type"),
                }
                for conv, meta in variants.items()
            }
            for tool, variants in cls._registry.items()
        }


def register_tool(tool, variant, description, input_type, output_type):
    def decorator(func):
        ToolRegistry.register(
            tool=tool,
            variant=variant,
            func=func,
            description=description,
            input_type=input_type,
            output_type=output_type,
        )
        return func

    return decorator
