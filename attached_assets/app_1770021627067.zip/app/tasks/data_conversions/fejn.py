import io
from pathlib import Path

import polars as pl
from fastapi import UploadFile

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.datev_export import datev_export_polars
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_output_path_datev, strip_task_id


@register_data_conversion(
    data_conversion="Fejn",
    conversion="default",
    description="Fejn default conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 2,
                "max_files": 2,
                "extensions": ["csv"],
            },
        ),
    },
    output_type="csv",
)
def fejn_import(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]

    # ========================== PLENTY-MARKETS DATEI ==========================
    try:
        df_plenty = pl.read_csv(file1, separator=";", infer_schema=False, ignore_errors=True)
        assert df_plenty.width == 37
    except FileNotFoundError as e:
        raise Exception("Die PlentyMarkets Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der PlentyMarkets ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_plenty = df_plenty.select([col for i, col in enumerate(df_plenty.columns) if i in [0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 15, 18, 22, 25, 34]])
    df_plenty = df_plenty.rename(
        dict(
            zip(
                df_plenty.columns[0:],
                [
                    "wkz",
                    "sh",
                    "umsatz",
                    "bu",
                    "gegenkonto",
                    "belegfeld",
                    "auftragsnummer",
                    "datum",
                    "konto",
                    "name",
                    "eulandbest",
                    "ustid",
                    "eusteuerbest",
                    "inhalt1",
                    "shop",
                ],
            )
        )
    )
    # ======================== ORDER TAGS Datei ===================================
    try:
        df_ordertag = pl.read_csv(file2, separator=",", infer_schema=False, ignore_errors=True)
        assert df_ordertag.width == 9
    except FileNotFoundError as e:
        raise Exception("Die OrderTag Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der OrderTag Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_ordertag = df_ordertag.select([col for i, col in enumerate(df_ordertag.columns) if i not in [0, 1, 2, 3, 4, 5]])
    df_ordertag = df_ordertag.rename(dict(zip(df_ordertag.columns[0:], ["belegfeld", "tags", "ext"])))

    # ========================== MERGING DATA ===============================
    df_merge = df_plenty.join(df_ordertag, how="left", on="belegfeld")


    # ========================== TEXTERKENNUNGSREGELN ===============================
    df_merge = df_merge.with_columns(pl.col("datum").str.slice(0, 5).str.replace_all(r"\.", "").alias("datum"))
    df_merge = df_merge.with_columns(pl.when(pl.col("tags").str.contains("(?i)shopify")).then(pl.lit("10001")).otherwise(pl.col("konto")).alias("konto"))
    df_merge = df_merge.with_columns(pl.when(pl.col("tags").str.contains("(?i)ivalo")).then(pl.lit("10002")).otherwise(pl.col("konto")).alias("konto"))
    df_merge = df_merge.with_columns(pl.when(pl.col("tags").str.contains("(?i)entire")).then(pl.lit("10003")).otherwise(pl.col("konto")).alias("konto"))
    df_merge = df_merge.with_columns(pl.when(pl.col("tags").str.contains("(?i)etsy")).then(pl.lit("10004")).otherwise(pl.col("konto")).alias("konto"))
    df_merge = df_merge.with_columns(pl.when(pl.col("tags").str.contains("(?i)avocado")).then(pl.lit("10005")).otherwise(pl.col("konto")).alias("konto"))
    df_merge = df_merge.with_columns(pl.when(pl.col("tags").str.contains("(?i)ankorstore")).then(pl.lit("10008")).otherwise(pl.col("konto")).alias("konto"))
    df_merge = df_merge.with_columns(pl.when(pl.col("shop").str.contains("(?i)fejn pos")).then(pl.lit("10009")).otherwise(pl.col("konto")).alias("konto"))
    df_merge = df_merge.with_columns(pl.when(pl.col("tags").str.contains("(?i)pos -")).then(pl.lit("10009")).otherwise(pl.col("konto")).alias("konto"))
    df_merge = df_merge.with_columns(pl.when(pl.col("konto").is_null()).then(pl.lit("10012")).otherwise(pl.col("konto")).alias("konto"))
    df_merge = df_merge.with_columns(pl.when(pl.col("konto") == 'null').then(pl.lit("10012")).otherwise(pl.col("konto")).alias("konto"))
    df_merge = df_merge.with_columns(pl.when(pl.col("tags").str.contains("(?i)faire")).then(pl.lit("10013")).otherwise(pl.col("konto")).alias("konto"))
    df_merge = df_merge.with_columns(pl.when(pl.col("tags").str.contains("(?i)slygad")).then(pl.lit("10015")).otherwise(pl.col("konto")).alias("konto"))
    df_merge = df_merge.with_columns(pl.when(pl.col("tags").str.contains("(?i)gutemarken")).then(pl.lit("10016")).otherwise(pl.col("konto")).alias("konto"))
    df_merge = df_merge.with_columns(pl.when(pl.col("tags").str.contains("(?i)gutscheinkauf")).then(pl.lit("1796")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_merge = df_merge.with_columns(
        pl.when((pl.col("tags").str.contains("(?i)gutschein_eingel")) & (pl.col('ext').is_null())).then(pl.lit("1796")).otherwise(
            pl.col("gegenkonto")).alias("gegenkonto"))

    df_merge = df_merge.drop('ext')

    # ========================== FEJN BUCHUNGSCODES ===============================
    df_codes = pl.read_csv("resources/fejn_bu_countrycodes.csv", separator=";", infer_schema=False)
    df_fejn = df_merge.join(df_codes, on=["eulandbest", "eusteuerbest"], how="left")

    # ========================== REGELN ===============================
    df_fejn = df_fejn.with_columns(pl.when(pl.col("bu_right").is_not_null()).then(pl.col("bu_right")).otherwise(pl.col("bu")).alias("bu"))
    df_fejn = df_fejn.drop("bu_right")
    df_fejn = df_fejn.with_columns(pl.when([pl.col("ustid").is_not_null(), pl.col("gegenkonto") == "1825"]).then(pl.col("ustid")).otherwise(pl.col("eulandbest")).alias("eulandbest"))
    df_fejn = df_fejn.with_columns(pl.when(pl.col("gegenkonto") == "8400").then(pl.lit(None)).otherwise(pl.col("bu")).alias("bu"))
    df_fejn = df_fejn.with_columns(
        pl.concat_str(
            [
                pl.coalesce([pl.col("shop"), pl.lit("unbekannter Shop")]),
                pl.lit(": "),
                pl.coalesce([pl.col("name"), pl.lit("Unbekannt")]),
            ]
        ).alias("buchungstext")
    )
    df_fejn = df_fejn.with_columns(pl.col("buchungstext").str.slice(0, 64))
    df_fejn = df_fejn.rename({"shop": "inhalt2"})
    df_fejn = df_fejn.with_columns(pl.col("umsatz").str.replace_all(r"\-", ""))
    df_fejn = df_fejn.with_columns(pl.lit("Payment Reference").alias("info1"))
    df_fejn = df_fejn.with_columns(pl.lit("Shop Bezeichnung").alias("info2"))
    df_fejn = df_fejn.filter(pl.col('umsatz') != '0,00')
    df_fejn = df_fejn.with_columns(pl.when(pl.col("gegenkonto").is_null()).then(pl.lit("8400")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_fejn = df_fejn.select([col for i, col in enumerate(df_fejn.columns) if i not in [9, 11, 15]])

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Fejn",
        conversion="default",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        datev_export_polars(
            df=df_fejn,
            month=month,
            year=year,
            buffer=buffer,
            bernr="12168",
            mdtnr="18665",
            skl="4",
            skr="3",
            text="Fejn default",
        )

        with open(output_path, "wb") as f:
            f.write(buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
