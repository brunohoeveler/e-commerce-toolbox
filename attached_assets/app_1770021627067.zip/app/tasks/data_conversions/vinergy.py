from pathlib import Path

import pandas as pd
from fastapi import UploadFile

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.datev_export import datev_format
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_output_path_datev, strip_task_id


@register_data_conversion(
    data_conversion="Vinergy",
    conversion="Mollie",
    description="Vinergy Mollie",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 3,
                "max_files": 3,
                "extensions": ["csv", "xlsx", "xls"],
            },
        ),
    },
    output_type="csv",
)
def vinergy_mollie(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]
    file3 = files[2]

    df_re = pd.read_excel(file1, skiprows=1, dtype=str)
    df_re.columns.values[1] = "renr"
    df_re.columns.values[9] = "belegfeld"
    df_re.columns.values[115] = "debitor"
    df_re = df_re[["renr", "belegfeld", "debitor"]]

    df_gs = pd.read_excel(file2, skiprows=1, dtype=str)
    df_gs.columns.values[41] = "renr"
    df_gs.columns.values[1] = "belegfeld"
    df_gs.columns.values[104] = "debitor"
    df_gs = df_gs[["renr", "belegfeld", "debitor"]]

    df_abgleich = pd.concat([df_re, df_gs])

    df_mollie = pd.read_csv(file3, dtype=str, sep=",")
    df_mollie.columns.values[0:9] = [
        "datum",
        "type",
        "payment",
        "del",
        "buchungstext",
        "del",
        "beschreibung",
        "umsatz",
        "wkz",
    ]
    del df_mollie["del"]
    df_mollie["datum"] = df_mollie["datum"].str[8:10] + df_mollie["datum"].str[5:7]
    df_mollie["sh"] = "s"
    df_mollie["konto"] = "184000"
    df_mollie.loc[df_mollie["umsatz"].str.contains("-"), "sh"] = "h"
    df_mollie["umsatz"] = df_mollie["umsatz"].str.replace("-", "")
    df_mollie["umsatz"] = df_mollie["umsatz"].str.replace(".", ",")
    df_mollie["belegfeld"] = df_mollie["beschreibung"]
    df_mollie.loc[df_mollie["type"] == "transfer", "belegfeld"] = "Guthabentransfer"
    df_mollie.loc[df_mollie["type"] == "invoice", "belegfeld"] = "Gebühren"
    df_mollie["belegfeld"] = df_mollie["belegfeld"].str.replace("'", "")
    df_mollie.loc[
        (df_mollie["type"].isin(["payment", "capture"])) & (df_mollie["belegfeld"].str.contains("Bestellung")),
        "belegfeld",
    ] = df_mollie["belegfeld"].str[-6:]
    df_mollie.loc[df_mollie["type"].isin(["capture", "payment", "refund"]), "gegenkonto"] = "137003"
    df_mollie.loc[df_mollie["type"] == "invoice", "gegenkonto"] = "7120000"
    df_mollie.loc[df_mollie["type"] == "transfer", "gegenkonto"] = "146000"

    df_merge = pd.merge(df_mollie, df_abgleich, how="left", on="belegfeld")
    df_merge.loc[~df_merge["debitor"].isnull(), "gegenkonto"] = df_merge["debitor"]
    df_merge["info1"] = "Zahlart"
    df_merge["inhalt1"] = df_merge["type"] + " - " + df_merge["payment"]
    df_merge.loc[df_merge["payment"].isnull(), "inhalt1"] = df_merge["type"]
    df_merge["buchungstext"] = df_merge["belegfeld"] + " - " + df_merge["buchungstext"]
    df_merge.loc[df_merge["buchungstext"].isnull(), "buchungstext"] = df_merge["belegfeld"]
    df_merge.loc[
        (df_merge["type"].isin(["payment", "capture"])) & (~df_merge["renr"].isnull()),
        "belegfeld",
    ] = df_merge["renr"]
    del df_merge["beschreibung"]
    del df_merge["type"]
    del df_merge["payment"]
    del df_merge["debitor"]
    del df_merge["renr"]

    df_export = datev_format(
        df_merge,
        bernr="12168",
        mdtnr="18150",
        skl="6",
        skr="4",
        year=year,
        month=month,
        text="Vinico mollie",
    )

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Vinergy",
        conversion="Mollie",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    df_export.to_csv(output_path, sep=";", index=False)

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Vinergy",
    conversion="Paypal",
    description="Vinergy Paypal",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 3,
                "max_files": 3,
                "extensions": ["csv", "xlsx", "xls"],
            },
        ),
    },
    output_type="csv",
)
def vinergy_paypal(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]
    file3 = files[2]

    df_re = pd.read_excel(file1, skiprows=1, dtype=str)
    df_re.columns.values[1] = "renr"
    df_re.columns.values[9] = "belegfeld"
    df_re.columns.values[115] = "debitor"
    df_re = df_re[["renr", "belegfeld", "debitor"]]

    df_gs = pd.read_excel(file2, skiprows=1, dtype=str)
    df_gs.columns.values[41] = "renr"
    df_gs.columns.values[1] = "belegfeld"
    df_gs.columns.values[104] = "debitor"
    df_gs = df_gs[["renr", "belegfeld", "debitor"]]

    df_abgleich = pd.concat([df_re, df_gs])
    df_abgleich.reset_index(inplace=True, drop=True)

    df_brutto = pd.read_csv(file3, dtype=str, sep=",")
    df_brutto.columns.values[0:18] = [
        "datum",
        "del",
        "del",
        "type",
        "wkz",
        "umsatz",
        "del",
        "del",
        "del",
        "auftragsnummer",
        "del",
        "name",
        "del",
        "del",
        "del",
        "del",
        "bestellnr",
        "del",
    ]
    del df_brutto["del"]
    df_brutto["gegenkonto"] = "137004"
    df_brutto.loc[
        df_brutto["type"].isin(["Bankgutschrift auf PayPal-Konto", "Von Nutzer eingeleitete Abbuchung"]),
        "gegenkonto",
    ] = "146000"

    df_fee = pd.read_csv(file3, dtype=str, sep=",")
    df_fee.columns.values[0:18] = [
        "datum",
        "del",
        "del",
        "type",
        "wkz",
        "del",
        "umsatz",
        "del",
        "del",
        "auftragsnummer",
        "del",
        "name",
        "del",
        "del",
        "del",
        "del",
        "bestellnr",
        "del",
    ]
    del df_fee["del"]
    df_fee = df_fee[df_fee["umsatz"] != "0,00"]
    df_fee["gegenkonto"] = "685500"
    df_fee["type"] = "Fee - " + df_fee["type"]

    df_paypal = pd.concat([df_brutto, df_fee])
    df_paypal.reset_index(inplace=True, drop=True)
    df_paypal["datum"] = df_paypal["datum"].str[:5].str.replace(".", "")
    df_paypal.loc[df_paypal["bestellnr"].astype(str).str.contains("Bestellung"), "bestellnr"] = df_paypal["bestellnr"].str[-6:]
    df_paypal["konto"] = "183000"
    df_paypal["sh"] = "s"
    df_paypal.loc[df_paypal["umsatz"].str.contains("-"), "sh"] = "h"
    df_paypal["umsatz"] = df_paypal["umsatz"].str.replace("-", "")
    df_paypal["umsatz"] = df_paypal["umsatz"].str.replace(".", "")
    df_paypal["buchungstext"] = df_paypal["bestellnr"] + " - " + df_paypal["name"]
    df_paypal["inhalt1"] = df_paypal["type"]
    df_paypal["info1"] = "Zahlart"
    del df_paypal["type"]
    df_paypal.loc[df_paypal["bestellnr"].isnull(), "bestellnr"] = "Guthabentransfer"

    df_merge = pd.merge(df_paypal, df_abgleich, how="left", left_on="bestellnr", right_on="belegfeld")
    del df_merge["belegfeld"]
    df_merge["belegfeld"] = df_merge["renr"]
    df_merge.loc[df_merge["belegfeld"].isnull(), "belegfeld"] = df_merge["bestellnr"]
    df_merge.loc[
        (~df_merge["debitor"].isnull())
        & (
            df_merge["inhalt1"].isin(
                [
                    "PayPal Express-Zahlung",
                    "Rückzahlung",
                    "Zahlung im Einzugsverfahren mit Zahlungsrechnung",
                ]
            )
        ),
        "gegenkonto",
    ] = df_merge["debitor"]
    del df_merge["renr"]
    del df_merge["bestellnr"]
    del df_merge["name"]
    del df_merge["debitor"]
    df_merge.loc[df_merge["inhalt1"].str.contains("Fee -"), "buchungstext"] = "Fee - " + df_merge["buchungstext"]
    df_merge.loc[df_merge["gegenkonto"] == "146000", "buchungstext"] = "Guthabentransfer"

    df_export = datev_format(
        df_merge,
        bernr="12168",
        mdtnr="18150",
        skl="6",
        skr="4",
        year=year,
        month=month,
        text="vinico paypal",
    )

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Vinergy",
        conversion="Paypal",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    df_export.to_csv(output_path, sep=";", index=False)

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
