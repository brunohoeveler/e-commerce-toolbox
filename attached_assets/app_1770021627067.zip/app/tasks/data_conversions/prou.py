import io
from pathlib import Path

import polars as pl
from fastapi import UploadFile

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.datev_export import datev_export_polars
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_output_path_datev, strip_task_id


@register_data_conversion(
    data_conversion="ProU",
    conversion="default",
    description="ProU default conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["csv"],
            },
        ),
    },
    output_type="csv",
)
def prou_import(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]

    try:
        df_import = pl.read_csv(file1)
    except FileNotFoundError as e:
        raise Exception("Die Transactions Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Transactions Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    cols = df_import.columns

    df_import = df_import.select(
        [
            pl.col(cols[0]).alias("name"),
            pl.col(cols[1]).alias("geb"),
            pl.col(cols[2]).alias("re"),
            pl.col(cols[3]).alias("datum"),
            pl.col(cols[4]).alias("von"),
            pl.col(cols[5]).alias("leistungsdatum"),
            pl.col(cols[6]).alias("umsatz"),
            pl.col(cols[7]).alias("fall"),
        ]
    )

    df_import = df_import.with_columns(
        [
            pl.lit("2100-" + pl.col("re").str.slice(0, 4) + "-" + pl.col("re").str.slice(7, 2)).alias("belegfeld"),
            pl.lit(df_import["name"] + ", " + df_import["re"]).alias("buchungstext"),
            pl.lit("8104000").alias("konto"),
            pl.lit("40001000").alias("gegenkonto"),
            pl.lit("h").alias("sh"),
        ]
    )

    df_import = df_import.with_columns(
        [
            pl.when(df_import["re"].str.slice(0, 4).is_in(["7355", "7356", "7357", "7358", "7359"])).then(pl.lit("8105000")).otherwise(pl.col("konto")).alias("konto"),
            pl.col("datum").str.slice(0, 6).str.replace(".", "").alias("datum"),
            pl.col("leistungsdatum").str.replace(".", "").alias("leistungsdatum"),
        ]
    ).drop(["name", "geb", "re", "von", "fall"])

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="ProU",
        conversion="default",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        datev_export_polars(
            df=df_import,
            month=month,
            year=year,
            buffer=buffer,
            bernr="12168",
            mdtnr="10652",
            skl="7",
            skr="3",
            text="ProU MVZ Import",
        )

        with open(output_path, "wb") as f:
            f.write(buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
