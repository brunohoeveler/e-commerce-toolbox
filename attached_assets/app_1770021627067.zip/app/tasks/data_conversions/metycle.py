import io
from pathlib import Path

import polars as pl
from fastapi import UploadFile

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_output_path_datev, strip_task_id


@register_data_conversion(
    data_conversion="Metycle",
    conversion="Airwallex",
    description="Metycle Airwallex conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["csv"],
            },
        ),
    },
    output_type="csv",
)
def metycle_airwallex(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]

    # ========================== AIRWALLEX DATEI ==========================
    try:
        df_import = pl.read_csv(file1, skip_rows=5, separator=",", infer_schema_length=0, truncate_ragged_lines=True)
    except FileNotFoundError as e:
        raise Exception("Die Airwallex Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Airwallex ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_import = df_import.select([col for i, col in enumerate(df_import.columns) if i in [1, 6, 10, 13, 23, 25, 28]])

    df_import = df_import.rename(
        dict(
            zip(
                df_import.columns[0:],
                [
                    "Auftragsnummer",
                    "Datum",
                    "Währung",
                    "Umsatz",
                    "Belegfeld1",
                    "bt1",
                    "bt2",
                ],
            )
        )
    )
    df_import = df_import.with_columns(pl.col("Datum").str.slice(0, 10).alias("Datum"))
    df_import = df_import.with_columns(pl.coalesce(pl.col("bt1"), pl.col("bt2"), pl.lit("-")).alias("Buchungstext"))
    df_import = df_import.drop("bt1", "bt2")
    df_import = df_import.with_columns(pl.lit("").alias("Konto"))
    df_import = df_import.filter(~pl.col("Währung").is_in(["CNY"]))
    df_import = df_import.with_columns(pl.when(pl.col("Währung") == "USD").then(pl.lit("1833")).otherwise(pl.col("Konto")).alias("Konto"))
    df_import = df_import.with_columns(pl.when(pl.col("Währung") == "EUR").then(pl.lit("1831")).otherwise(pl.col("Konto")).alias("Konto"))
    df_import = df_import.with_columns(pl.when(pl.col("Währung") == "GBP").then(pl.lit("1834")).otherwise(pl.col("Konto")).alias("Konto"))
    df_import = df_import.with_columns(pl.col("Umsatz").str.replace_all(r"\.", ",").alias("Umsatz"))
    df_import = df_import[
        [
            "Datum",
            "Währung",
            "Umsatz",
            "Belegfeld1",
            "Buchungstext",
            "Auftragsnummer",
            "Konto",
        ]
    ]

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Metycle",
        conversion="Airwallex",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        df_import.write_csv(buffer, separator=";")
        buffer.seek(0)
        with open(output_path, "w", encoding="utf-8-sig") as f:
            f.write(buffer.read().decode("utf-8"))

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
