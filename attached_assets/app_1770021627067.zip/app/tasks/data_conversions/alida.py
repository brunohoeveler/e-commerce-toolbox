import io
from pathlib import Path

import polars as pl
from fastapi import UploadFile

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.datev_export import datev_export_polars
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_output_path_datev, strip_task_id


@register_data_conversion(
    data_conversion="Alida",
    conversion="default",
    description="Alida default conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 2,
                "max_files": 2,
                "extensions": ["xlsx", "xls"],
            },
        ),
    },
    output_type="csv",
)
def alida_import(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]

    try:
        df_import = pl.read_excel(file1)
        assert df_import.width == 20
    except FileNotFoundError as e:
        raise Exception("Die Transactions Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Transactions Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_import = df_import.slice(5)
    cols = df_import.columns
    df_import = df_import.select(
        [
            pl.col(cols[12]).alias("umsatz"),
            pl.col(cols[2]).alias("datum"),
            pl.col(cols[4]).alias("belegfeld"),
            pl.col(cols[13]).alias("buchungstext"),
            pl.col(cols[17]).alias("kontostelle"),
            pl.col(cols[0]).alias("account"),
        ]
    )

    df_import = df_import.with_columns(
        [
            pl.when(pl.col("umsatz").str.contains("-")).then(pl.lit("S")).otherwise(pl.lit("H")).alias("sh"),
            pl.col("umsatz").str.replace_all(r"\.", ",").str.replace_all(r"\-", ""),
            pl.lit("179200").alias("konto"),
            pl.col("buchungstext").str.slice(0, 60).alias("buchungstext"),
        ]
    )

    df_import = df_import.with_columns(
        pl.when(
            # Check if the colon exists in the string (colon_position is not -1)
            pl.col("account").str.find(":") != -1
        )
        .then(
            # Extract the character after the ":" and check if it's a digit
            pl.col("account").str.extract(r":(.)").str.contains(r"^\d$")
        )
        .otherwise(False)  # If there's no ":", return False
        .alias("is_digit_after_colon")
    )

    df_import = df_import.with_columns(
        pl.when((pl.col("account").str.contains(":")) & (pl.col("is_digit_after_colon")))
        .then((pl.col("account").str.slice(pl.col("account").str.find(":") + 1, 6)))
        .otherwise(pl.col("account"))
        .alias("account")
    )

    df_import = df_import.with_columns(pl.col("account").str.slice(0, 6))

    df_import = df_import.with_columns(
        [
            pl.col("datum").str.slice(8, 2) + pl.col("datum").str.slice(5, 2).alias("datum"),
            pl.when(pl.col("kontostelle") == "Denmark").then(pl.lit("10")).alias("kostenstelle"),
        ]
    ).drop("is_digit_after_colon")

    try:
        df_mapping = pl.read_excel(file2)
        assert df_mapping.width == 3
    except FileNotFoundError as e:
        raise Exception("Die Mappings Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Mappings Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_mapping = df_mapping.rename({"Netsuite": "account", "Description": "description", "DATEV": "gegenkonto"})

    # Drop the 'description' column
    df_mapping = df_mapping.drop("description")

    # Drop duplicates based on the 'account' column
    df_mapping = df_mapping.unique(subset=["account"])

    df_mapping = df_mapping.with_columns([pl.col("account").cast(str), pl.col("gegenkonto").cast(str)])

    # Perform the merge (join) operation
    df_merge = df_import.join(df_mapping, on="account", how="left")
    df_merge.drop("account")

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Alida",
        conversion="default",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        datev_export_polars(
            month=month,
            year=year,
            buffer=buffer,
            df=df_merge,
            bernr="490340",
            mdtnr="11015",
            skl="6",
            skr="3",
            text="Alida Import",
        )

        with open(output_path, "wb") as f:
            f.write(buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
