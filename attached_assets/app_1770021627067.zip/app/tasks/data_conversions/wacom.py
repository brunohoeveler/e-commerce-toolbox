from pathlib import Path

import pandas as pd
import polars as pl
from fastapi import UploadFile

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.data_conversions.wacom import wacom_sap_converter
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_output_path, strip_task_id


# Funktion zum Erstellen von Mitarbeiterdatensätzen aus einer Eingabedatei
@register_data_conversion(
    data_conversion="Wacom SAP",
    conversion="Spain",
    description="WACOM SAP Spain Converter",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "description": "Excel file containing Spain data sets",
                "min_files": 1,
                "max_files": 1,
                "extensions": ["xlsx", "xls"],
            },
        ),
    },
    output_type="xlsx",
)
def wacom_sap_spain(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file = files[0]

    df_pandas = pd.read_excel(file, skiprows=12)
    df_pandas.columns.values[0:7] = ["text", "total", "Isidre Martin Solano", "J Antonio Garrido Dominguez", "del", "del", "del"]
    del df_pandas["del"]

    df_import = pl.from_pandas(df_pandas)
    df_import = df_import.filter(pl.col("total").is_not_null())
    df_import = df_import.drop("total")

    df_import = df_import.with_columns(
        pl.when(pl.col("text").str.contains(" 001 "))
        .then(pl.lit("base_salary"))
        .when(pl.col("text").str.contains(" 022 "))
        .then(pl.lit("base_salary"))
        .when(pl.col("text").str.contains(" 023 "))
        .then(pl.lit("base_salary"))
        .when(pl.col("text").str.contains(" 101 "))
        .then(pl.lit("base_salary"))
        .when(pl.col("text").str.contains(" 032 "))
        .then(pl.lit("car_allowance"))
        .when(pl.col("text").str.contains(" 025 "))
        .then(pl.lit("home_office"))
        .when(pl.col("text").str.contains("TOTAL COSTE S.S."))
        .then(pl.lit("soc_sec_employer"))
        .when(pl.col("text").str.contains(" 838 "))
        .then(pl.lit("soc_sec_employee"))
        .when(pl.col("text").str.contains(" 840 "))
        .then(pl.lit("soc_sec_employee"))
        .when(pl.col("text").str.contains(" 862 "))
        .then(pl.lit("income_tax"))
        .when(pl.col("text").str.contains(" 033 "))
        .then(pl.lit("bonus"))
        .when(pl.col("text").str.contains("TOTAL LIQUIDO"))
        .then(pl.lit("net_salary"))
        .alias("text")
    )
    df_import = df_import.filter(pl.col("text").is_not_null())
    df_import = df_import.group_by("text").sum()
    df_import = df_import.unpivot(index="text", variable_name="name", value_name="amount")
    df_import = df_import.with_columns(pl.col("amount").round(2))
    df_import = df_import.filter(pl.col("amount") != 0)
    df_import = df_import.cast({"amount": pl.String})
    df_import = df_import.with_columns(pl.lit(f"Salaries Spain {month} {year}").alias("header"))
    df_import = df_import.with_columns(pl.when(pl.col("text").is_in(["base_salary", "bonus", "home_office", "car_allowance", "soc_sec_employer"])).then(pl.lit("40")).otherwise(pl.lit("50")).alias("sh"))

    df_import = df_import.with_columns(
        pl.when(pl.col("text").is_in(["base_salary", "home_office", "car_allowance"]))
        .then(pl.lit("83222200"))
        .when(pl.col("text") == "bonus")
        .then(pl.lit("83311000"))
        .when(pl.col("text") == "soc_sec_employer")
        .then(pl.lit("83510100"))
        .otherwise(pl.lit("41418150"))
        .alias("account")
    )

    df_social = df_import.filter(pl.col("text") == "soc_sec_employer")
    df_social = df_social.with_columns(pl.lit("50").alias("sh"))
    df_social = df_social.with_columns(pl.lit("41418150").alias("account"))
    df_import = pl.concat([df_import, df_social])

    df_import = df_import.with_columns(pl.concat_str([pl.lit(f"{month}/{year} Spain "), pl.col("text"), pl.lit(" "), pl.col("name")]).alias("text"))
    df_import = df_import.with_columns(
        pl.when((pl.col("sh") == "40") & (pl.col("name").str.contains("(?i)isidre")))
        .then(pl.lit("340302"))
        .when((pl.col("sh") == "40") & (pl.col("name").str.contains("(?i)garrido")))
        .then(pl.lit("490142"))
        .alias("costcenter")
    )
    df_import = df_import.drop("name")

    df_sap = wacom_sap_converter(df=df_import, currency='EUR')

    # Garrido Sonderposition
    df_sap = df_sap.with_columns(pl.when(pl.col('text').str.contains('(?i)garrido')).then(pl.lit('2'))
                                 .otherwise(pl.col('serial')).alias('serial'))
    df_sap = df_sap.with_columns(pl.when(pl.col('text').str.contains('(?i)garrido')).then(pl.lit('1021'))
                                 .otherwise(pl.col('company')).alias('company'))
    df_sap = df_sap.sort(pl.col('serial'))
    df_sap = df_sap.filter(pl.col('amount') != '0.0')



    # Build output path
    output_path = generate_output_path(
        user_id=user_id,
        data_conversion="Wacom SAP",
        conversion="Spain",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="xlsx",
    )

    ensure_output_folder(output_path)

    # Save output
    df_sap.write_excel(output_path)

    # Clean up
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Wacom SAP",
    conversion="Hungary",
    description="WACOM SAP Hungary Converter",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "description": "Excel file containing Hungary data sets",
                "min_files": 1,
                "max_files": 1,
                "extensions": ["xlsx", "xls"],
            },
        ),
    },
    output_type="xlsx",
)
def wacom_sap_hungary(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file = files[0]

    df_import = pd.read_excel(file, dtype=str)
    df_import = pl.from_pandas(df_import)

    df_import = df_import.select([col for i, col in enumerate(df_import.columns) if i in [1, 2, 3]])
    df_import = df_import.rename(dict(zip(df_import.columns[0:], ["text", "text2", "amount"])))

    df_import = df_import.with_columns(
        pl.when(pl.col("text") == "454004")
        .then(pl.lit(f"{month}/{year} Hungary soc_sec_employee HAJNALKA GAL"))
        .when(pl.col("text") == "620004")
        .then(pl.lit(f"{month}/{year} Hungary net_salary HAJNALKA GAL"))
        .when(pl.col("text") == "455000")
        .then(pl.lit(f"{month}/{year} Hungary base_salary HAJNALKA GAL"))
        .when(pl.col("text") == "454104")
        .then(pl.lit(f"{month}/{year} Hungary soc_sec_employer HAJNALKA GAL"))
        .otherwise(pl.col("text"))
        .alias("text")
    )

    df_import = df_import.with_columns(
        pl.when(pl.col("text2").str.contains("(?i)bonus"))
        .then(pl.lit(f"{month}/{year} Hungary bonus HAJNALKA GAL"))
        .when(pl.col("text2").str.contains("(?i)13th"))
        .then(pl.lit(f"{month}/{year} Hungary 13th_salary HAJNALKA GAL"))
        .otherwise(pl.col('text'))
        .alias("text")
    ).drop('text2')


    df_import = df_import.with_columns(pl.lit(f"Salaries Hungary {month} {year}").alias("header"))
    df_import = df_import.with_columns(
        pl.when(pl.col("text").str.contains("base_salary"))
        .then(pl.lit("83222200"))
        .when(pl.col("text").str.contains("bonus"))
        .then(pl.lit("83311000"))
        .when(pl.col("text").str.contains("13th"))
        .then(pl.lit("83222200"))
        .when(pl.col("text").str.contains("soc_sec_employer"))
        .then(pl.lit("83510100"))
        .when(pl.col("text").str.contains("soc_sec_employee"))
        .then(pl.lit("41418210"))
        .when(pl.col("text").str.contains("net_salary"))
        .then(pl.lit("41418210"))
        .alias("account")
    )
    df_import = df_import.with_columns(
        pl.when(pl.col("text").str.contains("base_salary"))
        .then(pl.lit("40"))
        .when(pl.col("text").str.contains("bonus"))
        .then(pl.lit("40"))
        .when(pl.col("text").str.contains("13th"))
        .then(pl.lit("40"))
        .when(pl.col("text").str.contains("soc_sec_employer"))
        .then(pl.lit("40"))
        .when(pl.col("text").str.contains("soc_sec_employee"))
        .then(pl.lit("50"))
        .when(pl.col("text").str.contains("net_salary"))
        .then(pl.lit("50"))
        .alias("sh")
    )

    df_social = df_import.filter(pl.col("text").str.contains("(?i)soc_sec_employer"))
    df_social = df_social.with_columns(pl.lit("50").alias("sh"))
    df_social = df_social.with_columns(pl.lit("41418210").alias("account"))
    df_import = pl.concat([df_import, df_social])

    df_import = df_import.with_columns(pl.when(pl.col("account").is_in(["83222200", "83311000","83510100"])).then(pl.lit("347402")).alias("costcenter"))

    df_sap = wacom_sap_converter(df=df_import, currency="HUF")

    # Build output path
    output_path = generate_output_path(
        user_id=user_id,
        data_conversion="Wacom SAP",
        conversion="Hungary",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="xlsx",
    )

    ensure_output_folder(output_path)

    # Save output
    df_sap.write_excel(output_path)

    # Clean up
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Wacom SAP",
    conversion="Netherlands",
    description="WACOM SAP Netherlands Converter",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "description": "Excel file containing Netherlands data sets",
                "min_files": 1,
                "max_files": 1,
                "extensions": ["csv"],
            },
        ),
    },
    output_type="xlsx",
)
def wacom_sap_netherlands(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file = files[0]

    df_import = pl.read_csv(file, separator=";")

    df_import = df_import.filter(pl.col("Periode") != "nvt")

    df_import = df_import.select([col for i, col in enumerate(df_import.columns) if i in [11, 12, 13]])

    df_import = df_import.with_columns(
        pl.when(pl.col("Debet") == "0").then(pl.concat_str([pl.lit("-"), pl.col("Credit")])).otherwise(
            pl.col("Debet")).alias("amount"))

    df_import = df_import.drop(["Debet", "Credit"])

    df_import = df_import.rename(dict(zip(df_import.columns[0:], ["text", "amount"])))

    df_import = df_import.with_columns(
        pl.when(pl.col("text").str.contains("(?i)salaris"))
        .then(pl.lit(f"{month}/{year} Netherlands base_salary K NOYDENS"))
        .when(pl.col("text").str.contains("(?i)mobil"))
        .then(pl.lit(f"{month}/{year} Netherlands car_allowance K NOYDENS"))
        .when(pl.col("text").str.contains("(?i)lijfrente"))
        .then(pl.lit(f"{month}/{year} Netherlands pension_employer K NOYDENS"))
        .when(pl.col("text").str.contains("(?i)verg"))
        .then(pl.lit(f"{month}/{year} Netherlands home_office K NOYDENS"))
        .when(pl.col("text").str.contains("(?i)cadeau"))
        .then(pl.lit(f"{month}/{year} Netherlands gift_card K NOYDENS"))
        .when(pl.col("text").str.contains("(?i)nettoloon"))
        .then(pl.lit(f"{month}/{year} Netherlands net_salary K NOYDENS"))
        .when(pl.col("text").str.contains("(?i)fiscus"))
        .then(pl.lit(f"{month}/{year} Netherlands tax_and_soc_sec K NOYDENS"))
        .when(pl.col("text").str.contains("(?i)lb-pr"))
        .then(pl.lit("del"))
        .when(pl.col("text").str.contains("(?i)lb/pr"))
        .then(pl.lit("del"))
        .when(pl.col("text").str.contains("(?i)afdr"))
        .then(pl.lit(f"{month}/{year} Netherlands soc_sec_employer K NOYDENS"))
        .when(pl.col("text").str.contains("(?i)wga"))
        .then(pl.lit(f"{month}/{year} Netherlands soc_sec_employer K NOYDENS"))
        .when(pl.col("text").str.contains("(?i)provisie"))
        .then(pl.lit(f"{month}/{year} Netherlands bonus K NOYDENS"))
        .when(pl.col("text").str.contains("(?i)maand"))
        .then(pl.lit(f"{month}/{year} Netherlands 13th_salary K NOYDENS"))
        .otherwise(pl.col("text"))
        .alias("text")
    )

    df_import = df_import.with_columns(pl.col("amount").str.replace_all(r"\,", "."))
    df_import = df_import.cast({"amount": pl.Float64})
    df_import = df_import.group_by("text").sum()
    df_import = df_import.with_columns(pl.col("amount").round(2))
    df_import = df_import.filter(pl.col("text") != "del")
    df_import = df_import.cast({"amount": pl.String})
    df_import = df_import.with_columns(
        pl.when(pl.col("amount").str.contains("-")).then(pl.lit("50")).otherwise(pl.lit("40")).alias("sh"))
    df_import = df_import.with_columns(pl.col("amount").str.replace_all(r"\-", ""))
    df_import = df_import.with_columns(pl.when(pl.col("sh") == "40").then(pl.lit("340302")).alias("costcenter"))
    df_import = df_import.with_columns(pl.lit(f"Salaries Netherlands {month} {year}").alias("header"))
    df_import = df_import.with_columns(
        pl.when(pl.col("text").str.contains("(?i)base_salary"))
        .then(pl.lit("83222200"))
        .when(pl.col("text").str.contains("(?i)car_allowance"))
        .then(pl.lit("83222200"))
        .when(pl.col("text").str.contains("(?i)13th"))
        .then(pl.lit("83222200"))
        .when(pl.col("text").str.contains("(?i)bonus"))
        .then(pl.lit("83311000"))
        .when(pl.col("text").str.contains("(?i)gift_card"))
        .then(pl.lit("83222200"))
        .when(pl.col("text").str.contains("(?i)home_office"))
        .then(pl.lit("83222200"))
        .when(pl.col("text").str.contains("(?i)pension_employer"))
        .then(pl.lit("83510100"))
        .when(pl.col("text").str.contains("(?i)soc_sec_employer"))
        .then(pl.lit("83510100"))
        .when(pl.col("text").str.contains("(?i)tax_and_soc_sec"))
        .then(pl.lit("41418170"))
        .when(pl.col("text").str.contains("(?i)net_salary"))
        .then(pl.lit("41418170"))
        .alias("account")
    )

    df_sap = wacom_sap_converter(df=df_import, currency='EUR')

    # Build output path
    output_path = generate_output_path(
        user_id=user_id,
        data_conversion="Wacom SAP",
        conversion="Netherlands",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="xlsx",
    )

    ensure_output_folder(output_path)

    # Save output
    df_sap.write_excel(output_path)

    # Clean up
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Wacom SAP",
    conversion="Sweden",
    description="WACOM SAP Sweden Converter",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "description": "Excel file containing Sweden data sets",
                "min_files": 1,
                "max_files": 1,
                "extensions": ["xls", "xlsx"],
            },
        ),
    },
    output_type="xlsx",
)
def wacom_sap_sweden(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file = files[0]

    df_import = pl.read_excel(file, infer_schema_length=0)

    df_import = df_import.select([col for i, col in enumerate(df_import.columns) if i in [1, 2, 8]])

    df_import = df_import.rename(dict(zip(df_import.columns[0:], ["text2", "text", "amount"])))

    df_import = df_import.with_columns(
        pl.when(pl.col("text").str.contains("(?i)monthly salary"))
        .then(pl.lit(f"{month}/{year} Sweden base_salary FREDRIK JUTHBERG"))
        .when(pl.col("text").str.contains("(?i)vacation pay"))
        .then(pl.lit(f"{month}/{year} Sweden vacation_pay FREDRIK JUTHBERG"))
        .when(pl.col("text2").str.contains("(?i)912"))
        .then(pl.lit(f"{month}/{year} Sweden income_tax FREDRIK JUTHBERG"))
        .when(pl.col("text").str.contains("(?i)rounding"))
        .then(pl.lit(f"{month}/{year} Sweden currency_rounding FREDRIK JUTHBERG"))
        .when(pl.col("text").str.contains("(?i)social fee"))
        .then(pl.lit(f"{month}/{year} Sweden soc_sec_employer FREDRIK JUTHBERG"))
        .when(pl.col("text2").str.contains("(?i)914"))
        .then(pl.lit(f"{month}/{year} Sweden income_tax_bonus FREDRIK JUTHBERG"))
        .when(pl.col("text2").str.contains("(?i)130"))
        .then(pl.lit(f"{month}/{year} Sweden bonus FREDRIK JUTHBERG"))
        .alias("text")
    ).drop('text2')
    df_import = df_import.filter(pl.col("text") != "null")

    df_social = df_import
    df_social = df_social.cast({"amount": pl.Float64})
    df_social = df_social.with_columns(
        pl.when(pl.col("text").str.contains("(?i)bonus"))
        .then(pl.lit(f"{month}/{year} Sweden net_salary FREDRIK JUTHBERG"))
        .when(pl.col("text").str.contains("(?i)base_salary"))
        .then(pl.lit(f"{month}/{year} Sweden net_salary FREDRIK JUTHBERG"))
        .when(pl.col("text").str.contains("(?i)vacation_pay"))
        .then(pl.lit(f"{month}/{year} Sweden net_salary FREDRIK JUTHBERG"))
        .when(pl.col("text").str.contains("(?i)income_tax"))
        .then(pl.lit(f"{month}/{year} Sweden net_salary FREDRIK JUTHBERG"))
        .when(pl.col("text").str.contains("(?i)currency_rounding"))
        .then(pl.lit(f"{month}/{year} Sweden net_salary FREDRIK JUTHBERG"))
        .when(pl.col("text").str.contains("(?i)soc_sec_employer"))
        .then(pl.lit(f"{month}/{year} Sweden soc_sec_employer FREDRIK JUTHBERG"))
        .alias("text")
    )
    df_social = df_social.group_by("text").sum()
    df_social = df_social.cast({"amount": pl.String})
    df_social = df_social.filter(pl.col("text") != "null")

    df_import = df_import.with_columns(
        pl.when(pl.col("text").str.contains("(?i)base_salary"))
        .then(pl.lit("83222200"))
        .when(pl.col("text").str.contains("(?i)sweden bonus"))
        .then(pl.lit("83311000"))
        .when(pl.col("text").str.contains("(?i)vacation_pay"))
        .then(pl.lit("83222200"))
        .when(pl.col("text").str.contains("(?i)soc_sec_employer"))
        .then(pl.lit("83510100"))
        .when(pl.col("text").str.contains("(?i)currency_rounding"))
        .then(pl.lit("83222200"))
        .when(pl.col("text").str.contains("(?i)income_tax"))
        .then(pl.lit("41418190"))
        .alias("account")
    )
    df_import = df_import.with_columns(
        pl.when(pl.col("text").str.contains("(?i)base_salary"))
        .then(pl.lit("40"))
        .when(pl.col("text").str.contains("(?i)vacation_pay"))
        .then(pl.lit("40"))
        .when(pl.col("text").str.contains("(?i)sweden bonus"))
        .then(pl.lit("40"))
        .when(pl.col("text").str.contains("(?i)soc_sec_employer"))
        .then(pl.lit("40"))
        .when((pl.col("text").str.contains("(?i)currency_rounding")) & (pl.col("amount").str.contains("(?i)-")))
        .then(pl.lit("50"))
        .when(pl.col("text").str.contains("(?i)income_tax"))
        .then(pl.lit("50"))
        .otherwise(pl.lit("40"))
        .alias("sh")
    )

    df_social = df_social.with_columns(
        pl.when(pl.col("text").str.contains("(?i)net_salary")).then(pl.lit("41418190")).when(pl.col("text").str.contains("(?i)soc_sec_employer")).then(pl.lit("41418190")).alias("account")
    )

    df_social = df_social.with_columns(pl.when(pl.col("text").str.contains("(?i)net_salary")).then(pl.lit("50")).when(pl.col("text").str.contains("(?i)soc_sec_employer")).then(pl.lit("50")).alias("sh"))

    df_import = pl.concat([df_import, df_social])
    df_import = df_import.with_columns(pl.col("amount").str.replace_all(r"\-", ""))
    df_import = df_import.with_columns(pl.when(pl.col("account").str.slice(0, 1) == "8").then(pl.lit("340302")).alias("costcenter"))
    df_import = df_import.with_columns(pl.lit(f"Salaries Sweden {month} {year}").alias("header"))

    df_sap = wacom_sap_converter(df=df_import, currency='SEK')

    # Build output path
    output_path = generate_output_path(
        user_id=user_id,
        data_conversion="Wacom SAP",
        conversion="Sweden",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="xlsx",
    )

    ensure_output_folder(output_path)

    # Save output
    df_sap.write_excel(output_path)

    # Clean up
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Wacom SAP",
    conversion="Italy",
    description="WACOM SAP Italy Converter",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "description": "Excel file containing Italy data sets",
                "min_files": 1,
                "max_files": 1,
                "extensions": ["xls", "xlsx"],
            },
        ),
    },
    output_type="xlsx",
)
def wacom_sap_italy(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file = files[0]

    df_import = pl.read_excel(file, infer_schema_length=0)

    df_social = df_import

    df_import = df_import.select([col for i, col in enumerate(df_import.columns) if i in [6, 16, 17]])

    df_import = df_import.rename(dict(zip(df_import.columns[0:], ["name", "text", "amount"])))

    df_import = df_import.with_columns(
        pl.when(pl.col("text").str.contains("(?i)a01001"))
        .then(pl.lit("base_salary"))
        .when(pl.col("text").str.contains("(?i)a01030"))
        .then(pl.lit("base_salary"))
        .when(pl.col("text").str.contains("(?i)a01029"))
        .then(pl.lit("base_salary"))
        .when(pl.col("text").str.contains("(?i)a01028"))
        .then(pl.lit("base_salary"))
        .when(pl.col("text").str.contains("(?i)a01005"))
        .then(pl.lit("bonus"))
        .when(pl.col("text").str.contains("(?i)a08 trattenute"))
        .then(pl.lit("soc_sec_employee"))
        .when(pl.col("text").str.contains("(?i)a09001"))
        .then(pl.lit("income_tax"))
        .when(pl.col("text").str.contains("(?i)a09007"))
        .then(pl.lit("tax_ded_regional"))
        .when(pl.col("text").str.contains("(?i)a09009"))
        .then(pl.lit("tax_ded_local"))
        .when(pl.col("text").str.contains("(?i)a11 arrotondamento"))
        .then(pl.lit("base_salary_add"))
        .when(pl.col("text").str.contains("(?i)a13"))
        .then(pl.lit("net_salary"))
        .otherwise(pl.col("text"))
        .alias("text")
    )

    df_import = df_import.cast({'amount': pl.Float64})
    df_import = df_import.group_by(["name", "text"]).sum()
    df_import = df_import.with_columns(pl.col('amount').round(2))
    df_import = df_import.cast({'amount': pl.String})

    df_import = df_import.filter(pl.col("text").is_in(["base_salary", "soc_sec_employee", "income_tax", "tax_ded_regional", "tax_ded_local", "base_salary_add", "net_salary", "bonus"]))

    df_social = df_social.select([col for i, col in enumerate(df_social.columns) if i in [6, 16, 19]])

    df_social = df_social.rename(dict(zip(df_social.columns[0:], ["name", "text", "amount"])))

    df_social = df_social.with_columns(
        pl.when(pl.col("text").str.contains("(?i)a08021"))
        .then(pl.lit("soc_sec_employer"))
        .when(pl.col("text").str.contains("(?i)c01 contributi"))
        .then(pl.lit("soc_sec_employer"))
        .when(pl.col("text").str.contains("(?i)c03 contributi"))
        .then(pl.lit("soc_sec_employer"))
        .when(pl.col("text").str.contains("(?i)c26001"))
        .then(pl.lit("soc_sec_employer"))
        .otherwise(pl.col("text"))
        .alias("text")
    )

    df_social = df_social.filter(pl.col("text").is_in(["soc_sec_employer"]))
    df_social = df_social.cast({"amount": pl.Float64})

    df_social_all = df_social
    df_social_all = df_social_all.group_by(["text"]).sum()
    df_social_all = df_social_all.with_columns(pl.col('amount').round(2))
    df_social_all = df_social_all.cast({"amount": pl.String})
    df_social_all = df_social_all.with_columns(pl.lit("soc_sec_employer_overall").alias("text"))
    df_social_all = df_social_all.with_columns(pl.lit("all").alias("name"))

    df_social = df_social.group_by(["name", "text"]).sum()
    df_social = df_social.with_columns(pl.col('amount').round(2))
    df_social = df_social.cast({"amount": pl.String})

    df_import = pl.concat([df_import, df_social, df_social_all], how="align")

    df_import = df_import.with_columns(pl.concat_str([pl.lit(f"{month}/{year} Italy "), pl.col("text"), pl.lit(" "), pl.col("name")]).alias("text"))
    df_import = df_import.with_columns(
        pl.when(pl.col("name").str.contains("(?i)corno"))
        .then(pl.lit("340302"))
        .when(pl.col("name").str.contains("(?i)di carmine"))
        .then(pl.lit("341502"))
        .when(pl.col("name").str.contains("(?i)zanardo"))
        .then(pl.lit("490162"))
        .when(pl.col("name").str.contains("(?i)missana"))
        .then(pl.lit("340302"))
        .when(pl.col("name").str.contains("(?i)lorefice"))
        .then(pl.lit("490122"))
        .alias("costcenter")
    )
    df_import = df_import.drop("name")
    df_import = df_import.with_columns(pl.lit(f"Salaries Italy {month} {year}").alias("header"))
    df_import = df_import.with_columns(pl.when(pl.col("amount").str.contains("-")).then(pl.lit("50")).otherwise(pl.lit("40")).alias("sh"))
    df_import = df_import.with_columns(pl.when(pl.col("text").str.contains("soc_sec_employer_overall")).then(pl.lit("50")).otherwise(pl.col("sh")).alias("sh"))
    df_import = df_import.with_columns(pl.col("amount").str.replace_all(r"\-", ""))

    df_import = df_import.with_columns(
        pl.when(pl.col("text").str.contains("(?i)base_salary"))
        .then(pl.lit("83222200"))
        .when(pl.col("text").str.contains("(?i)bonus"))
        .then(pl.lit("83311000"))
        .when(pl.col("text").str.contains("(?i)tax_ded_regional"))
        .then(pl.lit("83510100"))
        .when(pl.col("text").str.contains("(?i)tax_ded_local"))
        .then(pl.lit("83510100"))
        .when(pl.col("text").str.contains("(?i)base_salary_add"))
        .then(pl.lit("83222200"))
        .when(pl.col("text").str.contains("(?i)soc_sec_employee"))
        .then(pl.lit("41418140"))
        .when(pl.col("text").str.contains("(?i)income_tax"))
        .then(pl.lit("41418140"))
        .when(pl.col("text").str.contains("(?i)net_salary"))
        .then(pl.lit("41418140"))
        .when(pl.col("text").str.contains("(?i)soc_sec_employer"))
        .then(pl.lit("83510100"))
        .when(pl.col("text").str.contains("(?i)soc_sec_employer_overall"))
        .then(pl.lit("41418140"))
        .alias("account")
    )

    df_import = df_import.with_columns(pl.when(pl.col("account") == "41418140").then(pl.lit("")).otherwise(pl.col("costcenter")).alias("costcenter"))

    df_sap = wacom_sap_converter(df=df_import, currency='EUR')

    # Build output path
    output_path = generate_output_path(
        user_id=user_id,
        data_conversion="Wacom SAP",
        conversion="Italy",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="xlsx",
    )

    ensure_output_folder(output_path)

    # Save output
    df_sap.write_excel(output_path)

    # Clean up
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Wacom SAP",
    conversion="France",
    description="WACOM SAP France Converter",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "description": "Excel file containing France data sets",
                "min_files": 1,
                "max_files": 1,
                "extensions": ["xls", "xlsx"],
            },
        ),
    },
    output_type="xlsx",
)
def wacom_sap_france(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file = files[0]

    df_pandas = pd.read_excel(file, skiprows=1, dtype=str)

    header = df_pandas.iloc[0].ffill(axis=0)
    df_pandas = df_pandas[1:]
    df_pandas.columns = header

    df_pandas.columns.values[0:2] = ['code', 'text']
    df_pandas = df_pandas.melt(id_vars=['code', 'text'], value_name='amount', var_name='employee')
    df_pandas['amount'] = df_pandas['amount'].astype(str).str.lstrip("\n\r")

    df_import = pl.from_pandas(df_pandas)
    df_import = df_import.with_columns(pl.when(pl.col('amount').is_in(['Base S.', 'Salarial', 'Patronal']))
                                       .then(pl.col('amount')).alias('type'))
    df_import = df_import.with_columns(pl.col('type').forward_fill())
    df_import = df_import.filter(pl.col('amount') != 'nan')
    df_import = df_import.filter(pl.col('employee') != 'TOTAL')
    df_import = df_import.filter(~pl.col('amount').is_in(['Base S.', 'Salarial', 'Patronal']))

    df_import = df_import.with_columns([
        pl.col("employee").str.splitn(" ", 2).struct.field('field_0').alias("maid"),
        pl.col("employee").str.splitn(" ", 2).struct.field('field_1').alias("name")
    ]).drop(['employee', 'maid'])

    df_import = df_import.with_columns(pl.when((pl.col('text').str.contains('(?i)sous-total salaire de base')) &
                                               (pl.col('type').str.contains('(?i)salarial')))
                                       .then(pl.lit('base_salary'))
                                       .when((pl.col('code').is_in(['A06.3', 'F21'])) &
                                             (pl.col('type').str.contains('(?i)salarial')))
                                       .then(pl.lit('home_office'))
                                       .when((pl.col('text') == 'Total des retenues') &
                                             (pl.col('type').str.contains('(?i)salarial')))
                                       .then(pl.lit('soc_sec_employee'))
                                       .when((pl.col('text') == 'Total des retenues') &
                                             (pl.col('type').str.contains('(?i)patronal')))
                                       .then(pl.lit('soc_sec_employer'))
                                       .when((pl.col('text').str.contains('PAS')) &
                                             (pl.col('type').str.contains('(?i)salarial')))
                                       .then(pl.lit('income_tax'))
                                       .when((pl.col('text') == 'Net à payer') &
                                             (pl.col('type').str.contains('(?i)salarial')))
                                       .then(pl.lit('net_salary'))
                                       .when((pl.col('code') == 'D05') &
                                             (pl.col('type').str.contains('(?i)salarial')))
                                       .then(pl.lit('13th_salary'))
                                       .when((pl.col('code') == 'B01') &
                                             (pl.col('type').str.contains('(?i)salarial')))
                                       .then(pl.lit('bonus'))
                                       .when((pl.col('text').str.contains('(?i)heures supplémentaires')) &
                                             (pl.col('type').str.contains('(?i)salarial')))
                                       .then(pl.lit('extra_hours'))
                                       .when((pl.col('text').str.contains('(?i)heures de dimanche')) &
                                             (pl.col('type').str.contains('(?i)salarial')))
                                       .then(pl.lit('extra_hours'))
                                       .alias('text'))

    df_import = df_import.filter(pl.col('text').is_not_null()).drop(['code', 'type'])
    df_import = df_import.cast({'amount': pl.Float64})
    df_import = df_import.group_by(['text', 'name']).sum()
    df_import = df_import.with_columns(pl.col('amount').round(2))
    df_import = df_import.cast({'amount': pl.String})
    df_import = df_import.with_columns(pl.col('amount').str.replace(r'\-', ''))

    df_import = df_import.with_columns(pl.lit(f"Salaries France {month} {year}").alias('header'))
    df_import = df_import.with_columns(pl.concat_str([pl.lit(f"{month}/{year} France "), pl.col('text'), pl.lit(' '), pl.col('name')])
                                       .alias('text'))

    df_import = df_import.with_columns(pl.when(pl.col('text').str.contains('base_salary')).then(pl.lit('83222200'))
                                       .when(pl.col('text').str.contains('home_office')).then(pl.lit('83222200'))
                                       .when(pl.col('text').str.contains('extra_hours')).then(pl.lit('83222200'))
                                       .when(pl.col('text').str.contains('13th_salary')).then(pl.lit('83222200'))
                                       .when(pl.col('text').str.contains('bonus')).then(pl.lit('83311000'))
                                       .when(pl.col('text').str.contains('soc_sec_employer')).then(pl.lit('83510100'))
                                       .when(pl.col('text').str.contains('soc_sec_employee')).then(pl.lit('41418120'))
                                       .when(pl.col('text').str.contains('net_salary')).then(pl.lit('41418120'))
                                       .when(pl.col('text').str.contains('income_tax')).then(pl.lit('41418120'))
                                       .alias('account'))

    df_social = df_import.filter(pl.col('text').str.contains('soc_sec_employer'))
    df_social = df_social.with_columns(pl.lit('41418120').alias('account'))

    df_import = pl.concat([df_import, df_social])
    df_import = df_import.sort('name').drop('name')
    df_import = df_import.with_columns(pl.when(pl.col('account').str.slice(0, 1) == '8')
                                       .then(pl.lit('40')).otherwise(pl.lit('50')).alias('sh'))
    df_import = df_import.with_columns(pl.when(pl.col('account').str.slice(0, 1) == '8')
                                       .then(pl.when(pl.col('text').str.contains('(?i)joao')).then(pl.lit('340502'))
                                             .when(pl.col('text').str.contains('(?i)lory')).then(pl.lit('340302'))
                                             .when(pl.col('text').str.contains('(?i)stadler')).then(pl.lit('341502'))
                                             ).alias('costcenter'))

    df_sap = wacom_sap_converter(df=df_import, currency='EUR')

    # Build output path
    output_path = generate_output_path(
        user_id=user_id,
        data_conversion="Wacom SAP",
        conversion="France",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="xlsx",
    )

    ensure_output_folder(output_path)

    # Save output
    df_sap.write_excel(output_path)

    # Clean up
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
