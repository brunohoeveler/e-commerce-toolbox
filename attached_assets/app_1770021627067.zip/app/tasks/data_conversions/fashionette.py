import io
from pathlib import Path
from zipfile import ZipFile

import polars as pl
import xlsxwriter
from fastapi import UploadFile

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.datev_export import export_csv
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_output_path_datev, strip_task_id


@register_data_conversion(
    data_conversion="Fashionette",
    conversion="Intrastat",
    description="Fashionette Intrastat conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["xlsx", "xls"],
            },
        ),
    },
    output_type="csv",
)
def fashionette_intra(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]

    # ============================= FASHIONETTE IMPORT ===============================
    try:
        df_import = pl.read_excel(file1)
    except FileNotFoundError as e:
        raise Exception("Die Fashionette Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Fashionette Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    cols = df_import.columns

    df_import = df_import.select(
        [
            pl.col(cols[0]).alias("art"),
            pl.col(cols[5]).alias("zollpos"),
            pl.col(cols[6]).alias("beschreibung"),
            pl.col(cols[8]).alias("mwstid"),
            pl.col(cols[9]).alias("artgesch"),
            pl.col(cols[12]).alias("landhk"),
            pl.col(cols[13]).alias("einheit"),
            pl.col(cols[14]).alias("menge"),
            pl.col(cols[15]).alias("netto"),
            pl.col(cols[16]).alias("total"),
            pl.col(cols[17]).alias("betrag"),
            pl.col(cols[18]).alias("statistik"),
        ]
    )

    df_import = df_import.with_columns(
        [
            pl.lit("DE").alias("land"),
            pl.lit(pl.col("total").cast(pl.Int64) * 0.001).alias("gewicht"),
        ]
    )

    df_import = df_import.with_columns(
        [
            pl.col("gewicht").round(3).alias("gewicht"),
            pl.col("gewicht").cast(pl.Utf8).str.replace(".", ",").alias("gewicht"),
            pl.when(pl.col("einheit").str.contains("ja")).then(pl.lit("1,000")).otherwise(pl.lit("0,000")).alias("menge"),
            pl.when(pl.col("gewicht").str.len_chars() == 1)
            .then(pl.col("gewicht") + ",000")
            .when(pl.col("gewicht").str.len_chars() == 3)
            .then(pl.col("gewicht") + "00")
            .when(pl.col("gewicht").str.len_chars() == 4)
            .then(pl.col("gewicht") + "0")
            .otherwise(pl.col("gewicht"))
            .alias("gewicht"),
        ]
    )

    df_import = df_import.with_columns([pl.col("gewicht").str.slice(0, 5).alias("gewicht")])

    df_import = df_import.with_columns(
        [
            pl.when(pl.col("gewicht") == "0,000").then(pl.lit("0,001")).otherwise(pl.col("gewicht")).alias("gewicht"),
            pl.col("betrag").cast(pl.Utf8) + ",00",
            pl.col("statistik").cast(pl.Utf8) + ",00",
            pl.col("beschreibung").cast(pl.Utf8).str.replace(";", ","),
            pl.col("zollpos").cast(pl.Utf8),
        ]
    )

    # ============================ ZOLL DATEI ========================================
    try:
        df_zoll = pl.read_excel("resources/warenverzeichnis_zoll.xlsx", sheet_name="warenverzeichnis")
    except FileNotFoundError as e:
        raise Exception("Die OrderTag Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der OrderTag Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_zoll = df_zoll.select(
        {
            df_zoll.columns[1]: "zollpos",
            df_zoll.columns[3]: "einheitzoll",
        }
    )

    df_zoll = df_zoll.filter(pl.col("einheitzoll").is_not_null())

    df_zoll = df_zoll.with_columns([pl.col("zollpos").str.replace(" ", "").alias("zollpos")])

    df_zoll = df_zoll.with_columns(
        [
            pl.when(pl.col("zonlpos").str.len_chars() == 6).then(pl.col("zollpos").cast(pl.Utf8) + "00").cast(str).alias("zollpos"),
        ]
    ).unique(subset="zollpos")

    df_merge = df_import.join(df_zoll, on="zollpos", how="left")

    df_merge = df_merge.with_columns(
        [
            pl.when(pl.col("einheitzoll").str.contains("-")).then(pl.lit("Nein")).otherwise(pl.lit("Ja")).alias("zollvorgabe"),
            pl.when((pl.col("zollvorgabe") == "Ja") & (pl.col("einheit") == "Nein")).then(pl.lit("1,000")).otherwise(pl.col("menge")).alias("menge"),
            pl.col("menge").str.replace(".", ",").alias("menge"),
        ]
    )

    df_merge = df_merge.with_columns(
        [
            pl.when(pl.col("einheitzoll") == "g").then(pl.col("total").cast(pl.Utf8) + ",000").otherwise(pl.col("menge")).alias("menge"),
            pl.col("menge").str.replace(".", ",").alias("menge"),
        ]
    )

    df_merge = df_merge.with_columns(
        [
            pl.col("menge").str.replace(".", ",").alias("menge"),
        ]
    ).select(
        [
            "art",
            "zollpos",
            "beschreibung",
            "land",
            "landhk",
            "artgesch",
            "gewicht",
            "menge",
            "betrag",
            "statistik",
            "mwstid",
        ]
    )

    df_fexport = df_merge.filter(pl.col("art") == "Eingang")
    df_fimport = df_merge.filter(pl.col("art") == "Versendungen")
    df_fexport = df_fexport.drop("art")
    df_fimport = df_fimport.drop(["art", "mwstid"])

    # ============================= CSV & EXCEL EXPORT ===============================
    csv_fexport_buffer = io.BytesIO()
    csv_fimport_buffer = io.BytesIO()
    export_csv(df=df_fexport, sep=";", path=csv_fexport_buffer)
    export_csv(df=df_fimport, sep=";", path=csv_fimport_buffer)
    csv_fexport_buffer.seek(0)
    csv_fimport_buffer.seek(0)

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Fashionette",
        conversion="Intra",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="zip",
    )

    ensure_output_folder(output_path)

    # Use a ZipFile object to write multiple dataframes to the buffer
    with ZipFile(output_path, "w") as zf:
        # CSV for df_fexport
        df_fexport.write_csv(csv_fexport_buffer, separator=";")
        csv_fexport_buffer.seek(0)
        zf.writestr(
            f"Fashionette_Intrastat_Export_{year}_{month}.csv",
            csv_fexport_buffer.read(),
        )

        # CSV for df_fimport
        df_fimport.write_csv(csv_fimport_buffer, separator=";")
        csv_fimport_buffer.seek(0)
        zf.writestr(
            f"Fashionette_Intrastat_Import_{year}_{month}.csv",
            csv_fimport_buffer.read(),
        )

        # Excel file with multiple sheets
        excel_buffer = io.BytesIO()
        with xlsxwriter.Workbook(excel_buffer) as workbook:
            # Add export sheet
            export_sheet = workbook.add_worksheet("export")
            for row_idx, row in enumerate(df_fexport.to_numpy()):
                export_sheet.write_row(row_idx, 0, row)

            # Add import sheet
            import_sheet = workbook.add_worksheet("import")
            for row_idx, row in enumerate(df_fimport.to_numpy()):
                import_sheet.write_row(row_idx, 0, row)

        excel_buffer.seek(0)
        zf.writestr(f"Fashionette_Intrastat_Protokoll_{year}_{month}.xlsx", excel_buffer.read())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
