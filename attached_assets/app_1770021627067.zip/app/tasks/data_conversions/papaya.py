import math
import re
from pathlib import Path

import langid
import numpy as np
import pandas as pd
import pdfplumber
from fastapi import UploadFile
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils.dataframe import dataframe_to_rows

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_output_path, strip_task_id


@register_data_conversion(
    data_conversion="Papaya",
    conversion="Lohnsteuer",
    description="Papaya Lohnsteuer conversion",
    input_type={
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["pdf"],
            },
        ),
    },
    output_type="xlsx",
)
def papaya_lohnsteuer(task, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    our_files = files[0]

    ################################ REGULARY EXPRESSION FOR ALL THE RESEARCH IN THE PDF FILES ########################################################

    name = re.compile(
        r'(?P<first_name>[A-ZÄÖÜ][a-zäöüß]+)\s(?P<last_name>[A-ZÄÖÜ][a-zäöüß-]+(?:\s(?:von|von der|van der))?)(?:\s(?P<suffix>(?<=\s)[JS]r\.|I{1,3}))?')  # Regular expressiob for all name

    Companyname = re.compile(r'GmbH')  # Regular expression for company name

    Base_Salary = re.compile(r'Salary/Gehalt')  # Regular expression for gehalt

    TGI = re.compile(r'Tax/Social')  # Regular expression for social

    Net = re.compile(r'Acc.no')  # Regular expression for net pay

    # NetIncome=re.compile(r'^Statement of earnings')

    Wage = re.compile(r'(^L|^N\s1.)')  # Regular expression for Wage Tax and Tax Deduction
    WageS = re.compile(r'^S\s\d')
    WageE = re.compile(r'^E\s\d')

    Car = re.compile(r'Privatfahrten/priv. use')  #

    CarAllowance = re.compile(r'car benefit/KFZ- Sachb.')

    Commission = re.compile(r'^011\sPrämie')

    Period = re.compile(r'^Pay Advice')

    ID = re.compile(r'^000')

    Uberstd = re.compile('Überstdgrundvergütung')
    Uberstd2 = re.compile('^N\s002')
    WeekendSamstag = re.compile('090 weekend work 150% Satu.')
    WeekendSonntag = re.compile('092 weekend work 150% Sund. ')

    BetragAVAG = re.compile(r'901 Betr.AV.AG lfd.ST-frei')
    BetragAVANST = re.compile(r'911 Betr.AV.AN lfd.ST-frei')
    BetragAVANGE = re.compile('914 Betr.AV.AN lfd.Geh.Ver ')

    PV = re.compile(r'AG-Zuschuss zur PV')

    KV = re.compile(r'AG-Zuschuss zur KV')

    GBzurPV = re.compile(r'Gesamtbeitrag zur PV')

    GBzurKV = re.compile(r'Gesamtbeitrag zur KV')

    HO = re.compile(r'Home Office')

    Contrgroup = re.compile(r'^\d{8}\w\d{3}')
    # Kirche=re.compile(r'Home Office')
    HIincome = re.compile(r'^Tax. ')

    CI24 = re.compile('^Solidarity surcharge')

    PIline = re.compile('^Wage tax')

    UIline = re.compile('^Church tax')

    Bonuslfd = re.compile('Bonus lfd.')
    BonusEBZ = re.compile('009 Bonus EBZ')

    RAllowance = re.compile('Residence Allowance')
    RAllowanceNet = re.compile('119\sResidence Allowance net')

    PrivateLI = re.compile('priv. liability insura. ')

    PrivateHI = re.compile('priv. household insura. ')

    Direkt = re.compile('Direktversicherung')
    CorrectionN = re.compile('^N\s')

    AGzuschussPV0 = re.compile('9983 AG-Zuschuss zur PV')

    AGzuschussKV0 = re.compile('9995 AG-Zuschuss zur KV')

    Bereits = re.compile('9079 bereits erhalten|Already paid')

    lineitemsw = re.compile('^Tx')

    Correction = re.compile('From correction')

    Bav_Abzug = re.compile('bAV-Abzug')

    #######################################FUNCTION###############################################

    def extract_UI(line_items, indicators):
        for ind in indicators:
            if ind in line_items:
                idx = line_items.index(ind)
                if idx > 0:
                    value = line_items[idx - 1]
                    value = f"{value[:-2]},{value[-2:]}"
                    return value.replace('.', '')
        return None

    def extract_value_before(line_items, indicators, offset):
        for ind in indicators:
            if ind in line_items:
                idx = line_items.index(ind)
                if idx >= offset:
                    return line_items[idx - offset]
        return None

    def extract_value_after(line_items, indicators, offset=1):
        for ind in indicators:
            if ind in line_items:
                idx = line_items.index(ind)
                if idx + offset < len(line_items):
                    return line_items[idx + offset]
        return None

    ################################  DECLARATION OF ALL THE LIST ###################################################################

    Company = []
    Employee = []
    Basesalary = []
    Basesalary2 = []  # Pour le total
    TotalGrossIncome = []
    MitarbeiterID = []
    Netpay = []
    WageTax = []
    WageTaxN = []
    WageTaxS = []
    WageTaxE = []
    CarBenefit = []
    CarBenefitMinus = []
    CommissionList = []
    Date = []

    Uberstunde = []
    SaturdayWork = []
    SundayWork = []

    PersonalBetriebNr = []

    Betrag901 = []
    Betrag911 = []
    Betrag914 = []
    AGZuschussKV = []
    AGZuschussPV = []
    BereitsErhalten = []
    GBKV = []
    GBPV = []
    Homeoffice = []
    ChurchTax = []
    ChurchTaxN = []
    ChurchTaxS = []
    Solidarity = []
    SolidarityN = []
    SolidarityS = []
    SocialD = []
    SocialDN = []
    AGsocial = []
    CIcont = []
    CIcontN = []
    PICont = []
    PIContN = []
    UICont = []
    UIContN = []
    HICont = []
    HIContN = []
    CIcontE = []
    PIContE = []
    UIContE = []
    HIContE = []
    EmpSocSec = []
    Bav_list = []
    Bav_listAbzug = []
    Cont = []
    ERTotalCost = []
    Emp = []
    Bonus = []
    BonusEBZlist = []
    Resid = []
    ResidNet = []
    PLI = []
    PHI = []
    DV = []
    linewage = []
    linetitlewage = []
    FromCorrection = []
    CorrectionSickPayList = []
    CorrectionNSalaryList = []
    CorrectionHIlist = []
    CorrectionNHIlist = []
    CorrectionNCIlist = []
    CorrectionCIlist = []
    FZList = []
    SonderzahlunglIST = []
    UnterstutzungLIST = []

    #############################################  RESEARCH START AND INCORPORATION OF ALL AMOUNT AND NAME IN LIST   ####################################

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            # Récupération du contenu de la page
            text = page.extract_text()
            for line in text.split('\n'):
                if Bereits.search(line):
                    line_items_Bereits = line.split()
                    last_value = line_items_Bereits[-1]

                    # Normalisation : enlever les séparateurs et remplacer la virgule
                    val = last_value.replace('.', '').replace(',', '.').strip()

                    # Cas 1 : le "-" est à la fin → on le met au début
                    if val.endswith('-') or val.startswith('-'):
                        val = '-' + val[:-1]

                    # Cas 3 : pas de "-" → on laisse tel quel
                    else:
                        val = val

                    BereitsErhalten2 = (val, num_page)
                    BereitsErhalten.append(BereitsErhalten2)

                if CorrectionN.search(line):
                    # Si oui → on garde uniquement les lignes qui commencent par "N"
                    lineitemsN = line.split()
                    if "001" in lineitemsN:
                        CSalaryAmount = (lineitemsN[-1].replace('-', ''), num_page)
                        CorrectionNSalaryList.append(CSalaryAmount)
                    else:
                        line_items_WageN = line.split()
                        if line_items_WageN[0] == 'N' and \
                                (line_items_WageN[2] != line_items_WageN[1]):
                            WageTaxN1 = lineitemsN[2]
                            WageTaxN1 = f"{WageTaxN1[:-2]},{WageTaxN1[-2:]}"
                            WageTaxN1 = (WageTaxN1, num_page)
                            WageTaxN.append(WageTaxN1)
                            # SocialDN1 = (line_items_WageN[-1].replace('-', ''), num_page)
                            # SocialDN.append(SocialDN1)

                            # print(WageTaxN1)

                            if len(line_items_WageN) > 4:
                                SolidarityN1 = line_items_WageN[3]
                                SolidarityN1 = f"{SolidarityN1[:-2]},{SolidarityN1[-2:]}"
                                SolidarityN1 = (SolidarityN1, num_page)
                                SolidarityN.append(SolidarityN1)
                                # SocialDN1 = (line_items_WageN[-1].replace('-', ''), num_page)
                                # SocialDN.append(SocialDN1)
                                # print(SolidarityS2)
                        else:
                            if (line_items_WageN[2] == line_items_WageN[1]):
                                # print(line_items_Wage)
                                SocialDN1 = (line_items_WageN[-1].replace('-', ''), num_page)
                                SocialDN.append(SocialDN1)
                                UI = line_items_WageN[-2].replace('-', '')
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = (UI.replace('.', ''), num_page)

                                PI = line_items_WageN[-3].replace('-', '')
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PI = (PI.replace('.', ''), num_page)

                                # UI = f"{UI[:-2]},{UI[-2:]}"

                                # AGPV = (line_items_ZuschussPV[-1].replace('-', '').replace('.', ''), num_page)
                                UIContN.append(UI)
                                PIContN.append(PI)
            # print(text)
            if text and "(1.C)" in text:
                continue
            elif text and "(2.C)" in text:
                continue

            lang = langid.classify(text)[0]

            # print(text)
            for line in text.split('\n'):
                if lang == 'en':

                    if name.search(line):

                        # elif not Car.search(line):
                        # CarBenefit.append('')
                        line_items_name = line.split()
                        if len(line_items_name) <= 3 and "Straße" not in line_items_name \
                                and "Weg" not in line_items_name \
                                and "Security" not in line_items_name \
                                and "Sozialversicherungspflichtiges" not in line_items_name \
                                and "Verdienstbescheinigung" not in line_items_name \
                                and "Pfändung" not in line_items_name \
                                and "Darlehen" not in line_items_name \
                                and "Commerzbank" not in line_items_name \
                                and "Landstr." not in line_items_name \
                                and "Str." not in line_items_name \
                                and "Ufer" not in line_items_name \
                                and "Damm" not in line_items_name \
                                and "Bad" not in line_items_name \
                                and 'Csepella,' not in line_items_name:
                            filtered_list = [item for item in line_items_name if
                                             not item[-1].replace(',', '').replace('.', '').isdigit()]
                            Mitarbeiter = ' '.join(filtered_list)
                            Employee.append(Mitarbeiter)

                            # print(Mitarbeiter)

                    if Companyname.search(line):
                        line_items_company = line.split()
                        if len(line_items_company) == 2:
                            if "Docker" in line_items_company[0]:
                                Company.append('Docker')
                            elif "LANDA" in line_items_company[0]:
                                Company.append('Landa Digital Printing,Germany')
                            elif "TotalIT" in line_items_company[0]:
                                Company.append('Total IT')

                    if Base_Salary.search(line):
                        line_items_base = line.split()
                        if 'Salary/Ge' not in line_items_base:
                            BaseS = (line_items_base[-1].replace('.', '').replace('-', ''), num_page)

                            Basesalary.append(BaseS)
                            BaseS2 = line_items_base[-1].replace('.', '').replace('-', '')
                            Basesalary2.append(BaseS2)
                        # print(line_items_base)

                    if TGI.search(line):
                        line_items_tgi = line.split()
                        TotalGrossIncome.append(line_items_tgi[-1].replace('.', ''))
                        # print(line_items_tgi)
                        # print(line_items_base)
                    if Net.search(line):
                        line_items_net = line.split()
                        # print(line_items_net)
                        if "pay" and "advice." not in line_items_net:
                            # del line_items_net

                            if len(line_items_net[-2]) > 3:
                                # print(line_items_net)
                                AG = line_items_net[-2].replace('.', '').replace('-', '')
                                AG = f"{AG[:-2]},{AG[-2:]}"
                                AGsocial.append(AG)

                                ERTotalCost.append(line_items_net[-2].replace('.', '').replace('-', ''))
                                EmpSoc = line_items_net[-3].replace('.', '').replace('-', '')
                                EmpSoc = f"{EmpSoc[:-2]},{EmpSoc[-2:]}"
                                Emp.append(EmpSoc)

                                EmpSocSec2 = line_items_net[-4].replace('.', '').replace('-', '')

                                EmpSocSec2 = f"{EmpSocSec2[:-2]},{EmpSocSec2[-2:]}"
                                if len(line_items_net[-4]) == 2:
                                    EmpSocSec2 = '0,00'
                                    # EmpSocSec.append(EmpSocSec2)
                                # print(EmpSocSec2)
                                EmpSocSec.append(EmpSocSec2)
                            # elif line_items_net[-4] =='06':
                            # EmpSocSec.append('0,00')

                            else:
                                AGsocial.append('')

                            # AGsocial.append(line_items_net[-2].replace('.','').replace('-',''))
                            # print(line_items_net)
                            Netpay.append(line_items_net[-1].replace('.', '').replace('-', ''))

                    if Correction.search(line):
                        line_items_correction = line.split()
                        last_value = line_items_correction[-1]

                        # Remplacer la virgule par un point pour les décimales
                        val = last_value.replace('.', '').replace(',', '.').strip()

                        # Cas 1 : le "-" est à la fin → on le met au début
                        if val.endswith('-') or val.startswith('-'):
                            val = '-' + val[:-1]
                        else:
                            val = val

                        Correction2 = (val, num_page)
                        FromCorrection.append(Correction2)
                        # print(FromCorrection)

                        # print(FromCorrection)

                    if WageS.search(line):
                        line_items_WageS = line.split()
                        WageTaxS2 = line_items_WageS[2]
                        WageTaxS2 = f"{WageTaxS2[:-2]},{WageTaxS2[-2:]}"
                        WageTaxS2 = (WageTaxS2, num_page)
                        WageTaxS.append(WageTaxS2)
                        # print(WageTaxS)

                        if len(line_items_WageS) > 4:
                            SolidarityS2 = line_items_WageS[3]
                            # print(SolidarityS2)

                            if int(SolidarityS2) < 10000:
                                ChurchTaxS2 = SolidarityS2
                                ChurchTaxS2 = (ChurchTaxS2, num_page)
                                ChurchTaxS.append(ChurchTaxS2)
                            else:
                                SolidarityS2 = f"{SolidarityS2[:-2]},{SolidarityS2[-2:]}"
                                SolidarityS2 = (SolidarityS2, num_page)
                                SolidarityS.append(SolidarityS2)

                    if WageE.search(line):
                        line_items_WageE = line.split()
                        WageTaxE2 = line_items_WageE[2]
                        WageTaxE2 = f"{WageTaxE2[:-2]},{WageTaxE2[-2:]}"
                        WageTaxE2 = (WageTaxE2, num_page)
                        WageTaxE.append(WageTaxE2)
                        # print(line_items_WageE)
                        UIE = line_items_WageE[-3]
                        UIE = f"{UIE[:-2]},{UIE[-2:]}"
                        UIE = (UIE.replace('.', ''), num_page)

                        PIE = line_items_WageE[-4]
                        PIE = f"{PIE[:-2]},{PIE[-2:]}"
                        PIE = (PIE.replace('.', ''), num_page)

                        HIE = line_items_WageE[-5]
                        HIE = f"{HIE[:-2]},{HIE[-2:]}"
                        HIE = (HIE.replace('.', ''), num_page)

                        CIE = line_items_WageE[-2]
                        CIE = f"{CIE[:-2]},{CIE[-2:]}"
                        CIE = (CIE.replace('.', ''), num_page)

                        UIContE.append(UIE)
                        PIContE.append(PIE)
                        HIContE.append(HIE)
                        CIcontE.append(CIE)

                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # print(line_items_Wage)

                        # print(line_items_Wage)
                        if line_items_Wage[
                            0] == 'L' and '773,80' not in line_items_Wage and 'Z' not in line_items_Wage:  # FAIRE EN SORTE DAVOIR LES HI COMTRIBUTIONS
                            # print(line_items_Wage)

                            if len(line_items_Wage) > 2 and line_items_Wage[2] != line_items_Wage[1] and \
                                    line_items_Wage[3] != line_items_Wage[2]:
                                # print(line_items_Wage)
                                Wage2 = line_items_Wage[2]

                                # print(Sol2)
                                # Format with one comma before the last two numbers
                                Wage2 = f"{Wage2[:-2]},{Wage2[-2:]}"
                                WageTax.append(Wage2.replace('.', ''))
                                # print(Wage2)

                                if len(line_items_Wage) == 5:

                                    # Solidarity.append(Solidarity2)

                                    if len(line_items_Wage[2]) >= len(line_items_Wage[3]) and int(
                                            line_items_Wage[-1].replace(".", "").replace(",", "")) < 200000:
                                        churchtax2 = line_items_Wage[-2]
                                        churchtax2 = f"{churchtax2[:-2]},{churchtax2[-2:]}"
                                        churchtax2 = (churchtax2, num_page)
                                        ChurchTax.append(churchtax2)
                                    elif len(line_items_Wage[2]) >= len(line_items_Wage[3]) and int(
                                            line_items_Wage[-1].replace(".", "").replace(",", "")) > 200000:
                                        Solidarity2 = line_items_Wage[-2]
                                        Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                        Solidarity2 = (Solidarity2, num_page)
                                        Solidarity.append(Solidarity2)
                                elif len(line_items_Wage) == 6 and len(line_items_Wage[-2]) == 3:
                                    Solidarity2 = line_items_Wage[-2]
                                    Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                    Solidarity2 = (Solidarity2, num_page)
                                    Solidarity.append(Solidarity2)
                                elif len(line_items_Wage) == 5 and len(line_items_Wage[2]) - len(
                                        line_items_Wage[3]) == 1 and line_items_Wage[-2] < "15000":
                                    churchtax2 = line_items_Wage[-2]
                                    churchtax2 = f"{churchtax2[:-2]},{churchtax2[-2:]}"
                                    churchtax2 = (churchtax2, num_page)
                                    ChurchTax.append(churchtax2)
                                elif len(line_items_Wage) == 5 and len(line_items_Wage[2]) - len(
                                        line_items_Wage[-1]) == 1 and line_items_Wage[-2] > "15000":
                                    Solidarity2 = line_items_Wage[-2]
                                    Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                    Solidarity2 = (Solidarity2, num_page)
                                    Solidarity.append(Solidarity2)

                                elif len(line_items_Wage) == 6:
                                    Solidarity2 = line_items_Wage[-2]
                                    Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                    Solidarity2 = (Solidarity2, num_page)
                                    Solidarity.append(Solidarity2)

                                    churchtax2 = line_items_Wage[-3]
                                    churchtax2 = f"{churchtax2[:-2]},{churchtax2[-2:]}"
                                    churchtax2 = (churchtax2, num_page)
                                    ChurchTax.append(churchtax2)

                                    # print(churchtax2)





                            elif len(line_items_Wage) == 2:  # KEY MARCUS MOSS
                                # WageTax.append('')
                                SocialD.append('')
                                # Basesalary.append('0')
                                # UICont.append('')
                                # 0PICont.append('')

                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:
                            # print(line_items_Wage)
                            SocialD.append(line_items_Wage[-1].replace('.', ''))

                            # else:
                            # SocialD.append('')
                            # print(line_items_Wage)
                            # SocialD.append(line_items_Wage[-1])
                            if len(line_items_Wage) == 6:
                                # print(line_items_Wage)
                                UI = line_items_Wage[-2].replace('-', '')
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = (UI.replace('.', ''), num_page)

                                PI = line_items_Wage[-3].replace('-', '')
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PI = (PI.replace('.', ''), num_page)

                                # UI = f"{UI[:-2]},{UI[-2:]}"

                                # AGPV = (line_items_ZuschussPV[-1].replace('-', '').replace('.', ''), num_page)
                                UICont.append(UI)
                                PICont.append(PI)


                            elif 'Z' in line_items_Wage or 'E' in line_items_Wage or '1' in line_items_Wage or '2' in line_items_Wage or '3' in line_items_Wage or '4' in line_items_Wage:

                                # print(line_items_Wage)
                                UI = extract_UI(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'])

                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = UI.replace(',,', ',')

                                UI = (UI.replace('.', ''), num_page)

                                PI = extract_value_before(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'], 2)
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PI = (PI.replace('.', ''), num_page)

                                if len(line_items_Wage) > 7:
                                    HI = extract_value_before(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'], 3)

                                    HI = f"{HI[:-2]},{HI[-2:]}"
                                    HI = (HI.replace('.', ''), num_page)
                                    HICont.append(HI)

                                    CI = extract_value_after(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'], 1)

                                    CI = f"{CI[:-2]},{CI[-2:]}"
                                    CI = (CI.replace('.', ''), num_page)
                                    CIcont.append(CI)

                                # UI = f"{UI[:-2]},{UI[-2:]}"
                                # PI = f"{PI[:-2]},{PI[-2:]}"
                                # SocialD.append(line_items_Wage[-1])

                                UICont.append(UI)
                                PICont.append(PI)



                            elif len(line_items_Wage) >= 9:
                                # print(line_items_Wage)
                                UI = line_items_Wage[-3]
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = (UI.replace('.', ''), num_page)

                                PI = line_items_Wage[-4]
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PI = (PI.replace('.', ''), num_page)

                                HI = line_items_Wage[-6]
                                HI = f"{HI[:-2]},{HI[-2:]}"
                                HI = (HI.replace('.', ''), num_page)

                                CI = line_items_Wage[-2]
                                CI = f"{CI[:-2]},{CI[-2:]}"
                                CI = (CI.replace('.', ''), num_page)

                                # UI = f"{UI[:-2]},{UI[-2:]}"
                                # PI = f"{PI[:-2]},{PI[-2:]}"
                                UICont.append(UI)
                                PICont.append(PI)
                                HICont.append(HI)
                                CIcont.append(CI)
                            # print(line_items_Wage)
                            # else:
                            # SocialD.append('')

                    if Car.search(line):
                        line_items_Car = line.split()
                        CarPrivate = (line_items_Car[-1].replace('-', ''), num_page)
                        CarPrivate2 = ('-' + line_items_Car[-1].replace('-', ''), num_page)
                        CarBenefit.append(CarPrivate)
                        # listminus=["-" + x[:-1] for x in CarBenefit]
                        CarBenefitMinus.append(CarPrivate2)

                        # CarBenefit.append('0')
                        # CarBenefitMinus.append('0')

                    if Commission.search(line):
                        line_items_Comission = line.split()
                        Commission2 = (line_items_Comission[-1].replace('.', '').replace('-', ''), num_page)
                        CommissionList.append(Commission2)
                        # print(line_items_Comission)

                    if Period.search(line):
                        line_items_Period = line.split()
                        month = ' '.join(line_items_Period[3:5])
                        Date.append(month)
                        # print(month)
                    if ID.search(line):
                        line_items_ID = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        # print(line_items_ID)
                        MitarbeiterID.append(line_items_ID[0])

                    if Uberstd.search(line) or Uberstd2.search(line):
                        line_items_uberstd = line.split()
                        # print(line_items_uberstd)
                        if len(line_items_uberstd) > 2:
                            Uberstunde2 = (line_items_uberstd[-1].replace('.', '').replace('-', ''), num_page)
                            Uberstunde.append(Uberstunde2)  #
                            # print(Uberstunde2)

                    if WeekendSamstag.search(line):
                        line_items_Samstag = line.split()
                        Samstag2 = (line_items_Samstag[-1].replace('.', '').replace('-', ''), num_page)
                        SaturdayWork.append(Samstag2)  #
                        # print(line_items_Samstag)

                    if WeekendSonntag.search(line):
                        line_items_Sonntag = line.split()
                        Sonntag2 = (line_items_Sonntag[-1].replace('.', '').replace('-', ''), num_page)
                        SundayWork.append(Sonntag2)

                    if Bonuslfd.search(line):
                        line_items_lfd = line.split()
                        # print(line_items_lfd)
                        # if len(line_items_uberstd) >2:
                        Bonus1 = (line_items_lfd[-1].replace('.', '').replace('-', ''), num_page)
                        Bonus.append(Bonus1)  #
                        # print(Uberstunde2)

                    if BonusEBZ.search(line):
                        line_items_BonusEBZ = line.split()
                        # print(line_items_BonusEBZ)
                        Bonus2 = (line_items_BonusEBZ[-1].replace('.', '').replace('-', ''), num_page)
                        BonusEBZlist.append(Bonus2)

                    if PrivateLI.search(line):
                        line_items_PLI = line.split()
                        # print(line_items_PLI)
                        # if len(line_items_uberstd) >2:
                        PLI1 = (line_items_PLI[-1].replace('.', '').replace('-', ''), num_page)
                        PLI.append(PLI1)  #

                    if PrivateHI.search(line):
                        line_items_PHI = line.split()
                        # print(line_items_PLI)
                        # if len(line_items_uberstd) >2:
                        PHI1 = (line_items_PHI[-1].replace('.', '').replace('-', ''), num_page)
                        # print(PHI1)
                        PHI.append(PHI1)

                    if RAllowance.search(line):
                        line_items_RA = line.split()
                        # print(line_items_PLI)
                        # if len(line_items_uberstd) >2:
                        RA1 = (line_items_RA[-1].replace('.', '').replace('-', ''), num_page)
                        Resid.append(RA1)

                    if RAllowanceNet.search(line):
                        line_items_RAnet = line.split()
                        # print(line_items_RAnet)
                        # if len(line_items_uberstd) >2:
                        RA2 = (line_items_RAnet[-1].replace('.', '').replace('-', ''), num_page)
                        ResidNet.append(RA2)

                    if BetragAVAG.search(line):
                        line_items_Betrag = line.split()
                        # print(line_items_Betrag)
                        BetragAVAGlfd = (line_items_Betrag[-1].replace('-', ''), num_page)
                        # print(BetragAVAGlfd)
                        Betrag901.append(BetragAVAGlfd)

                    if BetragAVANST.search(line):
                        line_items_Betrag = line.split()
                        BetragANAm = (line_items_Betrag[-1].replace('-', ''), num_page)
                        Betrag911.append(BetragANAm)

                    if BetragAVANGE.search(line):
                        line_items_BetragGE = line.split()
                        # print(line_items_BetragGE)
                        BetragANAmGe = ('-' + line_items_BetragGE[-1].replace('-', ''), num_page)
                        Betrag914.append(BetragANAmGe)

                        # print(Uberstunde)

                    if GBzurPV.search(line):
                        line_items_GBPV = line.split()
                        GBPVAmount = ('-' + line_items_GBPV[-1].replace('-', ''), num_page)
                        # print(line_items_GBPV)
                        GBPV.append(GBPVAmount)

                    if GBzurKV.search(line):
                        line_items_GBKV = line.split()
                        # print(line_items_GBKV)
                        GBKVAmount = ('-' + line_items_GBKV[-1].replace('-', ''), num_page)
                        # print(line_items_GBPV)
                        GBKV.append(GBKVAmount)

                    if HO.search(line):
                        line_items_HO = line.split()
                        HOamount = (line_items_HO[-1].replace('-', ''), num_page)
                        Homeoffice.append(HOamount)
                    # print(Homeoffice)

                    # if CI24.search(line):
                    # line_items_SS = line.split()
                    # print(line_items_SS)
                    # if line_items_SS[2].isdigit():
                    # Solidarity_Surcharge = line_items_SS[2].replace('-', '').replace('.', '')
                    # Solidarity_Surcharge = f"{Solidarity_Surcharge[:-2]},{Solidarity_Surcharge[-2:]}"
                    # Solidarity_Surcharge = (Solidarity_Surcharge, num_page)
                    # print(Solidarity_Surcharge)
                    # Solidarity.append(Solidarity_Surcharge)
                    # if CarAllowance.search(line):
                    # line_items_CarAl=line.split()
                    # print(line_items_CarAl)
                    if Direkt.search(line):
                        line_items_DV = line.split()
                        # print(line_items_DV)
                        DVamount = ('-' + line_items_DV[-1].replace('-', '').replace('.', ''), num_page)
                        DV.append(DVamount)

                    if AGzuschussPV0.search(line):
                        line_items_ZuschussPV = line.split()
                        AGPV = (line_items_ZuschussPV[-1].replace('-', '').replace('.', ''), num_page)
                        AGZuschussPV.append(AGPV)
                        # print(AGPV)

                    if Bereits.search(line):
                        line_items_Bereits = line.split()
                        last_value = line_items_Bereits[-1]

                        # Normalisation : enlever les séparateurs et remplacer la virgule
                        val = last_value.replace('.', '').replace(',', '.').strip()

                        # Cas 1 : le "-" est à la fin → on le met au début
                        if val.endswith('-') or val.startswith('-'):
                            val = '-' + val[:-1]

                        # Cas 3 : pas de "-" → on laisse tel quel
                        else:
                            val = val

                        BereitsErhalten2 = (val, num_page)
                        BereitsErhalten.append(BereitsErhalten2)

                    if AGzuschussKV0.search(line):
                        line_items_ZuschussKV = line.split()
                        # print(line_items_ZuschussKV)
                        AGKV = (line_items_ZuschussKV[-1].replace('-', '').replace('.', ''), num_page)
                        AGZuschussKV.append(AGKV)
                        # print(AGPV)

                    if Contrgroup.search(line):
                        line_items_Cont = line.split()

                        # print(line_items_Cont)
                        if line_items_Cont[-1] == '30' or line_items_Cont[-1] == '04':
                            Cont.append(line_items_Cont[-3])
                        else:
                            Cont.append(line_items_Cont[-2])
                        # if line_items_Cont[-1]!='1':
                        # Cont.append(line_items_Cont[-3])
                        # else:
                        # Cont.append(line_items_Cont[-2])
                        # print(line_items_Cont)
                        # Cont.append(line_items_Cont[-3])

                    if UIline.search(line):
                        line_items_UI = line.split()

    # Sum of all numbers and replacement to be float

    for i in range(len(Basesalary)):
        # Replace the period with an empty string
        Basesalary2[i] = Basesalary2[i].replace(',', '.')

    for i in range(len(TotalGrossIncome)):
        # Replace the period with an empty string
        TotalGrossIncome[i] = TotalGrossIncome[i].replace(',', '.')

    for i in range(len(Netpay)):
        # Replace the period with an empty string
        Netpay[i] = Netpay[i].replace(',', '.')

    # for i in range(len(CarBenefit)):
    # Replace the period with an empty string
    # CarBenefit[i] = CarBenefit[i].replace(',', '.')

    for i in range(len(WageTax)):
        # Replace the period with an empty string
        if WageTax[i] == '':
            WageTax[i] = '0'
        WageTax[i] = WageTax[i].replace(',', '.')

    # print(FromCorrection)

    total = sum(float(num) for num in Basesalary2)
    totalTGI = sum(float(num) for num in TotalGrossIncome)
    totalNet = sum(float(num) for num in Netpay)
    # totalCar= sum(float(num) for num in CarBenefit)
    totalWage = sum(float(num) for num in WageTax)

    totalNet = round(totalNet, 2)
    totalWage = round(totalWage, 2)
    totalTGI = round(totalTGI, 2)

    total = str(total).replace('.', ',')
    totalTGI = str(totalTGI).replace('.', ',')
    totalNet = str(totalNet).replace('.', ',')
    # totalCar = str(totalCar).replace('.',',')
    totalWage = str(totalWage).replace('.', ',')
    # totalCommission = str(totalCommission).replace('.', ',')
    # total=total.replace(',', '|').replace('.', ',').replace('|', '.')
    # print(total)
    # print(totalTGI)
    # print(totalNet)

    # Replacement to be normal number
    for i in range(len(Basesalary2)):
        # Replace the period with an empty string
        Basesalary2[i] = Basesalary2[i].replace('.', ',')

    for i in range(len(TotalGrossIncome)):
        # Replace the period with an empty string
        TotalGrossIncome[i] = TotalGrossIncome[i].replace('.', ',')

    for i in range(len(Netpay)):
        # Replace the period with an empty string
        Netpay[i] = Netpay[i].replace('.', ',')

    # for i in range(len(CarBenefit)):
    # Replace the period with an empty string
    # CarBenefit[i] = CarBenefit[i].replace('.', ',')

    for i in range(len(WageTax)):
        # Replace the period with an empty string

        WageTax[i] = WageTax[i].replace('.', ',')
    # Add empty line
    Company.append('')
    Employee.append('')
    # Basesalary.append('')
    TotalGrossIncome.append('')
    MitarbeiterID.append('')
    Netpay.append('')
    WageTax.append('')
    # CarBenefit.append('')
    # CarBenefitMinus.append('')
    # CommissionList.append('')
    Date.append('')

    Company.append('')
    Employee.append('TOTAL')

    TotalGrossIncome.append(totalTGI)
    MitarbeiterID.append('')
    Netpay.append(totalNet)
    WageTax.append(totalWage)
    # CarBenefit.append(totalCar)
    # CarBenefitMinus.append('-'+totalCar)
    # CommissionList.append(totalCommission)
    Date.append('')

    # CarBenefitMinus=["-" + x[:-1] for x in CarBenefit]

    ### TAKE ALL THE PAGE NUMBER FOR UBERSTUNDEN
    Num_pages = [tup[-1] for tup in Uberstunde]
    # print(Num_pages)
    WorkerIDuberstd = []
    UberstdNumpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):

            if num_page in Num_pages:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                    # pint(text)
                    # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_ID2 = line.split()
                        # month=' '.join(line_items_Period[3:5])                            # print(line_items_ID2)
                        WorkerIDuberstd.append(line_items_ID2[0])
                        # print(line_items_ID2)
                    if Uberstd.search(line):
                        line_items_uberstd = line.split()
                        if len(line_items_uberstd) > 2:
                            Uberstunde3 = line_items_uberstd[-1].replace('.', '').replace('-', '')
                            UberstdNumpages.append(Uberstunde3)
                            # print(Uberstunde3)

    ### TAKE ALL THE PAGE NUMBER FOR home office
    Num_pages2 = [tup[-1] for tup in Homeoffice]
    # print(Num_pages)
    WorkerIDHomeOffice = []
    HomeOfficeNumpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages2:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_HOid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDHomeOffice.append(line_items_HOid2[0])
                        # print(line_items_ID2)
                    if HO.search(line):
                        line_items_HO2 = line.split()
                        # print(line_items_HO2)
                        HomeOfficeNumpages.append(line_items_HO2[-1])

    ### TAKE ALL THE PAGE NUMBER FOR Bonuslfd
    Num_pages3 = [tup[-1] for tup in Bonus]
    # print(Num_pages)
    WorkerIDBonus = []
    BonusNumpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages3:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                    # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Bonusid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDBonus.append(line_items_Bonusid2[0])
                        # print(line_items_Bonusid2)
                    if Bonuslfd.search(line):
                        line_items_Bonus2 = line.split()
                        # print(line_items_HO2)
                        BonusNumpages.append(line_items_Bonus2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR BonusEBZ
    Num_pages32 = [tup[-1] for tup in BonusEBZlist]
    # print(Num_pages)
    WorkerIDBonusEBZ = []
    BonusEBZNumpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages32:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                    # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_BonusEBZid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDBonusEBZ.append(line_items_BonusEBZid2[0])
                        # print(line_items_Bonusid2)
                    if BonusEBZ.search(line):
                        line_items_BonusEBZ2 = line.split()
                        # print(line_items_HO2)
                        BonusEBZNumpages.append(line_items_BonusEBZ2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Private Liability
    Num_pages4 = [tup[-1] for tup in PLI]
    # print(Num_pages)
    WorkerIDPLI = []
    PLINumpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages4:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                    # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_PLIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDPLI.append(line_items_PLIid2[0])
                        # print(line_items_PLIid2)
                    if PrivateLI.search(line):
                        line_items_PLI2 = line.split()
                        # print(line_items_PLI2)
                        PLINumpages.append(line_items_PLI2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Private Household
    Num_pages5 = [tup[-1] for tup in PHI]
    # print(Num_pages5)
    WorkerIDPHI = []
    PHINumpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages5:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                    # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_PHIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDPHI.append(line_items_PHIid2[0])
                    # print(line_items_PHIid2)
                    if PrivateHI.search(line):
                        line_items_PHI2 = line.split()
                        # print(line_items_PHI2)
                        PHINumpages.append(line_items_PHI2[-1].replace('.', ''))
    ### TAKE ALL THE PAGE NUMBER FOR Residance Allowance
    Num_pages6 = [tup[-1] for tup in Resid]
    # print(Num_pages5)
    WorkerIDRA = []
    RANumpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages6:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                    # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_RAid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDRA.append(line_items_RAid2[0])
                        # print(line_items_RAid2)
                    if RAllowance.search(line):
                        line_items_RA2 = line.split()
                        # print(line_items_RA2)
                        RANumpages.append(line_items_RA2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Residance Allowance Net
    Num_pages6b = [tup[-1] for tup in ResidNet]
    # print(Num_pages5)
    WorkerIDRANet = []
    RANumpagesNet = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages6b:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                    # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_RAid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDRANet.append(line_items_RAid2[0])
                        # print(line_items_RAid2)
                    if RAllowanceNet.search(line):
                        line_items_RA2 = line.split()
                        # print(line_items_RA2)
                        RANumpagesNet.append(line_items_RA2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR CHURCHTAX
    Num_pages7 = [tup[-1] for tup in ChurchTax]
    # print(Num_pages5)
    WorkerID_Church = []
    Church_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages7:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                    # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Churchid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Church.append(line_items_Churchid2[0])
                        # print(line_items_RAid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # print(line_items_Wage)

                        # print(line_items_Wage)
                        if line_items_Wage[
                            0] == 'L' and '773,80' not in line_items_Wage and 'Z' not in line_items_Wage:  # FAIRE EN SORTE DAVOIR LES HI COMTRIBUTIONS
                            # print(line_items_Wage)

                            if len(line_items_Wage) > 2 and line_items_Wage[2] != line_items_Wage[1] and \
                                    line_items_Wage[3] != line_items_Wage[2]:
                                # print(line_items_Wage)
                                Wage2 = line_items_Wage[2]

                                # print(Sol2)
                                # Format with one comma before the last two numbers
                                Wage2 = f"{Wage2[:-2]},{Wage2[-2:]}"
                                WageTax.append(Wage2.replace('.', ''))
                                # print(Wage2)

                                if len(line_items_Wage) == 5 and len(line_items_Wage[2]) >= len(line_items_Wage[3]):
                                    churchtax2 = line_items_Wage[-2]
                                    churchtax2 = f"{churchtax2[:-2]},{churchtax2[-2:]}"
                                    # churchtax2 = (churchtax2, num_page)
                                    Church_Numpages.append(churchtax2)

                                elif len(line_items_Wage) == 5 and len(line_items_Wage[2]) - len(
                                        line_items_Wage[3]) == 1 and line_items_Wage[-2] < "15000":
                                    churchtax2 = line_items_Wage[-2]
                                    churchtax2 = f"{churchtax2[:-2]},{churchtax2[-2:]}"
                                    # churchtax2 = (churchtax2, num_page)
                                    # Church_Numpages.append(churchtax2)

    ### TAKE ALL THE PAGE NUMBER FOR Solidarity Surcharge
    Num_pages8 = [tup[-1] for tup in Solidarity]
    # print(Num_pages5)
    WorkerID_Solidarity = []
    Solidarity_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages8:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Solidarityid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Solidarity.append(line_items_Solidarityid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # print(line_items_Wage)

                        # print(line_items_Wage)
                        if line_items_Wage[
                            0] == 'L' and '773,80' not in line_items_Wage and 'Z' not in line_items_Wage:  # FAIRE EN SORTE DAVOIR LES HI COMTRIBUTIONS
                            # print(line_items_Wage)

                            if len(line_items_Wage) == 5 and len(line_items_Wage[2]) >= len(line_items_Wage[3]):

                                Solidarity2 = line_items_Wage[-2]
                                Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                # Solidarity2 = (Solidarity2, num_page)
                                # Solidarity2 = (Solidarity2, num_page)
                                Solidarity_Numpages.append(Solidarity2)
                            elif len(line_items_Wage) == 6 and len(line_items_Wage[-2]) == 3:
                                Solidarity2 = line_items_Wage[-2]
                                Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                Solidarity_Numpages.append(Solidarity2)

                            elif len(line_items_Wage) == 4 and len(line_items_Wage[2]) - len(
                                    line_items_Wage[-1]) == 1 and line_items_Wage[-1] > "15000":
                                Solidarity2 = line_items_Wage[-1]
                                Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                # Solidarity_Numpages.append(Solidarity2)

    ### TAKE ALL THE PAGE NUMBER FOR Direktversicherung
    Num_pages9 = [tup[-1] for tup in DV]
    # print(Num_pages5)
    WorkerID_DV = []
    DV_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages9:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_DVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_DV.append(line_items_DVid2[0])
                        # print(line_items_Solidarityid2)
                    if Direkt.search(line):
                        line_items_DV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        DV_Numpages.append('-' + line_items_DV2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Base Salary
    Num_pages10 = [tup[-1] for tup in Basesalary]
    # print(Num_pages5)
    WorkerID_BaseSalary = []
    Basesalary_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages10:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Baseid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_BaseSalary.append(line_items_Baseid2[0])
                        # print(line_items_Solidarityid2)
                    if Base_Salary.search(line):
                        line_items_Base2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Basesalary_Numpages.append(line_items_Base2[-1].replace('.', '').replace('-', ''))
    # print(WorkerID_Solidarity)

    ### TAKE ALL THE PAGE NUMBER FOR AGzuschussPV
    Num_pages11 = [tup[-1] for tup in AGZuschussPV]
    # print(Num_pages5)
    WorkerID_AGZuschussPV = []
    AGZuschussPV_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages11:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_AGPVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_AGZuschussPV.append(line_items_AGPVid2[0])
                        # print(line_items_Solidarityid2)
                    if AGzuschussPV0.search(line):
                        line_items_AGPV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        AGZuschussPV_Numpages.append(line_items_AGPV2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR AGzuschussKV
    Num_pages12 = [tup[-1] for tup in AGZuschussKV]
    # print(Num_pages5)
    WorkerID_AGZuschussKV = []
    AGZuschussKV_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages12:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_AGKVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_AGZuschussKV.append(line_items_AGKVid2[0])
                        # print(line_items_Solidarityid2)
                    if AGzuschussKV0.search(line):
                        line_items_AGKV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        AGZuschussKV_Numpages.append(line_items_AGKV2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR HI,CI,UI,PI
    Num_pages13 = [tup[-1] for tup in UICont]
    Num_pages14 = [tup[-1] for tup in PICont]
    Num_pages15 = [tup[-1] for tup in HICont]
    Num_pages16 = [tup[-1] for tup in CIcont]
    # print(Num_pages5)
    WorkerID_UICont = []
    WorkerID_PICont = []
    WorkerID_HICont = []
    WorkerID_CICont = []

    UICont_Numpages = []
    PICont_Numpages = []
    HICont_Numpages = []
    CICont_Numpages = []

    ### TAKE ALL THE PAGE NUMBER FOR HI,CI,UI,PI For E
    Num_pages132 = [tup[-1] for tup in UIContE]
    Num_pages142 = [tup[-1] for tup in PIContE]
    Num_pages152 = [tup[-1] for tup in HIContE]
    Num_pages162 = [tup[-1] for tup in CIcontE]
    # print(Num_pages5)
    WorkerID_UIContE = []
    WorkerID_PIContE = []
    WorkerID_HIContE = []
    WorkerID_CIContE = []

    UIContE_Numpages = []
    PIContE_Numpages = []
    HIContE_Numpages = []
    CIContE_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages13:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_UIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_UICont.append(line_items_UIid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # DV2=line_items_DV2[-1]
                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:

                            if len(line_items_Wage) == 6:
                                # print(line_items_Wage)
                                UI = line_items_Wage[-2].replace('-', '')
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UICont_Numpages.append(UI)


                            elif 'Z' in line_items_Wage or 'E' in line_items_Wage or '1' in line_items_Wage or '2' in line_items_Wage or '3' in line_items_Wage or '4' in line_items_Wage:
                                # print(line_items_Wage)
                                UI = extract_UI(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'])

                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = UI.replace(',,', ',')

                                UICont_Numpages.append(UI)
                                # PICont.append(PI)



                            elif len(line_items_Wage) >= 9:
                                # print(line_items_Wage)
                                UI = line_items_Wage[-3]
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UICont_Numpages.append(UI)

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages132:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_UIidE2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_UIContE.append(line_items_UIidE2[0])
                        # print(line_items_Solidarityid2)
                    if WageE.search(line):
                        line_items_WageE = line.split()
                        UIE = line_items_WageE[-3]
                        UIE = f"{UIE[:-2]},{UIE[-2:]}"
                        UIContE_Numpages.append(UIE)

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages14:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_PIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_PICont.append(line_items_PIid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # DV2=line_items_DV2[-1]
                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:

                            if len(line_items_Wage) == 6:
                                # print(line_items_Wage)
                                PI = line_items_Wage[-3].replace('-', '')
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PICont_Numpages.append(PI)


                            elif 'Z' in line_items_Wage or 'E' in line_items_Wage or '1' in line_items_Wage or '2' in line_items_Wage or '4' in line_items_Wage:
                                # print(line_items_Wage)
                                PI = extract_value_before(line_items_Wage, ['Z', 'E', '1', '2', '4'], 2)
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PICont_Numpages.append(PI)
                                # PICont.append(PI)

                            elif len(line_items_Wage) >= 9:
                                # print(line_items_Wage)
                                PI = line_items_Wage[-4]
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PICont_Numpages.append(PI)

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages142:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_PIidE2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_PIContE.append(line_items_PIidE2[0])
                    if WageE.search(line):
                        line_items_WageE = line.split()
                        PIE = line_items_WageE[-4]
                        PIE = f"{PIE[:-2]},{PIE[-2:]}"
                        PIContE_Numpages.append(PIE)

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages15:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_HIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_HICont.append(line_items_HIid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # DV2=line_items_DV2[-1]
                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:
                            if 'Z' in line_items_Wage:
                                if len(line_items_Wage) > 7:
                                    HI = extract_value_before(line_items_Wage, ['Z', 'E', '1', '2', '4'], 3)

                                    HI = f"{HI[:-2]},{HI[-2:]}"
                                    HICont_Numpages.append(HI)

                            elif len(line_items_Wage) >= 9:
                                HI = line_items_Wage[-6]
                                HI = f"{HI[:-2]},{HI[-2:]}"
                                HICont_Numpages.append(HI)

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages152:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_HIidE2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_HIContE.append(line_items_HIidE2[0])
                        # print(line_items_Solidarityid2)
                    if WageE.search(line):
                        line_items_WageE = line.split()
                        HIE = line_items_WageE[-5]
                        HIE = f"{HIE[:-2]},{HIE[-2:]}"
                        HIContE_Numpages.append(HIE)

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages16:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_CIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_CICont.append(line_items_CIid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # DV2=line_items_DV2[-1]
                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:
                            if 'Z' in line_items_Wage:
                                if len(line_items_Wage) > 7:
                                    CI = extract_value_after(line_items_Wage, ['Z', 'E', '1', '2', '4'], 1)

                                    CI = f"{CI[:-2]},{CI[-2:]}"
                                    # CI = (CI.replace('.', ''), num_page)
                                    CICont_Numpages.append(CI)

                            elif len(line_items_Wage) >= 9:

                                CI = line_items_Wage[-2]
                                CI = f"{CI[:-2]},{CI[-2:]}"
                                CICont_Numpages.append(CI)

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages162:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_CIidE2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_CIContE.append(line_items_CIidE2[0])
                        # print(line_items_Solidarityid2)
                    if WageE.search(line):
                        line_items_WageE = line.split()
                        CIE = line_items_WageE[-2]
                        CIE = f"{CIE[:-2]},{CIE[-2:]}"
                        CIContE_Numpages.append(CIE)

    ### TAKE ALL THE PAGE NUMBER FOR GBzurKV
    Num_pages17 = [tup[-1] for tup in GBKV]
    # print(Num_pages5)
    WorkerID_GBKV = []
    GBKV_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages17:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_GBKVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_GBKV.append(line_items_GBKVid2[0])
                        # print(line_items_Solidarityid2)
                    if GBzurKV.search(line):
                        line_items_GBKV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        GBKV_Numpages.append('-' + line_items_GBKV2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR GBzurPV
    Num_pages18 = [tup[-1] for tup in GBPV]
    # print(Num_pages5)
    WorkerID_GBPV = []
    GBPV_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages18:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_GBPVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_GBPV.append(line_items_GBPVid2[0])
                        # print(line_items_Solidarityid2)
                    if GBzurPV.search(line):
                        line_items_GBPV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        GBPV_Numpages.append('-' + line_items_GBPV2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR CarBenefit
    Num_pages19 = [tup[-1] for tup in CarBenefit]
    # print(Num_pages5)
    WorkerID_CarBenefit = []
    CarBenefit_Numpages = []
    CarBenefitMinus_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages19:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Carid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_CarBenefit.append(line_items_Carid2[0])
                        # print(line_items_Solidarityid2)
                    if Car.search(line):
                        line_items_Car2 = line.split()
                        # DV2=line_items_DV2[-1]
                        CarBenefit_Numpages.append(line_items_Car2[-1].replace('.', '').replace('-', ''))
                        CarBenefitMinus_Numpages.append('-' + line_items_Car2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Betrag911
    Num_pages20 = [tup[-1] for tup in Betrag911]
    # print(Num_pages5)
    WorkerID_Betrag911 = []
    Betrag911_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages20:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_911id2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Betrag911.append(line_items_911id2[0])
                        # print(line_items_Solidarityid2)
                    if BetragAVANST.search(line):
                        line_items_AVAN2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Betrag911_Numpages.append(line_items_AVAN2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Betrag914
    Num_pages21 = [tup[-1] for tup in Betrag914]
    # print(Num_pages5)
    WorkerID_Betrag914 = []
    Betrag914_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages21:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_914id2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Betrag914.append(line_items_914id2[0])
                        # print(line_items_Solidarityid2)
                    if BetragAVANGE.search(line):
                        line_items_AVANGE2 = line.split()
                        # print(line_items_AVANGE2)
                        Betrag914_Numpages.append('-' + line_items_AVANGE2[-1].replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Betrag901
    Num_pages21b = [tup[-1] for tup in Betrag901]
    # print(Num_pages5)
    WorkerID_Betrag901 = []
    Betrag901_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages21b:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_901id2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Betrag901.append(line_items_901id2[0])
                        # print(WorkerID_Betrag901)
                    if BetragAVAG.search(line):
                        line_items_AVAGE2 = line.split()
                        # print(line_items_AVAGE2)
                        Betrag901_Numpages.append(line_items_AVAGE2[-1].replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR SaturdayWork
    Num_pages22 = [tup[-1] for tup in SaturdayWork]
    # print(Num_pages5)
    WorkerID_SaturdayWork = []
    SaturdayWork_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages22:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Samstagid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_SaturdayWork.append(line_items_Samstagid2[0])
                        # print(line_items_Solidarityid2)
                    if WeekendSamstag.search(line):
                        line_items_Samstag2 = line.split()
                        # print(line_items_AVANGE2)
                        SaturdayWork_Numpages.append(line_items_Samstag2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR SundayWork
    Num_pages23 = [tup[-1] for tup in SundayWork]
    # print(Num_pages5)
    WorkerID_SundayWork = []
    SundayWork_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages23:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Sonntagid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_SundayWork.append(line_items_Sonntagid2[0])
                        # print(line_items_Solidarityid2)
                    if WeekendSonntag.search(line):
                        line_items_Sonntag2 = line.split()
                        # print(line_items_AVANGE2)
                        SundayWork_Numpages.append(line_items_Sonntag2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Salary_Correction (1.C)
    Num_pages300 = [tup[-1] for tup in CorrectionNSalaryList]
    # print(Num_pages5)
    WorkerID_NSalary = []
    NSalary_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages300:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_NSalaryid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_NSalary.append(line_items_NSalaryid2[0])
                        # print(line_items_NSalaryid2)
                    if CorrectionN.search(line):
                        line_items_NSalary2 = line.split()
                        # print(line_items_NSalary2)
                        if "001" in line_items_NSalary2:
                            NSalary2 = line_items_NSalary2[-1]
                            # NSalary2= f"{NSalary2[:-2]},{NSalary2[-2:]}"
                            # print(NSalary2)
                            NSalary_Numpages.append(NSalary2.replace('.', ''))
    ### TAKE ALL THE PAGE NUMBER FOR Wage_Correction
    Num_pages301 = [tup[-1] for tup in WageTaxN]
    # print(Num_pages301)
    WorkerID_WageN = []
    WageN_Numpages = []
    SolidarityN_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages301:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_WageNid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_WageN.append(line_items_WageNid2[0])
                        # print(line_items_Solidarityid2)
                    if CorrectionN.search(line):
                        lineitemsN2 = line.split()
                        if "001" not in lineitemsN2:
                            line_items_WageN = line.split()
                            # print(line_items_WageN)
                            if line_items_WageN[2] != line_items_WageN[1]:
                                WageTaxN1 = line_items_WageN[2]
                                WageTaxN1 = f"{WageTaxN1[:-2]},{WageTaxN1[-2:]}"
                                # WageTaxN1 = (WageTaxN1, num_page)
                                WageN_Numpages.append(WageTaxN1)
                                if len(line_items_WageN) > 4:
                                    SolidarityN1 = line_items_WageN[3]
                                    SolidarityN1 = f"{SolidarityN1[:-2]},{SolidarityN1[-2:]}"
                                    # SolidarityN1 = (SolidarityN1, num_page)
                                    SolidarityN_Numpages.append(SolidarityN1)
                                # print(WageTaxN1)
    # print(SocialDN)
    ### TAKE ALL THE PAGE NUMBER FOR UI and Pi_Correction
    Num_pages303 = [tup[-1] for tup in UIContN]
    # print(Num_pages301)
    WorkerID_UIContN = []
    UIContN_Numpages = []
    PIContN_Numpages = []
    SocialDN_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages303:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_UIContNid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_UIContN.append(line_items_UIContNid2[0])
                    if CorrectionN.search(line):
                        lineitemsN2 = line.split()
                        if "001" not in lineitemsN2:
                            line_items_UIContN = line.split()
                            # print(line_items_WageN)

                            if len(line_items_UIContN) == 6 and (line_items_UIContN[2] == line_items_UIContN[1]):
                                SocialDN1 = line_items_UIContN[-1].replace('-', '')
                                # print(line_items_Wage)
                                UI = line_items_UIContN[-2].replace('-', '')
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = UI.replace('.', '')

                                PI = line_items_UIContN[-3].replace('-', '')
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PI = PI.replace('.', '')

                                # UI = f"{UI[:-2]},{UI[-2:]}"

                                # AGPV = (line_items_ZuschussPV[-1].replace('-', '').replace('.', ''), num_page)
                                UIContN_Numpages.append(UI)
                                PIContN_Numpages.append(PI)
                                SocialDN_Numpages.append(SocialDN1)

    ### TAKE ALL THE PAGE NUMBER FOR WageS
    Num_pages24 = [tup[-1] for tup in WageTaxS]
    # print(Num_pages5)
    WorkerID_WageS = []
    WageS_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages24:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_WageSid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_WageS.append(line_items_WageSid2[0])
                        # print(line_items_Solidarityid2)
                    if WageS.search(line):
                        line_items_WageS2 = line.split()
                        # print(line_items_WageS2)
                        WageTaxS2 = line_items_WageS2[2]
                        WageTaxS2 = f"{WageTaxS2[:-2]},{WageTaxS2[-2:]}"
                        # print(line_items_WageS2)
                        WageS_Numpages.append(WageTaxS2.replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Solidarity(S)
    Num_pages25 = [tup[-1] for tup in SolidarityS]
    # print(Num_pages5)
    WorkerID_SolidarityS = []
    SolidarityS_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages25:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_SolidaritySid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_SolidarityS.append(line_items_SolidaritySid2[0])
                        # print(line_items_Solidarityid2)
                    if WageS.search(line):
                        line_items_WageS2 = line.split()
                        # print(line_items_WageS2)
                        if len(line_items_WageS2) > 4:
                            SolidarityTaxS2 = line_items_WageS2[3]
                            SolidarityTaxS2 = f"{SolidarityTaxS2[:-2]},{SolidarityTaxS2[-2:]}"
                            # print(line_items_WageS2)
                            SolidarityS_Numpages.append(SolidarityTaxS2.replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR ChurchTax(S)
    Num_pages252 = [tup[-1] for tup in ChurchTaxS]
    # print(Num_pages5)
    WorkerID_ChurchTaxS = []
    ChurchTaxS_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages252:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_ChurchTaxSid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_ChurchTaxS.append(line_items_ChurchTaxSid2[0])
                        # print(line_items_Solidarityid2)
                    if WageS.search(line):
                        line_items_WageS2 = line.split()
                        # print(line_items_WageS2)
                        if len(line_items_WageS2) > 4:
                            ChurchTaxS2 = line_items_WageS2[3]
                            ChurchTaxS2 = f"{ChurchTaxS2[:-2]},{ChurchTaxS2[-2:]}"
                            # print(line_items_WageS2)
                            ChurchTaxS_Numpages.append(ChurchTaxS2.replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR 9079 Bereits erhalten
    Num_pages26 = [tup[-1] for tup in BereitsErhalten]
    # print(Num_pages5)
    WorkerID_Bereits = []
    Bereits_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages26:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Bereitsid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Bereits.append(line_items_Bereitsid2[0])
                        # print(line_items_Solidarityid2)
                    if Bereits.search(line):
                        line_items_Bereits2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Bereits_Numpages.append("-" + line_items_Bereits2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR 011 Prämie

    Num_pages27 = [tup[-1] for tup in CommissionList]
    WorkerID_Commission = []
    Commission_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages27:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_commissionid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Commission.append(line_items_commissionid2[0])
                        # print(line_items_Solidarityid2)
                    if Commission.search(line):
                        line_items_commission2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Commission_Numpages.append(line_items_commission2[-1].replace('.', '').replace('-', ''))

    ## TAKE ALL THE PAGE NUMBER FOR FraiwilligZuschlageList
    Num_pages32 = [tup[-1] for tup in FromCorrection]
    # print(Num_pages5)
    WorkerID_FromCorrection = []
    FC_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages32:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_FCid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_FromCorrection.append(line_items_FCid2[0])
                        # print(line_items_Solidarityid2)
                    if Correction.search(line):

                        line_items_correction = line.split()
                        last_value = line_items_correction[-1]

                        # Remplacer la virgule par un point pour les décimales
                        val = last_value.replace('.', '').replace(',', '.').strip()

                        # Cas 1 : le "-" est à la fin → on le met au début
                        if val.endswith('-') or val.startswith('-'):
                            val = '-' + val[:-1]
                            val = f"{val[:-2]},{val[-2:]}"
                        else:
                            val = val
                            val = f"{val[:-2]},{val[-2:]}"

                        Correction2 = val
                        FC_Numpages.append(Correction2.replace('.', ''))
                        # print(FromCorrection)
                        # FC_Numpages.append( line_items_FC2[-1].replace('.', '').replace('-', ''))
    ########################TAKE ALL THE PAGE NUMBER FOR COMMISSION################################

    df = pd.DataFrame(columns=["Company", "Period", "Worker ID", "Worker Name", "Contr. Group", "Base Salary",
                               "Base Salary_Correction",
                               "Commission", "Home_Office", "Überstdgrundvergütung", "Weekend Work Saturday",
                               "Weekend Work Sunday",
                               "Betr.AV.AG_lfd.ST-frei", "Betr.AV.AN lfd.ST-frei", "Betr.AV.AN lfd.Geh.Ver",
                               'bAV AG-Zus. lfd.ST-frei',
                               'Freiwillige Zulage', 'Unterstützungskasse', 'Sonderzahlung',
                               "Privatfahrten/priv. use", "Bonus lfd.", "Bonus EBZ", "Residence Allowance",
                               "Residence Allowance Net",
                               "Private household insurance", "Private liability insurance",
                               "Total Gross Pay", "Total Gross Pay_Correction",
                               "Church Tax", "Church Tax_Correction",
                               "Solidarity Surcharge", "Solidarity Surcharge_Correction",
                               "EE-Wage tax", "EE-Wage tax_Correction",
                               "CI Contribution", "CI Contribution_Correction",
                               "HI Contribution", "HI Contribution_Correction",
                               "PI Contribution", "PI Contribution_Correction",
                               "UI Contribution", "UI Contribution_Correction",
                               "Social Security Deductions", "Social Security Deductions_Correction",
                               "car benefit/KFZ- Sachb.", "Already Paid", "AG-Zuschuss_zur_PV", "AG-Zuschuss_zur_KV",
                               "Gesamtbeitrag_zur_PV",
                               "Gesamtbeitrag_zur_KV", "bAV-Abzug", 'Correction Sick Pay', 'Correction CI-ER',
                               'Correction HI-ER',
                               'Direktversicherung', "Private Savings", "ER-Unemployment",
                               "Emp.Soc.Sec",
                               "ER Cost. Add", "ER Total Cost", "From Correction",
                               "Total Net Pay"])

    df["Company"] = pd.Series(Company, dtype=object)
    df["Worker ID"] = pd.Series(MitarbeiterID, dtype=object)
    # df["From Correction"]=pd.Series(FromCorrection, dtype=object)

    # Uberstd EQUALIZER
    finallistuberstd = list(zip(WorkerIDuberstd, UberstdNumpages))
    # print(finallistuberstd)
    # print(UberstdNumpages)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistuberstd:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Überstdgrundvergütung'] = tup[1]

    # Saturday EQUALIZER
    finallistSaturdayWork = list(zip(WorkerID_SaturdayWork, SaturdayWork_Numpages))
    # print(finallistuberstd)
    # print(UberstdNumpages)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSaturdayWork:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Weekend Work Saturday'] = tup[1]

    # Sunday EQUALIZER
    finallistSundayWork = list(zip(WorkerID_SundayWork, SundayWork_Numpages))
    # print(finallistuberstd)
    # print(UberstdNumpages)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSundayWork:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Weekend Work Sunday'] = tup[1]

    # HOMEOFFICE EQUALIZER
    finallistHO = list(zip(WorkerIDHomeOffice, HomeOfficeNumpages))

    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistHO:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Home_Office'] = tup[1]

    # Bonus Equalizer
    finallistBonus = list(zip(WorkerIDBonus, BonusNumpages))

    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBonus:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Bonus lfd.'] = tup[1]

    # BonusEBZ Equalizer
    finallistBonusEBZ = list(zip(WorkerIDBonusEBZ, BonusEBZNumpages))

    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBonusEBZ:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Bonus EBZ'] = tup[1]

    # PLI Equalizer
    finallistPLI = list(zip(WorkerIDPLI, PLINumpages))

    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistPLI:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Private liability insurance'] = tup[1]

    # PHI Equalizer
    finallistPHI = list(zip(WorkerIDPHI, PHINumpages))
    # print(finallistPHI)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistPHI:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Private household insurance'] = tup[1]

    # RA Equalizer
    finallistRA = list(zip(WorkerIDRA, RANumpages))
    # print(finallistRA)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistRA:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Residence Allowance'] = tup[1]

    # RANet Equalizer
    finallistRANet = list(zip(WorkerIDRANet, RANumpagesNet))
    # print(finallistRA)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistRANet:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Residence Allowance Net'] = tup[1]

    # Church Equalizer
    finallistChurch = list(zip(WorkerID_Church, Church_Numpages))
    # print(finallistChurch)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistChurch:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Church Tax'] = tup[1]

    # Solidarity Surcharge Equalizer
    finallistSS = list(zip(WorkerID_Solidarity, Solidarity_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSS:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Solidarity Surcharge'] = tup[1]

    # WageS Equalizer
    finallistWageS = list(zip(WorkerID_WageS, WageS_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistWageS:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'EE-Wage tax (S)'] = tup[1]

    # BaseSalaryS Equalizer
    finallistNSalary = list(zip(WorkerID_NSalary, NSalary_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistNSalary:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Base Salary_Correction'] = tup[1]

    # WageN Equalizer
    finallistWageN = list(zip(WorkerID_WageN, WageN_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistWageN:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'EE-Wage tax_Correction'] = tup[1]

    # SolidarityN Equalizer
    finallistSolidarityN = list(zip(WorkerID_WageN, SolidarityN_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSolidarityN:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Solidarity Surcharge_Correction'] = tup[1]

    # UIContN Equalizer
    finallistUIContN = list(zip(WorkerID_UIContN, UIContN_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistUIContN:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'UI Contribution_Correction'] = tup[1]

    # PIContN Equalizer
    finallistPIContN = list(zip(WorkerID_UIContN, PIContN_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistPIContN:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'PI Contribution_Correction'] = tup[1]

    # SocialDN Equalizer
    finallistSocialDN = list(zip(WorkerID_UIContN, SocialDN_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSocialDN:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Social Security Deductions_Correction'] = tup[1]

    # SolidarityS Equalizer
    finallistSolidarityS = list(zip(WorkerID_SolidarityS, SolidarityS_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSolidarityS:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Solidarity Surcharge (S)'] = tup[1]

    # ChurchTaxS Equalizer
    finallistChurchTaxS = list(zip(WorkerID_ChurchTaxS, ChurchTaxS_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistChurchTaxS:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Church Tax(S)'] = tup[1]

    # DirektV Equalizer
    finallistDV = list(zip(WorkerID_DV, DV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistDV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Direktversicherung'] = tup[1]

    # BaseSalary Equalizer
    finallistBS = list(zip(WorkerID_BaseSalary, Basesalary_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBS:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Base Salary'] = tup[1]

    # Basesalary.append('')

    # AGPV Equalizer
    finallistAGPV = list(zip(WorkerID_AGZuschussPV, AGZuschussPV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistAGPV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'AG-Zuschuss_zur_PV'] = tup[1]

    # AGPV Equalizer
    finallistBereits = list(zip(WorkerID_Bereits, Bereits_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBereits:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Already Paid'] = tup[1]

    # Commission Equalizer
    finallistCommission = list(zip(WorkerID_Commission, Commission_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistCommission:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Commission'] = tup[1]

    # AGKV Equalizer
    finallistAGKV = list(zip(WorkerID_AGZuschussKV, AGZuschussKV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistAGKV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'AG-Zuschuss_zur_KV'] = tup[1]

    # GBKV Equalizer
    finallistGBKV = list(zip(WorkerID_GBKV, GBKV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistGBKV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Gesamtbeitrag_zur_KV'] = tup[1]

    # GBKV Equalizer
    finallistGBPV = list(zip(WorkerID_GBPV, GBPV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistGBPV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Gesamtbeitrag_zur_PV'] = tup[1]

    # Betrag911 Equalizer
    finallistBetrag911 = list(zip(WorkerID_Betrag911, Betrag911_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBetrag911:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Betr.AV.AN lfd.ST-frei'] = tup[1]

    # Betrag914 Equalizer
    finallistBetrag914 = list(zip(WorkerID_Betrag914, Betrag914_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBetrag914:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Betr.AV.AN lfd.Geh.Ver'] = tup[1]

    # Betrag901 Equalizer
    finallistBetrag901 = list(zip(WorkerID_Betrag901, Betrag901_Numpages))
    # print(finallistBetrag901)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBetrag901:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Betr.AV.AG_lfd.ST-frei'] = tup[1]

    # Car Equalizer
    finallistCarBenefit = list(zip(WorkerID_CarBenefit, CarBenefit_Numpages))
    finallistCarBenefitMinus = list(zip(WorkerID_CarBenefit, CarBenefitMinus_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistCarBenefit:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Privatfahrten/priv. use'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistCarBenefitMinus:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'car benefit/KFZ- Sachb.'] = tup[1]

    # UICont,PICont Equalizer
    finallistUICont = list(zip(WorkerID_UICont, UICont_Numpages))
    finallistPICont = list(zip(WorkerID_PICont, PICont_Numpages))
    finallistHICont = list(zip(WorkerID_HICont, HICont_Numpages))
    finallistCICont = list(zip(WorkerID_CICont, CICont_Numpages))

    # UICont,PICont Equalizer for E
    finallistUIContE = list(zip(WorkerID_UIContE, UIContE_Numpages))
    finallistPIContE = list(zip(WorkerID_PIContE, PIContE_Numpages))
    finallistHIContE = list(zip(WorkerID_HIContE, HIContE_Numpages))
    finallistCIContE = list(zip(WorkerID_CIContE, CIContE_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistUICont:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'UI Contribution'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistUIContE:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'UI Contribution(E)'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistUIContE:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'UI Contribution(E)'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistPICont:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'PI Contribution'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistPIContE:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'PI Contribution(E)'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistHICont:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'HI Contribution'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistHIContE:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'HI Contribution(E)'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistCICont:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'CI Contribution'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistCIContE:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'CI Contribution(E)'] = tup[1]

    finallistFC = list(zip(WorkerID_FromCorrection, FC_Numpages))
    for index, row in df.iterrows():
        for tup in finallistFC:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'From Correction'] = tup[1]

    df["Period"] = pd.Series(Date, dtype=object)
    df["Worker Name"] = pd.Series(Employee, dtype=object)
    df['Base Salary'] = np.where(df['Worker Name'] == 'TOTAL', total, df['Base Salary'])
    df["Total Gross Pay"] = pd.Series(TotalGrossIncome, dtype=object)
    # df["Commission"] = pd.Series(CommissionList, dtype=object)
    df["EE-Wage tax"] = pd.Series(WageTax, dtype=object)
    df["Total Net Pay"] = pd.Series(Netpay, dtype=object)
    # df["Betr.AV.AG_lfd.ST-frei"] = pd.Series(Betrag901, dtype=object)
    df["Social Security Deductions"] = pd.Series(SocialD, dtype=object)
    df["Contr. Group"] = pd.Series(Cont, dtype=object)
    df["Emp.Soc.Sec"] = pd.Series(EmpSocSec, dtype=object)
    df["ER Cost. Add"] = pd.Series(Emp, dtype=object)
    df["ER Total Cost"] = pd.Series(AGsocial, dtype=object)  # Jai remplacé parce que cest la meme

    #####################################ESSAI POUR DICTIONNAIRE######################################################
    dfempty = pd.DataFrame([[np.nan] * len(df.columns)], columns=df.columns)  # emptycolumn

    df2 = {
        "Company": '',
        "Period": '',
        "Worker ID": '',
        "Worker Name": 'TOTAL',
        "Worker Cost Center": '',
        "Base Salary": total,
        "Car allowance": '',
        "Expense reimbursement": '',
        "Total Gross Pay": totalTGI,
        "EE-Unemployment": '',
        "EE-Social Security": '',
        "EE-Wage tax": totalWage,
        "Phone Reimbursement": '',
        "EE-Private Savings": '',
        "Total Net Pay": totalNet,
        "ER-Unemployment": '',
        "ER-Social Security": '',
        "Social Security": '',
        "Private Nurse Insurance": '',
        "Private Savings": '',
        "Total ER Contributions": '',
        "Total ER Cost": ''
    }

    # print(Uberstunde)
    # print(CommissionList)
    # Remove duplicates based on a specific column

    # print(df.head(5))

    # Créer un nouveau classeur Excel
    wb = Workbook()
    ws = wb.active

    # Ajouter l'en-tête du DataFrame à la feuille Excel
    header_row = df.columns.tolist()
    ws.append(header_row)

    # Ajouter les données du DataFrame à la feuille Excel
    for row in dataframe_to_rows(df, index=False, header=False):
        ws.append(row)

    # Appliquer un formatage numérique explicite (pour gérer les virgules décimales)
    for row in ws.iter_rows(min_row=2, min_col=2, max_col=2):  # Colonne des montants
        for cell in row:
            if isinstance(cell.value, (int, float)):
                cell.number_format = "#,##0.00"  # Format numérique

    # Ajouter un style à la ligne d'en-tête
    for cell in ws[1]:
        cell.font = Font(underline='single', bold=True)
        cell.fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")

    # Ajuster la largeur des colonnes
    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            if cell.value:
                max_length = max(max_length, len(str(cell.value)))
        adjusted_width = (max_length + 2) * 1.2
        ws.column_dimensions[column_letter].width = adjusted_width

    # Enregistrer le fichier Excel
    # wb.save('C:/Users/PK.MbeleSamba/Desktop/G2N_report_Landa_09.xlsx')# Créer un nouveau classeur Excel
    wb = Workbook()
    ws = wb.active

    # Ajouter l'en-tête du DataFrame à la feuille Excel
    header_row = df.columns.tolist()
    ws.append(header_row)

    # Ajouter les données du DataFrame à la feuille Excel
    # Pas de manipulation explicite des nombres ici
    for row in dataframe_to_rows(df, index=False, header=False):
        ws.append(row)

    # Appliquer un style à la ligne d'en-tête
    for cell in ws[1]:
        cell.font = Font(underline='single', bold=True)
        cell.fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")

    # Ajuster la largeur des colonnes
    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            if cell.value:
                max_length = max(max_length, len(str(cell.value)))
        adjusted_width = (max_length + 2) * 1.2
        ws.column_dimensions[column_letter].width = adjusted_width
    # Insérer les valeurs en s'assurant qu'elles sont bien en nombre

    # df = df.apply(lambda col: pd.to_numeric(col.str.replace(',', '.'), errors='ignore') if col.dtype=='str' and col.str.contains(',').any() else col)
    # Récupérer la première ligne (les en-têtes)
    # Récupérer la première ligne (les en-têtes)
    header = [cell.value for cell in ws[1]]

    # Déterminer l'indice (1-based) de la colonne "Base Salary"
    try:
        start_col = header.index("Base Salary") + 1
    except ValueError:
        print("La colonne 'Base Salary' n'a pas été trouvée dans l'en-tête.")
        start_col = None

    if start_col is not None:
        # Parcourir toutes les lignes à partir de la 2ème ligne (en-tête exclu)
        for row in ws.iter_rows(min_row=2):
            for col in range(start_col, ws.max_column + 1):
                cell = row[col - 1]  # L'indexation Python commence à 0

                # Si la cellule contient une chaîne (donc pas encore convertie en nombre)
                if cell.value is not None and isinstance(cell.value, str):
                    # Nettoyer la valeur : supprimer les espaces et remplacer la virgule par un point
                    valeur_str = cell.value.strip().replace(" ", "").replace(",", ".")
                    try:
                        # Convertir en float
                        cell.value = float(valeur_str)
                    except ValueError:
                        print(f"Conversion impossible pour la cellule {cell.coordinate} avec la valeur '{cell.value}'")

        # Appliquer le format numérique aux cellules déjà en nombre
        for row in ws.iter_rows(min_row=2):
            for col in range(start_col, ws.max_column + 1):
                cell = row[col - 1]

                # Vérifier si la cellule est un nombre valide
                if isinstance(cell.value, (int, float)) and not math.isnan(cell.value):
                    # Ne pas convertir en texte, juste appliquer un format d'affichage
                    cell.number_format = "0.00"

                # Facultatif : vous pouvez forcer le type texte en ajoutant une apostrophe (mais cela affichera l'apostrophe dans certaines configurations)
            # cell.value = "'" + format(cell.value, '.2f')

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path(
        user_id=user_id,
        data_conversion="Papaya",
        conversion="Lohnsteuer",
        task_id=task.request.id,
        extension="xlsx",
    )

    ensure_output_folder(output_path)

    wb.save(output_path)

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Papaya",
    conversion="Hartree",
    description="Papaya Hartree conversion",
    input_type={
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["pdf"],
            },
        ),
    },
    output_type="xlsx",
)

def papaya_hartree(task, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    our_files = files[0]

    ################################ REGULARY EXPRESSION FOR ALL THE RESEARCH IN THE PDF FILES ########################################################

    name = re.compile(
        r'(?P<first_name>[A-ZÄÖÜ][a-zäöüß]+)\s(?P<last_name>[A-ZÄÖÜ][a-zäöüß-]+(?:\s(?:von|von der|van der))?)(?:\s(?P<suffix>(?<=\s)[JS]r\.|I{1,3}))?')  # Regular expressiob for all name

    Companyname = re.compile(r'GmbH')  # Regular expression for company name

    Base_Salary = re.compile(
        r'200\sSalary/Gehalt|Gehalt/Salary|100\sStundenlohn|102\sGehalt')  # Regular expression for gehalt

    TGI = re.compile(r'Tax/Social')  # Regular expression for social

    Net = re.compile(r'Acc.no')  # Regular expression for net pay

    BAV_re = re.compile(r"891 bAV AG-Zus. lfd.ST-frei")

    # NetIncome=re.compile(r'^Statement of earnings')

    Wage = re.compile(r'(^L|^N\s1.)')  # Regular expression for Wage Tax and Tax Deduction
    WageS = re.compile(r'^S\s\d')
    WageE = re.compile(r'^E\s\d')

    Car = re.compile(r'Privatfahrten/priv. use')  #

    CarAllowance = re.compile(r'^201 Car Allowance')

    Commission = re.compile(r'^011\sPrämie')

    Period = re.compile(r'^Pay Advice')

    ID = re.compile(r'^000')

    Uberstd = re.compile('Überstdgrundvergütung')
    Uberstd2 = re.compile('^N\s002')
    WeekendSamstag = re.compile('090 weekend work 150% Satu.')
    WeekendSonntag = re.compile('092 weekend work 150% Sund. ')

    BetragAVAG = re.compile(r'901 Betr.AV.AG lfd.ST-frei')
    BetragAVANST = re.compile(r'911 Betr.AV.AN lfd.ST-frei')
    BetragAVANGE = re.compile('914 Betr.AV.AN lfd.Geh.Ver ')

    PV = re.compile(r'AG-Zuschuss zur PV')

    KV = re.compile(r'AG-Zuschuss zur KV')

    GBzurPV = re.compile(r'Gesamtbeitrag zur PV')

    GBzurKV = re.compile(r'Gesamtbeitrag zur KV')

    HO = re.compile(r'Home Office')

    Contrgroup = re.compile(r'^\d{8}\w\d{3}')
    PersonalBetrieb = re.compile(r'^\*\s\d{6}\*')
    # Kirche=re.compile(r'Home Office')
    HIincome = re.compile(r'^Tax. ')

    CI24 = re.compile('^Solidarity surcharge')

    PIline = re.compile('^Wage tax')

    UIline = re.compile('^Church tax')

    Bonuslfd = re.compile('Bonus lfd.')
    BonusEBZ = re.compile('009 Bonus EBZ')

    RAllowance = re.compile('Residence Allowance')
    RAllowanceNet = re.compile('119\sResidence Allowance net')

    PrivateLI = re.compile('priv. liability insura. ')

    PrivateHI = re.compile('priv. household insura. ')

    Direkt = re.compile('Direktversicherung')

    AGzuschussPV0 = re.compile('9983 AG-Zuschuss zur PV')

    AGzuschussKV0 = re.compile('9995 AG-Zuschuss zur KV')

    Bereits = re.compile('9079 bereits erhalten')

    lineitemsw = re.compile('^Tx')

    Correction = re.compile('From correction')

    CorrectionN = re.compile('^N\s')

    CorrectionSickPay = re.compile('300 Correction 05-Sick Pay')

    CorrectionCI = re.compile(' 9091 Corr. CI-ER May ')

    CorrectionHI = re.compile(' 9090 Corr. HI-ER May')

    FreiwilligeZuschlage = re.compile('Freiwillige Zulage')

    Sonderzahlung = re.compile(' Sonderzahlung zusätzl.')

    Unterstutzung = re.compile('Unterstützungskasse')

    Bav_Abzug = re.compile('bAV-Abzug')

    #######################################FUNCTION###############################################

    def extract_UI(line_items, indicators):
        for ind in indicators:
            if ind in line_items:
                idx = line_items.index(ind)
                if idx > 0:
                    value = line_items[idx - 1]
                    value = f"{value[:-2]},{value[-2:]}"
                    return value.replace('.', '')
        return None

    def extract_value_before(line_items, indicators, offset):
        for ind in indicators:
            if ind in line_items:
                idx = line_items.index(ind)
                if idx >= offset:
                    return line_items[idx - offset]
        return None

    def extract_value_after(line_items, indicators, offset=1):
        for ind in indicators:
            if ind in line_items:
                idx = line_items.index(ind)
                if idx + offset < len(line_items):
                    return line_items[idx + offset]
        return None

    ################################  DECLARATION OF ALL THE LIST ###################################################################

    Company = []
    Employee = []
    Basesalary = []
    Basesalary2 = []  # Pour le total
    TotalGrossIncome = []
    MitarbeiterID = []
    Netpay = []
    WageTax = []
    WageTaxN = []
    WageTaxS = []
    WageTaxE = []
    CarBenefit = []
    CarBenefitMinus = []
    CommissionList = []
    Date = []

    Uberstunde = []
    SaturdayWork = []
    SundayWork = []

    PersonalBetriebNr = []

    Betrag901 = []
    Betrag911 = []
    Betrag914 = []
    AGZuschussKV = []
    AGZuschussPV = []
    BereitsErhalten = []
    GBKV = []
    GBPV = []
    Homeoffice = []
    ChurchTax = []
    ChurchTaxN = []
    ChurchTaxS = []
    Solidarity = []
    SolidarityN = []
    SolidarityS = []
    SocialD = []
    SocialDN = []
    AGsocial = []
    CIcont = []
    CIcontN = []
    PICont = []
    PIContN = []
    UICont = []
    UIContN = []
    HICont = []
    HIContN = []
    CIcontE = []
    PIContE = []
    UIContE = []
    HIContE = []
    EmpSocSec = []
    Bav_list = []
    Bav_listAbzug = []
    Cont = []
    ERTotalCost = []
    Emp = []
    Bonus = []
    BonusEBZlist = []
    Resid = []
    ResidNet = []
    PLI = []
    PHI = []
    DV = []
    linewage = []
    linetitlewage = []
    FromCorrection = []
    CorrectionSickPayList = []
    CorrectionNSalaryList = []
    CorrectionHIlist = []
    CorrectionNHIlist = []
    CorrectionNCIlist = []
    CorrectionCIlist = []
    FZList = []
    SonderzahlunglIST = []
    UnterstutzungLIST = []

    #############################################  RESEARCH START AND INCORPORATION OF ALL AMOUNT AND NAME IN LIST   ####################################

    with (pdfplumber.open(our_files) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            # Récupération du contenu de la page
            text = page.extract_text()

            for line in text.split('\n'):
                if CorrectionN.search(line):
                    # Si oui → on garde uniquement les lignes qui commencent par "N"
                    lineitemsN = line.split()
                    if "001" in lineitemsN:
                        CSalaryAmount = (lineitemsN[-1].replace('-', ''), num_page)
                        CorrectionNSalaryList.append(CSalaryAmount)
                    else:
                        line_items_WageN = line.split()
                        if line_items_WageN[0] == 'N' and \
                                (line_items_WageN[2] != line_items_WageN[1]):
                            WageTaxN1 = lineitemsN[2]
                            WageTaxN1 = f"{WageTaxN1[:-2]},{WageTaxN1[-2:]}"
                            WageTaxN1 = (WageTaxN1, num_page)
                            WageTaxN.append(WageTaxN1)

                            # print(WageTaxN1)

                            if len(line_items_WageN) > 4:
                                SolidarityN1 = line_items_WageN[3]
                                SolidarityN1 = f"{SolidarityN1[:-2]},{SolidarityN1[-2:]}"
                                SolidarityN1 = (SolidarityN1, num_page)
                                SolidarityN.append(SolidarityN1)
                                # print(SolidarityS2)
                        else:
                            if (line_items_WageN[2] == line_items_WageN[1]):
                                # print(line_items_Wage)
                                SocialDN1 = (line_items_WageN[-1].replace('-', ''), num_page)
                                SocialDN.append(SocialDN1)
                                UI = line_items_WageN[-2].replace('-', '')
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = (UI.replace('.', ''), num_page)

                                PI = line_items_WageN[-3].replace('-', '')
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PI = (PI.replace('.', ''), num_page)

                                # UI = f"{UI[:-2]},{UI[-2:]}"

                                # AGPV = (line_items_ZuschussPV[-1].replace('-', '').replace('.', ''), num_page)
                                UIContN.append(UI)
                                PIContN.append(PI)

                                # print(lineitemsN)

                        # print(lineitemsN)
            if text and "(1.C)" in text:
                continue  # Ignore la page et passe à la suivante
            elif text and "(2.C)" in text:
                continue

            lang = langid.classify(text)[0]

            # print(text)
            for line in text.split('\n'):
                if lang == 'en':

                    if name.search(line):

                        # elif not Car.search(line):
                        # CarBenefit.append('')
                        line_items_name = line.split()
                        if len(line_items_name) <= 3 and "Straße" not in line_items_name \
                                and "Weg" not in line_items_name \
                                and "Security" not in line_items_name \
                                and "Sozialversicherungspflichtiges" not in line_items_name \
                                and "Verdienstbescheinigung" not in line_items_name \
                                and "Pfändung" not in line_items_name \
                                and "Darlehen" not in line_items_name \
                                and "Commerzbank" not in line_items_name \
                                and "Landstr." not in line_items_name \
                                and "Str." not in line_items_name \
                                and "Str" not in line_items_name \
                                and "Stephansweg" not in line_items_name \
                                and "Ufer" not in line_items_name \
                                and "Damm" not in line_items_name \
                                and "Bad" not in line_items_name \
                                and 'Csepella,' not in line_items_name:
                            filtered_list = [item for item in line_items_name if
                                             not item[-1].replace(',', '').replace('.', '').isdigit()]
                            Mitarbeiter = ' '.join(filtered_list)
                            Employee.append(Mitarbeiter)
                            # print(Mitarbeiter)
                        # Employee.append(Mitarbeiter)
                        # print(Mitarbeiter)
                    if PersonalBetrieb.search(line):
                        line_items_PBNr = line.split()
                        # print(line_items_PBNr)
                        PersonalBetriebNr.append(line_items_PBNr[1].replace('*', ''))
                    if Companyname.search(line):
                        line_items_company = line.split()
                        company_info = line_items_company[0]
                        name_part = company_info.split('GmbH')[0]
                        spaced_name = ' '.join(re.findall(r'[A-Z][a-z]+|\([^)]+\)', name_part))
                        company_name = spaced_name + ' GmbH'
                        Company.append(company_name)
                        # print(company_name)

                    if Base_Salary.search(line):
                        line_items_base = line.split()

                        BaseS2 = (line_items_base[-1].replace('.', '').replace('-', ''))
                        Basesalary.append(BaseS2)
                        # print(line_items_base)

                    if TGI.search(line):
                        line_items_tgi = line.split()
                        TotalGrossIncome.append(line_items_tgi[-1].replace('.', ''))
                        # print(line_items_tgi)
                        # print(line_items_base)
                    if Net.search(line):
                        line_items_net = line.split()
                        # print(line_items_net)
                        if "pay" and "advice." not in line_items_net:
                            # del line_items_net

                            if len(line_items_net[-2]) > 3:
                                AG = line_items_net[-2].replace('.', '').replace('-', '')
                                AG = f"{AG[:-2]},{AG[-2:]}"
                                AGsocial.append(AG)

                                ERTotalCost.append(line_items_net[-2].replace('.', '').replace('-', ''))
                                EmpSoc = line_items_net[-3].replace('.', '').replace('-', '')
                                EmpSoc = f"{EmpSoc[:-2]},{EmpSoc[-2:]}"
                                Emp.append(EmpSoc)

                                EmpSocSec2 = line_items_net[-4].replace('.', '').replace('-', '')

                                EmpSocSec2 = f"{EmpSocSec2[:-2]},{EmpSocSec2[-2:]}"
                                if len(line_items_net[-4]) == 2:
                                    EmpSocSec2 = '0,00'
                                    # EmpSocSec.append(EmpSocSec2)
                                # print(EmpSocSec2)
                                EmpSocSec.append(EmpSocSec2)
                            # elif line_items_net[-4] =='06':
                            # EmpSocSec.append('0,00')

                            else:
                                AGsocial.append('')

                            # AGsocial.append(line_items_net[-2].replace('.','').replace('-',''))
                            # print(line_items_net)
                            Netpay.append(line_items_net[-1].replace('.', '').replace('-', ''))

                    if Correction.search(line):
                        line_items_correction = line.split()
                        # print(line_items_net)

                        Correction2 = (line_items_correction[-1].replace('.', '').replace('-', ''), num_page)
                        # print(Correction2)
                        FromCorrection.append(Correction2)
                        # print(FromCorrection)

                    if WageS.search(line):
                        line_items_WageS = line.split()
                        WageTaxS2 = line_items_WageS[2]
                        WageTaxS2 = f"{WageTaxS2[:-2]},{WageTaxS2[-2:]}"
                        WageTaxS2 = (WageTaxS2, num_page)
                        WageTaxS.append(WageTaxS2)
                        # print(WageTaxS)

                        if len(line_items_WageS) > 4:
                            SolidarityS2 = line_items_WageS[3]
                            # print(SolidarityS2)

                            if int(SolidarityS2) < 10000:
                                ChurchTaxS2 = SolidarityS2
                                ChurchTaxS2 = (ChurchTaxS2, num_page)
                                ChurchTaxS.append(ChurchTaxS2)
                            else:
                                SolidarityS2 = f"{SolidarityS2[:-2]},{SolidarityS2[-2:]}"
                                SolidarityS2 = (SolidarityS2, num_page)
                                SolidarityS.append(SolidarityS2)

                    if WageE.search(line):
                        line_items_WageE = line.split()
                        WageTaxE2 = line_items_WageE[2]
                        WageTaxE2 = f"{WageTaxE2[:-2]},{WageTaxE2[-2:]}"
                        WageTaxE2 = (WageTaxE2, num_page)
                        WageTaxE.append(WageTaxE2)
                        # print(line_items_WageE)
                        UIE = line_items_WageE[-3]
                        UIE = f"{UIE[:-2]},{UIE[-2:]}"
                        UIE = (UIE.replace('.', ''), num_page)

                        PIE = line_items_WageE[-4]
                        PIE = f"{PIE[:-2]},{PIE[-2:]}"
                        PIE = (PIE.replace('.', ''), num_page)

                        HIE = line_items_WageE[-5]
                        HIE = f"{HIE[:-2]},{HIE[-2:]}"
                        HIE = (HIE.replace('.', ''), num_page)

                        CIE = line_items_WageE[-2]
                        CIE = f"{CIE[:-2]},{CIE[-2:]}"
                        CIE = (CIE.replace('.', ''), num_page)

                        UIContE.append(UIE)
                        PIContE.append(PIE)
                        HIContE.append(HIE)
                        CIcontE.append(CIE)

                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # print(line_items_Wage)

                        # print(line_items_Wage)
                        if line_items_Wage[
                            0] == 'L' and '773,80' not in line_items_Wage and 'Z' not in line_items_Wage:  # FAIRE EN SORTE DAVOIR LES HI COMTRIBUTIONS
                            # print(line_items_Wage)

                            if len(line_items_Wage) > 2 and line_items_Wage[2] != line_items_Wage[1] and \
                                    line_items_Wage[3] != line_items_Wage[2]:
                                # print(line_items_Wage)
                                Wage2 = line_items_Wage[2]

                                # print(Sol2)
                                # Format with one comma before the last two numbers
                                Wage2 = f"{Wage2[:-2]},{Wage2[-2:]}"
                                WageTax.append(Wage2.replace('.', ''))
                                # print(Wage2)

                                if len(line_items_Wage) == 5:

                                    # Solidarity.append(Solidarity2)

                                    if len(line_items_Wage[2]) >= len(line_items_Wage[3]) and int(
                                            line_items_Wage[-1].replace(".", "").replace(",", "")) < 200000:
                                        churchtax2 = line_items_Wage[-2]
                                        churchtax2 = f"{churchtax2[:-2]},{churchtax2[-2:]}"
                                        churchtax2 = (churchtax2, num_page)
                                        ChurchTax.append(churchtax2)
                                    elif len(line_items_Wage[2]) >= len(line_items_Wage[3]) and int(
                                            line_items_Wage[-1].replace(".", "").replace(",", "")) > 200000:
                                        Solidarity2 = line_items_Wage[-2]
                                        Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                        Solidarity2 = (Solidarity2, num_page)
                                        Solidarity.append(Solidarity2)
                                elif len(line_items_Wage) == 6 and len(line_items_Wage[-2]) == 3:
                                    Solidarity2 = line_items_Wage[-2]
                                    Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                    Solidarity2 = (Solidarity2, num_page)
                                    Solidarity.append(Solidarity2)
                                elif len(line_items_Wage) == 5 and len(line_items_Wage[2]) - len(
                                        line_items_Wage[3]) == 1 and line_items_Wage[-2] < "15000":
                                    churchtax2 = line_items_Wage[-2]
                                    churchtax2 = f"{churchtax2[:-2]},{churchtax2[-2:]}"
                                    churchtax2 = (churchtax2, num_page)
                                    ChurchTax.append(churchtax2)
                                elif len(line_items_Wage) == 5 and len(line_items_Wage[2]) - len(
                                        line_items_Wage[-1]) == 1 and line_items_Wage[-2] > "15000":
                                    Solidarity2 = line_items_Wage[-2]
                                    Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                    Solidarity2 = (Solidarity2, num_page)
                                    Solidarity.append(Solidarity2)

                                elif len(line_items_Wage) == 6:
                                    Solidarity2 = line_items_Wage[-2]
                                    Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                    Solidarity2 = (Solidarity2, num_page)
                                    Solidarity.append(Solidarity2)

                                    churchtax2 = line_items_Wage[-3]
                                    churchtax2 = f"{churchtax2[:-2]},{churchtax2[-2:]}"
                                    churchtax2 = (churchtax2, num_page)
                                    ChurchTax.append(churchtax2)

                                    # print(churchtax2)





                            elif len(line_items_Wage) == 2:  # KEY MARCUS MOSS
                                # WageTax.append('')
                                SocialD.append('')
                                # Basesalary.append('0')
                                # UICont.append('')
                                # 0PICont.append('')

                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:
                            # print(line_items_Wage)
                            SocialD.append(line_items_Wage[-1].replace('.', ''))

                            # else:
                            # SocialD.append('')
                            # print(line_items_Wage)
                            # SocialD.append(line_items_Wage[-1])
                            if len(line_items_Wage) == 6:
                                # print(line_items_Wage)
                                UI = line_items_Wage[-2].replace('-', '')
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = (UI.replace('.', ''), num_page)

                                PI = line_items_Wage[-3].replace('-', '')
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PI = (PI.replace('.', ''), num_page)

                                # UI = f"{UI[:-2]},{UI[-2:]}"

                                # AGPV = (line_items_ZuschussPV[-1].replace('-', '').replace('.', ''), num_page)
                                UICont.append(UI)
                                PICont.append(PI)


                            elif 'Z' in line_items_Wage or 'E' in line_items_Wage or '1' in line_items_Wage or '2' in line_items_Wage or '3' in line_items_Wage or '4' in line_items_Wage:

                                # print(line_items_Wage)
                                UI = extract_UI(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'])

                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = UI.replace(',,', ',')

                                UI = (UI.replace('.', ''), num_page)

                                PI = extract_value_before(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'], 2)
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PI = (PI.replace('.', ''), num_page)

                                if len(line_items_Wage) > 7:
                                    HI = extract_value_before(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'], 3)

                                    HI = f"{HI[:-2]},{HI[-2:]}"
                                    HI = (HI.replace('.', ''), num_page)
                                    HICont.append(HI)

                                    CI = extract_value_after(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'], 1)

                                    CI = f"{CI[:-2]},{CI[-2:]}"
                                    CI = (CI.replace('.', ''), num_page)
                                    CIcont.append(CI)

                                # UI = f"{UI[:-2]},{UI[-2:]}"
                                # PI = f"{PI[:-2]},{PI[-2:]}"
                                # SocialD.append(line_items_Wage[-1])

                                UICont.append(UI)
                                PICont.append(PI)



                            elif len(line_items_Wage) >= 9:
                                # print(line_items_Wage)
                                UI = line_items_Wage[-3]
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = (UI.replace('.', ''), num_page)

                                PI = line_items_Wage[-4]
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PI = (PI.replace('.', ''), num_page)

                                HI = line_items_Wage[-6]
                                HI = f"{HI[:-2]},{HI[-2:]}"
                                HI = (HI.replace('.', ''), num_page)

                                CI = line_items_Wage[-2]
                                CI = f"{CI[:-2]},{CI[-2:]}"
                                CI = (CI.replace('.', ''), num_page)

                                # UI = f"{UI[:-2]},{UI[-2:]}"
                                # PI = f"{PI[:-2]},{PI[-2:]}"
                                UICont.append(UI)
                                PICont.append(PI)
                                HICont.append(HI)
                                CIcont.append(CI)
                            # print(line_items_Wage)
                            # else:
                            # SocialD.append('')

                    if CarAllowance.search(line):
                        line_items_Car = line.split()
                        # print(line_items_Car)
                        CarPrivate = (line_items_Car[-1].replace('-', ''), num_page)
                        CarPrivate2 = ('-' + line_items_Car[-1].replace('-', ''), num_page)
                        CarBenefit.append(CarPrivate)
                        # listminus=["-" + x[:-1] for x in CarBenefit]
                        # CarBenefitMinus.append(CarPrivate2)

                        # CarBenefit.append('0')
                        # CarBenefitMinus.append('0')

                    if Commission.search(line):
                        line_items_Comission = line.split()
                        Commission2 = (line_items_Comission[-1].replace('.', '').replace('-', ''), num_page)
                        CommissionList.append(Commission2)
                        # print(line_items_Comission)

                    if BAV_re.search(line):
                        line_items_BAV = line.split()
                        BAVAGZ = (line_items_BAV[-1].replace('.', '').replace('-', ''), num_page)
                        Bav_list.append(BAVAGZ)
                        # print(line_items_Comission)

                    if Bav_Abzug.search(line):
                        line_items_BAVAbzug = line.split()
                        BAVABZ = (line_items_BAVAbzug[-1].replace('.', '').replace('-', ''), num_page)
                        Bav_listAbzug.append(BAVABZ)
                        # print(line_items_Comission)

                    if Period.search(line):
                        line_items_Period = line.split()
                        month = ' '.join(line_items_Period[3:5])
                        Date.append(month)
                        # print(month)
                    if ID.search(line):
                        line_items_ID = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        # print(line_items_ID)
                        MitarbeiterID.append(line_items_ID[0])

                    if Uberstd.search(line) or Uberstd2.search(line):
                        line_items_uberstd = line.split()
                        # print(line_items_uberstd)
                        if len(line_items_uberstd) > 2:
                            Uberstunde2 = (line_items_uberstd[-1].replace('.', '').replace('-', ''), num_page)
                            Uberstunde.append(Uberstunde2)  #
                            # print(Uberstunde2)

                    if WeekendSamstag.search(line):
                        line_items_Samstag = line.split()
                        Samstag2 = (line_items_Samstag[-1].replace('.', '').replace('-', ''), num_page)
                        SaturdayWork.append(Samstag2)  #
                        # print(line_items_Samstag)

                    if WeekendSonntag.search(line):
                        line_items_Sonntag = line.split()
                        Sonntag2 = (line_items_Sonntag[-1].replace('.', '').replace('-', ''), num_page)
                        SundayWork.append(Sonntag2)

                    if Bonuslfd.search(line):
                        line_items_lfd = line.split()
                        # print(line_items_lfd)
                        # if len(line_items_uberstd) >2:
                        Bonus1 = (line_items_lfd[-1].replace('.', '').replace('-', ''), num_page)
                        Bonus.append(Bonus1)  #
                        # print(Uberstunde2)

                    if BonusEBZ.search(line):
                        line_items_BonusEBZ = line.split()
                        # print(line_items_BonusEBZ)
                        Bonus2 = (line_items_BonusEBZ[-1].replace('.', '').replace('-', ''), num_page)
                        BonusEBZlist.append(Bonus2)

                    if PrivateLI.search(line):
                        line_items_PLI = line.split()
                        # print(line_items_PLI)
                        # if len(line_items_uberstd) >2:
                        PLI1 = (line_items_PLI[-1].replace('.', '').replace('-', ''), num_page)
                        PLI.append(PLI1)  #

                    if PrivateHI.search(line):
                        line_items_PHI = line.split()
                        # print(line_items_PLI)
                        # if len(line_items_uberstd) >2:
                        PHI1 = (line_items_PHI[-1].replace('.', '').replace('-', ''), num_page)
                        # print(PHI1)
                        PHI.append(PHI1)

                    if RAllowance.search(line):
                        line_items_RA = line.split()
                        # print(line_items_PLI)
                        # if len(line_items_uberstd) >2:
                        RA1 = (line_items_RA[-1].replace('.', '').replace('-', ''), num_page)
                        Resid.append(RA1)

                    if RAllowanceNet.search(line):
                        line_items_RAnet = line.split()
                        # print(line_items_RAnet)
                        # if len(line_items_uberstd) >2:
                        RA2 = (line_items_RAnet[-1].replace('.', '').replace('-', ''), num_page)
                        ResidNet.append(RA2)

                    if BetragAVAG.search(line):
                        line_items_Betrag = line.split()
                        # print(line_items_Betrag)
                        BetragAVAGlfd = (line_items_Betrag[-1].replace('-', ''), num_page)
                        # print(BetragAVAGlfd)
                        Betrag901.append(BetragAVAGlfd)

                    if BetragAVANST.search(line):
                        line_items_Betrag = line.split()
                        BetragANAm = (line_items_Betrag[-1].replace('-', ''), num_page)
                        Betrag911.append(BetragANAm)

                    if BetragAVANGE.search(line):
                        line_items_BetragGE = line.split()
                        # print(line_items_BetragGE)
                        BetragANAmGe = ('-' + line_items_BetragGE[-1].replace('-', ''), num_page)
                        Betrag914.append(BetragANAmGe)

                        # print(Uberstunde)

                    if GBzurPV.search(line):
                        line_items_GBPV = line.split()
                        GBPVAmount = ('-' + line_items_GBPV[-1].replace('-', ''), num_page)
                        # print(line_items_GBPV)
                        GBPV.append(GBPVAmount)

                    if GBzurKV.search(line):
                        line_items_GBKV = line.split()
                        # print(line_items_GBKV)
                        GBKVAmount = ('-' + line_items_GBKV[-1].replace('-', ''), num_page)
                        # print(line_items_GBPV)
                        GBKV.append(GBKVAmount)

                    if CorrectionSickPay.search(line):  # Pour les corrections sick juste pour ce mois
                        line_items_CSP = line.split()
                        # print(line_items_GBKV)
                        CSPAmount = ('-' + line_items_CSP[-1].replace('-', ''), num_page)
                        # print(line_items_GBPV)
                        CorrectionSickPayList.append(CSPAmount)

                    if CorrectionHI.search(line):  # Pour les corrections sick juste pour ce mois
                        line_items_CHI = line.split()
                        # print(line_items_GBKV)
                        CHIAmount = ('-' + line_items_CHI[-1].replace('-', ''), num_page)
                        # print(line_items_GBPV)
                        CorrectionHIlist.append(CHIAmount)

                    if CorrectionCI.search(line):  # Pour les corrections sick juste pour ce mois
                        line_items_CCI = line.split()
                        # print(line_items_GBKV)
                        CCIAmount = ('-' + line_items_CCI[-1].replace('-', ''), num_page)
                        # print(line_items_GBPV)
                        CorrectionCIlist.append(CCIAmount)

                    if HO.search(line):
                        line_items_HO = line.split()
                        HOamount = (line_items_HO[-1].replace('-', ''), num_page)
                        Homeoffice.append(HOamount)
                    # print(Homeoffice)

                    # if CI24.search(line):
                    # line_items_SS = line.split()
                    # print(line_items_SS)
                    # if line_items_SS[2].isdigit():
                    # Solidarity_Surcharge = line_items_SS[2].replace('-', '').replace('.', '')
                    # Solidarity_Surcharge = f"{Solidarity_Surcharge[:-2]},{Solidarity_Surcharge[-2:]}"
                    # Solidarity_Surcharge = (Solidarity_Surcharge, num_page)
                    # print(Solidarity_Surcharge)
                    # Solidarity.append(Solidarity_Surcharge)
                    # if CarAllowance.search(line):
                    # line_items_CarAl=line.split()
                    # print(line_items_CarAl)
                    if Direkt.search(line):
                        line_items_DV = line.split()
                        # print(line_items_DV)
                        DVamount = ('-' + line_items_DV[-1].replace('-', '').replace('.', ''), num_page)
                        DV.append(DVamount)

                    if AGzuschussPV0.search(line):
                        line_items_ZuschussPV = line.split()
                        AGPV = (line_items_ZuschussPV[-1].replace('-', '').replace('.', ''), num_page)
                        AGZuschussPV.append(AGPV)
                        # print(AGPV)

                    if Bereits.search(line):
                        line_items_Bereits = line.split()
                        # print(line_items_Bereits)
                        BereitsErhalten2 = (line_items_Bereits[-1].replace('-', '').replace('.', ''), num_page)
                        BereitsErhalten.append(BereitsErhalten2)

                    if AGzuschussKV0.search(line):
                        line_items_ZuschussKV = line.split()
                        # print(line_items_ZuschussKV)
                        AGKV = (line_items_ZuschussKV[-1].replace('-', '').replace('.', ''), num_page)
                        AGZuschussKV.append(AGKV)
                        # print(AGPV)

                    if Contrgroup.search(line):
                        line_items_Cont = line.split()

                        # print(line_items_Cont)
                        if line_items_Cont[-1] == '30' or line_items_Cont[-1] == '04':
                            Cont.append(line_items_Cont[-3])
                        else:
                            Cont.append(line_items_Cont[-2])
                        # if line_items_Cont[-1]!='1':
                        # Cont.append(line_items_Cont[-3])
                        # else:
                        # Cont.append(line_items_Cont[-2])
                        # print(line_items_Cont)
                        # Cont.append(line_items_Cont[-3])

                    if UIline.search(line):
                        line_items_UI = line.split()

                    if FreiwilligeZuschlage.search(line):
                        line_items_FZ = line.split()
                        FZ = (line_items_FZ[-1].replace('-', '').replace('.', ''), num_page)
                        FZList.append(FZ)
                        # print(line_items_FZ)

                    if Sonderzahlung.search(line):
                        line_items_SZ = line.split()
                        SZ = (line_items_SZ[-1].replace('-', '').replace('.', ''), num_page)
                        SonderzahlunglIST.append(SZ)

                    if Unterstutzung.search(line):
                        line_items_UnterS = line.split()
                        UStzung = (line_items_UnterS[-1].replace('-', '').replace('.', ''), num_page)
                        UnterstutzungLIST.append(UStzung)

    # Sum of all numbers and replacement to be float

    # for i in range(len(Basesalary)):
    # Replace the period with an empty string
    # Basesalary2[i] = Basesalary2[i].replace(',', '.')

    for i in range(len(TotalGrossIncome)):
        # Replace the period with an empty string
        TotalGrossIncome[i] = TotalGrossIncome[i].replace(',', '.')

    for i in range(len(Netpay)):
        # Replace the period with an empty string
        Netpay[i] = Netpay[i].replace(',', '.')

    # for i in range(len(CarBenefit)):
    # Replace the period with an empty string
    # CarBenefit[i] = CarBenefit[i].replace(',', '.')

    for i in range(len(WageTax)):
        # Replace the period with an empty string
        if WageTax[i] == '':
            WageTax[i] = '0'
        WageTax[i] = WageTax[i].replace(',', '.')

    # print(FromCorrection)

    # total = sum(float(num) for num in Basesalary2)
    totalTGI = sum(float(num) for num in TotalGrossIncome)
    totalNet = sum(float(num) for num in Netpay)
    # totalCar= sum(float(num) for num in CarBenefit)
    totalWage = sum(float(num) for num in WageTax)

    totalNet = round(totalNet, 2)
    totalWage = round(totalWage, 2)
    totalTGI = round(totalTGI, 2)

    # total = str(total).replace('.', ',')
    totalTGI = str(totalTGI).replace('.', ',')
    totalNet = str(totalNet).replace('.', ',')
    # totalCar = str(totalCar).replace('.',',')
    totalWage = str(totalWage).replace('.', ',')
    # totalCommission = str(totalCommission).replace('.', ',')
    # total=total.replace(',', '|').replace('.', ',').replace('|', '.')
    # print(total)
    # print(totalTGI)
    # print(totalNet)

    # Replacement to be normal number
    for i in range(len(Basesalary2)):
        # Replace the period with an empty string
        Basesalary2[i] = Basesalary2[i].replace('.', ',')

    for i in range(len(TotalGrossIncome)):
        # Replace the period with an empty string
        TotalGrossIncome[i] = TotalGrossIncome[i].replace('.', ',')

    for i in range(len(Netpay)):
        # Replace the period with an empty string
        Netpay[i] = Netpay[i].replace('.', ',')

    # for i in range(len(CarBenefit)):
    # Replace the period with an empty string
    # CarBenefit[i] = CarBenefit[i].replace('.', ',')

    for i in range(len(WageTax)):
        # Replace the period with an empty string

        WageTax[i] = WageTax[i].replace('.', ',')

    # Add empty line
    Company.append('')
    Employee.append('')
    # Basesalary.append('')
    TotalGrossIncome.append('')
    MitarbeiterID.append('')
    Netpay.append('')
    WageTax.append('')
    # CarBenefit.append('')
    # CarBenefitMinus.append('')
    # CommissionList.append('')
    Date.append('')

    Company.append('')
    Employee.append('TOTAL')

    TotalGrossIncome.append(totalTGI)
    MitarbeiterID.append('')
    Netpay.append(totalNet)
    WageTax.append(totalWage)
    # CarBenefit.append(totalCar)
    # CarBenefitMinus.append('-'+totalCar)
    # CommissionList.append(totalCommission)
    Date.append('')

    # CarBenefitMinus=["-" + x[:-1] for x in CarBenefit]

    ### TAKE ALL THE PAGE NUMBER FOR UBERSTUNDEN
    Num_pages = [tup[-1] for tup in Uberstunde]
    # print(Num_pages)
    WorkerIDuberstd = []
    UberstdNumpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):

            if num_page in Num_pages:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_ID2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        # print(line_items_ID2)
                        WorkerIDuberstd.append(line_items_ID2[0])
                        # print(line_items_ID2)
                    if Uberstd.search(line):
                        line_items_uberstd = line.split()
                        if len(line_items_uberstd) > 2:
                            Uberstunde3 = line_items_uberstd[-1].replace('.', '').replace('-', '')
                            UberstdNumpages.append(Uberstunde3)
                            # print(Uberstunde3)

    ### TAKE ALL THE PAGE NUMBER FOR home office
    Num_pages2 = [tup[-1] for tup in Homeoffice]
    # print(Num_pages)
    WorkerIDHomeOffice = []
    HomeOfficeNumpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages2:

                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_HOid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDHomeOffice.append(line_items_HOid2[0])
                        # print(line_items_ID2)
                    if HO.search(line):
                        line_items_HO2 = line.split()
                        # print(line_items_HO2)
                        HomeOfficeNumpages.append(line_items_HO2[-1])

    ### TAKE ALL THE PAGE NUMBER FOR Bonuslfd
    Num_pages3 = [tup[-1] for tup in Bonus]
    # print(Num_pages)
    WorkerIDBonus = []
    BonusNumpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages3:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Bonusid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDBonus.append(line_items_Bonusid2[0])
                        # print(line_items_Bonusid2)
                    if Bonuslfd.search(line):
                        line_items_Bonus2 = line.split()
                        # print(line_items_HO2)
                        BonusNumpages.append(line_items_Bonus2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR BonusEBZ
    Num_pages32 = [tup[-1] for tup in BonusEBZlist]
    # print(Num_pages)
    WorkerIDBonusEBZ = []
    BonusEBZNumpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages32:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                    # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_BonusEBZid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDBonusEBZ.append(line_items_BonusEBZid2[0])
                        # print(line_items_Bonusid2)
                    if BonusEBZ.search(line):
                        line_items_BonusEBZ2 = line.split()
                        # print(line_items_HO2)
                        BonusEBZNumpages.append(line_items_BonusEBZ2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Private Liability
    Num_pages4 = [tup[-1] for tup in PLI]
    # print(Num_pages)
    WorkerIDPLI = []
    PLINumpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages4:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_PLIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDPLI.append(line_items_PLIid2[0])
                        # print(line_items_PLIid2)
                    if PrivateLI.search(line):
                        line_items_PLI2 = line.split()
                        # print(line_items_PLI2)
                        PLINumpages.append(line_items_PLI2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Private Household
    Num_pages5 = [tup[-1] for tup in PHI]
    # print(Num_pages5)
    WorkerIDPHI = []
    PHINumpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages5:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_PHIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDPHI.append(line_items_PHIid2[0])
                    # print(line_items_PHIid2)
                    if PrivateHI.search(line):
                        line_items_PHI2 = line.split()
                        # print(line_items_PHI2)
                        PHINumpages.append(line_items_PHI2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Residance Allowance
    Num_pages6 = [tup[-1] for tup in Resid]
    # print(Num_pages5)
    WorkerIDRA = []
    RANumpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages6:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_RAid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDRA.append(line_items_RAid2[0])
                        # print(line_items_RAid2)
                    if RAllowance.search(line):
                        line_items_RA2 = line.split()
                        # print(line_items_RA2)
                        RANumpages.append(line_items_RA2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Residance Allowance Net
    Num_pages6b = [tup[-1] for tup in ResidNet]
    # print(Num_pages5)
    WorkerIDRANet = []
    RANumpagesNet = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages6b:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_RAid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDRANet.append(line_items_RAid2[0])
                        # print(line_items_RAid2)
                    if RAllowanceNet.search(line):
                        line_items_RA2 = line.split()
                        # print(line_items_RA2)
                        RANumpagesNet.append(line_items_RA2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR CHURCHTAX
    Num_pages7 = [tup[-1] for tup in ChurchTax]
    # print(Num_pages5)
    WorkerID_Church = []
    Church_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages7:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Churchid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Church.append(line_items_Churchid2[0])
                        # print(line_items_RAid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # print(line_items_Wage)

                        # print(line_items_Wage)
                        if line_items_Wage[
                            0] == 'L' and '773,80' not in line_items_Wage and 'Z' not in line_items_Wage:  # FAIRE EN SORTE DAVOIR LES HI COMTRIBUTIONS
                            # print(line_items_Wage)

                            if len(line_items_Wage) > 2 and line_items_Wage[2] != line_items_Wage[1] and \
                                    line_items_Wage[3] != line_items_Wage[2]:
                                # print(line_items_Wage)
                                Wage2 = line_items_Wage[2]

                                # print(Sol2)
                                # Format with one comma before the last two numbers
                                Wage2 = f"{Wage2[:-2]},{Wage2[-2:]}"
                                WageTax.append(Wage2.replace('.', ''))
                                # print(Wage2)

                                if len(line_items_Wage) == 5 and len(line_items_Wage[2]) >= len(line_items_Wage[3]):
                                    churchtax2 = line_items_Wage[-2]
                                    churchtax2 = f"{churchtax2[:-2]},{churchtax2[-2:]}"
                                    # churchtax2 = (churchtax2, num_page)
                                    Church_Numpages.append(churchtax2)

                                elif len(line_items_Wage) == 5 and len(line_items_Wage[2]) - len(
                                        line_items_Wage[3]) == 1 and line_items_Wage[-2] < "15000":
                                    churchtax2 = line_items_Wage[-2]
                                    churchtax2 = f"{churchtax2[:-2]},{churchtax2[-2:]}"
                                    # churchtax2 = (churchtax2, num_page)
                                    # Church_Numpages.append(churchtax2)

    ### TAKE ALL THE PAGE NUMBER FOR Solidarity Surcharge
    Num_pages8 = [tup[-1] for tup in Solidarity]
    # print(Num_pages5)
    WorkerID_Solidarity = []
    Solidarity_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages8:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Solidarityid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Solidarity.append(line_items_Solidarityid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # print(line_items_Wage)

                        # print(line_items_Wage)
                        if line_items_Wage[
                            0] == 'L' and '773,80' not in line_items_Wage and 'Z' not in line_items_Wage:  # FAIRE EN SORTE DAVOIR LES HI COMTRIBUTIONS
                            # print(line_items_Wage)

                            if len(line_items_Wage) == 5 and len(line_items_Wage[2]) >= len(line_items_Wage[3]):

                                Solidarity2 = line_items_Wage[-2]
                                Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                # Solidarity2 = (Solidarity2, num_page)
                                # Solidarity2 = (Solidarity2, num_page)
                                Solidarity_Numpages.append(Solidarity2)
                            elif len(line_items_Wage) == 6 and len(line_items_Wage[-2]) == 3:
                                Solidarity2 = line_items_Wage[-2]
                                Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                Solidarity_Numpages.append(Solidarity2)

                            elif len(line_items_Wage) == 4 and len(line_items_Wage[2]) - len(
                                    line_items_Wage[-1]) == 1 and line_items_Wage[-1] > "15000":
                                Solidarity2 = line_items_Wage[-1]
                                Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                # Solidarity_Numpages.append(Solidarity2)

    ### TAKE ALL THE PAGE NUMBER FOR Direktversicherung
    Num_pages9 = [tup[-1] for tup in DV]
    # print(Num_pages5)
    WorkerID_DV = []
    DV_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages9:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_DVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_DV.append(line_items_DVid2[0])
                        # print(line_items_Solidarityid2)
                    if Direkt.search(line):
                        line_items_DV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        DV_Numpages.append('-' + line_items_DV2[-1].replace('.', '').replace('-', ''))

    # print(WorkerID_Solidarity)

    ### TAKE ALL THE PAGE NUMBER FOR AGzuschussPV
    Num_pages11 = [tup[-1] for tup in AGZuschussPV]
    # print(Num_pages5)
    WorkerID_AGZuschussPV = []
    AGZuschussPV_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages11:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_AGPVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_AGZuschussPV.append(line_items_AGPVid2[0])
                        # print(line_items_Solidarityid2)
                    if AGzuschussPV0.search(line):
                        line_items_AGPV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        AGZuschussPV_Numpages.append(line_items_AGPV2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR AGzuschussKV
    Num_pages12 = [tup[-1] for tup in AGZuschussKV]
    # print(Num_pages5)
    WorkerID_AGZuschussKV = []
    AGZuschussKV_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages12:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_AGKVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_AGZuschussKV.append(line_items_AGKVid2[0])
                        # print(line_items_Solidarityid2)
                    if AGzuschussKV0.search(line):
                        line_items_AGKV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        AGZuschussKV_Numpages.append(line_items_AGKV2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR HI,CI,UI,PI
    Num_pages13 = [tup[-1] for tup in UICont]
    Num_pages14 = [tup[-1] for tup in PICont]
    Num_pages15 = [tup[-1] for tup in HICont]
    Num_pages16 = [tup[-1] for tup in CIcont]
    # print(Num_pages5)
    WorkerID_UICont = []
    WorkerID_PICont = []
    WorkerID_HICont = []
    WorkerID_CICont = []

    UICont_Numpages = []
    PICont_Numpages = []
    HICont_Numpages = []
    CICont_Numpages = []

    ### TAKE ALL THE PAGE NUMBER FOR HI,CI,UI,PI For E
    Num_pages132 = [tup[-1] for tup in UIContE]
    Num_pages142 = [tup[-1] for tup in PIContE]
    Num_pages152 = [tup[-1] for tup in HIContE]
    Num_pages162 = [tup[-1] for tup in CIcontE]
    # print(Num_pages5)
    WorkerID_UIContE = []
    WorkerID_PIContE = []
    WorkerID_HIContE = []
    WorkerID_CIContE = []

    UIContE_Numpages = []
    PIContE_Numpages = []
    HIContE_Numpages = []
    CIContE_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages13:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_UIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_UICont.append(line_items_UIid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # DV2=line_items_DV2[-1]
                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:

                            if len(line_items_Wage) == 6:
                                # print(line_items_Wage)
                                UI = line_items_Wage[-2].replace('-', '')
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UICont_Numpages.append(UI)


                            elif 'Z' in line_items_Wage or 'E' in line_items_Wage or '1' in line_items_Wage or '2' in line_items_Wage or '3' in line_items_Wage or '4' in line_items_Wage:
                                # print(line_items_Wage)
                                UI = extract_UI(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'])

                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = UI.replace(',,', ',')

                                UICont_Numpages.append(UI)
                                # PICont.append(PI)



                            elif len(line_items_Wage) >= 9:
                                # print(line_items_Wage)
                                UI = line_items_Wage[-3]
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UICont_Numpages.append(UI)

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages132:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_UIidE2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_UIContE.append(line_items_UIidE2[0])
                        # print(line_items_Solidarityid2)
                    if WageE.search(line):
                        line_items_WageE = line.split()
                        UIE = line_items_WageE[-3]
                        UIE = f"{UIE[:-2]},{UIE[-2:]}"
                        UIContE_Numpages.append(UIE)

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages14:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_PIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_PICont.append(line_items_PIid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # DV2=line_items_DV2[-1]
                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:

                            if len(line_items_Wage) == 6:
                                # print(line_items_Wage)
                                PI = line_items_Wage[-3].replace('-', '')
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PICont_Numpages.append(PI)


                            elif 'Z' in line_items_Wage or 'E' in line_items_Wage or '1' in line_items_Wage or '2' in line_items_Wage or '4' in line_items_Wage:
                                # print(line_items_Wage)
                                PI = extract_value_before(line_items_Wage, ['Z', 'E', '1', '2', '4'], 2)
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PICont_Numpages.append(PI)
                                # PICont.append(PI)

                            elif len(line_items_Wage) >= 9:
                                # print(line_items_Wage)
                                PI = line_items_Wage[-4]
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PICont_Numpages.append(PI)

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages142:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_PIidE2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_PIContE.append(line_items_PIidE2[0])
                    if WageE.search(line):
                        line_items_WageE = line.split()
                        PIE = line_items_WageE[-4]
                        PIE = f"{PIE[:-2]},{PIE[-2:]}"
                        PIContE_Numpages.append(PIE)

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages15:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_HIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_HICont.append(line_items_HIid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # DV2=line_items_DV2[-1]
                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:
                            if 'Z' in line_items_Wage:
                                if len(line_items_Wage) > 7:
                                    HI = extract_value_before(line_items_Wage, ['Z', 'E', '1', '2', '4'], 3)

                                    HI = f"{HI[:-2]},{HI[-2:]}"
                                    HICont_Numpages.append(HI)

                            elif len(line_items_Wage) >= 9:
                                HI = line_items_Wage[-6]
                                HI = f"{HI[:-2]},{HI[-2:]}"
                                HICont_Numpages.append(HI)

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages152:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_HIidE2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_HIContE.append(line_items_HIidE2[0])
                        # print(line_items_Solidarityid2)
                    if WageE.search(line):
                        line_items_WageE = line.split()
                        HIE = line_items_WageE[-5]
                        HIE = f"{HIE[:-2]},{HIE[-2:]}"
                        HIContE_Numpages.append(HIE)

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages16:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_CIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_CICont.append(line_items_CIid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # DV2=line_items_DV2[-1]
                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:
                            if 'Z' in line_items_Wage:
                                if len(line_items_Wage) > 7:
                                    CI = extract_value_after(line_items_Wage, ['Z', 'E', '1', '2', '4'], 1)

                                    CI = f"{CI[:-2]},{CI[-2:]}"
                                    # CI = (CI.replace('.', ''), num_page)
                                    CICont_Numpages.append(CI)

                            elif len(line_items_Wage) >= 9:

                                CI = line_items_Wage[-2]
                                CI = f"{CI[:-2]},{CI[-2:]}"
                                CICont_Numpages.append(CI)

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages162:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_CIidE2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_CIContE.append(line_items_CIidE2[0])
                        # print(line_items_Solidarityid2)
                    if WageE.search(line):
                        line_items_WageE = line.split()
                        CIE = line_items_WageE[-2]
                        CIE = f"{CIE[:-2]},{CIE[-2:]}"
                        CIContE_Numpages.append(CIE)

    ### TAKE ALL THE PAGE NUMBER FOR GBzurKV
    Num_pages17 = [tup[-1] for tup in GBKV]
    # print(Num_pages5)
    WorkerID_GBKV = []
    GBKV_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages17:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_GBKVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_GBKV.append(line_items_GBKVid2[0])
                        # print(line_items_Solidarityid2)
                    if GBzurKV.search(line):
                        line_items_GBKV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        GBKV_Numpages.append('-' + line_items_GBKV2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR GBzurPV
    Num_pages18 = [tup[-1] for tup in GBPV]
    # print(Num_pages5)
    WorkerID_GBPV = []
    GBPV_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages18:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_GBPVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_GBPV.append(line_items_GBPVid2[0])
                        # print(line_items_Solidarityid2)
                    if GBzurPV.search(line):
                        line_items_GBPV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        GBPV_Numpages.append('-' + line_items_GBPV2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR CarBenefit
    Num_pages19 = [tup[-1] for tup in CarBenefit]
    # print(Num_pages5)
    WorkerID_CarBenefit = []
    CarBenefit_Numpages = []
    CarBenefitMinus_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages19:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Carid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_CarBenefit.append(line_items_Carid2[0])
                        # print(line_items_Solidarityid2)
                    if CarAllowance.search(
                            line):  # J'ai mis CarAllowance ici parce que CAR simple c'est 'privatfahrten'
                        line_items_Car2 = line.split()
                        # DV2=line_items_DV2[-1]
                        CarBenefit_Numpages.append(line_items_Car2[-1].replace('.', '').replace('-', ''))
                        # CarBenefitMinus_Numpages.append('-' + line_items_Car2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Betrag911
    Num_pages20 = [tup[-1] for tup in Betrag911]
    # print(Num_pages5)
    WorkerID_Betrag911 = []
    Betrag911_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages20:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_911id2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Betrag911.append(line_items_911id2[0])
                        # print(line_items_Solidarityid2)
                    if BetragAVANST.search(line):
                        line_items_AVAN2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Betrag911_Numpages.append(line_items_AVAN2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Betrag914
    Num_pages21 = [tup[-1] for tup in Betrag914]
    # print(Num_pages5)
    WorkerID_Betrag914 = []
    Betrag914_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages21:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_914id2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Betrag914.append(line_items_914id2[0])
                        # print(line_items_Solidarityid2)
                    if BetragAVANGE.search(line):
                        line_items_AVANGE2 = line.split()
                        # print(line_items_AVANGE2)
                        Betrag914_Numpages.append('-' + line_items_AVANGE2[-1].replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Betrag901
    Num_pages21b = [tup[-1] for tup in Betrag901]
    # print(Num_pages5)
    WorkerID_Betrag901 = []
    Betrag901_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages21b:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_901id2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Betrag901.append(line_items_901id2[0])
                        # print(WorkerID_Betrag901)
                    if BetragAVAG.search(line):
                        line_items_AVAGE2 = line.split()
                        # print(line_items_AVAGE2)
                        Betrag901_Numpages.append(line_items_AVAGE2[-1].replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR SaturdayWork
    Num_pages22 = [tup[-1] for tup in SaturdayWork]
    # print(Num_pages5)
    WorkerID_SaturdayWork = []
    SaturdayWork_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages22:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Samstagid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_SaturdayWork.append(line_items_Samstagid2[0])
                        # print(line_items_Solidarityid2)
                    if WeekendSamstag.search(line):
                        line_items_Samstag2 = line.split()
                        # print(line_items_AVANGE2)
                        SaturdayWork_Numpages.append(line_items_Samstag2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR SundayWork
    Num_pages23 = [tup[-1] for tup in SundayWork]
    # print(Num_pages5)
    WorkerID_SundayWork = []
    SundayWork_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages23:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Sonntagid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_SundayWork.append(line_items_Sonntagid2[0])
                        # print(line_items_Solidarityid2)
                    if WeekendSonntag.search(line):
                        line_items_Sonntag2 = line.split()
                        # print(line_items_AVANGE2)
                        SundayWork_Numpages.append(line_items_Sonntag2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR WageS
    Num_pages24 = [tup[-1] for tup in WageTaxS]
    # print(Num_pages5)
    WorkerID_WageS = []
    WageS_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages24:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_WageSid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_WageS.append(line_items_WageSid2[0])
                        # print(line_items_Solidarityid2)
                    if WageS.search(line):
                        line_items_WageS2 = line.split()
                        # print(line_items_WageS2)
                        WageTaxS2 = line_items_WageS2[2]
                        WageTaxS2 = f"{WageTaxS2[:-2]},{WageTaxS2[-2:]}"
                        # print(line_items_WageS2)
                        WageS_Numpages.append(WageTaxS2.replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Salary_Correction (1.C)
    Num_pages300 = [tup[-1] for tup in CorrectionNSalaryList]
    # print(Num_pages5)
    WorkerID_NSalary = []
    NSalary_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages300:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_NSalaryid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_NSalary.append(line_items_NSalaryid2[0])
                        # print(line_items_NSalaryid2)
                    if CorrectionN.search(line):
                        line_items_NSalary2 = line.split()
                        # print(line_items_NSalary2)
                        if "001" in line_items_NSalary2:
                            NSalary2 = line_items_NSalary2[-1]
                            # NSalary2= f"{NSalary2[:-2]},{NSalary2[-2:]}"
                            # print(NSalary2)
                            NSalary_Numpages.append(NSalary2.replace('.', ''))
    ### TAKE ALL THE PAGE NUMBER FOR Wage_Correction
    Num_pages301 = [tup[-1] for tup in WageTaxN]
    # print(Num_pages301)
    WorkerID_WageN = []
    WageN_Numpages = []
    SolidarityN_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages301:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_WageNid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_WageN.append(line_items_WageNid2[0])
                        # print(line_items_Solidarityid2)
                    if CorrectionN.search(line):
                        lineitemsN2 = line.split()
                        if "001" not in lineitemsN2:
                            line_items_WageN = line.split()
                            # print(line_items_WageN)
                            if line_items_WageN[2] != line_items_WageN[1]:
                                WageTaxN1 = line_items_WageN[2]
                                WageTaxN1 = f"{WageTaxN1[:-2]},{WageTaxN1[-2:]}"
                                # WageTaxN1 = (WageTaxN1, num_page)
                                WageN_Numpages.append(WageTaxN1)
                                if len(line_items_WageN) > 4:
                                    SolidarityN1 = line_items_WageN[3]
                                    SolidarityN1 = f"{SolidarityN1[:-2]},{SolidarityN1[-2:]}"
                                    # SolidarityN1 = (SolidarityN1, num_page)
                                    SolidarityN_Numpages.append(SolidarityN1)
                            # print(WageTaxN1)

    ### TAKE ALL THE PAGE NUMBER FOR UI and Pi_Correction
    Num_pages303 = [tup[-1] for tup in UIContN]
    # print(Num_pages301)
    WorkerID_UIContN = []
    UIContN_Numpages = []
    PIContN_Numpages = []
    SocialDN_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages303:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_UIContNid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_UIContN.append(line_items_UIContNid2[0])
                    if CorrectionN.search(line):
                        lineitemsN2 = line.split()
                        if "001" not in lineitemsN2:
                            line_items_UIContN = line.split()
                            # print(line_items_WageN)

                            if len(line_items_UIContN) == 6 and (line_items_UIContN[2] == line_items_UIContN[1]):
                                # print(line_items_Wage)
                                SocialDN1 = line_items_WageN[-1].replace('-', '')
                                UI = line_items_UIContN[-2].replace('-', '')
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = UI.replace('.', '')

                                PI = line_items_UIContN[-3].replace('-', '')
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PI = PI.replace('.', '')

                                # UI = f"{UI[:-2]},{UI[-2:]}"

                                # AGPV = (line_items_ZuschussPV[-1].replace('-', '').replace('.', ''), num_page)
                                UIContN_Numpages.append(UI)
                                PIContN_Numpages.append(PI)
                                SocialDN_Numpages.append(SocialDN1)

    ### TAKE ALL THE PAGE NUMBER FOR Solidarity(S)
    Num_pages25 = [tup[-1] for tup in SolidarityS]
    # print(Num_pages5)
    WorkerID_SolidarityS = []
    SolidarityS_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages25:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_SolidaritySid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_SolidarityS.append(line_items_SolidaritySid2[0])
                        # print(line_items_Solidarityid2)
                    if WageS.search(line):
                        line_items_WageS2 = line.split()
                        # print(line_items_WageS2)
                        if len(line_items_WageS2) > 4:
                            SolidarityTaxS2 = line_items_WageS2[3]
                            SolidarityTaxS2 = f"{SolidarityTaxS2[:-2]},{SolidarityTaxS2[-2:]}"
                            # print(line_items_WageS2)
                            SolidarityS_Numpages.append(SolidarityTaxS2.replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR ChurchTax(S)
    Num_pages252 = [tup[-1] for tup in ChurchTaxS]
    # print(Num_pages5)
    WorkerID_ChurchTaxS = []
    ChurchTaxS_Numpages = []

    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages252:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_ChurchTaxSid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_ChurchTaxS.append(line_items_ChurchTaxSid2[0])
                        # print(line_items_Solidarityid2)
                    if WageS.search(line):
                        line_items_WageS2 = line.split()
                        # print(line_items_WageS2)
                        if len(line_items_WageS2) > 4:
                            ChurchTaxS2 = line_items_WageS2[3]
                            ChurchTaxS2 = f"{ChurchTaxS2[:-2]},{ChurchTaxS2[-2:]}"
                            # print(line_items_WageS2)
                            ChurchTaxS_Numpages.append(ChurchTaxS2.replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR 9079 Bereits erhalten
    Num_pages26 = [tup[-1] for tup in BereitsErhalten]
    # print(Num_pages5)
    WorkerID_Bereits = []
    Bereits_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages26:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Bereitsid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Bereits.append(line_items_Bereitsid2[0])
                        # print(line_items_Solidarityid2)
                    if Bereits.search(line):
                        line_items_Bereits2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Bereits_Numpages.append("-" + line_items_Bereits2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR 011 Prämie

    Num_pages27 = [tup[-1] for tup in CommissionList]
    WorkerID_Commission = []
    Commission_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages27:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_commissionid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Commission.append(line_items_commissionid2[0])
                        # print(line_items_Solidarityid2)
                    if Commission.search(line):
                        line_items_commission2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Commission_Numpages.append(line_items_commission2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR bav
    Num_pages28 = [tup[-1] for tup in Bav_list]
    # print(Num_pages)
    WorkerIDBav = []
    BavNumpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages28:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Bavid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDBav.append(line_items_Bavid2[0])
                        # print(line_items_Bonusid2)
                    if BAV_re.search(line):
                        line_items_Bav2 = line.split()
                        # print(line_items_HO2)
                        BavNumpages.append(line_items_Bav2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR bav_Abzug
    Num_pages2895 = [tup[-1] for tup in Bav_listAbzug]
    # print(Num_pages)
    WorkerIDBavAbz = []
    BavABZNumpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages2895:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_BAVAbzugid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDBavAbz.append(line_items_BAVAbzugid2[0])
                        # print(line_items_Bonusid2)
                    if Bav_Abzug.search(line):
                        line_items_BavAbz2 = line.split()
                        # print(line_items_HO2)
                        BavABZNumpages.append('-' + line_items_BavAbz2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR CorrectionSickPay
    Num_pages286 = [tup[-1] for tup in CorrectionSickPayList]
    # print(Num_pages5)
    WorkerID_CSP = []
    CSP_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages286:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_CSPid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_CSP.append(line_items_CSPid2[0])
                        # print(line_items_Solidarityid2)
                    if CorrectionSickPay.search(line):
                        line_items_CSP2 = line.split()
                        # DV2=line_items_DV2[-1]
                        CSP_Numpages.append('-' + line_items_CSP2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR CorrectionCI
    Num_pages287 = [tup[-1] for tup in CorrectionCIlist]
    # print(Num_pages5)
    WorkerID_CCI = []
    CCI_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages287:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_CCIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_CCI.append(line_items_CSPid2[0])
                        # print(line_items_Solidarityid2)
                    if CorrectionCI.search(line):
                        line_items_CCI2 = line.split()
                        # DV2=line_items_DV2[-1]
                        CCI_Numpages.append('-' + line_items_CCI2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR CorrectionCI
    Num_pages288 = [tup[-1] for tup in CorrectionHIlist]
    # print(Num_pages5)
    WorkerID_CHI = []
    CHI_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages288:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_CHIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_CHI.append(line_items_CSPid2[0])
                        # print(line_items_Solidarityid2)
                    if CorrectionHI.search(line):
                        line_items_CHI2 = line.split()
                        # DV2=line_items_DV2[-1]
                        CHI_Numpages.append('-' + line_items_CHI2[-1].replace('.', '').replace('-', ''))

    ## TAKE ALL THE PAGE NUMBER FOR UnterstutzungList
    Num_pages29 = [tup[-1] for tup in UnterstutzungLIST]
    # print(Num_pages5)
    WorkerID_Unterstutzung = []
    Unterstutzung_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages29:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_UnterStutzungid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Unterstutzung.append(line_items_UnterStutzungid2[0])
                        # print(line_items_Solidarityid2)
                    if Unterstutzung.search(line):
                        line_items_Unterstutzung2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Unterstutzung_Numpages.append(
                            '-' + line_items_Unterstutzung2[-1].replace('.', '').replace('-', ''))

    ## TAKE ALL THE PAGE NUMBER FOR SonderzahlungList
    Num_pages30 = [tup[-1] for tup in SonderzahlunglIST]
    # print(Num_pages5)
    WorkerID_Sonderzahlung = []
    Sonderzahlung_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages30:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Sonderzahlungid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Sonderzahlung.append(line_items_Sonderzahlungid2[0])
                        # print(line_items_Solidarityid2)
                    if Sonderzahlung.search(line):
                        line_items_Sonderzahlung2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Sonderzahlung_Numpages.append(
                            '-' + line_items_Sonderzahlung2[-1].replace('.', '').replace('-', ''))

    ## TAKE ALL THE PAGE NUMBER FOR FraiwilligZuschlageList
    Num_pages31 = [tup[-1] for tup in FZList]
    # print(Num_pages5)
    WorkerID_FZ = []
    FZ_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages31:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_FZid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_FZ.append(line_items_FZid2[0])
                        # print(line_items_Solidarityid2)
                    if FreiwilligeZuschlage.search(line):
                        line_items_FZ2 = line.split()
                        # DV2=line_items_DV2[-1]
                        FZ_Numpages.append('-' + line_items_FZ2[-1].replace('.', '').replace('-', ''))

    ## TAKE ALL THE PAGE NUMBER FOR FraiwilligZuschlageList
    Num_pages32 = [tup[-1] for tup in FromCorrection]
    # print(Num_pages5)
    WorkerID_FromCorrection = []
    FC_Numpages = []
    with pdfplumber.open(our_files) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages32:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_FCid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_FromCorrection.append(line_items_FCid2[0])
                        # print(line_items_Solidarityid2)
                    if Correction.search(line):
                        line_items_FC2 = line.split()
                        # DV2=line_items_DV2[-1]
                        FC_Numpages.append('-' + line_items_FC2[-1].replace('.', '').replace('-', ''))
    ########################TAKE ALL THE PAGE NUMBER FOR COMMISSION################################

    df = pd.DataFrame(columns=["Company", "Period", "Worker ID", "Worker Name", "Contr. Group", "Base Salary",
                               "Base Salary_Correction",
                               "Commission", "Home_Office", "Überstdgrundvergütung", "Weekend Work Saturday",
                               "Weekend Work Sunday",
                               "Betr.AV.AG_lfd.ST-frei", "Betr.AV.AN lfd.ST-frei", "Betr.AV.AN lfd.Geh.Ver",
                               'bAV AG-Zus. lfd.ST-frei',
                               'Freiwillige Zulage', 'Unterstützungskasse', 'Sonderzahlung',
                               "Privatfahrten/priv. use", "Bonus lfd.", "Bonus EBZ", "Residence Allowance",
                               "Residence Allowance Net",
                               "Private household insurance", "Private liability insurance",
                               "Total Gross Pay", "Total Gross Pay_Correction",
                               "Church Tax", "Church Tax_Correction",
                               "Solidarity Surcharge", "Solidarity Surcharge_Correction",
                               "EE-Wage tax", "EE-Wage tax_Correction",
                               "CI Contribution", "CI Contribution_Correction",
                               "HI Contribution", "HI Contribution_Correction",
                               "PI Contribution", "PI Contribution_Correction",
                               "UI Contribution", "UI Contribution_Correction",
                               "Social Security Deductions", "Social Security Deductions_Correction",
                               "car benefit/KFZ- Sachb.", "Bereits erhalten", "AG-Zuschuss_zur_PV",
                               "AG-Zuschuss_zur_KV",
                               "Gesamtbeitrag_zur_PV",
                               "Gesamtbeitrag_zur_KV", "bAV-Abzug", 'Correction Sick Pay', 'Correction CI-ER',
                               'Correction HI-ER',
                               'Direktversicherung', "Private Savings", "ER-Unemployment",
                               "Emp.Soc.Sec",
                               "ER Cost. Add", "ER Total Cost", "From Correction",
                               "Total Net Pay"])

    df["Company"] = pd.Series(Company, dtype=object)
    df["Worker ID"] = pd.Series(MitarbeiterID, dtype=object)
    # df["From Correction"]=pd.Series(FromCorrection, dtype=object)

    # Uberstd EQUALIZER
    finallistuberstd = list(zip(WorkerIDuberstd, UberstdNumpages))
    # print(finallistuberstd)
    # print(UberstdNumpages)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistuberstd:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Überstdgrundvergütung'] = tup[1]

    # Saturday EQUALIZER
    finallistSaturdayWork = list(zip(WorkerID_SaturdayWork, SaturdayWork_Numpages))
    # print(finallistuberstd)
    # print(UberstdNumpages)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSaturdayWork:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Weekend Work Saturday'] = tup[1]

    # Sunday EQUALIZER
    finallistSundayWork = list(zip(WorkerID_SundayWork, SundayWork_Numpages))
    # print(finallistuberstd)
    # print(UberstdNumpages)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSundayWork:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Weekend Work Sunday'] = tup[1]

    # HOMEOFFICE EQUALIZER
    finallistHO = list(zip(WorkerIDHomeOffice, HomeOfficeNumpages))

    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistHO:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Home_Office'] = tup[1]

    # Bonus Equalizer
    finallistBonus = list(zip(WorkerIDBonus, BonusNumpages))

    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBonus:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Bonus lfd.'] = tup[1]

    # BonusEBZ Equalizer
    finallistBonusEBZ = list(zip(WorkerIDBonusEBZ, BonusEBZNumpages))

    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBonusEBZ:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Bonus EBZ'] = tup[1]

    # PLI Equalizer
    finallistPLI = list(zip(WorkerIDPLI, PLINumpages))

    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistPLI:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Private liability insurance'] = tup[1]

    # PHI Equalizer
    finallistPHI = list(zip(WorkerIDPHI, PHINumpages))
    # print(finallistPHI)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistPHI:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Private household insurance'] = tup[1]

    # RA Equalizer be
    finallistRA = list(zip(WorkerIDRA, RANumpages))
    # print(finallistRA)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistRA:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Residence Allowance'] = tup[1]

    # RANet Equalizer
    finallistRANet = list(zip(WorkerIDRANet, RANumpagesNet))
    # print(finallistRA)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistRANet:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Residence Allowance Net'] = tup[1]

    # Church Equalizer
    finallistChurch = list(zip(WorkerID_Church, Church_Numpages))
    # print(finallistChurch)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistChurch:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Church Tax'] = tup[1]

    # Solidarity Surcharge Equalizer
    finallistSS = list(zip(WorkerID_Solidarity, Solidarity_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSS:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Solidarity Surcharge'] = tup[1]

    # WageS Equalizer
    finallistWageS = list(zip(WorkerID_WageS, WageS_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistWageS:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'EE-Wage tax (S)'] = tup[1]

    # SolidarityS Equalizer
    finallistSolidarityS = list(zip(WorkerID_SolidarityS, SolidarityS_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSolidarityS:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Solidarity Surcharge (S)'] = tup[1]

    # BaseSalaryS Equalizer
    finallistNSalary = list(zip(WorkerID_NSalary, NSalary_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistNSalary:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Base Salary_Correction'] = tup[1]

    # WageN Equalizer
    finallistWageN = list(zip(WorkerID_WageN, WageN_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistWageN:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'EE-Wage tax_Correction'] = tup[1]

    # SolidarityN Equalizer
    finallistSolidarityN = list(zip(WorkerID_WageN, SolidarityN_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSolidarityN:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Solidarity Surcharge_Correction'] = tup[1]

    # UIContN Equalizer
    finallistUIContN = list(zip(WorkerID_UIContN, UIContN_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistUIContN:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'UI Contribution_Correction'] = tup[1]

    # PIContN Equalizer
    finallistPIContN = list(zip(WorkerID_UIContN, PIContN_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistPIContN:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'PI Contribution_Correction'] = tup[1]

    # SocialDN Equalizer
    finallistSocialDN = list(zip(WorkerID_UIContN, SocialDN_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSocialDN:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Social Security Deductions_Correction'] = tup[1]

    # ChurchTaxS Equalizer
    finallistChurchTaxS = list(zip(WorkerID_ChurchTaxS, ChurchTaxS_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistChurchTaxS:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Church Tax(S)'] = tup[1]

    # DirektV Equalizer
    finallistDV = list(zip(WorkerID_DV, DV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistDV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Direktversicherung'] = tup[1]

    # Basesalary.append('')

    # AGPV Equalizer
    finallistAGPV = list(zip(WorkerID_AGZuschussPV, AGZuschussPV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistAGPV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'AG-Zuschuss_zur_PV'] = tup[1]

    # AGPV Equalizer
    finallistBereits = list(zip(WorkerID_Bereits, Bereits_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBereits:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Bereits erhalten'] = tup[1]

    # Commission Equalizer
    finallistCommission = list(zip(WorkerID_Commission, Commission_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistCommission:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Commission'] = tup[1]

    # AGKV Equalizer
    finallistAGKV = list(zip(WorkerID_AGZuschussKV, AGZuschussKV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistAGKV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'AG-Zuschuss_zur_KV'] = tup[1]

    # FZ Equalizer
    finallistFZ = list(zip(WorkerID_FZ, FZ_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistFZ:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Freiwillige Zulage'] = tup[1]

    # SZ Equalizer
    finallistSZ = list(zip(WorkerID_Sonderzahlung, Sonderzahlung_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSZ:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Sonderzahlung'] = tup[1]

    # Unterstutzung Equalizer
    finallistUstutzung = list(zip(WorkerID_Unterstutzung, Unterstutzung_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistUstutzung:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Unterstützungskasse'] = tup[1]

    # GBKV Equalizer
    finallistGBKV = list(zip(WorkerID_GBKV, GBKV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistGBKV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Gesamtbeitrag_zur_KV'] = tup[1]

    # GBKV Equalizer
    finallistGBPV = list(zip(WorkerID_GBPV, GBPV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistGBPV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Gesamtbeitrag_zur_PV'] = tup[1]

    # Betrag911 Equalizer
    finallistBetrag911 = list(zip(WorkerID_Betrag911, Betrag911_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBetrag911:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Betr.AV.AN lfd.ST-frei'] = tup[1]

    # Betrag914 Equalizer
    finallistBetrag914 = list(zip(WorkerID_Betrag914, Betrag914_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBetrag914:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Betr.AV.AN lfd.Geh.Ver'] = tup[1]

    # Betrag901 Equalizer
    finallistBetrag901 = list(zip(WorkerID_Betrag901, Betrag901_Numpages))
    # print(finallistBetrag901)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBetrag901:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Betr.AV.AG_lfd.ST-frei'] = tup[1]

    # Car Equalizer
    finallistCarBenefit = list(zip(WorkerID_CarBenefit, CarBenefit_Numpages))
    finallistCarBenefitMinus = list(zip(WorkerID_CarBenefit, CarBenefitMinus_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistCarBenefit:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Privatfahrten/priv. use'] = tup[1]

    # CSP EQUALIZER
    finallistCSP = list(zip(WorkerID_CSP, CSP_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistCSP:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Correction Sick Pay'] = tup[1]

    # CSP EQUALIZER
    finallistCCI = list(zip(WorkerID_CCI, CCI_Numpages))
    for index, row in df.iterrows():
        for tup in finallistCCI:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Correction CI-ER'] = tup[1]

    finallistCHI = list(zip(WorkerID_CHI, CHI_Numpages))
    for index, row in df.iterrows():
        for tup in finallistCHI:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Correction HI-ER'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistCarBenefitMinus:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'car benefit/KFZ- Sachb.'] = tup[1]

    # UICont,PICont Equalizer
    finallistUICont = list(zip(WorkerID_UICont, UICont_Numpages))
    finallistPICont = list(zip(WorkerID_PICont, PICont_Numpages))
    finallistHICont = list(zip(WorkerID_HICont, HICont_Numpages))
    finallistCICont = list(zip(WorkerID_CICont, CICont_Numpages))

    # UICont,PICont Equalizer for E
    finallistUIContE = list(zip(WorkerID_UIContE, UIContE_Numpages))
    finallistPIContE = list(zip(WorkerID_PIContE, PIContE_Numpages))
    finallistHIContE = list(zip(WorkerID_HIContE, HIContE_Numpages))
    finallistCIContE = list(zip(WorkerID_CIContE, CIContE_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistUICont:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'UI Contribution'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistUIContE:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'UI Contribution(E)'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistUIContE:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'UI Contribution(E)'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistPICont:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'PI Contribution'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistPIContE:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'PI Contribution(E)'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistHICont:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'HI Contribution'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistHIContE:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'HI Contribution(E)'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistCICont:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'CI Contribution'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistCIContE:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'CI Contribution(E)'] = tup[1]

    finallistBAV = list(zip(WorkerIDBav, BavNumpages))
    for index, row in df.iterrows():
        for tup in finallistBAV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'bAV AG-Zus. lfd.ST-frei'] = tup[1]

    finallistBAVABZ = list(zip(WorkerIDBavAbz, BavABZNumpages))
    for index, row in df.iterrows():
        for tup in finallistBAVABZ:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'bAV-Abzug'] = tup[1]

    finallistFC = list(zip(WorkerID_FromCorrection, FC_Numpages))
    for index, row in df.iterrows():
        for tup in finallistFC:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'From Correction'] = tup[1]

    df["Period"] = pd.Series(Date, dtype=object)
    df["Worker Name"] = pd.Series(Employee, dtype=object)
    # df["Personal_BNr"] = pd.Series(PersonalBetriebNr, dtype=object)
    df['Base Salary'] = pd.Series(Basesalary, dtype=object)
    df["Total Gross Pay"] = pd.Series(TotalGrossIncome, dtype=object)
    # df["Commission"] = pd.Series(CommissionList, dtype=object)
    df["EE-Wage tax"] = pd.Series(WageTax, dtype=object)
    df["Total Net Pay"] = pd.Series(Netpay, dtype=object)
    # df["Betr.AV.AG_lfd.ST-frei"] = pd.Series(Betrag901, dtype=object)
    df["Social Security Deductions"] = pd.Series(SocialD, dtype=object)
    df["Contr. Group"] = pd.Series(Cont, dtype=object)
    df["Emp.Soc.Sec"] = pd.Series(EmpSocSec, dtype=object)
    df["ER Cost. Add"] = pd.Series(Emp, dtype=object)
    df["ER Total Cost"] = pd.Series(AGsocial, dtype=object)  # Jai remplacé parce que cest la meme
    df["Worker ID"] = pd.Series(PersonalBetriebNr, dtype=object)
    #####################################ESSAI POUR DICTIONNAIRE######################################################
    dfempty = pd.DataFrame([[np.nan] * len(df.columns)], columns=df.columns)  # emptycolumn

    df2 = {
        "Company": '',
        "Period": '',
        "Worker ID": '',
        "Worker Name": 'TOTAL',
        "Worker Cost Center": '',
        "Car allowance": '',
        "Expense reimbursement": '',
        "Private Nurse Insurance": '',
        "Total Gross Pay": totalTGI,
        "EE-Unemployment": '',
        "EE-Social Security": '',
        "EE-Wage tax": totalWage,
        "Phone Reimbursement": '',
        "EE-Private Savings": '',
        "Total Net Pay": totalNet,
        "ER-Unemployment": '',
        "ER-Social Security": '',
        "Social Security": '',
        "Private Nurse Insurance": '',
        "Private Savings": '',
        "Total ER Contributions": '',
        "Total ER Cost": ''
    }

    # print(Uberstunde)
    # print(CommissionList)
    # Remove duplicates based on a specific column

    # print(df.head(5))
    # print(df.to_markdown())

    # Créer un nouveau classeur Excel
    wb = Workbook()
    ws = wb.active

    # Ajouter l'en-tête du DataFrame à la feuille Excel
    header_row = df.columns.tolist()
    ws.append(header_row)

    # Ajouter les données du DataFrame à la feuille Excel
    for row in dataframe_to_rows(df, index=False, header=False):
        ws.append(row)

    # Appliquer un formatage numérique explicite (pour gérer les virgules décimales)
    for row in ws.iter_rows(min_row=2, min_col=2, max_col=2):  # Colonne des montants
        for cell in row:
            if isinstance(cell.value, (int, float)):
                cell.number_format = "#,##0.00"  # Format numérique

    # Ajouter un style à la ligne d'en-tête
    for cell in ws[1]:
        cell.font = Font(underline='single', bold=True)
        cell.fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")

    # Ajuster la largeur des colonnes
    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            if cell.value:
                max_length = max(max_length, len(str(cell.value)))
        adjusted_width = (max_length + 2) * 1.2
        ws.column_dimensions[column_letter].width = adjusted_width

    # Enregistrer le fichier Excel
    # wb.save('C:/Users/PK.MbeleSamba/Desktop/G2N_report_Landa_09.xlsx')# Créer un nouveau classeur Excel
    wb = Workbook()
    ws = wb.active

    # Ajouter l'en-tête du DataFrame à la feuille Excel
    header_row = df.columns.tolist()
    ws.append(header_row)

    # Ajouter les données du DataFrame à la feuille Excel
    # Pas de manipulation explicite des nombres ici
    for row in dataframe_to_rows(df, index=False, header=False):
        ws.append(row)

    # Appliquer un style à la ligne d'en-tête
    for cell in ws[1]:
        cell.font = Font(underline='single', bold=True)
        cell.fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")

    # Ajuster la largeur des colonnes
    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            if cell.value:
                max_length = max(max_length, len(str(cell.value)))
        adjusted_width = (max_length + 2) * 1.2
        ws.column_dimensions[column_letter].width = adjusted_width
    # Insérer les valeurs en s'assurant qu'elles sont bien en nombre

    # df = df.apply(lambda col: pd.to_numeric(col.str.replace(',', '.'), errors='ignore') if col.dtype=='str' and col.str.contains(',').any() else col)
    # Récupérer la première ligne (les en-têtes)
    # Récupérer la première ligne (les en-têtes)
    header = [cell.value for cell in ws[1]]

    # Déterminer l'indice (1-based) de la colonne "Base Salary"
    try:
        start_col = header.index("Base Salary") + 1
    except ValueError:
        print("La colonne 'Base Salary' n'a pas été trouvée dans l'en-tête.")
        start_col = None

    if start_col is not None:
        # Parcourir toutes les lignes à partir de la 2ème ligne (en-tête exclu)
        for row in ws.iter_rows(min_row=2):
            for col in range(start_col, ws.max_column + 1):
                cell = row[col - 1]  # L'indexation Python commence à 0

                # Si la cellule contient une chaîne (donc pas encore convertie en nombre)
                if cell.value is not None and isinstance(cell.value, str):
                    # Nettoyer la valeur : supprimer les espaces et remplacer la virgule par un point
                    valeur_str = cell.value.strip().replace(" ", "").replace(",", ".")
                    try:
                        # Convertir en float
                        cell.value = float(valeur_str)
                    except ValueError:
                        print(f"Conversion impossible pour la cellule {cell.coordinate} avec la valeur '{cell.value}'")

        # Appliquer le format numérique aux cellules déjà en nombre
        for row in ws.iter_rows(min_row=2):
            for col in range(start_col, ws.max_column + 1):
                cell = row[col - 1]

                # Vérifier si la cellule est un nombre valide
                if isinstance(cell.value, (int, float)) and not math.isnan(cell.value):
                    # Ne pas convertir en texte, juste appliquer un format d'affichage
                    cell.number_format = "0.00"

                # Facultatif : vous pouvez forcer le type texte en ajoutant une apostrophe (mais cela affichera l'apostrophe dans certaines configurations)
            # cell.value = "'" + format(cell.value, '.2f')

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path(
        user_id=user_id,
        data_conversion="Papaya",
        conversion="Hartree",
        task_id=task.request.id,
        extension="xlsx",
    )

    ensure_output_folder(output_path)

    wb.save(output_path)

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Papaya",
    conversion="UBC",
    description="Papaya UBC conversion",
    input_type={
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["pdf"],
            },
        ),
    },
    output_type="xlsx",
)

def papaya_ubc(task, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file = files[0]

    ################################ REGULARY EXPRESSION FOR ALL THE RESEARCH IN THE PDF FILES ########################################################

    name = re.compile(
        r'(?P<first_name>[A-ZÄÖÜ][a-zäöüß]+)\s(?P<last_name>[A-ZÄÖÜ][a-zäöüß-]+(?:\s(?:von|von der|van der))?)(?:\s(?P<suffix>(?<=\s)[JS]r\.|I{1,3}))?')  # Regular expressiob for all name

    Companyname = re.compile(r'GmbH')  # Regular expression for company name

    Base_Salary = re.compile(
        r'200\sSalary/Gehalt|Gehalt/Salary|100\sStundenlohn|102\sGehalt')  # Regular expression for gehalt

    TGI = re.compile(r'Tax/Social')  # Regular expression for social

    Net = re.compile(r'Acc.no')  # Regular expression for net pay

    BAV_re = re.compile(r"891 bAV AG-Zus. lfd.ST-frei")

    # NetIncome=re.compile(r'^Statement of earnings')

    Wage = re.compile(r'(^L|^N\s1.)')  # Regular expression for Wage Tax and Tax Deduction
    WageS = re.compile(r'^S\s\d')
    WageE = re.compile(r'^E\s\d')

    Car = re.compile(r'Privatfahrten/priv. use')  #

    CarAllowance = re.compile(r'^201 Car Allowance')

    Commission = re.compile(r'^011\sPrämie')

    Period = re.compile(r'^Pay Advice')

    ID = re.compile(r'^000')

    Uberstd = re.compile('Überstdgrundvergütung')
    Uberstd2 = re.compile('^N\s002')
    WeekendSamstag = re.compile('090 weekend work 150% Satu.')
    WeekendSonntag = re.compile('092 weekend work 150% Sund. ')

    BetragAVAG = re.compile(r'901 Betr.AV.AG lfd.ST-frei')
    BetragAVANST = re.compile(r'911 Betr.AV.AN lfd.ST-frei')
    BetragAVANGE = re.compile('914 Betr.AV.AN lfd.Geh.Ver ')

    PV = re.compile(r'AG-Zuschuss zur PV')

    KV = re.compile(r'AG-Zuschuss zur KV')

    GBzurPV = re.compile(r'Gesamtbeitrag zur PV')

    GBzurKV = re.compile(r'Gesamtbeitrag zur KV')

    HO = re.compile(r'Home Office')

    Contrgroup = re.compile(r'^\d{8}\w\d{3}')
    PersonalBetrieb = re.compile(r'^\*\s\d{6}\*')
    # Kirche=re.compile(r'Home Office')
    HIincome = re.compile(r'^Tax. ')

    CI24 = re.compile('^Solidarity surcharge')

    PIline = re.compile('^Wage tax')

    UIline = re.compile('^Church tax')

    Bonuslfd = re.compile('Bonus lfd.')
    BonusEBZ = re.compile('009 Bonus EBZ')

    RAllowance = re.compile('Residence Allowance')
    RAllowanceNet = re.compile('119\sResidence Allowance net')

    PrivateLI = re.compile('priv. liability insura. ')

    PrivateHI = re.compile('priv. household insura. ')

    Direkt = re.compile('Direktversicherung')

    AGzuschussPV0 = re.compile('9983 AG-Zuschuss zur PV')

    AGzuschussKV0 = re.compile('9995 AG-Zuschuss zur KV')

    Bereits = re.compile('9079 bereits erhalten')

    lineitemsw = re.compile('^Tx')

    Correction = re.compile('From correction')

    CorrectionN = re.compile('^N\s')

    CorrectionSickPay = re.compile('300 Correction 05-Sick Pay')

    CorrectionCI = re.compile(' 9091 Corr. CI-ER May ')

    CorrectionHI = re.compile(' 9090 Corr. HI-ER May')

    FreiwilligeZuschlage = re.compile('Freiwillige Zulage')

    Sonderzahlung = re.compile(' Sonderzahlung zusätzl.')

    Unterstutzung = re.compile('Unterstützungskasse')

    Bav_Abzug = re.compile('bAV-Abzug')

    #######################################FUNCTION###############################################

    def extract_UI(line_items, indicators):
        for ind in indicators:
            if ind in line_items:
                idx = line_items.index(ind)
                if idx > 0:
                    value = line_items[idx - 1]
                    value = f"{value[:-2]},{value[-2:]}"
                    return value.replace('.', '')
        return None

    def extract_value_before(line_items, indicators, offset):
        for ind in indicators:
            if ind in line_items:
                idx = line_items.index(ind)
                if idx >= offset:
                    return line_items[idx - offset]
        return None

    def extract_value_after(line_items, indicators, offset=1):
        for ind in indicators:
            if ind in line_items:
                idx = line_items.index(ind)
                if idx + offset < len(line_items):
                    return line_items[idx + offset]
        return None

    ################################  DECLARATION OF ALL THE LIST ###################################################################

    Company = []
    Employee = []
    Basesalary = []
    Basesalary2 = []  # Pour le total
    TotalGrossIncome = []
    MitarbeiterID = []
    Netpay = []
    WageTax = []
    WageTaxN = []
    WageTaxS = []
    WageTaxE = []
    CarBenefit = []
    CarBenefitMinus = []
    CommissionList = []
    Date = []

    Uberstunde = []
    SaturdayWork = []
    SundayWork = []

    PersonalBetriebNr = []

    Betrag901 = []
    Betrag911 = []
    Betrag914 = []
    AGZuschussKV = []
    AGZuschussPV = []
    BereitsErhalten = []
    GBKV = []
    GBPV = []
    Homeoffice = []
    ChurchTax = []
    ChurchTaxN = []
    ChurchTaxS = []
    Solidarity = []
    SolidarityN = []
    SolidarityS = []
    SocialD = []
    SocialDN = []
    AGsocial = []
    CIcont = []
    CIcontN = []
    PICont = []
    PIContN = []
    UICont = []
    UIContN = []
    HICont = []
    HIContN = []
    CIcontE = []
    PIContE = []
    UIContE = []
    HIContE = []
    EmpSocSec = []
    Bav_list = []
    Bav_listAbzug = []
    Cont = []
    ERTotalCost = []
    Emp = []
    Bonus = []
    BonusEBZlist = []
    Resid = []
    ResidNet = []
    PLI = []
    PHI = []
    DV = []
    linewage = []
    linetitlewage = []
    FromCorrection = []
    CorrectionSickPayList = []
    CorrectionNSalaryList = []
    CorrectionHIlist = []
    CorrectionNHIlist = []
    CorrectionNCIlist = []
    CorrectionCIlist = []
    FZList = []
    SonderzahlunglIST = []
    UnterstutzungLIST = []

    #############################################  RESEARCH START AND INCORPORATION OF ALL AMOUNT AND NAME IN LIST   ####################################

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            # Récupération du contenu de la page
            text = page.extract_text()

            for line in text.split('\n'):
                if CorrectionN.search(line):
                    # Si oui → on garde uniquement les lignes qui commencent par "N"
                    lineitemsN = line.split()
                    if "001" in lineitemsN:
                        CSalaryAmount = (lineitemsN[-1].replace('-', ''), num_page)
                        CorrectionNSalaryList.append(CSalaryAmount)
                    else:
                        line_items_WageN = line.split()
                        if line_items_WageN[0] == 'N' and \
                                (line_items_WageN[2] != line_items_WageN[1]):
                            WageTaxN1 = lineitemsN[2]
                            WageTaxN1 = f"{WageTaxN1[:-2]},{WageTaxN1[-2:]}"
                            WageTaxN1 = (WageTaxN1, num_page)
                            WageTaxN.append(WageTaxN1)

                            # print(WageTaxN1)

                            if len(line_items_WageN) > 4:
                                SolidarityN1 = line_items_WageN[3]
                                SolidarityN1 = f"{SolidarityN1[:-2]},{SolidarityN1[-2:]}"
                                SolidarityN1 = (SolidarityN1, num_page)
                                SolidarityN.append(SolidarityN1)
                                # print(SolidarityS2)
                        else:
                            if (line_items_WageN[2] == line_items_WageN[1]):
                                # print(line_items_Wage)
                                SocialDN1 = (line_items_WageN[-1].replace('-', ''), num_page)
                                SocialDN.append(SocialDN1)
                                UI = line_items_WageN[-2].replace('-', '')
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = (UI.replace('.', ''), num_page)

                                PI = line_items_WageN[-3].replace('-', '')
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PI = (PI.replace('.', ''), num_page)

                                # UI = f"{UI[:-2]},{UI[-2:]}"

                                # AGPV = (line_items_ZuschussPV[-1].replace('-', '').replace('.', ''), num_page)
                                UIContN.append(UI)
                                PIContN.append(PI)

                                # print(lineitemsN)

                        # print(lineitemsN)
            if text and "(1.C)" in text:
                continue  # Ignore la page et passe à la suivante
            elif text and "(2.C)" in text:
                continue

            lang = langid.classify(text)[0]

            # print(text)
            for line in text.split('\n'):
                if lang == 'en':

                    if name.search(line):

                        # elif not Car.search(line):
                        # CarBenefit.append('')
                        line_items_name = line.split()
                        if len(line_items_name) <= 3 and "Straße" not in line_items_name \
                                and "Weg" not in line_items_name \
                                and "Security" not in line_items_name \
                                and "Sozialversicherungspflichtiges" not in line_items_name \
                                and "Verdienstbescheinigung" not in line_items_name \
                                and "Pfändung" not in line_items_name \
                                and "Darlehen" not in line_items_name \
                                and "Commerzbank" not in line_items_name \
                                and "Landstr." not in line_items_name \
                                and "Str." not in line_items_name \
                                and "Str" not in line_items_name \
                                and "Stephansweg" not in line_items_name \
                                and "Ufer" not in line_items_name \
                                and "Damm" not in line_items_name \
                                and "Bad" not in line_items_name \
                                and 'Csepella,' not in line_items_name:
                            filtered_list = [item for item in line_items_name if
                                             not item[-1].replace(',', '').replace('.', '').isdigit()]
                            Mitarbeiter = ' '.join(filtered_list)
                            Employee.append(Mitarbeiter)
                            # print(Mitarbeiter)
                        # Employee.append(Mitarbeiter)
                        # print(Mitarbeiter)
                    if PersonalBetrieb.search(line):
                        line_items_PBNr = line.split()
                        # print(line_items_PBNr)
                        PersonalBetriebNr.append(line_items_PBNr[1].replace('*', ''))
                    if Companyname.search(line):
                        line_items_company = line.split()
                        company_info = line_items_company[0]
                        name_part = company_info.split('GmbH')[0]
                        spaced_name = ' '.join(re.findall(r'[A-Z][a-z]+|\([^)]+\)', name_part))
                        company_name = spaced_name + ' GmbH'
                        Company.append(company_name)
                        # print(company_name)

                    if Base_Salary.search(line):
                        line_items_base = line.split()

                        BaseS2 = (line_items_base[-1].replace('.', '').replace('-', ''))
                        Basesalary.append(BaseS2)
                        # print(line_items_base)

                    if TGI.search(line):
                        line_items_tgi = line.split()
                        TotalGrossIncome.append(line_items_tgi[-1].replace('.', ''))
                        # print(line_items_tgi)
                        # print(line_items_base)
                    if Net.search(line):
                        line_items_net = line.split()
                        # print(line_items_net)
                        if "pay" and "advice." not in line_items_net:
                            # del line_items_net

                            if len(line_items_net[-2]) > 3:
                                AG = line_items_net[-2].replace('.', '').replace('-', '')
                                AG = f"{AG[:-2]},{AG[-2:]}"
                                AGsocial.append(AG)

                                ERTotalCost.append(line_items_net[-2].replace('.', '').replace('-', ''))
                                EmpSoc = line_items_net[-3].replace('.', '').replace('-', '')
                                EmpSoc = f"{EmpSoc[:-2]},{EmpSoc[-2:]}"
                                Emp.append(EmpSoc)

                                EmpSocSec2 = line_items_net[-4].replace('.', '').replace('-', '')

                                EmpSocSec2 = f"{EmpSocSec2[:-2]},{EmpSocSec2[-2:]}"
                                if len(line_items_net[-4]) == 2:
                                    EmpSocSec2 = '0,00'
                                    # EmpSocSec.append(EmpSocSec2)
                                # print(EmpSocSec2)
                                EmpSocSec.append(EmpSocSec2)
                            # elif line_items_net[-4] =='06':
                            # EmpSocSec.append('0,00')

                            else:
                                AGsocial.append('')

                            # AGsocial.append(line_items_net[-2].replace('.','').replace('-',''))
                            # print(line_items_net)
                            Netpay.append(line_items_net[-1].replace('.', '').replace('-', ''))

                    if Correction.search(line):
                        line_items_correction = line.split()
                        # print(line_items_net)

                        Correction2 = (line_items_correction[-1].replace('.', '').replace('-', ''), num_page)
                        # print(Correction2)
                        FromCorrection.append(Correction2)
                        # print(FromCorrection)

                    if WageS.search(line):
                        line_items_WageS = line.split()
                        WageTaxS2 = line_items_WageS[2]
                        WageTaxS2 = f"{WageTaxS2[:-2]},{WageTaxS2[-2:]}"
                        WageTaxS2 = (WageTaxS2, num_page)
                        WageTaxS.append(WageTaxS2)
                        # print(WageTaxS)

                        if len(line_items_WageS) > 4:
                            SolidarityS2 = line_items_WageS[3]
                            # print(SolidarityS2)

                            if int(SolidarityS2) < 10000:
                                ChurchTaxS2 = SolidarityS2
                                ChurchTaxS2 = (ChurchTaxS2, num_page)
                                ChurchTaxS.append(ChurchTaxS2)
                            else:
                                SolidarityS2 = f"{SolidarityS2[:-2]},{SolidarityS2[-2:]}"
                                SolidarityS2 = (SolidarityS2, num_page)
                                SolidarityS.append(SolidarityS2)

                    if WageE.search(line):
                        line_items_WageE = line.split()
                        WageTaxE2 = line_items_WageE[2]
                        WageTaxE2 = f"{WageTaxE2[:-2]},{WageTaxE2[-2:]}"
                        WageTaxE2 = (WageTaxE2, num_page)
                        WageTaxE.append(WageTaxE2)
                        # print(line_items_WageE)
                        UIE = line_items_WageE[-3]
                        UIE = f"{UIE[:-2]},{UIE[-2:]}"
                        UIE = (UIE.replace('.', ''), num_page)

                        PIE = line_items_WageE[-4]
                        PIE = f"{PIE[:-2]},{PIE[-2:]}"
                        PIE = (PIE.replace('.', ''), num_page)

                        HIE = line_items_WageE[-5]
                        HIE = f"{HIE[:-2]},{HIE[-2:]}"
                        HIE = (HIE.replace('.', ''), num_page)

                        CIE = line_items_WageE[-2]
                        CIE = f"{CIE[:-2]},{CIE[-2:]}"
                        CIE = (CIE.replace('.', ''), num_page)

                        UIContE.append(UIE)
                        PIContE.append(PIE)
                        HIContE.append(HIE)
                        CIcontE.append(CIE)

                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # print(line_items_Wage)

                        # print(line_items_Wage)
                        if line_items_Wage[
                            0] == 'L' and '773,80' not in line_items_Wage and 'Z' not in line_items_Wage:  # FAIRE EN SORTE DAVOIR LES HI COMTRIBUTIONS
                            # print(line_items_Wage)

                            if len(line_items_Wage) > 2 and line_items_Wage[2] != line_items_Wage[1] and \
                                    line_items_Wage[3] != line_items_Wage[2]:
                                # print(line_items_Wage)
                                Wage2 = line_items_Wage[2]

                                # print(Sol2)
                                # Format with one comma before the last two numbers
                                Wage2 = f"{Wage2[:-2]},{Wage2[-2:]}"
                                WageTax.append(Wage2.replace('.', ''))
                                # print(Wage2)

                                if len(line_items_Wage) == 5:

                                    # Solidarity.append(Solidarity2)

                                    if len(line_items_Wage[2]) >= len(line_items_Wage[3]) and int(
                                            line_items_Wage[-1].replace(".", "").replace(",", "")) < 200000:
                                        churchtax2 = line_items_Wage[-2]
                                        churchtax2 = f"{churchtax2[:-2]},{churchtax2[-2:]}"
                                        churchtax2 = (churchtax2, num_page)
                                        ChurchTax.append(churchtax2)
                                    elif len(line_items_Wage[2]) >= len(line_items_Wage[3]) and int(
                                            line_items_Wage[-1].replace(".", "").replace(",", "")) > 200000:
                                        Solidarity2 = line_items_Wage[-2]
                                        Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                        Solidarity2 = (Solidarity2, num_page)
                                        Solidarity.append(Solidarity2)
                                elif len(line_items_Wage) == 6 and len(line_items_Wage[-2]) == 3:
                                    Solidarity2 = line_items_Wage[-2]
                                    Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                    Solidarity2 = (Solidarity2, num_page)
                                    Solidarity.append(Solidarity2)
                                elif len(line_items_Wage) == 5 and len(line_items_Wage[2]) - len(
                                        line_items_Wage[3]) == 1 and line_items_Wage[-2] < "15000":
                                    churchtax2 = line_items_Wage[-2]
                                    churchtax2 = f"{churchtax2[:-2]},{churchtax2[-2:]}"
                                    churchtax2 = (churchtax2, num_page)
                                    ChurchTax.append(churchtax2)
                                elif len(line_items_Wage) == 5 and len(line_items_Wage[2]) - len(
                                        line_items_Wage[-1]) == 1 and line_items_Wage[-2] > "15000":
                                    Solidarity2 = line_items_Wage[-2]
                                    Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                    Solidarity2 = (Solidarity2, num_page)
                                    Solidarity.append(Solidarity2)

                                elif len(line_items_Wage) == 6:
                                    Solidarity2 = line_items_Wage[-2]
                                    Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                    Solidarity2 = (Solidarity2, num_page)
                                    Solidarity.append(Solidarity2)

                                    churchtax2 = line_items_Wage[-3]
                                    churchtax2 = f"{churchtax2[:-2]},{churchtax2[-2:]}"
                                    churchtax2 = (churchtax2, num_page)
                                    ChurchTax.append(churchtax2)

                                    # print(churchtax2)





                            elif len(line_items_Wage) == 2:  # KEY MARCUS MOSS
                                # WageTax.append('')
                                SocialD.append('')
                                # Basesalary.append('0')
                                # UICont.append('')
                                # 0PICont.append('')

                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:
                            # print(line_items_Wage)
                            SocialD.append(line_items_Wage[-1].replace('.', ''))

                            # else:
                            # SocialD.append('')
                            # print(line_items_Wage)
                            # SocialD.append(line_items_Wage[-1])
                            if len(line_items_Wage) == 6:
                                # print(line_items_Wage)
                                UI = line_items_Wage[-2].replace('-', '')
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = (UI.replace('.', ''), num_page)

                                PI = line_items_Wage[-3].replace('-', '')
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PI = (PI.replace('.', ''), num_page)

                                # UI = f"{UI[:-2]},{UI[-2:]}"

                                # AGPV = (line_items_ZuschussPV[-1].replace('-', '').replace('.', ''), num_page)
                                UICont.append(UI)
                                PICont.append(PI)


                            elif 'Z' in line_items_Wage or 'E' in line_items_Wage or '1' in line_items_Wage or '2' in line_items_Wage or '3' in line_items_Wage or '4' in line_items_Wage:

                                # print(line_items_Wage)
                                UI = extract_UI(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'])

                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = UI.replace(',,', ',')

                                UI = (UI.replace('.', ''), num_page)

                                PI = extract_value_before(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'], 2)
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PI = (PI.replace('.', ''), num_page)

                                if len(line_items_Wage) > 7:
                                    HI = extract_value_before(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'], 3)

                                    HI = f"{HI[:-2]},{HI[-2:]}"
                                    HI = (HI.replace('.', ''), num_page)
                                    HICont.append(HI)

                                    CI = extract_value_after(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'], 1)

                                    CI = f"{CI[:-2]},{CI[-2:]}"
                                    CI = (CI.replace('.', ''), num_page)
                                    CIcont.append(CI)

                                # UI = f"{UI[:-2]},{UI[-2:]}"
                                # PI = f"{PI[:-2]},{PI[-2:]}"
                                # SocialD.append(line_items_Wage[-1])

                                UICont.append(UI)
                                PICont.append(PI)



                            elif len(line_items_Wage) >= 9:
                                # print(line_items_Wage)
                                UI = line_items_Wage[-3]
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = (UI.replace('.', ''), num_page)

                                PI = line_items_Wage[-4]
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PI = (PI.replace('.', ''), num_page)

                                HI = line_items_Wage[-6]
                                HI = f"{HI[:-2]},{HI[-2:]}"
                                HI = (HI.replace('.', ''), num_page)

                                CI = line_items_Wage[-2]
                                CI = f"{CI[:-2]},{CI[-2:]}"
                                CI = (CI.replace('.', ''), num_page)

                                # UI = f"{UI[:-2]},{UI[-2:]}"
                                # PI = f"{PI[:-2]},{PI[-2:]}"
                                UICont.append(UI)
                                PICont.append(PI)
                                HICont.append(HI)
                                CIcont.append(CI)
                            # print(line_items_Wage)
                            # else:
                            # SocialD.append('')

                    if CarAllowance.search(line):
                        line_items_Car = line.split()
                        # print(line_items_Car)
                        CarPrivate = (line_items_Car[-1].replace('-', ''), num_page)
                        CarPrivate2 = ('-' + line_items_Car[-1].replace('-', ''), num_page)
                        CarBenefit.append(CarPrivate)
                        # listminus=["-" + x[:-1] for x in CarBenefit]
                        # CarBenefitMinus.append(CarPrivate2)

                        # CarBenefit.append('0')
                        # CarBenefitMinus.append('0')

                    if Commission.search(line):
                        line_items_Comission = line.split()
                        Commission2 = (line_items_Comission[-1].replace('.', '').replace('-', ''), num_page)
                        CommissionList.append(Commission2)
                        # print(line_items_Comission)

                    if BAV_re.search(line):
                        line_items_BAV = line.split()
                        BAVAGZ = (line_items_BAV[-1].replace('.', '').replace('-', ''), num_page)
                        Bav_list.append(BAVAGZ)
                        # print(line_items_Comission)

                    if Bav_Abzug.search(line):
                        line_items_BAVAbzug = line.split()
                        BAVABZ = (line_items_BAVAbzug[-1].replace('.', '').replace('-', ''), num_page)
                        Bav_listAbzug.append(BAVABZ)
                        # print(line_items_Comission)

                    if Period.search(line):
                        line_items_Period = line.split()
                        month = ' '.join(line_items_Period[3:5])
                        Date.append(month)
                        # print(month)
                    if ID.search(line):
                        line_items_ID = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        # print(line_items_ID)
                        MitarbeiterID.append(line_items_ID[0])

                    if Uberstd.search(line) or Uberstd2.search(line):
                        line_items_uberstd = line.split()
                        # print(line_items_uberstd)
                        if len(line_items_uberstd) > 2:
                            Uberstunde2 = (line_items_uberstd[-1].replace('.', '').replace('-', ''), num_page)
                            Uberstunde.append(Uberstunde2)  #
                            # print(Uberstunde2)

                    if WeekendSamstag.search(line):
                        line_items_Samstag = line.split()
                        Samstag2 = (line_items_Samstag[-1].replace('.', '').replace('-', ''), num_page)
                        SaturdayWork.append(Samstag2)  #
                        # print(line_items_Samstag)

                    if WeekendSonntag.search(line):
                        line_items_Sonntag = line.split()
                        Sonntag2 = (line_items_Sonntag[-1].replace('.', '').replace('-', ''), num_page)
                        SundayWork.append(Sonntag2)

                    if Bonuslfd.search(line):
                        line_items_lfd = line.split()
                        # print(line_items_lfd)
                        # if len(line_items_uberstd) >2:
                        Bonus1 = (line_items_lfd[-1].replace('.', '').replace('-', ''), num_page)
                        Bonus.append(Bonus1)  #
                        # print(Uberstunde2)

                    if BonusEBZ.search(line):
                        line_items_BonusEBZ = line.split()
                        # print(line_items_BonusEBZ)
                        Bonus2 = (line_items_BonusEBZ[-1].replace('.', '').replace('-', ''), num_page)
                        BonusEBZlist.append(Bonus2)

                    if PrivateLI.search(line):
                        line_items_PLI = line.split()
                        # print(line_items_PLI)
                        # if len(line_items_uberstd) >2:
                        PLI1 = (line_items_PLI[-1].replace('.', '').replace('-', ''), num_page)
                        PLI.append(PLI1)  #

                    if PrivateHI.search(line):
                        line_items_PHI = line.split()
                        # print(line_items_PLI)
                        # if len(line_items_uberstd) >2:
                        PHI1 = (line_items_PHI[-1].replace('.', '').replace('-', ''), num_page)
                        # print(PHI1)
                        PHI.append(PHI1)

                    if RAllowance.search(line):
                        line_items_RA = line.split()
                        # print(line_items_PLI)
                        # if len(line_items_uberstd) >2:
                        RA1 = (line_items_RA[-1].replace('.', '').replace('-', ''), num_page)
                        Resid.append(RA1)

                    if RAllowanceNet.search(line):
                        line_items_RAnet = line.split()
                        # print(line_items_RAnet)
                        # if len(line_items_uberstd) >2:
                        RA2 = (line_items_RAnet[-1].replace('.', '').replace('-', ''), num_page)
                        ResidNet.append(RA2)

                    if BetragAVAG.search(line):
                        line_items_Betrag = line.split()
                        # print(line_items_Betrag)
                        BetragAVAGlfd = (line_items_Betrag[-1].replace('-', ''), num_page)
                        # print(BetragAVAGlfd)
                        Betrag901.append(BetragAVAGlfd)

                    if BetragAVANST.search(line):
                        line_items_Betrag = line.split()
                        BetragANAm = (line_items_Betrag[-1].replace('-', ''), num_page)
                        Betrag911.append(BetragANAm)

                    if BetragAVANGE.search(line):
                        line_items_BetragGE = line.split()
                        # print(line_items_BetragGE)
                        BetragANAmGe = ('-' + line_items_BetragGE[-1].replace('-', ''), num_page)
                        Betrag914.append(BetragANAmGe)

                        # print(Uberstunde)

                    if GBzurPV.search(line):
                        line_items_GBPV = line.split()
                        GBPVAmount = ('-' + line_items_GBPV[-1].replace('-', ''), num_page)
                        # print(line_items_GBPV)
                        GBPV.append(GBPVAmount)

                    if GBzurKV.search(line):
                        line_items_GBKV = line.split()
                        # print(line_items_GBKV)
                        GBKVAmount = ('-' + line_items_GBKV[-1].replace('-', ''), num_page)
                        # print(line_items_GBPV)
                        GBKV.append(GBKVAmount)

                    if CorrectionSickPay.search(line):  # Pour les corrections sick juste pour ce mois
                        line_items_CSP = line.split()
                        # print(line_items_GBKV)
                        CSPAmount = ('-' + line_items_CSP[-1].replace('-', ''), num_page)
                        # print(line_items_GBPV)
                        CorrectionSickPayList.append(CSPAmount)

                    if CorrectionHI.search(line):  # Pour les corrections sick juste pour ce mois
                        line_items_CHI = line.split()
                        # print(line_items_GBKV)
                        CHIAmount = ('-' + line_items_CHI[-1].replace('-', ''), num_page)
                        # print(line_items_GBPV)
                        CorrectionHIlist.append(CHIAmount)

                    if CorrectionCI.search(line):  # Pour les corrections sick juste pour ce mois
                        line_items_CCI = line.split()
                        # print(line_items_GBKV)
                        CCIAmount = ('-' + line_items_CCI[-1].replace('-', ''), num_page)
                        # print(line_items_GBPV)
                        CorrectionCIlist.append(CCIAmount)

                    if HO.search(line):
                        line_items_HO = line.split()
                        HOamount = (line_items_HO[-1].replace('-', ''), num_page)
                        Homeoffice.append(HOamount)
                    # print(Homeoffice)

                    # if CI24.search(line):
                    # line_items_SS = line.split()
                    # print(line_items_SS)
                    # if line_items_SS[2].isdigit():
                    # Solidarity_Surcharge = line_items_SS[2].replace('-', '').replace('.', '')
                    # Solidarity_Surcharge = f"{Solidarity_Surcharge[:-2]},{Solidarity_Surcharge[-2:]}"
                    # Solidarity_Surcharge = (Solidarity_Surcharge, num_page)
                    # print(Solidarity_Surcharge)
                    # Solidarity.append(Solidarity_Surcharge)
                    # if CarAllowance.search(line):
                    # line_items_CarAl=line.split()
                    # print(line_items_CarAl)
                    if Direkt.search(line):
                        line_items_DV = line.split()
                        # print(line_items_DV)
                        DVamount = ('-' + line_items_DV[-1].replace('-', '').replace('.', ''), num_page)
                        DV.append(DVamount)

                    if AGzuschussPV0.search(line):
                        line_items_ZuschussPV = line.split()
                        AGPV = (line_items_ZuschussPV[-1].replace('-', '').replace('.', ''), num_page)
                        AGZuschussPV.append(AGPV)
                        # print(AGPV)

                    if Bereits.search(line):
                        line_items_Bereits = line.split()
                        # print(line_items_Bereits)
                        BereitsErhalten2 = (line_items_Bereits[-1].replace('-', '').replace('.', ''), num_page)
                        BereitsErhalten.append(BereitsErhalten2)

                    if AGzuschussKV0.search(line):
                        line_items_ZuschussKV = line.split()
                        # print(line_items_ZuschussKV)
                        AGKV = (line_items_ZuschussKV[-1].replace('-', '').replace('.', ''), num_page)
                        AGZuschussKV.append(AGKV)
                        # print(AGPV)

                    if Contrgroup.search(line):
                        line_items_Cont = line.split()

                        # print(line_items_Cont)
                        if line_items_Cont[-1] == '30' or line_items_Cont[-1] == '04':
                            Cont.append(line_items_Cont[-3])
                        else:
                            Cont.append(line_items_Cont[-2])
                        # if line_items_Cont[-1]!='1':
                        # Cont.append(line_items_Cont[-3])
                        # else:
                        # Cont.append(line_items_Cont[-2])
                        # print(line_items_Cont)
                        # Cont.append(line_items_Cont[-3])

                    if UIline.search(line):
                        line_items_UI = line.split()

                    if FreiwilligeZuschlage.search(line):
                        line_items_FZ = line.split()
                        FZ = (line_items_FZ[-1].replace('-', '').replace('.', ''), num_page)
                        FZList.append(FZ)
                        # print(line_items_FZ)

                    if Sonderzahlung.search(line):
                        line_items_SZ = line.split()
                        SZ = (line_items_SZ[-1].replace('-', '').replace('.', ''), num_page)
                        SonderzahlunglIST.append(SZ)

                    if Unterstutzung.search(line):
                        line_items_UnterS = line.split()
                        UStzung = (line_items_UnterS[-1].replace('-', '').replace('.', ''), num_page)
                        UnterstutzungLIST.append(UStzung)

    # Sum of all numbers and replacement to be float

    # for i in range(len(Basesalary)):
    # Replace the period with an empty string
    # Basesalary2[i] = Basesalary2[i].replace(',', '.')

    for i in range(len(TotalGrossIncome)):
        # Replace the period with an empty string
        TotalGrossIncome[i] = TotalGrossIncome[i].replace(',', '.')

    for i in range(len(Netpay)):
        # Replace the period with an empty string
        Netpay[i] = Netpay[i].replace(',', '.')

    # for i in range(len(CarBenefit)):
    # Replace the period with an empty string
    # CarBenefit[i] = CarBenefit[i].replace(',', '.')

    for i in range(len(WageTax)):
        # Replace the period with an empty string
        if WageTax[i] == '':
            WageTax[i] = '0'
        WageTax[i] = WageTax[i].replace(',', '.')

    # print(FromCorrection)

    # total = sum(float(num) for num in Basesalary2)
    totalTGI = sum(float(num) for num in TotalGrossIncome)
    totalNet = sum(float(num) for num in Netpay)
    # totalCar= sum(float(num) for num in CarBenefit)
    totalWage = sum(float(num) for num in WageTax)

    totalNet = round(totalNet, 2)
    totalWage = round(totalWage, 2)
    totalTGI = round(totalTGI, 2)

    # total = str(total).replace('.', ',')
    totalTGI = str(totalTGI).replace('.', ',')
    totalNet = str(totalNet).replace('.', ',')
    # totalCar = str(totalCar).replace('.',',')
    totalWage = str(totalWage).replace('.', ',')
    # totalCommission = str(totalCommission).replace('.', ',')
    # total=total.replace(',', '|').replace('.', ',').replace('|', '.')
    # print(total)
    # print(totalTGI)
    # print(totalNet)

    # Replacement to be normal number
    for i in range(len(Basesalary2)):
        # Replace the period with an empty string
        Basesalary2[i] = Basesalary2[i].replace('.', ',')

    for i in range(len(TotalGrossIncome)):
        # Replace the period with an empty string
        TotalGrossIncome[i] = TotalGrossIncome[i].replace('.', ',')

    for i in range(len(Netpay)):
        # Replace the period with an empty string
        Netpay[i] = Netpay[i].replace('.', ',')

    # for i in range(len(CarBenefit)):
    # Replace the period with an empty string
    # CarBenefit[i] = CarBenefit[i].replace('.', ',')

    for i in range(len(WageTax)):
        # Replace the period with an empty string

        WageTax[i] = WageTax[i].replace('.', ',')

    # Add empty line
    Company.append('')
    Employee.append('')
    # Basesalary.append('')
    TotalGrossIncome.append('')
    MitarbeiterID.append('')
    Netpay.append('')
    WageTax.append('')
    # CarBenefit.append('')
    # CarBenefitMinus.append('')
    # CommissionList.append('')
    Date.append('')

    Company.append('')
    Employee.append('TOTAL')

    TotalGrossIncome.append(totalTGI)
    MitarbeiterID.append('')
    Netpay.append(totalNet)
    WageTax.append(totalWage)
    # CarBenefit.append(totalCar)
    # CarBenefitMinus.append('-'+totalCar)
    # CommissionList.append(totalCommission)
    Date.append('')

    # CarBenefitMinus=["-" + x[:-1] for x in CarBenefit]

    ### TAKE ALL THE PAGE NUMBER FOR UBERSTUNDEN
    Num_pages = [tup[-1] for tup in Uberstunde]
    # print(Num_pages)
    WorkerIDuberstd = []
    UberstdNumpages = []

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):

            if num_page in Num_pages:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_ID2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        # print(line_items_ID2)
                        WorkerIDuberstd.append(line_items_ID2[0])
                        # print(line_items_ID2)
                    if Uberstd.search(line):
                        line_items_uberstd = line.split()
                        if len(line_items_uberstd) > 2:
                            Uberstunde3 = line_items_uberstd[-1].replace('.', '').replace('-', '')
                            UberstdNumpages.append(Uberstunde3)
                            # print(Uberstunde3)

    ### TAKE ALL THE PAGE NUMBER FOR home office
    Num_pages2 = [tup[-1] for tup in Homeoffice]
    # print(Num_pages)
    WorkerIDHomeOffice = []
    HomeOfficeNumpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages2:

                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_HOid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDHomeOffice.append(line_items_HOid2[0])
                        # print(line_items_ID2)
                    if HO.search(line):
                        line_items_HO2 = line.split()
                        # print(line_items_HO2)
                        HomeOfficeNumpages.append(line_items_HO2[-1])

    ### TAKE ALL THE PAGE NUMBER FOR Bonuslfd
    Num_pages3 = [tup[-1] for tup in Bonus]
    # print(Num_pages)
    WorkerIDBonus = []
    BonusNumpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages3:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Bonusid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDBonus.append(line_items_Bonusid2[0])
                        # print(line_items_Bonusid2)
                    if Bonuslfd.search(line):
                        line_items_Bonus2 = line.split()
                        # print(line_items_HO2)
                        BonusNumpages.append(line_items_Bonus2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR BonusEBZ
    Num_pages32 = [tup[-1] for tup in BonusEBZlist]
    # print(Num_pages)
    WorkerIDBonusEBZ = []
    BonusEBZNumpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages32:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                    # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_BonusEBZid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDBonusEBZ.append(line_items_BonusEBZid2[0])
                        # print(line_items_Bonusid2)
                    if BonusEBZ.search(line):
                        line_items_BonusEBZ2 = line.split()
                        # print(line_items_HO2)
                        BonusEBZNumpages.append(line_items_BonusEBZ2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Private Liability
    Num_pages4 = [tup[-1] for tup in PLI]
    # print(Num_pages)
    WorkerIDPLI = []
    PLINumpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages4:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_PLIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDPLI.append(line_items_PLIid2[0])
                        # print(line_items_PLIid2)
                    if PrivateLI.search(line):
                        line_items_PLI2 = line.split()
                        # print(line_items_PLI2)
                        PLINumpages.append(line_items_PLI2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Private Household
    Num_pages5 = [tup[-1] for tup in PHI]
    # print(Num_pages5)
    WorkerIDPHI = []
    PHINumpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages5:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_PHIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDPHI.append(line_items_PHIid2[0])
                    # print(line_items_PHIid2)
                    if PrivateHI.search(line):
                        line_items_PHI2 = line.split()
                        # print(line_items_PHI2)
                        PHINumpages.append(line_items_PHI2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Residance Allowance
    Num_pages6 = [tup[-1] for tup in Resid]
    # print(Num_pages5)
    WorkerIDRA = []
    RANumpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages6:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_RAid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDRA.append(line_items_RAid2[0])
                        # print(line_items_RAid2)
                    if RAllowance.search(line):
                        line_items_RA2 = line.split()
                        # print(line_items_RA2)
                        RANumpages.append(line_items_RA2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Residance Allowance Net
    Num_pages6b = [tup[-1] for tup in ResidNet]
    # print(Num_pages5)
    WorkerIDRANet = []
    RANumpagesNet = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages6b:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_RAid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDRANet.append(line_items_RAid2[0])
                        # print(line_items_RAid2)
                    if RAllowanceNet.search(line):
                        line_items_RA2 = line.split()
                        # print(line_items_RA2)
                        RANumpagesNet.append(line_items_RA2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR CHURCHTAX
    Num_pages7 = [tup[-1] for tup in ChurchTax]
    # print(Num_pages5)
    WorkerID_Church = []
    Church_Numpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages7:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Churchid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Church.append(line_items_Churchid2[0])
                        # print(line_items_RAid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # print(line_items_Wage)

                        # print(line_items_Wage)
                        if line_items_Wage[
                            0] == 'L' and '773,80' not in line_items_Wage and 'Z' not in line_items_Wage:  # FAIRE EN SORTE DAVOIR LES HI COMTRIBUTIONS
                            # print(line_items_Wage)

                            if len(line_items_Wage) > 2 and line_items_Wage[2] != line_items_Wage[1] and \
                                    line_items_Wage[3] != line_items_Wage[2]:
                                # print(line_items_Wage)
                                Wage2 = line_items_Wage[2]

                                # print(Sol2)
                                # Format with one comma before the last two numbers
                                Wage2 = f"{Wage2[:-2]},{Wage2[-2:]}"
                                WageTax.append(Wage2.replace('.', ''))
                                # print(Wage2)

                                if len(line_items_Wage) == 5 and len(line_items_Wage[2]) >= len(line_items_Wage[3]):
                                    churchtax2 = line_items_Wage[-2]
                                    churchtax2 = f"{churchtax2[:-2]},{churchtax2[-2:]}"
                                    # churchtax2 = (churchtax2, num_page)
                                    Church_Numpages.append(churchtax2)

                                elif len(line_items_Wage) == 5 and len(line_items_Wage[2]) - len(
                                        line_items_Wage[3]) == 1 and line_items_Wage[-2] < "15000":
                                    churchtax2 = line_items_Wage[-2]
                                    churchtax2 = f"{churchtax2[:-2]},{churchtax2[-2:]}"
                                    # churchtax2 = (churchtax2, num_page)
                                    # Church_Numpages.append(churchtax2)

    ### TAKE ALL THE PAGE NUMBER FOR Solidarity Surcharge
    Num_pages8 = [tup[-1] for tup in Solidarity]
    # print(Num_pages5)
    WorkerID_Solidarity = []
    Solidarity_Numpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages8:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Solidarityid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Solidarity.append(line_items_Solidarityid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # print(line_items_Wage)

                        # print(line_items_Wage)
                        if line_items_Wage[
                            0] == 'L' and '773,80' not in line_items_Wage and 'Z' not in line_items_Wage:  # FAIRE EN SORTE DAVOIR LES HI COMTRIBUTIONS
                            # print(line_items_Wage)

                            if len(line_items_Wage) == 5 and len(line_items_Wage[2]) >= len(line_items_Wage[3]):

                                Solidarity2 = line_items_Wage[-2]
                                Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                # Solidarity2 = (Solidarity2, num_page)
                                # Solidarity2 = (Solidarity2, num_page)
                                Solidarity_Numpages.append(Solidarity2)
                            elif len(line_items_Wage) == 6 and len(line_items_Wage[-2]) == 3:
                                Solidarity2 = line_items_Wage[-2]
                                Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                Solidarity_Numpages.append(Solidarity2)

                            elif len(line_items_Wage) == 4 and len(line_items_Wage[2]) - len(
                                    line_items_Wage[-1]) == 1 and line_items_Wage[-1] > "15000":
                                Solidarity2 = line_items_Wage[-1]
                                Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                # Solidarity_Numpages.append(Solidarity2)

    ### TAKE ALL THE PAGE NUMBER FOR Direktversicherung
    Num_pages9 = [tup[-1] for tup in DV]
    # print(Num_pages5)
    WorkerID_DV = []
    DV_Numpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages9:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_DVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_DV.append(line_items_DVid2[0])
                        # print(line_items_Solidarityid2)
                    if Direkt.search(line):
                        line_items_DV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        DV_Numpages.append('-' + line_items_DV2[-1].replace('.', '').replace('-', ''))

    # print(WorkerID_Solidarity)

    ### TAKE ALL THE PAGE NUMBER FOR AGzuschussPV
    Num_pages11 = [tup[-1] for tup in AGZuschussPV]
    # print(Num_pages5)
    WorkerID_AGZuschussPV = []
    AGZuschussPV_Numpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages11:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_AGPVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_AGZuschussPV.append(line_items_AGPVid2[0])
                        # print(line_items_Solidarityid2)
                    if AGzuschussPV0.search(line):
                        line_items_AGPV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        AGZuschussPV_Numpages.append(line_items_AGPV2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR AGzuschussKV
    Num_pages12 = [tup[-1] for tup in AGZuschussKV]
    # print(Num_pages5)
    WorkerID_AGZuschussKV = []
    AGZuschussKV_Numpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages12:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_AGKVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_AGZuschussKV.append(line_items_AGKVid2[0])
                        # print(line_items_Solidarityid2)
                    if AGzuschussKV0.search(line):
                        line_items_AGKV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        AGZuschussKV_Numpages.append(line_items_AGKV2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR HI,CI,UI,PI
    Num_pages13 = [tup[-1] for tup in UICont]
    Num_pages14 = [tup[-1] for tup in PICont]
    Num_pages15 = [tup[-1] for tup in HICont]
    Num_pages16 = [tup[-1] for tup in CIcont]
    # print(Num_pages5)
    WorkerID_UICont = []
    WorkerID_PICont = []
    WorkerID_HICont = []
    WorkerID_CICont = []

    UICont_Numpages = []
    PICont_Numpages = []
    HICont_Numpages = []
    CICont_Numpages = []

    ### TAKE ALL THE PAGE NUMBER FOR HI,CI,UI,PI For E
    Num_pages132 = [tup[-1] for tup in UIContE]
    Num_pages142 = [tup[-1] for tup in PIContE]
    Num_pages152 = [tup[-1] for tup in HIContE]
    Num_pages162 = [tup[-1] for tup in CIcontE]
    # print(Num_pages5)
    WorkerID_UIContE = []
    WorkerID_PIContE = []
    WorkerID_HIContE = []
    WorkerID_CIContE = []

    UIContE_Numpages = []
    PIContE_Numpages = []
    HIContE_Numpages = []
    CIContE_Numpages = []

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages13:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_UIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_UICont.append(line_items_UIid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # DV2=line_items_DV2[-1]
                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:

                            if len(line_items_Wage) == 6:
                                # print(line_items_Wage)
                                UI = line_items_Wage[-2].replace('-', '')
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UICont_Numpages.append(UI)


                            elif 'Z' in line_items_Wage or 'E' in line_items_Wage or '1' in line_items_Wage or '2' in line_items_Wage or '3' in line_items_Wage or '4' in line_items_Wage:
                                # print(line_items_Wage)
                                UI = extract_UI(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'])

                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = UI.replace(',,', ',')

                                UICont_Numpages.append(UI)
                                # PICont.append(PI)



                            elif len(line_items_Wage) >= 9:
                                # print(line_items_Wage)
                                UI = line_items_Wage[-3]
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UICont_Numpages.append(UI)

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages132:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_UIidE2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_UIContE.append(line_items_UIidE2[0])
                        # print(line_items_Solidarityid2)
                    if WageE.search(line):
                        line_items_WageE = line.split()
                        UIE = line_items_WageE[-3]
                        UIE = f"{UIE[:-2]},{UIE[-2:]}"
                        UIContE_Numpages.append(UIE)

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages14:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_PIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_PICont.append(line_items_PIid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # DV2=line_items_DV2[-1]
                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:

                            if len(line_items_Wage) == 6:
                                # print(line_items_Wage)
                                PI = line_items_Wage[-3].replace('-', '')
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PICont_Numpages.append(PI)


                            elif 'Z' in line_items_Wage or 'E' in line_items_Wage or '1' in line_items_Wage or '2' in line_items_Wage or '4' in line_items_Wage:
                                # print(line_items_Wage)
                                PI = extract_value_before(line_items_Wage, ['Z', 'E', '1', '2', '4'], 2)
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PICont_Numpages.append(PI)
                                # PICont.append(PI)

                            elif len(line_items_Wage) >= 9:
                                # print(line_items_Wage)
                                PI = line_items_Wage[-4]
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PICont_Numpages.append(PI)

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages142:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_PIidE2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_PIContE.append(line_items_PIidE2[0])
                    if WageE.search(line):
                        line_items_WageE = line.split()
                        PIE = line_items_WageE[-4]
                        PIE = f"{PIE[:-2]},{PIE[-2:]}"
                        PIContE_Numpages.append(PIE)

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages15:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_HIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_HICont.append(line_items_HIid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # DV2=line_items_DV2[-1]
                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:
                            if 'Z' in line_items_Wage:
                                if len(line_items_Wage) > 7:
                                    HI = extract_value_before(line_items_Wage, ['Z', 'E', '1', '2', '4'], 3)

                                    HI = f"{HI[:-2]},{HI[-2:]}"
                                    HICont_Numpages.append(HI)

                            elif len(line_items_Wage) >= 9:
                                HI = line_items_Wage[-6]
                                HI = f"{HI[:-2]},{HI[-2:]}"
                                HICont_Numpages.append(HI)

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages152:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_HIidE2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_HIContE.append(line_items_HIidE2[0])
                        # print(line_items_Solidarityid2)
                    if WageE.search(line):
                        line_items_WageE = line.split()
                        HIE = line_items_WageE[-5]
                        HIE = f"{HIE[:-2]},{HIE[-2:]}"
                        HIContE_Numpages.append(HIE)

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages16:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_CIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_CICont.append(line_items_CIid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # DV2=line_items_DV2[-1]
                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:
                            if 'Z' in line_items_Wage:
                                if len(line_items_Wage) > 7:
                                    CI = extract_value_after(line_items_Wage, ['Z', 'E', '1', '2', '4'], 1)

                                    CI = f"{CI[:-2]},{CI[-2:]}"
                                    # CI = (CI.replace('.', ''), num_page)
                                    CICont_Numpages.append(CI)

                            elif len(line_items_Wage) >= 9:

                                CI = line_items_Wage[-2]
                                CI = f"{CI[:-2]},{CI[-2:]}"
                                CICont_Numpages.append(CI)

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages162:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_CIidE2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_CIContE.append(line_items_CIidE2[0])
                        # print(line_items_Solidarityid2)
                    if WageE.search(line):
                        line_items_WageE = line.split()
                        CIE = line_items_WageE[-2]
                        CIE = f"{CIE[:-2]},{CIE[-2:]}"
                        CIContE_Numpages.append(CIE)

    ### TAKE ALL THE PAGE NUMBER FOR GBzurKV
    Num_pages17 = [tup[-1] for tup in GBKV]
    # print(Num_pages5)
    WorkerID_GBKV = []
    GBKV_Numpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages17:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_GBKVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_GBKV.append(line_items_GBKVid2[0])
                        # print(line_items_Solidarityid2)
                    if GBzurKV.search(line):
                        line_items_GBKV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        GBKV_Numpages.append('-' + line_items_GBKV2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR GBzurPV
    Num_pages18 = [tup[-1] for tup in GBPV]
    # print(Num_pages5)
    WorkerID_GBPV = []
    GBPV_Numpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages18:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_GBPVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_GBPV.append(line_items_GBPVid2[0])
                        # print(line_items_Solidarityid2)
                    if GBzurPV.search(line):
                        line_items_GBPV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        GBPV_Numpages.append('-' + line_items_GBPV2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR CarBenefit
    Num_pages19 = [tup[-1] for tup in CarBenefit]
    # print(Num_pages5)
    WorkerID_CarBenefit = []
    CarBenefit_Numpages = []
    CarBenefitMinus_Numpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages19:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Carid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_CarBenefit.append(line_items_Carid2[0])
                        # print(line_items_Solidarityid2)
                    if CarAllowance.search(
                            line):  # J'ai mis CarAllowance ici parce que CAR simple c'est 'privatfahrten'
                        line_items_Car2 = line.split()
                        # DV2=line_items_DV2[-1]
                        CarBenefit_Numpages.append(line_items_Car2[-1].replace('.', '').replace('-', ''))
                        # CarBenefitMinus_Numpages.append('-' + line_items_Car2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Betrag911
    Num_pages20 = [tup[-1] for tup in Betrag911]
    # print(Num_pages5)
    WorkerID_Betrag911 = []
    Betrag911_Numpages = []

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages20:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_911id2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Betrag911.append(line_items_911id2[0])
                        # print(line_items_Solidarityid2)
                    if BetragAVANST.search(line):
                        line_items_AVAN2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Betrag911_Numpages.append(line_items_AVAN2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Betrag914
    Num_pages21 = [tup[-1] for tup in Betrag914]
    # print(Num_pages5)
    WorkerID_Betrag914 = []
    Betrag914_Numpages = []

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages21:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_914id2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Betrag914.append(line_items_914id2[0])
                        # print(line_items_Solidarityid2)
                    if BetragAVANGE.search(line):
                        line_items_AVANGE2 = line.split()
                        # print(line_items_AVANGE2)
                        Betrag914_Numpages.append('-' + line_items_AVANGE2[-1].replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Betrag901
    Num_pages21b = [tup[-1] for tup in Betrag901]
    # print(Num_pages5)
    WorkerID_Betrag901 = []
    Betrag901_Numpages = []

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages21b:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_901id2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Betrag901.append(line_items_901id2[0])
                        # print(WorkerID_Betrag901)
                    if BetragAVAG.search(line):
                        line_items_AVAGE2 = line.split()
                        # print(line_items_AVAGE2)
                        Betrag901_Numpages.append(line_items_AVAGE2[-1].replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR SaturdayWork
    Num_pages22 = [tup[-1] for tup in SaturdayWork]
    # print(Num_pages5)
    WorkerID_SaturdayWork = []
    SaturdayWork_Numpages = []

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages22:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Samstagid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_SaturdayWork.append(line_items_Samstagid2[0])
                        # print(line_items_Solidarityid2)
                    if WeekendSamstag.search(line):
                        line_items_Samstag2 = line.split()
                        # print(line_items_AVANGE2)
                        SaturdayWork_Numpages.append(line_items_Samstag2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR SundayWork
    Num_pages23 = [tup[-1] for tup in SundayWork]
    # print(Num_pages5)
    WorkerID_SundayWork = []
    SundayWork_Numpages = []

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages23:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Sonntagid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_SundayWork.append(line_items_Sonntagid2[0])
                        # print(line_items_Solidarityid2)
                    if WeekendSonntag.search(line):
                        line_items_Sonntag2 = line.split()
                        # print(line_items_AVANGE2)
                        SundayWork_Numpages.append(line_items_Sonntag2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR WageS
    Num_pages24 = [tup[-1] for tup in WageTaxS]
    # print(Num_pages5)
    WorkerID_WageS = []
    WageS_Numpages = []

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages24:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_WageSid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_WageS.append(line_items_WageSid2[0])
                        # print(line_items_Solidarityid2)
                    if WageS.search(line):
                        line_items_WageS2 = line.split()
                        # print(line_items_WageS2)
                        WageTaxS2 = line_items_WageS2[2]
                        WageTaxS2 = f"{WageTaxS2[:-2]},{WageTaxS2[-2:]}"
                        # print(line_items_WageS2)
                        WageS_Numpages.append(WageTaxS2.replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Salary_Correction (1.C)
    Num_pages300 = [tup[-1] for tup in CorrectionNSalaryList]
    # print(Num_pages5)
    WorkerID_NSalary = []
    NSalary_Numpages = []

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages300:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_NSalaryid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_NSalary.append(line_items_NSalaryid2[0])
                        # print(line_items_NSalaryid2)
                    if CorrectionN.search(line):
                        line_items_NSalary2 = line.split()
                        # print(line_items_NSalary2)
                        if "001" in line_items_NSalary2:
                            NSalary2 = line_items_NSalary2[-1]
                            # NSalary2= f"{NSalary2[:-2]},{NSalary2[-2:]}"
                            # print(NSalary2)
                            NSalary_Numpages.append(NSalary2.replace('.', ''))
    ### TAKE ALL THE PAGE NUMBER FOR Wage_Correction
    Num_pages301 = [tup[-1] for tup in WageTaxN]
    # print(Num_pages301)
    WorkerID_WageN = []
    WageN_Numpages = []
    SolidarityN_Numpages = []

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages301:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_WageNid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_WageN.append(line_items_WageNid2[0])
                        # print(line_items_Solidarityid2)
                    if CorrectionN.search(line):
                        lineitemsN2 = line.split()
                        if "001" not in lineitemsN2:
                            line_items_WageN = line.split()
                            # print(line_items_WageN)
                            if line_items_WageN[2] != line_items_WageN[1]:
                                WageTaxN1 = line_items_WageN[2]
                                WageTaxN1 = f"{WageTaxN1[:-2]},{WageTaxN1[-2:]}"
                                # WageTaxN1 = (WageTaxN1, num_page)
                                WageN_Numpages.append(WageTaxN1)
                                if len(line_items_WageN) > 4:
                                    SolidarityN1 = line_items_WageN[3]
                                    SolidarityN1 = f"{SolidarityN1[:-2]},{SolidarityN1[-2:]}"
                                    # SolidarityN1 = (SolidarityN1, num_page)
                                    SolidarityN_Numpages.append(SolidarityN1)
                            # print(WageTaxN1)

    ### TAKE ALL THE PAGE NUMBER FOR UI and Pi_Correction
    Num_pages303 = [tup[-1] for tup in UIContN]
    # print(Num_pages301)
    WorkerID_UIContN = []
    UIContN_Numpages = []
    PIContN_Numpages = []
    SocialDN_Numpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages303:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_UIContNid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_UIContN.append(line_items_UIContNid2[0])
                    if CorrectionN.search(line):
                        lineitemsN2 = line.split()
                        if "001" not in lineitemsN2:
                            line_items_UIContN = line.split()
                            # print(line_items_WageN)

                            if len(line_items_UIContN) == 6 and (line_items_UIContN[2] == line_items_UIContN[1]):
                                # print(line_items_Wage)
                                SocialDN1 = line_items_WageN[-1].replace('-', '')
                                UI = line_items_UIContN[-2].replace('-', '')
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = UI.replace('.', '')

                                PI = line_items_UIContN[-3].replace('-', '')
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PI = PI.replace('.', '')

                                # UI = f"{UI[:-2]},{UI[-2:]}"

                                # AGPV = (line_items_ZuschussPV[-1].replace('-', '').replace('.', ''), num_page)
                                UIContN_Numpages.append(UI)
                                PIContN_Numpages.append(PI)
                                SocialDN_Numpages.append(SocialDN1)

    ### TAKE ALL THE PAGE NUMBER FOR Solidarity(S)
    Num_pages25 = [tup[-1] for tup in SolidarityS]
    # print(Num_pages5)
    WorkerID_SolidarityS = []
    SolidarityS_Numpages = []

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages25:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_SolidaritySid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_SolidarityS.append(line_items_SolidaritySid2[0])
                        # print(line_items_Solidarityid2)
                    if WageS.search(line):
                        line_items_WageS2 = line.split()
                        # print(line_items_WageS2)
                        if len(line_items_WageS2) > 4:
                            SolidarityTaxS2 = line_items_WageS2[3]
                            SolidarityTaxS2 = f"{SolidarityTaxS2[:-2]},{SolidarityTaxS2[-2:]}"
                            # print(line_items_WageS2)
                            SolidarityS_Numpages.append(SolidarityTaxS2.replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR ChurchTax(S)
    Num_pages252 = [tup[-1] for tup in ChurchTaxS]
    # print(Num_pages5)
    WorkerID_ChurchTaxS = []
    ChurchTaxS_Numpages = []

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages252:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_ChurchTaxSid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_ChurchTaxS.append(line_items_ChurchTaxSid2[0])
                        # print(line_items_Solidarityid2)
                    if WageS.search(line):
                        line_items_WageS2 = line.split()
                        # print(line_items_WageS2)
                        if len(line_items_WageS2) > 4:
                            ChurchTaxS2 = line_items_WageS2[3]
                            ChurchTaxS2 = f"{ChurchTaxS2[:-2]},{ChurchTaxS2[-2:]}"
                            # print(line_items_WageS2)
                            ChurchTaxS_Numpages.append(ChurchTaxS2.replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR 9079 Bereits erhalten
    Num_pages26 = [tup[-1] for tup in BereitsErhalten]
    # print(Num_pages5)
    WorkerID_Bereits = []
    Bereits_Numpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages26:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Bereitsid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Bereits.append(line_items_Bereitsid2[0])
                        # print(line_items_Solidarityid2)
                    if Bereits.search(line):
                        line_items_Bereits2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Bereits_Numpages.append("-" + line_items_Bereits2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR 011 Prämie

    Num_pages27 = [tup[-1] for tup in CommissionList]
    WorkerID_Commission = []
    Commission_Numpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages27:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_commissionid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Commission.append(line_items_commissionid2[0])
                        # print(line_items_Solidarityid2)
                    if Commission.search(line):
                        line_items_commission2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Commission_Numpages.append(line_items_commission2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR bav
    Num_pages28 = [tup[-1] for tup in Bav_list]
    # print(Num_pages)
    WorkerIDBav = []
    BavNumpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages28:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Bavid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDBav.append(line_items_Bavid2[0])
                        # print(line_items_Bonusid2)
                    if BAV_re.search(line):
                        line_items_Bav2 = line.split()
                        # print(line_items_HO2)
                        BavNumpages.append(line_items_Bav2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR bav_Abzug
    Num_pages2895 = [tup[-1] for tup in Bav_listAbzug]
    # print(Num_pages)
    WorkerIDBavAbz = []
    BavABZNumpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages2895:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_BAVAbzugid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerIDBavAbz.append(line_items_BAVAbzugid2[0])
                        # print(line_items_Bonusid2)
                    if Bav_Abzug.search(line):
                        line_items_BavAbz2 = line.split()
                        # print(line_items_HO2)
                        BavABZNumpages.append('-' + line_items_BavAbz2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR CorrectionSickPay
    Num_pages286 = [tup[-1] for tup in CorrectionSickPayList]
    # print(Num_pages5)
    WorkerID_CSP = []
    CSP_Numpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages286:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_CSPid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_CSP.append(line_items_CSPid2[0])
                        # print(line_items_Solidarityid2)
                    if CorrectionSickPay.search(line):
                        line_items_CSP2 = line.split()
                        # DV2=line_items_DV2[-1]
                        CSP_Numpages.append('-' + line_items_CSP2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR CorrectionCI
    Num_pages287 = [tup[-1] for tup in CorrectionCIlist]
    # print(Num_pages5)
    WorkerID_CCI = []
    CCI_Numpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages287:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_CCIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_CCI.append(line_items_CSPid2[0])
                        # print(line_items_Solidarityid2)
                    if CorrectionCI.search(line):
                        line_items_CCI2 = line.split()
                        # DV2=line_items_DV2[-1]
                        CCI_Numpages.append('-' + line_items_CCI2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR CorrectionCI
    Num_pages288 = [tup[-1] for tup in CorrectionHIlist]
    # print(Num_pages5)
    WorkerID_CHI = []
    CHI_Numpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages288:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_CHIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_CHI.append(line_items_CSPid2[0])
                        # print(line_items_Solidarityid2)
                    if CorrectionHI.search(line):
                        line_items_CHI2 = line.split()
                        # DV2=line_items_DV2[-1]
                        CHI_Numpages.append('-' + line_items_CHI2[-1].replace('.', '').replace('-', ''))

    ## TAKE ALL THE PAGE NUMBER FOR UnterstutzungList
    Num_pages29 = [tup[-1] for tup in UnterstutzungLIST]
    # print(Num_pages5)
    WorkerID_Unterstutzung = []
    Unterstutzung_Numpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages29:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_UnterStutzungid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Unterstutzung.append(line_items_UnterStutzungid2[0])
                        # print(line_items_Solidarityid2)
                    if Unterstutzung.search(line):
                        line_items_Unterstutzung2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Unterstutzung_Numpages.append(
                            '-' + line_items_Unterstutzung2[-1].replace('.', '').replace('-', ''))

    ## TAKE ALL THE PAGE NUMBER FOR SonderzahlungList
    Num_pages30 = [tup[-1] for tup in SonderzahlunglIST]
    # print(Num_pages5)
    WorkerID_Sonderzahlung = []
    Sonderzahlung_Numpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages30:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Sonderzahlungid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Sonderzahlung.append(line_items_Sonderzahlungid2[0])
                        # print(line_items_Solidarityid2)
                    if Sonderzahlung.search(line):
                        line_items_Sonderzahlung2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Sonderzahlung_Numpages.append(
                            '-' + line_items_Sonderzahlung2[-1].replace('.', '').replace('-', ''))

    ## TAKE ALL THE PAGE NUMBER FOR FraiwilligZuschlageList
    Num_pages31 = [tup[-1] for tup in FZList]
    # print(Num_pages5)
    WorkerID_FZ = []
    FZ_Numpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages31:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_FZid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_FZ.append(line_items_FZid2[0])
                        # print(line_items_Solidarityid2)
                    if FreiwilligeZuschlage.search(line):
                        line_items_FZ2 = line.split()
                        # DV2=line_items_DV2[-1]
                        FZ_Numpages.append('-' + line_items_FZ2[-1].replace('.', '').replace('-', ''))

    ## TAKE ALL THE PAGE NUMBER FOR FraiwilligZuschlageList
    Num_pages32 = [tup[-1] for tup in FromCorrection]
    # print(Num_pages5)
    WorkerID_FromCorrection = []
    FC_Numpages = []
    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages32:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_FCid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_FromCorrection.append(line_items_FCid2[0])
                        # print(line_items_Solidarityid2)
                    if Correction.search(line):
                        line_items_FC2 = line.split()
                        # DV2=line_items_DV2[-1]
                        FC_Numpages.append('-' + line_items_FC2[-1].replace('.', '').replace('-', ''))
    ########################TAKE ALL THE PAGE NUMBER FOR COMMISSION################################

    df = pd.DataFrame(columns=["Company", "Period", "Worker ID", "Worker Name", "Contr. Group", "Base Salary",
                               "Base Salary_Correction",
                               "Commission", "Home_Office", "Überstdgrundvergütung", "Weekend Work Saturday",
                               "Weekend Work Sunday",
                               "Betr.AV.AG_lfd.ST-frei", "Betr.AV.AN lfd.ST-frei", "Betr.AV.AN lfd.Geh.Ver",
                               'bAV AG-Zus. lfd.ST-frei',
                               'Freiwillige Zulage', 'Unterstützungskasse', 'Sonderzahlung',
                               "Privatfahrten/priv. use", "Bonus lfd.", "Bonus EBZ", "Residence Allowance",
                               "Residence Allowance Net",
                               "Private household insurance", "Private liability insurance",
                               "Total Gross Pay", "Total Gross Pay_Correction",
                               "Church Tax", "Church Tax_Correction",
                               "Solidarity Surcharge", "Solidarity Surcharge_Correction",
                               "EE-Wage tax", "EE-Wage tax_Correction",
                               "CI Contribution", "CI Contribution_Correction",
                               "HI Contribution", "HI Contribution_Correction",
                               "PI Contribution", "PI Contribution_Correction",
                               "UI Contribution", "UI Contribution_Correction",
                               "Social Security Deductions", "Social Security Deductions_Correction",
                               "car benefit/KFZ- Sachb.", "Bereits erhalten", "AG-Zuschuss_zur_PV",
                               "AG-Zuschuss_zur_KV",
                               "Gesamtbeitrag_zur_PV",
                               "Gesamtbeitrag_zur_KV", "bAV-Abzug", 'Correction Sick Pay', 'Correction CI-ER',
                               'Correction HI-ER',
                               'Direktversicherung', "Private Savings", "ER-Unemployment",
                               "Emp.Soc.Sec",
                               "ER Cost. Add", "ER Total Cost", "From Correction",
                               "Total Net Pay"])

    df["Company"] = pd.Series(Company, dtype=object)
    df["Worker ID"] = pd.Series(MitarbeiterID, dtype=object)
    # df["From Correction"]=pd.Series(FromCorrection, dtype=object)

    # Uberstd EQUALIZER
    finallistuberstd = list(zip(WorkerIDuberstd, UberstdNumpages))
    # print(finallistuberstd)
    # print(UberstdNumpages)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistuberstd:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Überstdgrundvergütung'] = tup[1]

    # Saturday EQUALIZER
    finallistSaturdayWork = list(zip(WorkerID_SaturdayWork, SaturdayWork_Numpages))
    # print(finallistuberstd)
    # print(UberstdNumpages)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSaturdayWork:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Weekend Work Saturday'] = tup[1]

    # Sunday EQUALIZER
    finallistSundayWork = list(zip(WorkerID_SundayWork, SundayWork_Numpages))
    # print(finallistuberstd)
    # print(UberstdNumpages)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSundayWork:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Weekend Work Sunday'] = tup[1]

    # HOMEOFFICE EQUALIZER
    finallistHO = list(zip(WorkerIDHomeOffice, HomeOfficeNumpages))

    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistHO:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Home_Office'] = tup[1]

    # Bonus Equalizer
    finallistBonus = list(zip(WorkerIDBonus, BonusNumpages))

    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBonus:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Bonus lfd.'] = tup[1]

    # BonusEBZ Equalizer
    finallistBonusEBZ = list(zip(WorkerIDBonusEBZ, BonusEBZNumpages))

    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBonusEBZ:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Bonus EBZ'] = tup[1]

    # PLI Equalizer
    finallistPLI = list(zip(WorkerIDPLI, PLINumpages))

    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistPLI:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Private liability insurance'] = tup[1]

    # PHI Equalizer
    finallistPHI = list(zip(WorkerIDPHI, PHINumpages))
    # print(finallistPHI)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistPHI:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Private household insurance'] = tup[1]

    # RA Equalizer be
    finallistRA = list(zip(WorkerIDRA, RANumpages))
    # print(finallistRA)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistRA:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Residence Allowance'] = tup[1]

    # RANet Equalizer
    finallistRANet = list(zip(WorkerIDRANet, RANumpagesNet))
    # print(finallistRA)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistRANet:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Residence Allowance Net'] = tup[1]

    # Church Equalizer
    finallistChurch = list(zip(WorkerID_Church, Church_Numpages))
    # print(finallistChurch)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistChurch:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Church Tax'] = tup[1]

    # Solidarity Surcharge Equalizer
    finallistSS = list(zip(WorkerID_Solidarity, Solidarity_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSS:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Solidarity Surcharge'] = tup[1]

    # WageS Equalizer
    finallistWageS = list(zip(WorkerID_WageS, WageS_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistWageS:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'EE-Wage tax (S)'] = tup[1]

    # SolidarityS Equalizer
    finallistSolidarityS = list(zip(WorkerID_SolidarityS, SolidarityS_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSolidarityS:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Solidarity Surcharge (S)'] = tup[1]

    # BaseSalaryS Equalizer
    finallistNSalary = list(zip(WorkerID_NSalary, NSalary_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistNSalary:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Base Salary_Correction'] = tup[1]

    # WageN Equalizer
    finallistWageN = list(zip(WorkerID_WageN, WageN_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistWageN:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'EE-Wage tax_Correction'] = tup[1]

    # SolidarityN Equalizer
    finallistSolidarityN = list(zip(WorkerID_WageN, SolidarityN_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSolidarityN:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Solidarity Surcharge_Correction'] = tup[1]

    # UIContN Equalizer
    finallistUIContN = list(zip(WorkerID_UIContN, UIContN_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistUIContN:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'UI Contribution_Correction'] = tup[1]

    # PIContN Equalizer
    finallistPIContN = list(zip(WorkerID_UIContN, PIContN_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistPIContN:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'PI Contribution_Correction'] = tup[1]

    # SocialDN Equalizer
    finallistSocialDN = list(zip(WorkerID_UIContN, SocialDN_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSocialDN:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Social Security Deductions_Correction'] = tup[1]

    # ChurchTaxS Equalizer
    finallistChurchTaxS = list(zip(WorkerID_ChurchTaxS, ChurchTaxS_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistChurchTaxS:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Church Tax(S)'] = tup[1]

    # DirektV Equalizer
    finallistDV = list(zip(WorkerID_DV, DV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistDV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Direktversicherung'] = tup[1]

    # Basesalary.append('')

    # AGPV Equalizer
    finallistAGPV = list(zip(WorkerID_AGZuschussPV, AGZuschussPV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistAGPV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'AG-Zuschuss_zur_PV'] = tup[1]

    # AGPV Equalizer
    finallistBereits = list(zip(WorkerID_Bereits, Bereits_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBereits:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Bereits erhalten'] = tup[1]

    # Commission Equalizer
    finallistCommission = list(zip(WorkerID_Commission, Commission_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistCommission:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Commission'] = tup[1]

    # AGKV Equalizer
    finallistAGKV = list(zip(WorkerID_AGZuschussKV, AGZuschussKV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistAGKV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'AG-Zuschuss_zur_KV'] = tup[1]

    # FZ Equalizer
    finallistFZ = list(zip(WorkerID_FZ, FZ_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistFZ:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Freiwillige Zulage'] = tup[1]

    # SZ Equalizer
    finallistSZ = list(zip(WorkerID_Sonderzahlung, Sonderzahlung_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSZ:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Sonderzahlung'] = tup[1]

    # Unterstutzung Equalizer
    finallistUstutzung = list(zip(WorkerID_Unterstutzung, Unterstutzung_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistUstutzung:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Unterstützungskasse'] = tup[1]

    # GBKV Equalizer
    finallistGBKV = list(zip(WorkerID_GBKV, GBKV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistGBKV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Gesamtbeitrag_zur_KV'] = tup[1]

    # GBKV Equalizer
    finallistGBPV = list(zip(WorkerID_GBPV, GBPV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistGBPV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Gesamtbeitrag_zur_PV'] = tup[1]

    # Betrag911 Equalizer
    finallistBetrag911 = list(zip(WorkerID_Betrag911, Betrag911_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBetrag911:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Betr.AV.AN lfd.ST-frei'] = tup[1]

    # Betrag914 Equalizer
    finallistBetrag914 = list(zip(WorkerID_Betrag914, Betrag914_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBetrag914:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Betr.AV.AN lfd.Geh.Ver'] = tup[1]

    # Betrag901 Equalizer
    finallistBetrag901 = list(zip(WorkerID_Betrag901, Betrag901_Numpages))
    # print(finallistBetrag901)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBetrag901:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Betr.AV.AG_lfd.ST-frei'] = tup[1]

    # Car Equalizer
    finallistCarBenefit = list(zip(WorkerID_CarBenefit, CarBenefit_Numpages))
    finallistCarBenefitMinus = list(zip(WorkerID_CarBenefit, CarBenefitMinus_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistCarBenefit:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Privatfahrten/priv. use'] = tup[1]

    # CSP EQUALIZER
    finallistCSP = list(zip(WorkerID_CSP, CSP_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistCSP:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Correction Sick Pay'] = tup[1]

    # CSP EQUALIZER
    finallistCCI = list(zip(WorkerID_CCI, CCI_Numpages))
    for index, row in df.iterrows():
        for tup in finallistCCI:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Correction CI-ER'] = tup[1]

    finallistCHI = list(zip(WorkerID_CHI, CHI_Numpages))
    for index, row in df.iterrows():
        for tup in finallistCHI:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Correction HI-ER'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistCarBenefitMinus:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'car benefit/KFZ- Sachb.'] = tup[1]

    # UICont,PICont Equalizer
    finallistUICont = list(zip(WorkerID_UICont, UICont_Numpages))
    finallistPICont = list(zip(WorkerID_PICont, PICont_Numpages))
    finallistHICont = list(zip(WorkerID_HICont, HICont_Numpages))
    finallistCICont = list(zip(WorkerID_CICont, CICont_Numpages))

    # UICont,PICont Equalizer for E
    finallistUIContE = list(zip(WorkerID_UIContE, UIContE_Numpages))
    finallistPIContE = list(zip(WorkerID_PIContE, PIContE_Numpages))
    finallistHIContE = list(zip(WorkerID_HIContE, HIContE_Numpages))
    finallistCIContE = list(zip(WorkerID_CIContE, CIContE_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistUICont:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'UI Contribution'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistUIContE:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'UI Contribution(E)'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistUIContE:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'UI Contribution(E)'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistPICont:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'PI Contribution'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistPIContE:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'PI Contribution(E)'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistHICont:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'HI Contribution'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistHIContE:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'HI Contribution(E)'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistCICont:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'CI Contribution'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistCIContE:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'CI Contribution(E)'] = tup[1]

    finallistBAV = list(zip(WorkerIDBav, BavNumpages))
    for index, row in df.iterrows():
        for tup in finallistBAV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'bAV AG-Zus. lfd.ST-frei'] = tup[1]

    finallistBAVABZ = list(zip(WorkerIDBavAbz, BavABZNumpages))
    for index, row in df.iterrows():
        for tup in finallistBAVABZ:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'bAV-Abzug'] = tup[1]

    finallistFC = list(zip(WorkerID_FromCorrection, FC_Numpages))
    for index, row in df.iterrows():
        for tup in finallistFC:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'From Correction'] = tup[1]

    df["Period"] = pd.Series(Date, dtype=object)
    df["Worker Name"] = pd.Series(Employee, dtype=object)
    # df["Personal_BNr"] = pd.Series(PersonalBetriebNr, dtype=object)
    df['Base Salary'] = pd.Series(Basesalary, dtype=object)
    df["Total Gross Pay"] = pd.Series(TotalGrossIncome, dtype=object)
    # df["Commission"] = pd.Series(CommissionList, dtype=object)
    df["EE-Wage tax"] = pd.Series(WageTax, dtype=object)
    df["Total Net Pay"] = pd.Series(Netpay, dtype=object)
    # df["Betr.AV.AG_lfd.ST-frei"] = pd.Series(Betrag901, dtype=object)
    df["Social Security Deductions"] = pd.Series(SocialD, dtype=object)
    df["Contr. Group"] = pd.Series(Cont, dtype=object)
    df["Emp.Soc.Sec"] = pd.Series(EmpSocSec, dtype=object)
    df["ER Cost. Add"] = pd.Series(Emp, dtype=object)
    df["ER Total Cost"] = pd.Series(AGsocial, dtype=object)  # Jai remplacé parce que cest la meme
    df["Worker ID"] = pd.Series(PersonalBetriebNr, dtype=object)
    #####################################ESSAI POUR DICTIONNAIRE######################################################
    dfempty = pd.DataFrame([[np.nan] * len(df.columns)], columns=df.columns)  # emptycolumn

    df2 = {
        "Company": '',
        "Period": '',
        "Worker ID": '',
        "Worker Name": 'TOTAL',
        "Worker Cost Center": '',
        "Car allowance": '',
        "Expense reimbursement": '',
        "Private Nurse Insurance": '',
        "Total Gross Pay": totalTGI,
        "EE-Unemployment": '',
        "EE-Social Security": '',
        "EE-Wage tax": totalWage,
        "Phone Reimbursement": '',
        "EE-Private Savings": '',
        "Total Net Pay": totalNet,
        "ER-Unemployment": '',
        "ER-Social Security": '',
        "Social Security": '',
        "Private Nurse Insurance": '',
        "Private Savings": '',
        "Total ER Contributions": '',
        "Total ER Cost": ''
    }

    # print(Uberstunde)
    # print(CommissionList)
    # Remove duplicates based on a specific column

    # print(df.head(5))
    # print(df.to_markdown())

    # Créer un nouveau classeur Excel
    wb = Workbook()
    ws = wb.active

    # Ajouter l'en-tête du DataFrame à la feuille Excel
    header_row = df.columns.tolist()
    ws.append(header_row)

    # Ajouter les données du DataFrame à la feuille Excel
    for row in dataframe_to_rows(df, index=False, header=False):
        ws.append(row)

    # Appliquer un formatage numérique explicite (pour gérer les virgules décimales)
    for row in ws.iter_rows(min_row=2, min_col=2, max_col=2):  # Colonne des montants
        for cell in row:
            if isinstance(cell.value, (int, float)):
                cell.number_format = "#,##0.00"  # Format numérique

    # Ajouter un style à la ligne d'en-tête
    for cell in ws[1]:
        cell.font = Font(underline='single', bold=True)
        cell.fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")

    # Ajuster la largeur des colonnes
    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            if cell.value:
                max_length = max(max_length, len(str(cell.value)))
        adjusted_width = (max_length + 2) * 1.2
        ws.column_dimensions[column_letter].width = adjusted_width

    # Enregistrer le fichier Excel
    # wb.save('C:/Users/PK.MbeleSamba/Desktop/G2N_report_Landa_09.xlsx')# Créer un nouveau classeur Excel
    wb = Workbook()
    ws = wb.active

    # Ajouter l'en-tête du DataFrame à la feuille Excel
    header_row = df.columns.tolist()
    ws.append(header_row)

    # Ajouter les données du DataFrame à la feuille Excel
    # Pas de manipulation explicite des nombres ici
    for row in dataframe_to_rows(df, index=False, header=False):
        ws.append(row)

    # Appliquer un style à la ligne d'en-tête
    for cell in ws[1]:
        cell.font = Font(underline='single', bold=True)
        cell.fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")

    # Ajuster la largeur des colonnes
    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            if cell.value:
                max_length = max(max_length, len(str(cell.value)))
        adjusted_width = (max_length + 2) * 1.2
        ws.column_dimensions[column_letter].width = adjusted_width
    # Insérer les valeurs en s'assurant qu'elles sont bien en nombre

    # df = df.apply(lambda col: pd.to_numeric(col.str.replace(',', '.'), errors='ignore') if col.dtype=='str' and col.str.contains(',').any() else col)
    # Récupérer la première ligne (les en-têtes)
    # Récupérer la première ligne (les en-têtes)
    header = [cell.value for cell in ws[1]]

    # Déterminer l'indice (1-based) de la colonne "Base Salary"
    try:
        start_col = header.index("Base Salary") + 1
    except ValueError:
        print("La colonne 'Base Salary' n'a pas été trouvée dans l'en-tête.")
        start_col = None

    if start_col is not None:
        # Parcourir toutes les lignes à partir de la 2ème ligne (en-tête exclu)
        for row in ws.iter_rows(min_row=2):
            for col in range(start_col, ws.max_column + 1):
                cell = row[col - 1]  # L'indexation Python commence à 0

                # Si la cellule contient une chaîne (donc pas encore convertie en nombre)
                if cell.value is not None and isinstance(cell.value, str):
                    # Nettoyer la valeur : supprimer les espaces et remplacer la virgule par un point
                    valeur_str = cell.value.strip().replace(" ", "").replace(",", ".")
                    try:
                        # Convertir en float
                        cell.value = float(valeur_str)
                    except ValueError:
                        print(f"Conversion impossible pour la cellule {cell.coordinate} avec la valeur '{cell.value}'")

        # Appliquer le format numérique aux cellules déjà en nombre
        for row in ws.iter_rows(min_row=2):
            for col in range(start_col, ws.max_column + 1):
                cell = row[col - 1]

                # Vérifier si la cellule est un nombre valide
                if isinstance(cell.value, (int, float)) and not math.isnan(cell.value):
                    # Ne pas convertir en texte, juste appliquer un format d'affichage
                    cell.number_format = "0.00"

                # Facultatif : vous pouvez forcer le type texte en ajoutant une apostrophe (mais cela affichera l'apostrophe dans certaines configurations)
            # cell.value = "'" + format(cell.value, '.2f')

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path(
        user_id=user_id,
        data_conversion="Papaya",
        conversion="UBC",
        task_id=task.request.id,
        extension="xlsx",
    )

    ensure_output_folder(output_path)

    wb.save(output_path)

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Papaya",
    conversion="Lipton",
    description="Papaya Lipton conversion",
    input_type={
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["pdf"],
            },
        ),
    },
    output_type="xlsx",
)

def papaya_lipton(task, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file = files[0]

    ################################ REGULARY EXPRESSION FOR ALL THE RESEARCH IN THE PDF FILES ########################################################

    name = re.compile(
        r'(?P<first_name>[A-ZÄÖÜ][a-zäöüß]+)\s(?P<last_name>[A-ZÄÖÜ][a-zäöüß-]+(?:\s(?:von|von der|van der))?)(?:\s(?P<suffix>(?<=\s)[JS]r\.|I{1,3}))?')  # Regular expression for all name

    Companyname = re.compile(r'GmbH|Gm')  # Regular expression for company name

    Base_Salary = re.compile(
        r'200\sSalary/Gehalt|Gehalt/Salary|100\sStundenlohn|102\sGehalt')  # Regular expression for gehalt

    TGI = re.compile(r'Tax/Social')  # Regular expression for social

    Net = re.compile(r'Acc.no')  # Regular expression for net pay

    BAV_re = re.compile(r"891 bAV AG-Zus. lfd.ST-frei")

    # NetIncome=re.compile(r'^Statement of earnings')

    Wage = re.compile(r'(^L|^N\s1.)')  # Regular expression for Wage Tax and Tax Deduction
    WageS = re.compile(r'^S\s\d')
    WageE = re.compile(r'^E\s\d')

    Car = re.compile(r'Privatfahrten/priv. use')  #

    CarAllowance = re.compile(r'^201 Car Allowance')

    Commission = re.compile(r'^011\sPrämie')

    Period = re.compile(r'^Pay Advice')

    ID = re.compile(r'^000|^0000')

    Uberstd = re.compile('Überstdgrundvergütung')
    Uberstd2 = re.compile('^N\s002')
    WeekendSamstag = re.compile('090 weekend work 150% Satu.')
    WeekendSonntag = re.compile('092 weekend work 150% Sund. ')

    BetragAVAG = re.compile(r'901 Betr.AV.AG lfd.ST-frei')
    BetragAVAGEBZ = re.compile(r'Betr.AV.AG EBZ ST-frei')
    BetragAVANST = re.compile(r'911 Betr.AV.AN lfd.ST-frei')
    BetragAVANGE = re.compile('914 Betr.AV.AN lfd.Geh.Ver ')

    PV = re.compile(r'AG-Zuschuss zur PV')

    KV = re.compile(r'AG-Zuschuss zur KV')

    GBzurPV = re.compile(r'Gesamtbeitrag zur PV')

    GBzurKV = re.compile(r'Gesamtbeitrag zur KV')

    HO = re.compile(r'Home Office')

    Contrgroup = re.compile(r'^\d{8}\w\d{3}')
    # Kirche=re.compile(r'Home Office')
    HIincome = re.compile(r'^Tax. ')

    CI24 = re.compile('^Solidarity surcharge')

    PIline = re.compile('^Wage tax')

    UIline = re.compile('^Church tax')

    Bonuslfd = re.compile('Bonus lfd.')
    BonusEBZ = re.compile('009 Bonus EBZ')

    RAllowance = re.compile('Residence Allowance')
    RAllowanceNet = re.compile('119\sResidence Allowance net')

    PrivateLI = re.compile('priv. liability insura. ')

    PrivateHI = re.compile('priv. household insura. ')

    Direkt = re.compile('Direktversicherung')

    AGzuschussPV0 = re.compile('9983 AG-Zuschuss zur PV')

    AGzuschussKV0 = re.compile('9995 AG-Zuschuss zur KV')

    Bereits = re.compile('9079 bereits erhalten')

    lineitemsw = re.compile('^Tx')

    Correction = re.compile('From correction')

    CorrectionSickPay = re.compile('300 Correction 05-Sick Pay')

    CorrectionCI = re.compile(' 9091 Corr. CI-ER May ')

    CorrectionHI = re.compile(' 9090 Corr. HI-ER May')

    FreiwilligeZuschlage = re.compile('Freiwillige Zulage')

    Sonderzahlung = re.compile(' Sonderzahlung zusätzl.')

    Unterstutzung = re.compile('9001\sUnterstützungskasse')

    Mutterschaft = re.compile('859 Muttersch.geldzuschuss')

    PersonalBetrieb = re.compile(r'^\*\s\d{6}\*')

    #######################################FUNCTION###############################################

    def extract_UI(line_items, indicators):
        for ind in indicators:
            if ind in line_items:
                idx = line_items.index(ind)
                if idx > 0:
                    value = line_items[idx - 1]
                    value = f"{value[:-2]},{value[-2:]}"
                    return value.replace('.', '')
        return None

    def extract_value_before(line_items, indicators, offset):
        for ind in indicators:
            if ind in line_items:
                idx = line_items.index(ind)
                if idx >= offset:
                    return line_items[idx - offset]
        return None

    def extract_value_after(line_items, indicators, offset=1):
        for ind in indicators:
            if ind in line_items:
                idx = line_items.index(ind)
                if idx + offset < len(line_items):
                    return line_items[idx + offset]
        return None

    ################################  DECLARATION OF ALL THE LIST ###################################################################

    Company = []
    Employee = []
    Basesalary = []
    Basesalary2 = []  # Pour le total
    TotalGrossIncome = []
    MitarbeiterID = []
    Netpay = []
    WageTax = []
    WageTaxS = []
    WageTaxE = []
    CarBenefit = []
    CarBenefitMinus = []
    CommissionList = []
    Date = []

    Uberstunde = []
    SaturdayWork = []
    SundayWork = []

    Betrag901 = []
    Betrag906 = []
    Betrag911 = []
    Betrag914 = []
    AGZuschussKV = []
    AGZuschussPV = []
    BereitsErhalten = []
    GBKV = []
    GBPV = []
    Homeoffice = []
    ChurchTax = []
    ChurchTaxS = []
    Solidarity = []
    SolidarityS = []
    SocialD = []
    AGsocial = []
    CIcont = []
    PICont = []
    UICont = []
    HICont = []
    CIcontE = []
    PIContE = []
    UIContE = []
    HIContE = []
    EmpSocSec = []
    Bav_list = []
    Cont = []
    ERTotalCost = []
    Emp = []
    Bonus = []
    BonusEBZlist = []
    Resid = []
    ResidNet = []
    PLI = []
    PHI = []
    DV = []
    PersonalBetriebNr = []
    linewage = []
    linetitlewage = []
    FromCorrection = []
    CorrectionSickPayList = []
    CorrectionHIlist = []
    CorrectionCIlist = []
    FZList = []
    SonderzahlunglIST = []
    UnterstutzungLIST = []
    Muttergeldlist = []

    #############################################  RESEARCH START AND INCORPORATION OF ALL AMOUNT AND NAME IN LIST   ####################################

    with (pdfplumber.open(file) as pdf):
        for num_page, page in enumerate(pdf.pages, start=1):
            # Récupération du contenu de la page
            text = page.extract_text()
            # print(text)
            if text and "(1.C)" in text:
                continue  # Ignore la page et passe à la suivante
            elif text and "(2.C)" in text:
                continue
            elif text and "Probeabrechnung" in text:
                continue

            lang = langid.classify(text)[0]

            # print(text)
            for line in text.split('\n'):

                if name.search(line):

                    # elif not Car.search(line):
                    # CarBenefit.append('')
                    line_items_name = line.split()
                    if len(line_items_name) <= 3 and "Straße" not in line_items_name \
                            and "Weg" not in line_items_name \
                            and "Security" not in line_items_name \
                            and "Sozialversicherungspflichtiges" not in line_items_name \
                            and "Verdienstbescheinigung" not in line_items_name \
                            and "Pfändung" not in line_items_name \
                            and "Darlehen" not in line_items_name \
                            and "Commerzbank" not in line_items_name \
                            and "Landstr." not in line_items_name \
                            and "Landstraße" not in line_items_name \
                            and "Auf" not in line_items_name \
                            and "Str." not in line_items_name \
                            and "Str" not in line_items_name \
                            and "Stephansweg" not in line_items_name \
                            and "Ufer" not in line_items_name \
                            and "Damm" not in line_items_name \
                            and "Bad" not in line_items_name \
                            and 'Csepella,' not in line_items_name:
                        filtered_list = [item for item in line_items_name if
                                         not item[-1].replace(',', '').replace('.', '').isdigit()]
                        Mitarbeiter = ' '.join(filtered_list)
                        Employee.append(Mitarbeiter)
                        # print(Mitarbeiter)

                if Companyname.search(line):
                    line_items_company = line.split()
                    company_info = line_items_company[0]
                    name_part = company_info.split('Gm')[0]
                    spaced_name = ' '.join(re.findall(r'[A-Z][a-z]+|\([^)]+\)', name_part))
                    company_name = spaced_name + ' GmbH'
                    Company.append(company_name)
                    # print(company_name)

                if Base_Salary.search(line):
                    line_items_base = line.split()
                    BaseS2 = (line_items_base[-1].replace('.', '').replace('-', ''), num_page)
                    Basesalary.append(BaseS2)
                    # print(line_items_base)

                if Period.search(line):
                    line_items_Period = line.split()
                    month = ' '.join(line_items_Period[3:5])
                    Date.append(month)

                if ID.search(line):
                    line_items_ID = line.split()
                    # month=' '.join(line_items_Period[3:5])
                    # print(line_items_ID)
                    MitarbeiterID.append(line_items_ID[0])

                if Contrgroup.search(line):
                    line_items_Cont = line.split()

                    # print(line_items_Cont)
                    if line_items_Cont[-1] == '30':
                        Cont.append(line_items_Cont[-3])
                    else:
                        Cont.append(line_items_Cont[-2])

                if FreiwilligeZuschlage.search(line):
                    line_items_FZ = line.split()
                    FZ = (line_items_FZ[-1].replace('.', ''), num_page)
                    FZList.append(FZ)
                    # print(line_items_FZ)

                if Sonderzahlung.search(line):
                    line_items_SZ = line.split()
                    SZ = (line_items_SZ[-1].replace('.', ''), num_page)
                    SonderzahlunglIST.append(SZ)

                if Unterstutzung.search(line):
                    line_items_UnterS = line.split()
                    UStzung = (line_items_UnterS[-1].replace('.', ''), num_page)
                    UnterstutzungLIST.append(UStzung)

                if BetragAVAG.search(line):
                    line_items_Betrag = line.split()
                    # print(line_items_Betrag)
                    BetragAVAGlfd = (line_items_Betrag[-1].replace('-', '').replace('.', ''), num_page)
                    # print(BetragAVAGlfd)
                    Betrag901.append(BetragAVAGlfd)

                if BetragAVAGEBZ.search(line):
                    line_items_Betragebz = line.split()
                    # print(line_items_Betrag)
                    BetragAVAGebz = (line_items_Betrag[-1].replace('-', '').replace('.', ''), num_page)
                    # print(BetragAVAGlfd)
                    Betrag906.append(BetragAVAGebz)

                if BetragAVANST.search(line):
                    line_items_Betrag = line.split()
                    BetragANAm = (line_items_Betrag[-1].replace('-', ''), num_page)
                    Betrag911.append(BetragANAm)

                if BetragAVANGE.search(line):
                    line_items_BetragGE = line.split()
                    # print(line_items_BetragGE)
                    BetragANAmGe = ('-' + line_items_BetragGE[-1].replace('-', ''), num_page)
                    Betrag914.append(BetragANAmGe)

                    # print(Uberstunde)

                if GBzurPV.search(line):
                    line_items_GBPV = line.split()
                    GBPVAmount = ('-' + line_items_GBPV[-1].replace('-', ''), num_page)
                    # print(line_items_GBPV)
                    GBPV.append(GBPVAmount)

                if GBzurKV.search(line):
                    line_items_GBKV = line.split()
                    # print(line_items_GBKV)
                    GBKVAmount = ('-' + line_items_GBKV[-1].replace('-', ''), num_page)
                    # print(line_items_GBPV)
                    GBKV.append(GBKVAmount)

                if AGzuschussKV0.search(line):
                    line_items_ZuschussKV = line.split()
                    # print(line_items_ZuschussKV)
                    AGKV = (line_items_ZuschussKV[-1].replace('-', '').replace('.', ''), num_page)
                    AGZuschussKV.append(AGKV)

                if Direkt.search(line):
                    line_items_DV = line.split()
                    # print(line_items_DV)
                    DVamount = ('-' + line_items_DV[-1].replace('-', '').replace('.', ''), num_page)
                    DV.append(DVamount)

                if Mutterschaft.search(line):
                    line_items_Mutterschaft = line.split()
                    # print(line_items_DV)
                    Muttergeld = ('-' + line_items_Mutterschaft[-1].replace('-', '').replace('.', ''), num_page)
                    Muttergeldlist.append(Muttergeld)

                if AGzuschussPV0.search(line):
                    line_items_ZuschussPV = line.split()
                    AGPV = (line_items_ZuschussPV[-1].replace('-', '').replace('.', ''), num_page)
                    AGZuschussPV.append(AGPV)

                if TGI.search(line):
                    line_items_tgi = line.split()
                    TotalGrossIncome.append(line_items_tgi[-1].replace('.', ''))
                    # print(line_items_tgi)
                    # print(line_items_base)
                if Net.search(line):
                    line_items_net = line.split()
                    # print(line_items_net)
                    if "pay" and "advice." not in line_items_net:
                        # del line_items_net

                        if len(line_items_net[-2]) > 3:
                            AG = line_items_net[-2].replace('.', '').replace('-', '')
                            AG = f"{AG[:-2]},{AG[-2:]}"
                            AGsocial.append(AG)

                            ERTotalCost.append(line_items_net[-2].replace('.', '').replace('-', ''))
                            EmpSoc = line_items_net[-3].replace('.', '').replace('-', '')
                            EmpSoc = f"{EmpSoc[:-2]},{EmpSoc[-2:]}"
                            Emp.append(EmpSoc)

                            EmpSocSec2 = line_items_net[-4].replace('.', '').replace('-', '')

                            EmpSocSec2 = f"{EmpSocSec2[:-2]},{EmpSocSec2[-2:]}"
                            if len(line_items_net[-4]) == 2:
                                EmpSocSec2 = '0,00'
                                # EmpSocSec.append(EmpSocSec2)
                            # print(EmpSocSec2)
                            EmpSocSec.append(EmpSocSec2)
                        # elif line_items_net[-4] =='06':
                        # EmpSocSec.append('0,00')

                        else:
                            AGsocial.append('')

                        # AGsocial.append(line_items_net[-2].replace('.','').replace('-',''))
                        # print(line_items_net)
                        Netpay.append(line_items_net[-1].replace('.', '').replace('-', ''))

                if PersonalBetrieb.search(line):
                    line_items_PBNr = line.split()
                    # print(line_items_PBNr)
                    PersonalBetriebNr.append(line_items_PBNr[1].replace('*', ''))

                if Wage.search(line):
                    line_items_Wage = line.split()
                    # print(line_items_Wage)

                    # print(line_items_Wage)
                    if line_items_Wage[
                        0] == 'L' and '773,80' not in line_items_Wage and 'Z' not in line_items_Wage:  # FAIRE EN SORTE DAVOIR LES HI COMTRIBUTIONS
                        # print(line_items_Wage)

                        if len(line_items_Wage) > 2 and line_items_Wage[2] != line_items_Wage[1] and \
                                line_items_Wage[3] != line_items_Wage[2]:
                            # print(line_items_Wage)
                            Wage2 = line_items_Wage[2]

                            # print(Sol2)
                            # Format with one comma before the last two numbers
                            Wage2 = f"{Wage2[:-2]},{Wage2[-2:]}"
                            WageTax.append(Wage2.replace('.', ''))
                            # print(Wage2)

                            if len(line_items_Wage) == 5:

                                # Solidarity.append(Solidarity2)

                                if len(line_items_Wage[2]) >= len(line_items_Wage[3]) and int(
                                        line_items_Wage[-1].replace(".", "").replace(",", "")) < 200000:
                                    churchtax2 = line_items_Wage[-2]
                                    churchtax2 = f"{churchtax2[:-2]},{churchtax2[-2:]}"
                                    churchtax2 = (churchtax2, num_page)
                                    ChurchTax.append(churchtax2)
                                elif len(line_items_Wage[2]) >= len(line_items_Wage[3]) and int(
                                        line_items_Wage[-1].replace(".", "").replace(",", "")) > 200000:
                                    Solidarity2 = line_items_Wage[-2]
                                    Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                    Solidarity2 = (Solidarity2, num_page)
                                    Solidarity.append(Solidarity2)
                            elif len(line_items_Wage) == 6 and len(line_items_Wage[-2]) == 3:
                                Solidarity2 = line_items_Wage[-2]
                                Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                Solidarity2 = (Solidarity2, num_page)
                                Solidarity.append(Solidarity2)
                            elif len(line_items_Wage) == 5 and len(line_items_Wage[2]) - len(
                                    line_items_Wage[3]) == 1 and line_items_Wage[-2] < "15000":
                                churchtax2 = line_items_Wage[-2]
                                churchtax2 = f"{churchtax2[:-2]},{churchtax2[-2:]}"
                                churchtax2 = (churchtax2, num_page)
                                ChurchTax.append(churchtax2)
                            elif len(line_items_Wage) == 5 and len(line_items_Wage[2]) - len(
                                    line_items_Wage[-1]) == 1 and line_items_Wage[-2] > "15000":
                                Solidarity2 = line_items_Wage[-2]
                                Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                Solidarity2 = (Solidarity2, num_page)
                                Solidarity.append(Solidarity2)

                            elif len(line_items_Wage) == 6:
                                Solidarity2 = line_items_Wage[-2]
                                Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                Solidarity2 = (Solidarity2, num_page)
                                Solidarity.append(Solidarity2)

                                churchtax2 = line_items_Wage[-3]
                                churchtax2 = f"{churchtax2[:-2]},{churchtax2[-2:]}"
                                churchtax2 = (churchtax2, num_page)
                                ChurchTax.append(churchtax2)

                                # print(churchtax2)





                        elif len(line_items_Wage) == 2:  # KEY MARCUS MOSS
                            # WageTax.append('')
                            SocialD.append('')
                            # Basesalary.append('0')
                            # UICont.append('')
                            # 0PICont.append('')

                    if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                            (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                2]) and len(line_items_Wage) > 4:
                        # print(line_items_Wage)
                        SocialD.append(line_items_Wage[-1].replace('.', ''))

                        # else:
                        # SocialD.append('')
                        # print(line_items_Wage)
                        # SocialD.append(line_items_Wage[-1])
                        if len(line_items_Wage) == 6:
                            # print(line_items_Wage)
                            UI = line_items_Wage[-2].replace('-', '')
                            UI = f"{UI[:-2]},{UI[-2:]}"
                            UI = (UI.replace('.', ''), num_page)

                            PI = line_items_Wage[-3].replace('-', '')
                            PI = f"{PI[:-2]},{PI[-2:]}"
                            PI = (PI.replace('.', ''), num_page)

                            # UI = f"{UI[:-2]},{UI[-2:]}"

                            # AGPV = (line_items_ZuschussPV[-1].replace('-', '').replace('.', ''), num_page)
                            UICont.append(UI)
                            PICont.append(PI)


                        elif 'Z' in line_items_Wage or 'E' in line_items_Wage or '1' in line_items_Wage or '2' in line_items_Wage or '3' in line_items_Wage or '4' in line_items_Wage:

                            # print(line_items_Wage)
                            UI = extract_UI(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'])

                            UI = f"{UI[:-2]},{UI[-2:]}"
                            UI = UI.replace(',,', ',')

                            UI = (UI.replace('.', ''), num_page)

                            PI = extract_value_before(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'], 2)
                            PI = f"{PI[:-2]},{PI[-2:]}"
                            PI = (PI.replace('.', ''), num_page)

                            if len(line_items_Wage) > 7:
                                HI = extract_value_before(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'], 3)

                                HI = f"{HI[:-2]},{HI[-2:]}"
                                HI = (HI.replace('.', ''), num_page)
                                HICont.append(HI)

                                CI = extract_value_after(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'], 1)

                                CI = f"{CI[:-2]},{CI[-2:]}"
                                CI = (CI.replace('.', ''), num_page)
                                CIcont.append(CI)

                            # UI = f"{UI[:-2]},{UI[-2:]}"
                            # PI = f"{PI[:-2]},{PI[-2:]}"
                            # SocialD.append(line_items_Wage[-1])

                            UICont.append(UI)
                            PICont.append(PI)



                        elif len(line_items_Wage) >= 9:
                            # print(line_items_Wage)
                            UI = line_items_Wage[-3]
                            UI = f"{UI[:-2]},{UI[-2:]}"
                            UI = (UI.replace('.', ''), num_page)

                            PI = line_items_Wage[-4]
                            PI = f"{PI[:-2]},{PI[-2:]}"
                            PI = (PI.replace('.', ''), num_page)

                            HI = line_items_Wage[-6]
                            HI = f"{HI[:-2]},{HI[-2:]}"
                            HI = (HI.replace('.', ''), num_page)

                            CI = line_items_Wage[-2]
                            CI = f"{CI[:-2]},{CI[-2:]}"
                            CI = (CI.replace('.', ''), num_page)

                            # UI = f"{UI[:-2]},{UI[-2:]}"
                            # PI = f"{PI[:-2]},{PI[-2:]}"
                            UICont.append(UI)
                            PICont.append(PI)
                            HICont.append(HI)
                            CIcont.append(CI)

    ########################TAKE ALL THE PAGE NUMBER FOR COMMISSION################################

    df = pd.DataFrame(columns=["Company", "Period", "Worker ID", "Worker Name", "Contr. Group", "Base Salary"
        , "Commission", "Home_Office", "Überstdgrundvergütung", "Weekend Work Saturday", "Weekend Work Sunday",
                               "Betr.AV.AG_lfd.ST-frei", "Betr.AV.AN lfd.ST-frei", "Betr.AV.AG EBZ ST-frei",
                               "Betr.AV.AN lfd.Geh.Ver", 'Freiwillige Zulage'
        , 'Unterstützungskasse', 'Mutterschaft Geldzuschuss', 'Sonderzahlung',
                               "Privatfahrten/priv. use", "Bonus lfd.", "Bonus EBZ", "Residence Allowance",
                               "Residence Allowance Net",
                               "Private household insurance", "Private liability insurance",
                               "Total Gross Pay",
                               "Church Tax", "Church Tax(S)", "Solidarity Surcharge", "Solidarity Surcharge (S)",
                               "EE-Wage tax", "EE-Wage tax (S)",
                               "CI Contribution", "CI Contribution(E)",
                               "HI Contribution", "HI Contribution(E)",
                               "PI Contribution", "PI Contribution(E)",
                               "UI Contribution", "UI Contribution(E)",
                               "Social Security Deductions",
                               "car benefit/KFZ- Sachb.", "Bereits erhalten", "AG-Zuschuss_zur_PV",
                               "AG-Zuschuss_zur_KV",
                               "Gesamtbeitrag_zur_PV",
                               "Gesamtbeitrag_zur_KV", 'Direktversicherung', "Private Savings", "ER-Unemployment",
                               "Emp.Soc.Sec",
                               "ER Cost. Add", "ER Total Cost", "From Correction",
                               "Total Net Pay"])

    common_index = range(len(Employee))  # si 'Employee' est la plus longue
    df["Worker Name"] = pd.Series(Employee, index=common_index, dtype=object)
    # df["Base Salary"] = pd.Series(Basesalary2, dtype=object)

    df["Company"] = pd.Series(Company, index=common_index, dtype=object)
    df["Worker ID"] = pd.Series(MitarbeiterID, index=common_index, dtype=object)
    df["From Correction"] = pd.Series(FromCorrection, dtype=object)
    df["Period"] = pd.Series(Date, dtype=object)
    # df["Worker Name"] = pd.Series(Employee, dtype=object)
    # df['Base Salary'] = np.where(df['Worker Name'] == 'TOTAL', total, df['Base Salary'])
    df["Total Gross Pay"] = pd.Series(TotalGrossIncome, dtype=object)
    # df["Commission"] = pd.Series(CommissionList, dtype=object)
    df["EE-Wage tax"] = pd.Series(WageTax, dtype=object)
    df["Total Net Pay"] = pd.Series(Netpay, dtype=object)
    # df["Betr.AV.AG_lfd.ST-frei"] = pd.Series(Betrag901, dtype=object)
    df["Social Security Deductions"] = pd.Series(SocialD, dtype=object)
    df["Contr. Group"] = pd.Series(Cont, dtype=object)
    df["Emp.Soc.Sec"] = pd.Series(EmpSocSec, dtype=object)
    df["ER Cost. Add"] = pd.Series(Emp, dtype=object)
    df["ER Total Cost"] = pd.Series(AGsocial, dtype=object)  # Jai remplacé parce que cest la meme
    # df["Worker ID"] = pd.Series(PersonalBetriebNr,index=common_index, dtype=object)

    ## TAKE ALL THE PAGE NUMBER FOR UnterstutzungList
    Num_pages29 = [tup[-1] for tup in UnterstutzungLIST]
    # print(Num_pages5)
    WorkerID_Unterstutzung = []
    Unterstutzung_Numpages = []

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages29:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "Probeabrechnung" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_UnterStutzungid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Unterstutzung.append(line_items_UnterStutzungid2[0])
                        # print(line_items_Solidarityid2)
                    if Unterstutzung.search(line):
                        line_items_Unterstutzung2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Unterstutzung_Numpages.append(
                            '-' + line_items_Unterstutzung2[-1].replace('.', '').replace('-', ''))

    ## TAKE ALL THE PAGE NUMBER FOR UnterstutzungList
    Num_pages1 = [tup[-1] for tup in Muttergeldlist]
    # print(Num_pages5)
    WorkerID_Muttergeld = []
    Muttergeld_Numpages = []

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages1:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "Probeabrechnung" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Mutterid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Muttergeld.append(line_items_Mutterid2[0])
                        # print(line_items_Solidarityid2)
                    if Mutterschaft.search(line):
                        line_items_Mutter2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Muttergeld_Numpages.append(line_items_Mutter2[-1].replace('.', '').replace('-', ''))

    ## TAKE ALL THE PAGE NUMBER FOR SonderzahlungList
    Num_pages30 = [tup[-1] for tup in SonderzahlunglIST]
    # print(Num_pages5)
    WorkerID_Sonderzahlung = []
    Sonderzahlung_Numpages = []

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages30:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Sonderzahlungid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Sonderzahlung.append(line_items_Sonderzahlungid2[0])
                        # print(line_items_Solidarityid2)
                    if Sonderzahlung.search(line):
                        line_items_Sonderzahlung2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Sonderzahlung_Numpages.append(line_items_Sonderzahlung2[-1].replace('.', ''))

    ## TAKE ALL THE PAGE NUMBER FOR FraiwilligZuschlageList
    Num_pages31 = [tup[-1] for tup in FZList]
    # print(Num_pages5)
    WorkerID_FZ = []
    FZ_Numpages = []

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages31:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_FZid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_FZ.append(line_items_FZid2[0])
                        # print(line_items_Solidarityid2)
                    if FreiwilligeZuschlage.search(line):
                        line_items_FZ2 = line.split()
                        # DV2=line_items_DV2[-1]
                        FZ_Numpages.append(line_items_FZ2[-1].replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Betrag911
    Num_pages20 = [tup[-1] for tup in Betrag911]
    # print(Num_pages5)
    WorkerID_Betrag911 = []
    Betrag911_Numpages = []

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages20:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_911id2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Betrag911.append(line_items_911id2[0])
                        # print(line_items_Solidarityid2)
                    if BetragAVANST.search(line):
                        line_items_AVAN2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Betrag911_Numpages.append(line_items_AVAN2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Betrag914
    Num_pages21 = [tup[-1] for tup in Betrag914]
    # print(Num_pages5)
    WorkerID_Betrag914 = []
    Betrag914_Numpages = []

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages21:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_914id2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Betrag914.append(line_items_914id2[0])
                        # print(line_items_Solidarityid2)
                    if BetragAVANGE.search(line):
                        line_items_AVANGE2 = line.split()
                        # print(line_items_AVANGE2)
                        Betrag914_Numpages.append('-' + line_items_AVANGE2[-1].replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Betrag901
    Num_pages21b = [tup[-1] for tup in Betrag901]
    # print(Num_pages5)
    WorkerID_Betrag901 = []
    Betrag901_Numpages = []

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages21b:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_901id2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Betrag901.append(line_items_901id2[0])
                        # print(WorkerID_Betrag901)
                    if BetragAVAG.search(line):
                        line_items_AVAGE2 = line.split()
                        # print(line_items_AVAGE2)
                        Betrag901_Numpages.append(line_items_AVAGE2[-1].replace('-', '').replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Betrag906
    Num_pages21b2 = [tup[-1] for tup in Betrag906]
    # print(Num_pages5)
    WorkerID_Betrag906 = []
    Betrag906_Numpages = []

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages21b2:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_906id2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Betrag906.append(line_items_906id2[0])
                        # print(WorkerID_Betrag901)
                    if BetragAVAGEBZ.search(line):
                        line_items_AVAGEBZ2 = line.split()
                        # print(line_items_AVAGE2)
                        Betrag906_Numpages.append(line_items_AVAGEBZ2[-1].replace('-', '').replace('.', ''))

    ### TAKE ALL THE PAGE NUMBER FOR GBzurKV
    Num_pages17 = [tup[-1] for tup in GBKV]
    # print(Num_pages5)
    WorkerID_GBKV = []
    GBKV_Numpages = []

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages17:
                # Récupération du contenu de la page
                text = page.extract_text()

                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_GBKVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_GBKV.append(line_items_GBKVid2[0])
                        # print(line_items_Solidarityid2)
                    if GBzurKV.search(line):
                        line_items_GBKV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        GBKV_Numpages.append('-' + line_items_GBKV2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR GBzurPV
    Num_pages18 = [tup[-1] for tup in GBPV]
    # print(Num_pages5)
    WorkerID_GBPV = []
    GBPV_Numpages = []

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages18:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_GBPVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_GBPV.append(line_items_GBPVid2[0])
                        # print(line_items_Solidarityid2)
                    if GBzurPV.search(line):
                        line_items_GBPV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        GBPV_Numpages.append('-' + line_items_GBPV2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR AGzuschussPV
    Num_pages11 = [tup[-1] for tup in AGZuschussPV]
    # print(Num_pages5)
    WorkerID_AGZuschussPV = []
    AGZuschussPV_Numpages = []

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages11:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_AGPVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_AGZuschussPV.append(line_items_AGPVid2[0])
                        # print(line_items_Solidarityid2)
                    if AGzuschussPV0.search(line):
                        line_items_AGPV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        AGZuschussPV_Numpages.append(line_items_AGPV2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR AGzuschussKV
    Num_pages12 = [tup[-1] for tup in AGZuschussKV]
    # print(Num_pages5)
    WorkerID_AGZuschussKV = []
    AGZuschussKV_Numpages = []

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages12:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_AGKVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_AGZuschussKV.append(line_items_AGKVid2[0])
                        # print(line_items_Solidarityid2)
                    if AGzuschussKV0.search(line):
                        line_items_AGKV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        AGZuschussKV_Numpages.append(line_items_AGKV2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Direktversicherung
    Num_pages9 = [tup[-1] for tup in DV]
    # print(Num_pages5)
    WorkerID_DV = []
    DV_Numpages = []

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages9:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_DVid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_DV.append(line_items_DVid2[0])
                        # print(line_items_Solidarityid2)
                    if Direkt.search(line):
                        line_items_DV2 = line.split()
                        # DV2=line_items_DV2[-1]
                        DV_Numpages.append('-' + line_items_DV2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR Base Salary
    Num_pages10 = [tup[-1] for tup in Basesalary]
    # print(Num_pages5)
    WorkerID_BaseSalary = []
    Basesalary_Numpages = []

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages10:
                # Récupération du contenu de la page
                text = page.extract_text()
                if text and "(1.C)" in text:
                    continue
                elif text and "(2.C)" in text:
                    continue
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Baseid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_BaseSalary.append(line_items_Baseid2[0])
                        # print(line_items_Solidarityid2)
                    if Base_Salary.search(line):
                        line_items_Base2 = line.split()
                        # DV2=line_items_DV2[-1]
                        Basesalary_Numpages.append(line_items_Base2[-1].replace('.', '').replace('-', ''))

    ### TAKE ALL THE PAGE NUMBER FOR HI,CI,UI,PI
    Num_pages13 = [tup[-1] for tup in UICont]
    Num_pages14 = [tup[-1] for tup in PICont]
    Num_pages15 = [tup[-1] for tup in HICont]
    Num_pages16 = [tup[-1] for tup in CIcont]
    # print(Num_pages5)
    WorkerID_UICont = []
    WorkerID_PICont = []
    WorkerID_HICont = []
    WorkerID_CICont = []

    UICont_Numpages = []
    PICont_Numpages = []
    HICont_Numpages = []
    CICont_Numpages = []

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages13:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_UIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_UICont.append(line_items_UIid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # DV2=line_items_DV2[-1]
                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:

                            if len(line_items_Wage) == 6:
                                # print(line_items_Wage)
                                UI = line_items_Wage[-2].replace('-', '')
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UICont_Numpages.append(UI)


                            elif 'Z' in line_items_Wage or 'E' in line_items_Wage or '1' in line_items_Wage or '2' in line_items_Wage or '3' in line_items_Wage or '4' in line_items_Wage:
                                # print(line_items_Wage)
                                UI = extract_UI(line_items_Wage, ['Z', 'E', '1', '2', '3', '4'])

                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UI = UI.replace(',,', ',')

                                UICont_Numpages.append(UI)
                                # PICont.append(PI)



                            elif len(line_items_Wage) >= 9:
                                # print(line_items_Wage)
                                UI = line_items_Wage[-3]
                                UI = f"{UI[:-2]},{UI[-2:]}"
                                UICont_Numpages.append(UI)

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages14:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_PIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_PICont.append(line_items_PIid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # DV2=line_items_DV2[-1]
                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:

                            if len(line_items_Wage) == 6:
                                # print(line_items_Wage)
                                PI = line_items_Wage[-3].replace('-', '')
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PICont_Numpages.append(PI)


                            elif 'Z' in line_items_Wage or 'E' in line_items_Wage or '1' in line_items_Wage or '2' in line_items_Wage or '4' in line_items_Wage:
                                # print(line_items_Wage)
                                PI = extract_value_before(line_items_Wage, ['Z', 'E', '1', '2', '4'], 2)
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PICont_Numpages.append(PI)
                                # PICont.append(PI)

                            elif len(line_items_Wage) >= 9:
                                # print(line_items_Wage)
                                PI = line_items_Wage[-4]
                                PI = f"{PI[:-2]},{PI[-2:]}"
                                PICont_Numpages.append(PI)

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages15:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_HIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_HICont.append(line_items_HIid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # DV2=line_items_DV2[-1]
                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:
                            if 'Z' in line_items_Wage:
                                if len(line_items_Wage) > 7:
                                    HI = extract_value_before(line_items_Wage, ['Z', 'E', '1', '2', '4'], 3)

                                    HI = f"{HI[:-2]},{HI[-2:]}"
                                    HICont_Numpages.append(HI)

                            elif len(line_items_Wage) >= 9:
                                HI = line_items_Wage[-6]
                                HI = f"{HI[:-2]},{HI[-2:]}"
                                HICont_Numpages.append(HI)

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages16:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_CIid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_CICont.append(line_items_CIid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # DV2=line_items_DV2[-1]
                        if line_items_Wage[0] == 'L' and len(line_items_Wage) > 4 and \
                                (line_items_Wage[2] == line_items_Wage[1] or line_items_Wage[3] == line_items_Wage[
                                    2]) and len(line_items_Wage) > 4:
                            if 'Z' in line_items_Wage:
                                if len(line_items_Wage) > 7:
                                    CI = extract_value_after(line_items_Wage, ['Z', 'E', '1', '2', '4'], 1)

                                    CI = f"{CI[:-2]},{CI[-2:]}"
                                    # CI = (CI.replace('.', ''), num_page)
                                    CICont_Numpages.append(CI)

                            elif len(line_items_Wage) >= 9:

                                CI = line_items_Wage[-2]
                                CI = f"{CI[:-2]},{CI[-2:]}"
                                CICont_Numpages.append(CI)

    ### TAKE ALL THE PAGE NUMBER FOR CHURCHTAX
    Num_pages7 = [tup[-1] for tup in ChurchTax]
    # print(Num_pages5)
    WorkerID_Church = []
    Church_Numpages = []

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages7:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Churchid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Church.append(line_items_Churchid2[0])
                        # print(line_items_RAid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # print(line_items_Wage)

    ### TAKE ALL THE PAGE NUMBER FOR Solidarity Surcharge
    Num_pages8 = [tup[-1] for tup in Solidarity]
    # print(Num_pages5)
    WorkerID_Solidarity = []
    Solidarity_Numpages = []

    with pdfplumber.open(file) as pdf:
        for num_page, page in enumerate(pdf.pages, start=1):
            if num_page in Num_pages8:
                # Récupération du contenu de la page
                text = page.extract_text()
                # print(text)
                # Récupération du contenu de la page
                for line in text.split('\n'):
                    if ID.search(line):
                        line_items_Solidarityid2 = line.split()
                        # month=' '.join(line_items_Period[3:5])
                        WorkerID_Solidarity.append(line_items_Solidarityid2[0])
                        # print(line_items_Solidarityid2)
                    if Wage.search(line):
                        line_items_Wage = line.split()
                        # print(line_items_Wage)

                        # print(line_items_Wage)
                        if line_items_Wage[
                            0] == 'L' and '773,80' not in line_items_Wage and 'Z' not in line_items_Wage:  # FAIRE EN SORTE DAVOIR LES HI COMTRIBUTIONS
                            # print(line_items_Wage)

                            if len(line_items_Wage) == 5 and len(line_items_Wage[2]) >= len(line_items_Wage[3]):

                                Solidarity2 = line_items_Wage[-2]
                                Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                # Solidarity2 = (Solidarity2, num_page)
                                # Solidarity2 = (Solidarity2, num_page)
                                Solidarity_Numpages.append(Solidarity2)
                            elif len(line_items_Wage) == 6 and len(line_items_Wage[-2]) == 3:
                                Solidarity2 = line_items_Wage[-2]
                                Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                Solidarity_Numpages.append(Solidarity2)

                            elif len(line_items_Wage) == 4 and len(line_items_Wage[2]) - len(
                                    line_items_Wage[-1]) == 1 and line_items_Wage[-1] > "15000":
                                Solidarity2 = line_items_Wage[-1]
                                Solidarity2 = f"{Solidarity2[:-2]},{Solidarity2[-2:]}"
                                # Solidarity_Numpages.append(Solidarity2)

    # UICont,PICont Equalizer
    finallistUICont = list(zip(WorkerID_UICont, UICont_Numpages))
    finallistPICont = list(zip(WorkerID_PICont, PICont_Numpages))
    finallistHICont = list(zip(WorkerID_HICont, HICont_Numpages))
    finallistCICont = list(zip(WorkerID_CICont, CICont_Numpages))

    for index, row in df.iterrows():
        for tup in finallistUICont:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'UI Contribution'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistPICont:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'PI Contribution'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistHICont:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'HI Contribution'] = tup[1]

    for index, row in df.iterrows():
        for tup in finallistCICont:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'CI Contribution'] = tup[1]

    # FZ Equalizer
    finallistFZ = list(zip(WorkerID_FZ, FZ_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistFZ:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Freiwillige Zulage'] = tup[1]

    # Mutterschaft Equalizer
    finallistMutterschaft = list(zip(WorkerID_Muttergeld, Muttergeld_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistMutterschaft:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Mutterschaft Geldzuschuss'] = tup[1]

    # SZ Equalizer
    finallistSZ = list(zip(WorkerID_Sonderzahlung, Sonderzahlung_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSZ:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Sonderzahlung'] = tup[1]

    # Unterstutzung Equalizer
    finallistUstutzung = list(zip(WorkerID_Unterstutzung, Unterstutzung_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistUstutzung:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Unterstützungskasse'] = tup[1]

    # GBKV Equalizer
    finallistGBKV = list(zip(WorkerID_GBKV, GBKV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistGBKV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Gesamtbeitrag_zur_KV'] = tup[1]

    # GBKV Equalizer
    finallistGBPV = list(zip(WorkerID_GBPV, GBPV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistGBPV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Gesamtbeitrag_zur_PV'] = tup[1]

    # Betrag911 Equalizer
    finallistBetrag906 = list(zip(WorkerID_Betrag906, Betrag906_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBetrag906:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Betr.AV.AG EBZ ST-frei'] = tup[1]

    # Betrag911 Equalizer
    finallistBetrag911 = list(zip(WorkerID_Betrag911, Betrag911_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBetrag911:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Betr.AV.AN lfd.ST-frei'] = tup[1]

    # Betrag914 Equalizer
    finallistBetrag914 = list(zip(WorkerID_Betrag914, Betrag914_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBetrag914:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Betr.AV.AN lfd.Geh.Ver'] = tup[1]

    # Church Equalizer
    finallistChurch = list(zip(WorkerID_Church, Church_Numpages))
    # print(finallistChurch)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistChurch:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Church Tax'] = tup[1]

    # Solidarity Surcharge Equalizer
    finallistSS = list(zip(WorkerID_Solidarity, Solidarity_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistSS:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Solidarity Surcharge'] = tup[1]

    # Betrag901 Equalizer
    finallistBetrag901 = list(zip(WorkerID_Betrag901, Betrag901_Numpages))
    # print(finallistBetrag901)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBetrag901:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Betr.AV.AG_lfd.ST-frei'] = tup[1]

    # AGPV Equalizer
    finallistAGPV = list(zip(WorkerID_AGZuschussPV, AGZuschussPV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistAGPV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'AG-Zuschuss_zur_PV'] = tup[1]

    # AGKV Equalizer
    finallistAGKV = list(zip(WorkerID_AGZuschussKV, AGZuschussKV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistAGKV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'AG-Zuschuss_zur_KV'] = tup[1]

    # DirektV Equalizer
    finallistDV = list(zip(WorkerID_DV, DV_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistDV:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Direktversicherung'] = tup[1]

    # BaseSalary Equalizer
    finallistBS = list(zip(WorkerID_BaseSalary, Basesalary_Numpages))
    # print(finallistSS)
    # Update the values of 'Column2' based on the condition
    # Update the values of 'Überstdgrundvergütung' based on the condition
    for index, row in df.iterrows():
        for tup in finallistBS:
            if row['Worker ID'] == tup[0]:
                df.at[index, 'Base Salary'] = tup[1]

    print(df.to_markdown())
    wb = Workbook()
    ws = wb.active

    # Ajouter l'en-tête du DataFrame à la feuille Excel
    header_row = df.columns.tolist()
    ws.append(header_row)

    # Ajouter les données du DataFrame à la feuille Excel
    # Pas de manipulation explicite des nombres ici
    for row in dataframe_to_rows(df, index=False, header=False):
        ws.append(row)

    # Appliquer un style à la ligne d'en-tête
    for cell in ws[1]:
        cell.font = Font(underline='single', bold=True)
        cell.fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")

    # Ajuster la largeur des colonnes
    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            if cell.value:
                max_length = max(max_length, len(str(cell.value)))
        adjusted_width = (max_length + 2) * 1.2
        ws.column_dimensions[column_letter].width = adjusted_width
    # Insérer les valeurs en s'assurant qu'elles sont bien en nombre

    # df = df.apply(lambda col: pd.to_numeric(col.str.replace(',', '.'), errors='ignore') if col.dtype=='str' and col.str.contains(',').any() else col)
    # Récupérer la première ligne (les en-têtes)
    # Récupérer la première ligne (les en-têtes)
    header = [cell.value for cell in ws[1]]

    # Déterminer l'indice (1-based) de la colonne "Base Salary"
    try:
        start_col = header.index("Base Salary") + 1
    except ValueError:
        print("La colonne 'Base Salary' n'a pas été trouvée dans l'en-tête.")
        start_col = None

    if start_col is not None:
        # Parcourir toutes les lignes à partir de la 2ème ligne (en-tête exclu)
        for row in ws.iter_rows(min_row=2):
            for col in range(start_col, ws.max_column + 1):
                cell = row[col - 1]  # L'indexation Python commence à 0

                # Si la cellule contient une chaîne (donc pas encore convertie en nombre)
                if cell.value is not None and isinstance(cell.value, str):
                    # Nettoyer la valeur : supprimer les espaces et remplacer la virgule par un point
                    valeur_str = cell.value.strip().replace(" ", "").replace(",", ".")
                    try:
                        # Convertir en float
                        cell.value = float(valeur_str)
                    except ValueError:
                        print(f"Conversion impossible pour la cellule {cell.coordinate} avec la valeur '{cell.value}'")

        # Appliquer le format numérique aux cellules déjà en nombre
        for row in ws.iter_rows(min_row=2):
            for col in range(start_col, ws.max_column + 1):
                cell = row[col - 1]

                # Vérifier si la cellule est un nombre valide
                if isinstance(cell.value, (int, float)) and not math.isnan(cell.value):
                    # Ne pas convertir en texte, juste appliquer un format d'affichage
                    cell.number_format = "0.00"

                # Facultatif : vous pouvez forcer le type texte en ajoutant une apostrophe (mais cela affichera l'apostrophe dans certaines configurations)
            # cell.value = "'" + format(cell.value, '.2f')

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path(
        user_id=user_id,
        data_conversion="Papaya",
        conversion="Lipton",
        task_id=task.request.id,
        extension="xlsx",
    )

    ensure_output_folder(output_path)

    wb.save(output_path)

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}