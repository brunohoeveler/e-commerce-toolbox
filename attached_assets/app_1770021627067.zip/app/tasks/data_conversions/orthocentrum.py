import re
from pathlib import Path

import pandas as pd
import pdfplumber
from fastapi import UploadFile

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_output_path, strip_task_id


@register_data_conversion(
    data_conversion="OrthoCentrum",
    conversion="Ambulante Ausgangsliste",
    description="OrthoCentrum Ambulante Ausgangsliste conversion",
    input_type={
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["pdf"],
            },
        ),
    },
    output_type="csv",
)
def orthocentrum_ambulante_ausgangsliste(task, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]

    # Expression régulière pour capturer les groupes souhaités
    linie = re.compile(r"(\d{6}) (\d{2}\.\d{2}\.\d{2}) ([+-]?\d+,\d{2} €) ([+-]?\d+,\d{2} €) (\d{1,8}) ([\w\sÀ-ÿ,.\'-]+)")

    # Liste pour stocker les données extraites
    data = []

    # ========================== IMPORT DATEI ==========================
    with pdfplumber.open(file1) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            lines = text.split("\n")

            for line in lines:
                matches = linie.findall(line)
                # Ajouter les correspondances à la liste de données
                for match in matches:
                    data.append(
                        {
                            "Re-Nr": match[0],
                            "Datum": match[1],
                            "Betrag": match[2],
                            "Sachkosten": match[3],
                            "PatNr": match[4],
                            "Name": match[5],
                        }
                    )

    # Créer un DataFrame pandas à partir des données
    df = pd.DataFrame(data)

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path(
        user_id=user_id,
        data_conversion="OrthoCentrum",
        conversion="Ambulante Ausgangsliste",
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    df.to_csv(output_path, sep=";", encoding="latin-1", errors="ignore", index=False)

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
