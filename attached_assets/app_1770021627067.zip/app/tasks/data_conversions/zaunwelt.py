import io
from pathlib import Path

import polars as pl
from fastapi import UploadFile

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.datev_export import datev_export_polars
from app.utils.file_utils import delete_input_files, ensure_output_folder, strip_task_id, \
    generate_output_path_datev


@register_data_conversion(
    data_conversion="Zaunwelt",
    conversion="default",
    description="Transaktionsdaten Bestellnummer Matcher",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 2,
                "max_files": 2,
                "extensions": ["csv", "xlsx", "xls"],
            },
        ),
    },
    output_type="csv",
)
def zaunwelt_transaktionsbericht(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]

    try:
        df_buchungsstapel = pl.read_csv(
            file1,
            separator=";",
            infer_schema_length=10000,
            encoding="latin1",
            truncate_ragged_lines=True,
            skip_rows=1,
            has_header=True
        )
    except FileNotFoundError as e:
        raise Exception("Die Revenue Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e

    try:
        df_kontonummer = pl.read_excel(
            file2,
            has_header=False,
            infer_schema_length=10000
        )
        new_header = df_kontonummer.row(1)
        df_kontonummer = df_kontonummer.slice(2)
        df_kontonummer.columns = [str(col) for col in new_header]
    except FileNotFoundError as e:
        raise Exception("Die User Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e

    df_buchungsstapel = df_buchungsstapel.filter(
        (pl.col("Konto").cast(pl.Utf8) == "1000") |
        (pl.col("Gegenkonto").cast(pl.Utf8) == "1000")
    )

    # Fix Belegdatum: take all but last 2 digits as day, add month and year
    month_str = str(month).zfill(2)  # Convert to string with leading zero if needed
    year_str = str(year)  # Convert year to string
    df_buchungsstapel = df_buchungsstapel.with_columns(
        (pl.col("Belegdatum").cast(pl.Utf8).str.head(-2).str.zfill(2) + "." + month_str + "." + year_str).alias("Belegdatum")
    )

    # Join on Belegfeld 1 (buchungsstapel) = Belegfeld1 (kontonummer) and update Gegenkonto
    df_buchungsstapel = df_buchungsstapel.join(
        df_kontonummer.select(["Belegfeld1", pl.col("Gegenkonto").alias("Gegenkonto_neu")]),
        left_on="Belegfeld 1",
        right_on="Belegfeld1",
        how="left"
    ).with_columns(
        pl.coalesce(["Gegenkonto_neu", "Gegenkonto"]).alias("Gegenkonto")
    ).drop("Gegenkonto_neu")

    # Cast all columns to string
    df_buchungsstapel = df_buchungsstapel.cast({col: pl.Utf8 for col in df_buchungsstapel.columns})

    # Rename columns to match DATEV pattern (lowercase)
    df_buchungsstapel = df_buchungsstapel.rename({
        "Umsatz": "umsatz",
        "Soll/Haben-Kennzeichen": "sh",
        "WKZ Umsatz": "wkz",
        "Konto": "konto",
        "Gegenkonto": "gegenkonto",
        "BU-Schluessel": "bu",
        "Belegdatum": "datum",
        "Belegfeld 1": "belegfeld",
        "Belegfeld 2": "belegfeld2",
        "Buchungstext": "buchungstext",
    })

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Zaunwelt",
        conversion="default",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        datev_export_polars(
            df=df_buchungsstapel,
            month=month,
            year=year,
            buffer=buffer,
            bernr='33379',
            mdtnr='62820',
            skl='6',
            skr='3',
           text='Zaunwelt'
        )

        with open(output_path, "wb") as f:
            f.write(buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}