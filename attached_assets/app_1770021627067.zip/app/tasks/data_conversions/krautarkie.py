from pathlib import Path

import polars as pl
from fastapi import UploadFile

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_output_path, strip_task_id


@register_data_conversion(
    data_conversion="Krautarkie",
    conversion="Transaktionsbericht",
    description="Transaktionsdaten Bestellnummer Matcher",
    input_type={
        "files": (
            list[UploadFile],
            {
                "min_files": 2,
                "max_files": 2,
                "extensions": ["csv", "xlsx", "xls"],
            },
        ),
    },
    output_type="csv",
)
def krautarkie_transaktionsbericht(task, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]

    with open(file1, 'r', encoding='utf-8') as f:
        header_rows = [f.readline() for _ in range(11)]

    try:
        df_transactions = pl.read_csv(
            file1,
            separator=";",
            infer_schema_length=10000,
            encoding="utf-8",
            truncate_ragged_lines=True,
            skip_rows=11,
            has_header=True
        )
    except FileNotFoundError as e:
        raise Exception("Die Revenue Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e

    # Cut everything after Auszahlungswährung
    cols = df_transactions.columns
    cut_index = cols.index("Auszahlungswährung") + 1
    df_transactions = df_transactions.select(cols[:cut_index])

    try:
        df_kontonummer = pl.read_excel(
            file2,
            has_header=False,
            infer_schema_length=10000
        )
        new_header = df_kontonummer.row(1)
        df_kontonummer = df_kontonummer.slice(2)
        df_kontonummer.columns = [str(col) for col in new_header]
    except FileNotFoundError as e:
        raise Exception("Die User Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e

    # Join: match Bestellnummer (transactions) with Buchungstext (kontonummer)
    # Get Belegfeld1 and Gegenkonto_neu
    df_transactions = df_transactions.join(
        df_kontonummer.select([
            "Buchungstext",
            pl.col("Belegfeld1").alias("Belegfeld1_neu"),
            pl.col("Gegenkonto").alias("Gegenkonto_neu")
        ]),
        left_on="Bestellnummer",
        right_on="Buchungstext",
        how="left"
    )

    # Add Konto column with 1802
    # Add Gegenkonto based on Typ
    # Replace Bestellnummer with Belegfeld1 if match found
    df_transactions = df_transactions.with_columns([
        pl.lit("1802").alias("Konto"),
        pl.when(pl.col("Typ") == "Andere Gebühr").then(pl.lit("6855"))
        .when(pl.col("Typ") == "Bestellung").then(pl.col("Gegenkonto_neu"))
        .when(pl.col("Typ") == "Auszahlung").then(pl.lit("1460"))
        .otherwise(pl.lit(""))
        .alias("Gegenkonto"),
        pl.coalesce(["Belegfeld1_neu", "Bestellnummer"]).alias("Bestellnummer")
    ]).drop(["Gegenkonto_neu", "Belegfeld1_neu"])

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path(
        user_id=user_id,
        data_conversion="Krautarkie",
        conversion="Transaktionsbericht",
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    # Write output with header rows on top
    with open(output_path, 'w', encoding='utf-8') as f:
        # Write the original 11 header rows
        f.writelines(header_rows)
        # Write the dataframe
        f.write(df_transactions.write_csv(separator=";"))

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}