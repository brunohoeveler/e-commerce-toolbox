import io
import re
from pathlib import Path
from zipfile import ZipFile

import pandas as pd
from fastapi import UploadFile

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.datev_export import datev_format
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_output_path_datev, strip_task_id


@register_data_conversion(
    data_conversion="Tanzmuster",
    conversion="Plenty",
    description="Tanzmuster Plenty conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["csv"],
            },
        ),
    },
    output_type="zip",
)
def tanzmuster_plenty(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]

    # ======================== DATA IMPORT ====================================
    df_import = pd.read_csv(file1, delimiter=";", dtype=str)
    df_import.columns.values[0:3] = ["wkz", "sh", "umsatz"]
    df_import.columns.values[4:6] = ["gegenkonto", "belegfeld"]
    df_import.columns.values[7:11] = ["datum", "konto", "kundeid", "kunde"]
    df_import.columns.values[15] = "land"
    df_import.columns.values[18] = "ustid"
    df_import.columns.values[21:23] = ["abrechnungsreferenz", "steuersatz"]
    df_import.columns.values[34] = "inhalt1"
    df_import = df_import[
        [
            "wkz",
            "sh",
            "umsatz",
            "gegenkonto",
            "belegfeld",
            "datum",
            "konto",
            "kundeid",
            "kunde",
            "land",
            "ustid",
            "abrechnungsreferenz",
            "steuersatz",
            "inhalt1",
        ]
    ]

    # ========================== KONTEN LISTE ===================================
    konten = {
        "konto2": [
            "4120",
            "4120",
            "4120",
            "4120",
            "4320",
            "4321",
            "4322",
            "4324",
            "4325",
            "4326",
            "4327",
            "4328",
            "4329",
            "4330",
            "4331",
            "4332",
            "4333",
            "4334",
            "4335",
            "4336",
            "4337",
            "4350",
            "4351",
            "4352",
            "4353",
            "4354",
            "4355",
            "4356",
            "4400",
            "4358",
            "4359",
            "4120",
        ],
        "land": [
            "US",
            "CH",
            "GB",
            "IC",
            "LU",
            "PL",
            "CZ",
            "AT",
            "FR",
            "IT",
            "ES",
            "BE",
            "DK",
            "FI",
            "EL",
            "IE",
            "HR",
            "LV",
            "LT",
            "MT",
            "NL",
            "PT",
            "RO",
            "SE",
            "SK",
            "SI",
            "HU",
            "CY",
            "DE",
            "EE",
            "BG",
            "NO",
        ],
    }
    df_konten = pd.DataFrame(konten)

    # ======================== PROTOCOL ERSTELLUNG =================================
    df_protocol = pd.merge(df_import, df_konten, on="land", how="left")
    df_protocol["protocol"] = ""
    df_protocol.loc[df_protocol["konto2"].isnull(), "protocol"] = "W"
    df_protocol.loc[
        (~df_protocol["ustid"].isnull()) & (~df_protocol["steuersatz"].isin(["0,00", "0.00", "0,0", "0", "0.0"])) & (~df_protocol["ustid"].str[:2].isin(["DE"])),
        "protocol",
    ] = df_protocol["protocol"] + "X"
    df_protocol.loc[
        (df_protocol["konto2"].isin(["4120"])) & (~df_protocol["steuersatz"].isin(["0,00", "0.00", "0,0", "0", "0.0"])),
        "protocol",
    ] = df_protocol["protocol"] + "Y"
    df_protocol.loc[
        (df_protocol["belegfeld"].isin(["", " "])) | (df_protocol["belegfeld"].isnull()),
        "protocol",
    ] = df_protocol["protocol"] + "Z"
    df_protocol.loc[df_protocol["protocol"].isin(["W"]), "protocol"] = "Länderkürzel unbekannt"
    df_protocol.loc[df_protocol["protocol"].isin(["WX"]), "protocol"] = "Länderkürzel unbekannt, UstID ungültig"
    df_protocol.loc[df_protocol["protocol"].isin(["WY"]), "protocol"] = "Länderkürzel unbekannt, RE/Steuer falsch"
    df_protocol.loc[df_protocol["protocol"].isin(["WZ"]), "protocol"] = "Länderkürzel unbekannt, Belegnummer fehlt"
    df_protocol.loc[df_protocol["protocol"].isin(["WXY"]), "protocol"] = "Länderkürzel unbekannt, UstID ungültig, RE/Steuer falsch"
    df_protocol.loc[df_protocol["protocol"].isin(["WXZ"]), "protocol"] = "Länderkürzel unbekannt, UstID ungültig, Belegnummer fehlt"
    df_protocol.loc[df_protocol["protocol"].isin(["WYZ"]), "protocol"] = "Länderkürzel unbekannt, RE/Steuer falsch, Belegnummer fehlt"
    df_protocol.loc[df_protocol["protocol"].isin(["WXYZ"]), "protocol"] = "Länderkürzel unbekannt, UstID ungültig, RE/Steuer falsch, Belegnummer fehlt"
    df_protocol.loc[df_protocol["protocol"].isin(["X"]), "protocol"] = "UstID ungültig"
    df_protocol.loc[df_protocol["protocol"].isin(["XY"]), "protocol"] = "UstID ungültig, RE/Steuer falsch"
    df_protocol.loc[df_protocol["protocol"].isin(["XZ"]), "protocol"] = "UstID ungültig, Belegnummer fehlt"
    df_protocol.loc[df_protocol["protocol"].isin(["XYZ"]), "protocol"] = "UstID ungültig, RE/Steuer falsch, Belegnummer fehlt"
    df_protocol.loc[df_protocol["protocol"].isin(["Y"]), "protocol"] = "RE/Steuer falsch"
    df_protocol.loc[df_protocol["protocol"].isin(["YZ"]), "protocol"] = "RE/Steuer falsch, Belegnummer fehlt"
    df_protocol.loc[df_protocol["protocol"].isin(["Z"]), "protocol"] = "Belegnummer fehlt"
    df_protocol = df_protocol[~df_protocol["protocol"].isin([""])]
    df_protocol = df_protocol[["protocol"] + [col for col in df_protocol.columns if col != "protocol"]]

    # ======================== MERGE DATA ========================================
    df_merge = pd.merge(df_import, df_konten, on="land", how="left")
    df_merge.loc[~df_merge["konto2"].isnull(), "gegenkonto"] = df_merge["konto2"]
    del df_merge["konto2"]
    df_merge["buchungstext"] = df_merge["kunde"]
    df_merge.loc[~df_merge["kundeid"].isnull(), "buchungstext"] = df_merge["buchungstext"] + " " + df_merge["kundeid"]
    df_merge.loc[
        (~df_merge["ustid"].isnull()) & (df_merge["steuersatz"].isin(["0,00", "0.00", "0,0", "0", "0.0"])),
        "land",
    ] = df_merge["ustid"]
    df_merge["info1"] = "payment provider"
    df_merge.loc[df_merge["inhalt1"].str.contains("amazon", flags=re.I, regex=True), "konto"] = "10300"
    df_merge.loc[df_merge["inhalt1"].str.contains("paypal", flags=re.I, regex=True), "konto"] = "10301"
    df_merge.loc[df_merge["inhalt1"].str.contains("ebay", flags=re.I, regex=True), "konto"] = "10302"
    df_merge.loc[df_merge["inhalt1"].str.contains("mytoys", flags=re.I, regex=True), "konto"] = "10303"
    df_merge.loc[df_merge["inhalt1"].str.contains("otto", flags=re.I, regex=True), "konto"] = "10304"
    df_merge.loc[df_merge["inhalt1"].str.contains("zalando", flags=re.I, regex=True), "konto"] = "10305"
    df_merge.loc[
        ~df_merge["konto"].isin(["10300", "10301", "10302", "10303", "10304", "10305"]),
        "konto",
    ] = "10306"
    df_merge.loc[(~df_merge["ustid"].isnull()) & (df_merge["steuersatz"] == "19"), "gegenkonto"] = "4400"
    df_merge.loc[
        (df_merge["gegenkonto"] == "4120") & (df_merge["steuersatz"] == "19"),
        "gegenkonto",
    ] = "4400"
    df_merge.loc[
        (~df_merge["ustid"].isnull()) & (df_merge["steuersatz"].isin(["0,00", "0.00", "0,0", "0", "0.0"])),
        "gegenkonto",
    ] = "4125"
    df_merge["landhk"] = "DE"
    df_merge.columns.values[9] = "eulandbest"
    df_merge["datum"] = df_merge["datum"].str[:5]
    df_merge["datum"] = df_merge["datum"].str.replace(".", "")
    del df_merge["kunde"]
    del df_merge["kundeid"]
    del df_merge["ustid"]

    df_export = datev_format(
        df=df_merge,
        year=year,
        month=month,
        bernr="12168",
        mdtnr="18899",
        skl="4",
        skr="4",
        text="Tanzmuster plenty revenues",
    )

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Tanzmuster",
        conversion="Plenty",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="zip",
    )

    ensure_output_folder(output_path)

    with ZipFile(output_path, "w") as zf:
        # Convert df_export to a CSV and write it to a ZIP file in memory
        with zf.open(f"DTVF_Tanzmuster_Revenues_{year}_{month}.csv", "w") as f:
            f.write(df_export.to_csv(index=False, sep=";").encode("utf-8"))

        # Create a BytesIO stream for the Excel file
        excel_buffer = io.BytesIO()
        df_protocol.to_excel(excel_buffer, sheet_name="Protocol", index=False)
        excel_buffer.seek(0)  # Rewind the buffer
        zf.writestr(f"Protokoll_Tanzmuster_{year}_{month}.xlsx", excel_buffer.read())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
