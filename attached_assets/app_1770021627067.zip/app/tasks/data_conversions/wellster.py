import io
from pathlib import Path
from zipfile import ZipFile

import polars as pl
from fastapi import UploadFile

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.datev_export import datev_export_polars
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_output_path_datev, strip_task_id


@register_data_conversion(
    data_conversion="Wellster",
    conversion="Paypal",
    description="Wellster Paypal conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 3,
                "max_files": 3,
                "extensions": ["csv"],
            },
        ),
    },
    output_type="csv",
)
def wellster_paypal(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]
    file3 = files[2]

    # ====================== PAYMENTS & TECH DATEI DATEI IMPORT ==============================
    try:
        df_payments = pl.read_csv(file1, separator=",")
        assert df_payments.width == 41
    except FileNotFoundError as e:
        raise Exception("Die Paypal Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Fehler beim Lesen der Paypal Datei, bitte überprüfen, ob die Struktur richtig ist!") from e

    try:
        df_tech = pl.read_csv(file2, separator=",")
        assert df_tech.width == 41
    except FileNotFoundError as e:
        raise Exception("Die Tech Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Fehler beim Lesen der Tech Datei, bitte überprüfen, ob die Struktur richtig ist") from e

    cols = df_payments.columns
    df_payments = df_payments.select(cols[0:2] + [cols[4]] + cols[6:9] + [cols[10]] + [cols[12]] + cols[24:26])
    cols = df_tech.columns
    df_tech = df_tech.select(cols[0:2] + [cols[4]] + cols[6:9] + [cols[10]] + [cols[12]] + cols[24:26])
    df_payments = df_payments.with_columns(pl.lit("120400").alias("konto"))
    df_tech = df_tech.with_columns(pl.lit("120200").alias("konto"))
    df_payments = df_payments.select([col for i, col in enumerate(df_payments.columns)])
    df_payments = df_payments.rename(
        dict(
            zip(
                df_payments.columns[0:],
                [
                    "datum",
                    "zeit",
                    "typ",
                    "wkz",
                    "umsatz",
                    "fee",
                    "buchungstext",
                    "auftragsnummer",
                    "reference id",
                    "belegfeld",
                ],
            )
        )
    )
    df_tech = df_tech.rename(
        dict(
            zip(
                df_tech.columns[0:],
                [
                    "datum",
                    "zeit",
                    "typ",
                    "wkz",
                    "umsatz",
                    "fee",
                    "buchungstext",
                    "auftragsnummer",
                    "reference id",
                    "belegfeld",
                ],
            )
        )
    )

    # ======================= MERGE DATA ====================================
    df_merge = pl.concat([df_payments, df_tech])
    df_merge = df_merge.with_columns(
        [
            pl.when((pl.col("reference id").is_not_null()) & (pl.col("reference id") != "") & (~pl.col("reference id").str.contains("-")))
            .then(pl.col("reference id"))
            .otherwise(pl.col("auftragsnummer"))
            .alias("auftragsnummer")
        ]
    )
    df_merge = df_merge.with_columns(
        [
            pl.col("datum").str.slice(0, 5).str.replace_all(r"\.", "").str.replace_all(r"\/", "").alias("datum"),
            pl.lit("").alias("gegenkonto"),
            pl.when(pl.col("umsatz").str.contains("-")).then(pl.lit("H")).otherwise(pl.lit("S")).alias("sh"),
            pl.col("umsatz").str.replace_all(r"\-", "").str.replace_all(r"\.", "").alias("umsatz"),
        ]
    ).filter(~pl.col("umsatz").is_in(["0", "0,00", "0", "0,0", "0.0", "0.00"]))
    # ====================== SPLITTING FEE DATA ============================
    df_fee = df_merge.clone()
    df_merge = df_merge.drop(["fee"])
    df_fee = df_fee.drop(["umsatz", "zeit"])
    df_fee = df_fee.rename({df_fee.columns[3]: "umsatz"})
    df_fee = df_fee.filter(~pl.col("umsatz").is_in(["0", "0,00", "0", "0,0", "0.0", "0.00"]))
    cols = df_fee.columns
    new_order = [cols[0], "zeit"] + cols[1:]
    df_fee = df_fee.with_columns(
        [
            pl.lit("497100").alias("gegenkonto"),
            pl.when(pl.col("umsatz").str.contains("-")).then(pl.lit("H")).otherwise(pl.lit("S")).alias("sh"),
            (pl.lit("Fee: ") + pl.col("typ")).alias("typ"),
            pl.lit("").alias("zeit"),
        ]
    )
    df_fee = df_fee.with_columns(
        [
            pl.col("umsatz").str.replace_all(r"\-", "").str.replace_all(r"\.", "").alias("umsatz"),
        ]
    )
    df_fee = df_fee.with_columns()
    df_fee = df_fee.select(new_order)

    # ============== GEGENKONTO DEFINITION IN MERGE DATA =====================
    df_merge = df_merge.with_columns(
        [
            pl.when((pl.col("typ").is_in(["Dispute Fee", "Fee Reversal", "Konfliktgebühr"])))
            .then(pl.lit("497100"))
            .when(
                (
                    pl.col("typ").is_in(
                        [
                            "General Withdrawal",
                            "Allgemeine Abbuchung",
                            "Von Nutzer eingeleitete Abbuchung",
                        ]
                    )
                )
                & (pl.col("konto") == "120400")
            )
            .then(pl.lit("136002"))
            .when(
                (
                    pl.col("typ").is_in(
                        [
                            "General Withdrawal",
                            "Allgemeine Abbuchung",
                            "Von Nutzer eingeleitete Abbuchung",
                        ]
                    )
                )
                & (pl.col("konto") == "120200")
            )
            .then(pl.lit("136002"))
            .when(
                (
                    pl.col("typ").is_in(
                        [
                            "Instant Payment Review (IPR) reversal",
                            "Payment Refund",
                            "Payment Reversal",
                            "Chargeback",
                            "Express Checkout Payment",
                            "PreApproved Payment Bill User Payment",
                            "Subscription Payment",
                            "PayPal Express-Zahlung",
                            "Rückbuchung",
                            "Rückzahlung",
                            "Zahlung im Einzugsverfahren mit Zahlungsrechnung",
                            "Abonnementzahlung",
                        ]
                    )
                )
                & (pl.col("konto") == "120200")
            )
            .then(pl.lit("159030"))
            .when(
                (
                    pl.col("typ").is_in(
                        [
                            "Instant Payment Review (IPR) reversal",
                            "Payment Refund",
                            "Payment Reversal",
                            "Chargeback",
                            "Express Checkout Payment",
                            "PreApproved Payment Bill User Payment",
                            "Subscription Payment",
                            "PayPal Express-Zahlung",
                            "Rückbuchung",
                            "Rückzahlung",
                            "Zahlung im Einzugsverfahren mit Zahlungsrechnung",
                            "Abonnementzahlung",
                        ]
                    )
                )
                & (pl.col("konto") == "120400")
            )
            .then(pl.lit("159031"))
            .when(
                (
                    pl.col("typ").is_in(
                        [
                            "Funds collected for disbursement",
                            "Funds disbursed",
                            "Transfer of funds from General Account",
                        ]
                    )
                )
            )
            .then(pl.lit("136043"))
            .when(
                (
                    pl.col("typ").is_in(
                        [
                            "Cancellation of Hold for Dispute Resolution",
                            "General Hold",
                            "Hold on Balance for Dispute Investigation",
                            "Payment Hold",
                            "Payment Review Hold",
                            "Freigabe allgemeiner Einbehaltung",
                            "Freigabe der Reserve",
                            "Reserve Hold",
                            "Payment Release",
                            "Payment Review Release",
                            "Reserve Release",
                            "General Hold Release",
                            "Aufhebung der Guthabeneinbehaltung für Konfliktlösung",
                            "Freigabe der Reserve",
                            "Gegenwärtige Reserve",
                            "Allgemeine Einbehaltung",
                            "Guthabeneinbehaltung für Konfliktlösung",
                        ]
                    )
                )
                & (pl.col("konto") == "120200")
            )
            .then(pl.lit("136042"))
            .when(
                (
                    pl.col("typ").is_in(
                        [
                            "Cancellation of Hold for Dispute Resolution",
                            "General Hold",
                            "Hold on Balance for Dispute Investigation",
                            "Payment Hold",
                            "Payment Review Hold",
                            "Freigabe allgemeiner Einbehaltung",
                            "Freigabe der Reserve",
                            "Reserve Hold",
                            "Payment Release",
                            "Payment Review Release",
                            "Reserve Release",
                            "General Hold Release",
                            "Aufhebung der Guthabeneinbehaltung für Konfliktlösung",
                            "Freigabe der Reserve",
                            "Gegenwärtige Reserve",
                            "Allgemeine Einbehaltung",
                            "Guthabeneinbehaltung für Konfliktlösung",
                        ]
                    )
                )
                & (pl.col("konto") == "120400")
            )
            .then(pl.lit("136041"))
            .when(
                (
                    pl.col("typ").is_in(
                        [
                            "Eingezogene Beträge für Auszahlung",
                            "Geld ausgezahlt",
                            "Überweisung vom Hauptkonto",
                        ]
                    )
                )
            )
            .then(pl.lit("136031"))
            .alias("gegenkonto")
        ]
    )

    # =============== MERGING FEES AND REVENUES ===========================
    df_new_merge = pl.concat([df_merge, df_fee])
    desired_order = [
        "datum",
        "zeit",
        "typ",
        "wkz",
        "umsatz",
        "buchungstext",
        "auftragsnummer",
        "reference id",
        "belegfeld",
        "konto",
        "sh",
        "gegenkonto",
    ]
    df_new_merge = df_new_merge.select(desired_order)

    # ============== INTRODUCING WELLSTER DATA ============================
    try:
        df_wellster_rev = pl.read_csv(
            file3,
            separator=";",
        )
        assert df_wellster_rev.width == 14
    except FileNotFoundError as e:
        raise Exception("Die Debitor Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Fehler beim Lesen der Debitor Datei, bitte überprüfen, ob die Struktur richtig ist!") from e

    df_wellster_rev = df_wellster_rev.rename(
        {
            df_wellster_rev.columns[12]: "paymentprovider",
            df_wellster_rev.columns[9]: "gegenkonto_debitor",
            df_wellster_rev.columns[8]: "auftragsnummer",
        }
    )
    colsrev = df_wellster_rev.columns
    selected_col = [colsrev[8], colsrev[9], colsrev[3]]
    df_wellster_rev = df_wellster_rev.select(selected_col).unique(subset="auftragsnummer", maintain_order=True)

    df_result = df_new_merge.join(df_wellster_rev, on="auftragsnummer", how="left")
    df_result = df_result.with_columns(pl.col("belegfeld_right").alias("belegfeld"))
    df_result = df_result.unique(
        subset=[
            "datum",
            "typ",
            "umsatz",
            "buchungstext",
            "auftragsnummer",
            "reference id",
        ],
        keep="first",
    ).drop(["reference id", "belegfeld_right"])
    column_to_rename = df_result.columns[2]
    df_result = df_result.rename({column_to_rename: "inhalt1"})
    df_result = df_result.with_columns(pl.lit("Transaction Type").alias("info1")).sort("konto")

    # =============== SWITCHING DEBITOR TO KONTO ====================
    df_result = df_result.with_columns(
        pl.when((pl.col("gegenkonto_debitor").is_not_null()) & ((pl.col("gegenkonto") == "159030") | (pl.col("gegenkonto") == "159031")))
        .then(pl.col("gegenkonto_debitor"))
        .otherwise(pl.col("gegenkonto"))
        .alias("gegenkonto")
    )
    df_result.drop(["gegenkonto_debitor"])

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Wellster",
        conversion="Paypal",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        datev_export_polars(
            df=df_result,
            month=month,
            year=year,
            buffer=buffer,
            bernr="673388",
            mdtnr="17815",
            skl="6",
            skr="3",
            text="Wellster Paypal",
        )

        with open(output_path, "wb") as f:
            f.write(buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Wellster",
    conversion="Amazon",
    description="Wellster Amazon conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["csv"],
            },
        ),
    },
    output_type="csv",
)
def wellster_amazon(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]

    # =================================== IMPORT AMAZON =====================================
    try:
        df_import = pl.read_csv(file1, separator="\t", infer_schema_length=10000)
        assert df_import.width == 95
    except FileNotFoundError as e:
        raise Exception("Die Amazon Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Fehler beim Lesen der Amazon Datei, bitte überprüfen, ob die Struktur richtig ist!") from e

    df_import = df_import.rename(
        {
            df_import.columns[52]: "umsatz",
            df_import.columns[53]: "wkz",
            df_import.columns[11]: "datum",
            df_import.columns[82]: "belegfeld",
            df_import.columns[30]: "steuersatz",
            df_import.columns[6]: "auftragsnummer",
            df_import.columns[68]: "eulandbest",
            df_import.columns[78]: "ustid",
        }
    ).filter(pl.col("umsatz").is_not_null())

    # remove all other columns
    df_import = df_import[
        "umsatz",
        "wkz",
        "datum",
        "belegfeld",
        "steuersatz",
        "auftragsnummer",
        "eulandbest",
        "ustid",
    ]

    df_import = df_import.with_columns(
        [
            pl.col("datum").str.replace_all(r"\-", "").str.slice(0, 4).alias("datum"),
            pl.col("steuersatz").str.replace_all(r"\.", ",").alias("steuersatz"),
            pl.lit("5000200").alias("konto"),
            pl.when(pl.col("umsatz").str.contains("-")).then(pl.lit("H")).otherwise(pl.lit("S")).alias("sh"),
            pl.col("umsatz").str.replace_all(r"\.", ",").str.replace_all(r"\-", "").alias("umsatz"),
            pl.when((pl.col("eulandbest") == "DE") & (pl.col("steuersatz").cast(pl.Utf8) == "0,07"))
            .then(pl.lit("830300"))
            .when((pl.col("eulandbest") == "DE") & (pl.col("steuersatz").cast(pl.Utf8) == "0,19"))
            .then(pl.lit("840300"))
            .otherwise(pl.lit(None))
            .alias("gegenkonto"),
        ]
    )

    df_notde = df_import.filter(pl.col("gegenkonto").is_null())
    df_import = df_import.filter(pl.col("gegenkonto").is_not_null())

    # ================================ IMPORT OSS KONTEN =====================================
    try:
        df_oss = pl.read_excel("resources/wellster_amazon_konten.xlsx")
        assert df_oss.width == 4
    except AssertionError as e:
        raise Exception("Fehler beim Lesen einer Internen-Datei, bitte melden Sie sich beim System Administrator!") from e

    df_oss = df_oss.drop(df_oss.columns[0])
    df_oss = df_oss.rename({df_oss.columns[0]: "gegenkonto_oss"})

    # ================================ MERGE DATA =============================================
    df_merge = df_notde.join(
        df_oss,
        left_on=["eulandbest", "steuersatz"],
        right_on=["Land", "Steuersatz"],
        how="left",
    )

    df_merge = df_merge.with_columns(pl.when(pl.col("gegenkonto_oss").is_null()).then(pl.lit("812000")).otherwise(pl.col("gegenkonto_oss")).alias("gegenkonto")).drop("gegenkonto_oss")

    df_result = pl.concat([df_import, df_merge])

    df_result = df_result.with_columns(
        [
            pl.when(pl.col("gegenkonto") == "812000").then(pl.col("eulandbest").cast(pl.Utf8)).otherwise(pl.lit("")).alias("buchungstext"),
            pl.when(pl.col("gegenkonto") == "812000")
            .then(pl.lit(""))
            .when(pl.col("ustid").is_not_null() & ~pl.col("ustid").str.slice(0, 2).is_in(["DE"]))
            .then(pl.col("ustid").cast(pl.Utf8))
            .otherwise(pl.col("eulandbest"))
            .str.replace("GR", "EL")
            .alias("eulandbest"),
            pl.when(pl.col("ustid").is_not_null() & ~pl.col("ustid").str.slice(0, 2).is_in(["DE"])).then(pl.lit("812500")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"),
            pl.lit("DE").alias("landhk"),
        ]
    ).drop("ustid")

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Wellster",
        conversion="Amazon",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        datev_export_polars(
            df=df_result,
            month=month,
            year=year,
            buffer=buffer,
            bernr="673388",
            mdtnr="17815",
            skl="6",
            skr="3",
            text="Wellster Amazon",
        )

        with open(output_path, "wb") as f:
            f.write(buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Wellster",
    conversion="Revenues",
    description="Wellster Revenues conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 2,
                "max_files": 2,
                "extensions": ["csv"],
            },
        ),
    },
    output_type="zip",
)
def wellster_revenues(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]

    try:
        df_revenue = pl.read_csv(file1, separator=",", infer_schema_length=10000)
        assert df_revenue.width == 26
    except FileNotFoundError as e:
        raise Exception("Die Revenue Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Fehler beim Lesen der Revenue Datei, bitte überprüfen, ob die Struktur richtig ist!") from e

    df_revenue = df_revenue.drop('adyen_payment_intent')

    try:
        df_user = pl.read_csv(file2, separator=";", infer_schema_length=10000, encoding="ISO-8859-1")
        assert df_user.width == 6
    except FileNotFoundError as e:
        raise Exception("Die User Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Fehler beim Lesen der User Datei, bitte überprüfen, ob die Struktur richtig ist!") from e

    df_user = df_user.rename({df_user.columns[0]: "user_id", df_user.columns[5]: "konto_user"}).select(["user_id", "konto_user"]).unique(subset="user_id")

    df_revenue = df_revenue.with_columns([pl.when(pl.col("revenue_type") == "digital_german_revenues").then(pl.lit("810010")).otherwise(pl.lit("")).alias("gegenkonto")])
    df_revenue = df_revenue.with_columns(
        [
            pl.when(pl.col("revenue_type") == "digital_revenues").then(pl.lit("160430")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"),
        ]
    )

    df_revenue = df_revenue.with_columns([pl.when(pl.col("revenue_type") == "rx_otc_revenues").then(pl.lit("840600")).otherwise(pl.col("gegenkonto")).alias("gegenkonto")])
    df_revenue = df_revenue.with_columns(
        [
            pl.when(pl.col("revenue_type") == "shipping_revenues").then(pl.lit("840900")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"),
        ]
    )
    df_revenue = df_revenue.with_columns(
        [
            pl.when((pl.col("revenue_type") == "ur_revenues") & (pl.col("retailer") == "Apon") & (pl.col("tax_rate").cast(pl.Utf8) == "0.07"))
            .then(pl.lit("832002"))
            .otherwise(pl.col("gegenkonto"))
            .alias("gegenkonto"),
        ]
    )
    df_revenue = df_revenue.with_columns(
        [
            pl.when((pl.col("revenue_type") == "ur_revenues") & (pl.col("retailer") == "Apon") & (pl.col("tax_rate").cast(pl.Utf8) == "0.19"))
            .then(pl.lit("832001"))
            .otherwise(pl.col("gegenkonto"))
            .alias("gegenkonto"),
        ]
    )
    df_revenue = df_revenue.with_columns(
        [
            pl.when((pl.col("revenue_type") == "ur_revenues") & (pl.col("retailer") == "Gate56") & (pl.col("tax_rate").cast(pl.Utf8) == "0.07"))
            .then(pl.lit("830700"))
            .otherwise(pl.col("gegenkonto"))
            .alias("gegenkonto"),
        ]
    )
    df_revenue = df_revenue.with_columns(
        [
            pl.when((pl.col("revenue_type") == "ur_revenues") & (pl.col("retailer") == "Gate56") & (pl.col("tax_rate").cast(pl.Utf8) == "0.19"))
            .then(pl.lit("840700"))
            .otherwise(pl.col("gegenkonto"))
            .alias("gegenkonto"),
        ]
    )
    df_revenue = df_revenue.with_columns(
        [
            pl.when(pl.col("invoice_deployer_name") == "BNS").then(pl.lit("160440")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"),
        ]
    )
    df_revenue = df_revenue.with_columns([pl.when(pl.col("revenue_type").is_null()).then(pl.lit("159100")).otherwise(pl.col("gegenkonto")).alias("gegenkonto")])
    df_revenue = df_revenue.with_columns(
        [
            pl.when(pl.col("amount").cast(pl.Utf8).str.contains("-")).then(pl.lit("H")).otherwise(pl.lit("S")).alias("s_h"),
        ]
    )
    df_revenue = df_revenue.with_columns(
        [
            pl.col("amount").cast(pl.Utf8).str.replace_all(r"\-", "").str.replace_all(r"\,", "").str.replace_all(r"\.", ",").alias("amount"),
        ]
    )
    df_revenue = df_revenue.with_columns([pl.col("tax_rate").cast(pl.Utf8).str.replace_all(r"\.", ",").alias("tax_rate")])

    df_merge = df_revenue.join(df_user, on="user_id", how="left")

    df_merge = df_merge.with_columns(
        [
            pl.when(pl.col("gegenkonto").cast(pl.Utf8).is_in(["832002", "832001"])).then(pl.lit("NL826534405B01")).otherwise(pl.lit("")).alias("landhk"),
        ]
    )
    df_merge = df_merge.with_columns([pl.when(pl.col("payment_provider").str.contains("stripe")).then(pl.col("stripe_payment_intent")).otherwise(pl.lit("")).alias("auftragsnummer")])
    df_merge = df_merge.with_columns([pl.when(pl.col("payment_provider").str.contains("paypal")).then(pl.col("paypal_txn_id")).otherwise(pl.col("auftragsnummer")).alias("auftragsnummer")])
    df_merge = df_merge.with_columns([pl.when(pl.col("payment_provider").is_null()).then(pl.lit("not found")).otherwise(pl.col("auftragsnummer")).alias("auftragsnummer")])

    cols = df_merge.columns
    df_merge = df_merge.select(
        [
            pl.col(cols[7]).alias("umsatz"),
            pl.col(cols[8]).alias("sh"),
            pl.col(cols[25]).alias("gegenkonto"),
            pl.col(cols[1]).alias("belegfeld"),
            pl.col(cols[10]).alias("datum"),
            pl.col(cols[14]).alias("buchungstext"),
            pl.col(cols[17]).alias("steuersatz"),
            pl.col(cols[27]).alias("landhk"),
            pl.col(cols[28]).alias("auftragsnummer"),
            pl.col(cols[26]).cast(pl.Utf8).alias("konto"),
            pl.col(cols[11]).alias("debitor_id"),
            pl.col(cols[12]).alias("user_id"),
            pl.col(cols[18]).alias("payment_provider"),
            pl.col(cols[21]).alias("stripe-paypal"),
        ]
    )
    df_usage = df_merge.clone()

    df_merge = df_merge.with_columns(
        [
            pl.when(pl.col("gegenkonto").cast(pl.Utf8).is_in(["832002", "832001"])).then(pl.lit("DE")).otherwise(pl.col("landhk")).alias("eulandbest"),
            pl.col("datum").str.replace_all(r"\.", "").alias("datum"),
        ]
    )
    df_merge = df_merge.with_columns(
        [
            pl.col("datum").str.slice(0, 4).cast(pl.Utf8).alias("datum"),
            pl.col("auftragsnummer").cast(pl.Utf8),
        ]
    ).drop(["debitor_id", "user_id", "payment_provider", "stripe-paypal"])

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Wellster",
        conversion="Revenues",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="zip",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        df_export = datev_export_polars(
            df=df_merge,
            month=month,
            year=year,
            buffer=buffer,
            bernr="673388",
            mdtnr="17815",
            skl="6",
            skr="3",
            text="Wellster Revenue",
        )

        with ZipFile(output_path, "w") as zf:
            with zf.open(f"DTVF_Wellster_Revenues_{year}_{month}.csv", "w") as f:
                f.write(df_export.read())

            with zf.open(f"Debitoren_Wellster_Revenues_{year}_{month}.csv", "w") as f:
                f.write(df_usage.write_csv(separator=";").encode("utf-8"))

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Wellster",
    conversion="Stripe",
    description="Wellster Stripe conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 2,
                "max_files": 2,
                "extensions": ["csv"],
            },
        ),
    },
    output_type="zip",
)
def wellster_stripe(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]

    try:
        df_stripe = pl.read_csv(file1, separator=",", infer_schema_length=0)
        assert df_stripe.width == 51
    except FileNotFoundError as e:
        raise Exception("Die Stripe Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Stripe Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_stripe = df_stripe.rename(
        {
            df_stripe.columns[9]: "wkz",
            df_stripe.columns[10]: "umsatz",
            df_stripe.columns[28]: "auftragsnummer",
            df_stripe.columns[38]: "belegfeld",
        }
    )

    df_stripe = df_stripe.with_columns(
        pl.lit("120030").alias("konto"),
        pl.concat_str(
            [
                pl.col("balance_transaction_reporting_category"),
                pl.lit(" "),
                pl.col("balance_transaction_component"),
            ]
        ).alias("buchungstext"),
    )

    df_network = pl.DataFrame(
        {
            "umsatz": [str(df_stripe.filter(pl.col("buchungstext").str.contains("network")).select(pl.col("umsatz").cast(pl.Float64).sum().round(2)).item())],
            "sh": ["S"],
            "wkz": ["EUR"],
            "datum": [f"01{month}"],
            "konto": ["120030"],
            "belegfeld": ["Sammelposten Network Costs"],
            "buchungstext": ["Sammelposten Network Costs"],
            "auftragsnummer": ["Sammelposten Network Costs"],
            "gegenkonto": ["497030"],
        }
    )

    df_stripe = (
        df_stripe.filter(~pl.col("buchungstext").str.contains("network"))
        .with_columns(
            [
                pl.when(pl.col("umsatz").str.contains("-")).then(pl.lit("H")).otherwise(pl.lit("S")).alias("sh"),
                pl.col("umsatz").cast(pl.Float64).round(2).cast(str).str.replace_all(r"\-", "").str.replace_all(r"\.", ",").alias("umsatz"),
                (pl.col("activity_end_date").str.slice(-2) + pl.col("activity_end_date").str.slice(5, 2)).alias("datum"),
            ]
        )
        .select(
            [
                "umsatz",
                "sh",
                "wkz",
                "datum",
                "konto",
                "belegfeld",
                "buchungstext",
                "auftragsnummer",
            ]
        )
    )

    df_network = df_network.with_columns(
        [
            pl.when(pl.col("umsatz").str.contains("-")).then(pl.lit("H")).alias("sh"),
            pl.col("umsatz").str.replace_all(r"\-", "").str.replace_all(r"\.", ",").alias("umsatz"),
        ]
    )

    try:
        df_usage = pl.read_csv(file2, separator=";")
        assert df_usage.width == 14
    except FileNotFoundError as e:
        raise Exception("Die Debitor Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Debitor Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_stripepaypal = (
        df_usage.filter(pl.col("payment_provider") == "stripe-paypal")
        .select(pl.col("stripe-paypal").alias("auftragsnummer"))
        .unique(subset=["auftragsnummer"])
        .with_columns(pl.lit("x").alias("match"))
        .filter(pl.col("auftragsnummer").is_not_null())
    )

    df_stripepaypal = df_stripe.join(df_stripepaypal, on="auftragsnummer", how="left")

    df_stripe = df_stripepaypal.filter(pl.col("match").is_null()).clone().drop("match")

    df_stripepaypal = df_stripepaypal.filter(pl.col("match") == "x").with_columns(pl.lit("136031").alias("gegenkonto")).drop("match")

    df_stripe = df_stripe.with_columns(
        pl.when(pl.col("buchungstext").str.contains("fee")).then(pl.lit("497030")).when(pl.col("buchungstext").str.contains("transfer")).then(pl.lit("136030")).otherwise(pl.lit(None)).alias("gegenkonto")
    )

    df_stripe_match = df_stripe.filter(pl.col("gegenkonto").is_null()).drop("gegenkonto")

    df_stripe = df_stripe.filter(pl.col("gegenkonto").is_in(["497030", "136030"]))

    df_usage = (
        df_usage.filter(pl.col("payment_provider").str.contains("stripe") & ~pl.col("payment_provider").str.contains("paypal"))
        .select(
            [
                pl.col("konto").alias("gegenkonto"),
                pl.col("stripe-paypal").alias("auftragsnummer"),
            ]
        )
        .unique(subset=["auftragsnummer"])
    )

    df_match = df_stripe_match.join(df_usage, on="auftragsnummer", how="left")
    df_match = df_match.with_columns(pl.when(pl.col("gegenkonto").is_null()).then(pl.lit("159096")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))

    df_ergebnis = pl.concat([df_match, df_stripe, df_stripepaypal, df_network])

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Wellster",
        conversion="Stripe",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        datev_export_polars(
            df=df_ergebnis,
            month=month,
            year=year,
            buffer=buffer,
            bernr="673388",
            mdtnr="17815",
            skl="6",
            skr="3",
            text="Wellster Stripe",
        )

        with open(output_path, "wb") as f:
            f.write(buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
