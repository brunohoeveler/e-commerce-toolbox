import io
from pathlib import Path
from zipfile import ZipFile

import polars as pl
from fastapi import UploadFile

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.datev_export import datev_export_polars
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_output_path, strip_task_id


@register_data_conversion(
    data_conversion="Item",
    conversion="ASCII",
    description="Item ASCII conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 2,
                "max_files": 2,
                "extensions": ["csv", "txt", "xlsx", "xls"],
            },
        ),
    },
    output_type="zip",
)
def item_ascii(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]

    try:
        df_import = pl.read_csv(
            file1,
            separator="|",
            infer_schema=False,
            skip_rows=1,
            truncate_ragged_lines=True,
            ignore_errors=True,
        )
        assert df_import.width == 400
    except FileNotFoundError as e:
        raise Exception("Die PlentyMarkets Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der PlentyMarkets ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_import = df_import.rename(
        {
            df_import.columns[4]: "maid",
            df_import.columns[5]: "nachname",
            df_import.columns[6]: "vorname",
            df_import.columns[125]: "zahlungsart",
            df_import.columns[129]: "kreditkartennummer",
            df_import.columns[119]: "bu",
            df_import.columns[166]: "sachkonto",
            df_import.columns[18]: "sapsuche",
            df_import.columns[62]: "transaktionstyp",
            df_import.columns[63]: "datum",
            df_import.columns[168]: "umsatz",
            df_import.columns[145]: "zahlungsempfaenger",
            df_import.columns[10]: "standort",
        }
    )
    df_import = df_import.select(
        [
            "maid",
            "vorname",
            "nachname",
            "zahlungsart",
            "kreditkartennummer",
            "bu",
            "sachkonto",
            "sapsuche",
            "transaktionstyp",
            "datum",
            "umsatz",
            "zahlungsempfaenger",
            "standort",
        ]
    )
    df_import = df_import.with_columns(pl.col("sachkonto").str.replace(" ", ""))
    df_import = df_import.filter(~pl.col("umsatz").is_in(["0,00"]))
    df_import = df_import.filter(pl.col("sachkonto").is_not_null())
    df_import = df_import.filter(~pl.col("zahlungsart").is_in(["CBCP", "COPD"]))
    df_cash = df_import.filter(pl.col("zahlungsart").str.contains("(?i)cash"))
    df_card = df_import.filter(~pl.col("zahlungsart").str.contains("(?i)cash"))

    try:
        df_activecc = pl.read_excel(file2)
        # assert df_activecc.width == 37
    except FileNotFoundError as e:
        raise Exception("Die PlentyMarkets Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der PlentyMarkets ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_activecc = df_activecc.rename(
        {
            df_activecc.columns[4]: "maid",
            df_activecc.columns[5]: "category",
            df_activecc.columns[0]: "gegenkonto",
        }
    )
    df_activecc = df_activecc.select(["maid", "category", "gegenkonto"])
    df_activecash = df_activecc.filter(pl.col("category").str.contains("(?i)cash"))
    df_activecash = df_activecash.unique(subset=["maid"])
    df_activecard = df_activecc.filter(~pl.col("category").str.contains("(?i)cash"))
    df_activecard = df_activecard.unique(subset=["maid"])

    df_cardmerge = df_card.join(df_activecard, on="maid", how="left")
    df_cashmerge = df_cash.join(df_activecash, on="maid", how="left")

    df_merge = pl.concat([df_cardmerge, df_cashmerge])

    df_merge = df_merge.with_columns(pl.when(~pl.col("category").str.contains("(?i)cash")).then(pl.col("datum").str.slice(0, 7)).otherwise(pl.col("sapsuche")).alias("sapsuche")).drop("category")

    df_merge = df_merge.with_columns(pl.col("zahlungsempfaenger").str.slice(0, 35))
    df_merge = df_merge.with_columns((pl.col("transaktionstyp") + " // " + pl.col("zahlungsempfaenger")).alias("buchungstext"))
    df_merge = df_merge.with_columns(
        pl.when(pl.col("buchungstext").is_null()).then(pl.col("nachname").cast(pl.Utf8) + ": " + pl.col("transaktionstyp").cast(pl.Utf8)).otherwise(pl.col("buchungstext")).alias("buchungstext")
    )
    df_merge = df_merge.with_columns(pl.when(pl.col("bu").is_in(["80", "90"])).then(pl.col("bu").str.slice(0, 1)).otherwise(pl.col("bu")).alias("bu"))

    df_merge = df_merge.drop(
        [
            "transaktionstyp",
            "zahlungsempfaenger",
            "sapsuche",
            "vorname",
            "nachname",
            "zahlungsart",
            "kreditkartennummer",
        ]
    )
    df_merge = df_merge.rename({"maid": "belegfeld", "sachkonto": "konto", "datum": "belegdatum"})
    df_merge = df_merge.select(
        [
            "umsatz",
            "belegdatum",
            "konto",
            "gegenkonto",
            "bu",
            "belegfeld",
            "buchungstext",
            "standort",
        ]
    )
    df_merge = df_merge.with_columns([pl.when(pl.col("bu").is_null()).then(pl.lit("490")).otherwise(pl.col("bu")).alias("bu")])
    df_merge = df_merge.with_columns(pl.when((pl.col("bu") == "490") & (pl.col("konto") == "46500000")).then(pl.lit("52")).otherwise(pl.col("bu")).alias("bu"))
    df_merge = df_merge.with_columns(pl.col("gegenkonto").cast(pl.String))

    df_merge = df_merge.drop("standort")


    # ========================== SPEICHERN =========================
    output_path = generate_output_path(
        user_id=user_id,
        data_conversion="Item",
        conversion="ASCII",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="zip",
    )

    ensure_output_folder(output_path)

    ascii_buffer = io.BytesIO()

    with ZipFile(output_path, "w") as zf:
        ascii_buffer.seek(0)
        df_merge.write_csv(ascii_buffer, separator=";")
        ascii_buffer.seek(0)
        zf.writestr(f"Item_Ascii_{year}_{month}.csv", ascii_buffer.read())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Item",
    conversion="Debitoren",
    description="Item Debitoren conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["csv", "txt"],
            },
        ),
    },
    output_type="csv",
)
def item_deb(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]

    try:
        df_debitoren = pl.read_csv(
            file1,
            separator=";",
            has_header=False,
            new_columns=[
                "wkz",
                "umsatz",
                "sh",
                "gegenkonto",
                "belegfeld",
                "datum",
                "konto",
                "y",
                "x",
                "kurs",
                "z",
                "Beleglink",
            ],
        )
        assert df_debitoren.width == 12
    except FileNotFoundError as e:
        raise Exception("Die PlentyMarkets Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der PlentyMarkets ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e
    df_debitoren = df_debitoren.select(
        [
            "wkz",
            "umsatz",
            "sh",
            "gegenkonto",
            "belegfeld",
            "datum",
            "konto",
            "kurs",
            "Beleglink",
        ]
    )

    df_debitoren = df_debitoren.with_columns([pl.col("datum").str.replace_all(r"\.", "").alias("datum")])

    df_debitoren = df_debitoren.with_columns([pl.col("konto").cast(pl.Utf8), pl.col("gegenkonto").cast(pl.Utf8)])

    df_debitoren = df_debitoren.with_columns(pl.col("datum").str.slice(0, 4).alias("datum"))

    df_debitoren = df_debitoren.with_columns([pl.col(col).cast(pl.Utf8) for col in df_debitoren.columns])

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path(user_id=user_id, data_conversion="Item", conversion="Debitoren", month=month, year=year, task_id=task.request.id, extension="csv", datev=True)

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        datev_export_polars(
            df=df_debitoren,
            month=month,
            year=year,
            buffer=buffer,
            bernr="12168",
            mdtnr="10076",
            skl="8",
            skr="3",
            text="Item Debitoren Import",
        )

        with open(output_path, "wb") as f:
            f.write(buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Item",
    conversion="Stammdaten",
    description="Item Stammdaten conversion",
    input_type={
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["csv", "txt"],
            },
        ),
    },
    output_type="csv",
)
def item_stammdaten(task, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]

    try:
        column_names = [
            "konto",
            "name",
            "trash",
            "trash2",
            "euland",
            "strasse",
            "plz",
            "ort",
            "land",
            "bedingung1",
            "bedingung2",
        ]
        column_types = {name: pl.Utf8 for name in column_names}
        df_debitoren = pl.read_csv(
            file1,
            separator=";",
            has_header=False,
            new_columns=column_names,
            schema_overrides=column_types,
            encoding="latin-1",
        )
        assert df_debitoren.width == 11
    except FileNotFoundError as e:
        raise Exception("Die PlentyMarkets Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der PlentyMarkets ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e
    try:
        df_deb_bedingungen = pl.read_excel("resources/item_bedingungen.xlsx")
    except FileNotFoundError as e:
        raise Exception("Eine Interne Datei fehlt bitte melden Sie dich beim Software Solutions Team") from e

    df_debitoren = df_debitoren.drop(["trash", "trash2"])

    df_deb_bedingungen = df_deb_bedingungen.rename(
        {
            df_deb_bedingungen.columns[0]: "bedingung",
            df_deb_bedingungen.columns[1]: "nummer",
        }
    ).select(["bedingung", "nummer"])

    df_debitoren = df_debitoren.with_columns((pl.col("bedingung1") + " " + pl.col("bedingung2")).alias("bedingung"))

    df_merge = df_debitoren.join(df_deb_bedingungen, on="bedingung", how="left")

    df_merge = df_merge.with_columns(pl.col("nummer").cast(str).alias("nummer"))

    df_merge = df_merge.rename(
        {
            df_merge.columns[0]: "konto",
            df_merge.columns[1]: "name",
            df_merge.columns[2]: "euland",
            df_merge.columns[3]: "strasse",
            df_merge.columns[4]: "plz",
            df_merge.columns[5]: "ort",
            df_merge.columns[6]: "land",
            df_merge.columns[7]: "bedingung1",
            df_merge.columns[8]: "bedingung2",
            df_merge.columns[9]: "bedingung",
            df_merge.columns[10]: "nummer",
        }
    )

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path(
        user_id=user_id,
        data_conversion="Item",
        conversion="Stammdaten",
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with open(output_path, mode="w", encoding="utf-8-sig", newline="") as f:
        f.write(df_merge.write_csv(separator=";"))

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}



@register_data_conversion(
    data_conversion="Item",
    conversion="ASCII_neu",
    description="Item ASCII conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 2,
                "max_files": 2,
                "extensions": ["csv", "txt", "xlsx", "xls"],
            },
        ),
    },
    output_type="zip",
)
def item_ascii_neu(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]

    try:
        df_import = pl.read_csv(
            file1,
            separator="|",
            infer_schema=False,
            skip_rows=1,
            truncate_ragged_lines=True,
            ignore_errors=True,
        )
        assert df_import.width == 400
    except FileNotFoundError as e:
        raise Exception("Die ASCII Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der ASCII Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_import = df_import.rename(
        {
            df_import.columns[4]: "maid",
            df_import.columns[5]: "nachname",
            df_import.columns[6]: "vorname",
            df_import.columns[125]: "zahlungsart",
            df_import.columns[129]: "kreditkartennummer",
            df_import.columns[119]: "bu",
            df_import.columns[166]: "sachkonto",
            df_import.columns[18]: "sapsuche",
            df_import.columns[62]: "transaktionstyp",
            df_import.columns[63]: "datum",
            df_import.columns[168]: "umsatz",
            df_import.columns[145]: "zahlungsempfaenger",
            df_import.columns[10]: "standort",
        }
    )
    df_import = df_import.select(
        [
            "maid",
            "vorname",
            "nachname",
            "zahlungsart",
            "kreditkartennummer",
            "bu",
            "sachkonto",
            "sapsuche",
            "transaktionstyp",
            "datum",
            "umsatz",
            "zahlungsempfaenger",
            "standort",
        ]
    )
    df_import = df_import.with_columns(pl.col("sachkonto").str.replace(" ", ""))
    df_import = df_import.filter(~pl.col("umsatz").is_in(["0,00"]))
    df_import = df_import.filter(pl.col("sachkonto").is_not_null())
    df_import = df_import.filter(~pl.col("zahlungsart").is_in(["CBCP", "COPD"]))
    df_cash = df_import.filter(pl.col("zahlungsart").str.contains("(?i)cash"))
    df_card = df_import.filter(~pl.col("zahlungsart").str.contains("(?i)cash"))

    try:
        df_activecc = pl.read_excel(file2)
        # assert df_activecc.width == 37
    except FileNotFoundError as e:
        raise Exception("Die PlentyMarkets Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der PlentyMarkets ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_activecc = df_activecc.rename(
        {
            df_activecc.columns[4]: "maid",
            df_activecc.columns[5]: "category",
            df_activecc.columns[0]: "gegenkonto",
        }
    )
    df_activecc = df_activecc.select(["maid", "category", "gegenkonto"])
    df_activecash = df_activecc.filter(pl.col("category").str.contains("(?i)cash"))
    df_activecash = df_activecash.unique(subset=["maid"])
    df_activecard = df_activecc.filter(~pl.col("category").str.contains("(?i)cash"))
    df_activecard = df_activecard.unique(subset=["maid"])

    df_cardmerge = df_card.join(df_activecard, on="maid", how="left")
    df_cashmerge = df_cash.join(df_activecash, on="maid", how="left")

    df_merge = pl.concat([df_cardmerge, df_cashmerge])

    df_merge = df_merge.with_columns(pl.when(~pl.col("category").str.contains("(?i)cash")).then(pl.col("datum").str.slice(0, 7)).otherwise(pl.col("sapsuche")).alias("sapsuche")).drop("category")

    df_merge = df_merge.with_columns(pl.col("zahlungsempfaenger").str.slice(0, 35))
    df_merge = df_merge.with_columns((pl.col("transaktionstyp") + " // " + pl.col("zahlungsempfaenger")).alias("buchungstext"))
    df_merge = df_merge.with_columns(
        pl.when(pl.col("buchungstext").is_null()).then(pl.col("nachname").cast(pl.Utf8) + ": " + pl.col("transaktionstyp").cast(pl.Utf8)).otherwise(pl.col("buchungstext")).alias("buchungstext")
    )
    df_merge = df_merge.with_columns(pl.when(pl.col("bu").is_in(["80", "90"])).then(pl.col("bu").str.slice(0, 1)).otherwise(pl.col("bu")).alias("bu"))

    df_merge = df_merge.drop(
        [
            "transaktionstyp",
            "zahlungsempfaenger",
            "sapsuche",
            "vorname",
            "nachname",
            "zahlungsart",
            "kreditkartennummer",
        ]
    )
    df_merge = df_merge.rename({"maid": "belegfeld", "sachkonto": "konto", "datum": "belegdatum"})
    df_merge = df_merge.select(
        [
            "umsatz",
            "belegdatum",
            "konto",
            "gegenkonto",
            "bu",
            "belegfeld",
            "buchungstext",
            "standort",
        ]
    )
    df_merge = df_merge.with_columns([pl.when(pl.col("bu").is_null()).then(pl.lit("490")).otherwise(pl.col("bu")).alias("bu")])
    df_merge = df_merge.with_columns(pl.when((pl.col("bu") == "490") & (pl.col("konto") == "46500000")).then(pl.lit("52")).otherwise(pl.col("bu")).alias("bu"))
    df_merge = df_merge.with_columns(pl.col("gegenkonto").cast(pl.String))
    df_merge = df_merge.with_columns(pl.when(pl.col('gegenkonto').str.slice(0, 5) == '70001').then(pl.lit('17400100')).otherwise(pl.col('gegenkonto')).alias('gegenkonto'))

    df_lohn = df_merge.filter(pl.col('gegenkonto') == '17400100')
    df_merge = df_merge.drop("standort")
    df_merge = df_merge.with_columns(pl.col("belegdatum").cast(pl.String))
    df_merge = df_merge.with_columns(pl.col("gegenkonto").cast(pl.String))
    df_merge = df_merge.with_columns(pl.when(pl.col('gegenkonto').str.slice(0,5) == '70002')
                                     .then(pl.concat_str([
                                        pl.col('belegdatum').str.slice(0,4),
                                        pl.lit('-'),
                                        pl.col('belegdatum').str.slice(5, 2)]))
                                     .otherwise(pl.col('belegfeld')).alias('belegfeld'))


    df_mapping = pl.DataFrame({
        "standort": ["Nossen", "Ulm", "Mannheim", "Hamburg", "Mühlhausen", "Hannover", "Berlin", "Ludwigsburg",
                     "Solingen (FRI)", "Solingen (PIE)", "Freiburg"],
        "mandantennr": ["10444", "10446", "10445", "10431", "10441", "10436", "10439", "10448",
                     "18073", "10430", "10447"]
    })

    hr_abteilung = ['1023', '1370', '1372', '1497', '1778', '1838', '2019', '2406', '2435', '2466', '2787', '2834',
                    '2925']
    bf_abteilung = ['0005', '0008', '0009', '1212', '1439']

    df_lohn = df_lohn.join(df_mapping, on='standort', how='left')
    df_lohn = df_lohn.with_columns(pl.when(pl.col('belegfeld').is_in(hr_abteilung)).then(pl.lit('10681')).
                                   otherwise(pl.col('mandantennr')).alias('mandantennr'))
    df_lohn = df_lohn.with_columns(pl.when(pl.col('belegfeld').is_in(bf_abteilung)).then(pl.lit('10429')).
                                   otherwise(pl.col('mandantennr')).alias('mandantennr'))

    df_lohn = df_lohn.with_columns(pl.when(pl.col('konto') == '46640000').then(pl.lit('9979'))
                                   .otherwise(pl.lit('9099')).alias('konto'))
    df_lohn = df_lohn.with_columns(pl.col('umsatz').str.replace_all(r'\,', '.'))
    df_lohn = df_lohn.cast({'umsatz': pl.Float64})

    df_lohn = (df_lohn.group_by(['konto', 'gegenkonto', 'belegfeld', 'standort', 'mandantennr'])
               .agg(pl.sum('umsatz').alias('umsatz')))

    df_lohn = df_lohn.cast({'umsatz': pl.String})
    df_lohn = df_lohn.with_columns(pl.col('umsatz').str.replace_all(r'\.', ','))

    df_lohn = df_lohn.select(['umsatz', 'konto', 'gegenkonto', 'belegfeld','mandantennr', 'standort'])
    df_lohn = df_lohn.rename({'belegfeld': 'personalnr', 'konto': 'kennziffer'})

    # ========================== SPEICHERN =========================
    output_path = generate_output_path(
        user_id=user_id,
        data_conversion="Item",
        conversion="ASCII",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="zip",
    )

    ensure_output_folder(output_path)

    ascii_buffer = io.BytesIO()
    lohn_buffer = io.BytesIO()

    with ZipFile(output_path, "w") as zf:
        ascii_buffer.seek(0)
        df_merge.write_csv(ascii_buffer, separator=";")
        ascii_buffer.seek(0)
        zf.writestr(f"Item_Ascii_{year}_{month}.csv", ascii_buffer.read())
        lohn_buffer.seek(0)
        df_lohn.write_csv(lohn_buffer, separator=";")
        lohn_buffer.seek(0)
        zf.writestr(f"Item_Lohn_{year}_{month}.csv", lohn_buffer.read())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}