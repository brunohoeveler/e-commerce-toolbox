import io
from pathlib import Path

import polars as pl
from fastapi import UploadFile

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.datev_export import datev_export_polars
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_output_path_datev, strip_task_id


@register_data_conversion(
    data_conversion="JustVirtual",
    conversion="invoices",
    description="JustVirtual Invoices conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["csv"],
            },
        ),
    },
    output_type="csv",
)
def justvirtual_invoices_import(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]

    # ========================== IMPORT DATEI ==========================
    try:
        df_import = pl.read_csv(file1, separator=";", infer_schema_length=0)
    except FileNotFoundError as e:
        raise Exception("Die csv-Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der csv-Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_import = df_import[
        "19_steuer_netto",
        "19_steuer_betrag",
        "7_steuer_netto",
        "7_steuer_betrag",
        "dokument_art",
        "rechnungsadresse_interne_id",
        "rechnungsdatum",
        "rechnungsnummer",
        "rechnungsadresse_vorname",
        "rechnungsadresse_nachname",
        "status",
        "rechnungsadresse_land",
    ]

    df_import = df_import.with_columns(pl.concat_str(pl.col("dokument_art"), pl.lit(" - "), pl.col("rechnungsadresse_vorname"), pl.lit(" "), pl.col("rechnungsadresse_nachname")).alias("buchungstext"))

    df_import = df_import.filter(pl.col("status").is_in(["Bezahlt", "Festgeschrieben"]))
    df_import = df_import.filter(pl.col("rechnungsadresse_land") == "DE")
    df_import = df_import.with_columns(pl.col('19_steuer_betrag').str.replace_all(r"\,", "."))
    df_import = df_import.with_columns(pl.col('19_steuer_netto').str.replace_all(r"\,", "."))
    df_import = df_import.with_columns(pl.col('7_steuer_betrag').str.replace_all(r"\,", "."))
    df_import = df_import.with_columns(pl.col('7_steuer_netto').str.replace_all(r"\,", "."))
    df_import = df_import.with_columns((pl.col('19_steuer_betrag').cast(pl.Float64) + pl.col('19_steuer_netto').cast(pl.Float64))
                                       .alias('19_steuer_netto').cast(pl.String))
    df_import = df_import.with_columns((pl.col('7_steuer_betrag').cast(pl.Float64) + pl.col('7_steuer_netto').cast(pl.Float64))
                                       .alias('7_steuer_netto').cast(pl.String))
    df_import = df_import.with_columns(pl.col('19_steuer_netto').str.replace_all(r"\.", ","))
    df_import = df_import.with_columns(pl.col('7_steuer_netto').str.replace_all(r"\.", ","))

    df_import = df_import.drop("dokument_art", "rechnungsadresse_nachname", "rechnungsadresse_vorname", "status", "rechnungsadresse_land", "7_steuer_betrag", "19_steuer_betrag")
    df_import = df_import.rename({"rechnungsnummer": "belegfeld", "rechnungsdatum": "datum", "rechnungsadresse_interne_id": "gegenkonto", "19_steuer_netto": "4406", "7_steuer_netto": "4306"})
    df_import = df_import.unpivot(index=["gegenkonto", "datum", "belegfeld", "buchungstext"], variable_name="konto", value_name="umsatz")

    df_import = df_import.with_columns(pl.when(pl.col("gegenkonto").str.len_chars() == 1).then(pl.concat_str([pl.lit("1000"), pl.col("gegenkonto")])).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(pl.when(pl.col("gegenkonto").str.len_chars() == 2).then(pl.concat_str([pl.lit("100"), pl.col("gegenkonto")])).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(pl.when(pl.col("gegenkonto").str.len_chars() == 3).then(pl.concat_str([pl.lit("10"), pl.col("gegenkonto")])).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(pl.when(pl.col("gegenkonto").str.len_chars() == 4).then(pl.concat_str([pl.lit("1"), pl.col("gegenkonto")])).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))

    df_import = df_import.with_columns(pl.lit("H").alias("sh"))
    df_import = df_import.with_columns(pl.when(pl.col("umsatz").str.contains("-")).then(pl.lit("S")).otherwise(pl.col("sh")).alias("sh"))
    df_import = df_import.with_columns(pl.col("umsatz").str.replace("-", ""))
    df_import = df_import.filter(~pl.col("umsatz").is_in(["0,00", "0", "0,0"]))
    df_import = df_import.with_columns(pl.col("datum").str.replace_all(r"\.", ""))
    df_import = df_import.with_columns(pl.col("datum").str.slice(0, 4))

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="JustVirtual",
        conversion="invoices",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        datev_export_polars(
            df=df_import,
            month=month,
            year=year,
            buffer=buffer,
            bernr="85867",
            mdtnr="11030",
            skl="4",
            skr="4",
            text="Ghost Import Invoices",
        )

        with open(output_path, "wb") as f:
            f.write(buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="JustVirtual",
    conversion="billings",
    description="JustVirtual Billings conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["csv"],
            },
        ),
    },
    output_type="csv",
)
def justvirtual_billings_import(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]

    try:
        df_import = pl.read_csv(file1, separator=";", infer_schema_length=0)
    except FileNotFoundError as e:
        raise Exception("Die csv-Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der csv-Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_import = df_import[
        "19_steuer_betrag",
        "19_steuer_netto",
        "7_steuer_betrag",
        "7_steuer_netto",
        "lieferdienste_online_bezahlt_betrag",
        "lieferdienste_rueckerstattungen_betrag",
        "lieferdienste_trinkgeld_betrag",
        "rechnungsempfaenger_interne_id",
        "rechnungsempfaenger_nachname",
        "rechnungsempfaenger_vorname",
        "rechnungsempfaenger_vertragsname",
        "rechnungsempfaenger_land",
        "rechnungsinformationen_status",
        "rechnungsinformationen_rechnungsdatum",
        "rechnungsinformationen_rechnungsnummer",
    ]

    df_import = df_import.filter(pl.col("rechnungsempfaenger_land") == "DE")
    df_import = df_import.filter(pl.col("rechnungsinformationen_status") == "FINAL")
    df_import = df_import.with_columns(pl.concat_str(pl.col("rechnungsempfaenger_vorname"), pl.lit(" "), pl.col("rechnungsempfaenger_nachname")).alias("buchungstext"))

    columns_to_process = [
        "19_steuer_betrag",
        "19_steuer_netto",
        "7_steuer_betrag",
        "7_steuer_netto",
        "lieferdienste_online_bezahlt_betrag",
        "lieferdienste_rueckerstattungen_betrag",
        "lieferdienste_trinkgeld_betrag",
    ]

    df_import = df_import.with_columns([pl.col(col).str.replace_all(",", ".").cast(pl.Float64, strict=False) for col in columns_to_process])

    df_import = df_import.with_columns((pl.col("19_steuer_betrag") + pl.col("19_steuer_netto")).alias("19_brutto"))
    df_import = df_import.with_columns((pl.col("7_steuer_betrag") + pl.col("7_steuer_netto")).alias("7_brutto"))
    df_import = df_import.with_columns((pl.col("lieferdienste_online_bezahlt_betrag") + pl.col("lieferdienste_trinkgeld_betrag") - pl.col("lieferdienste_rueckerstattungen_betrag")).alias("online_gesamt"))

    columns_to_reprocess = ["19_brutto", "7_brutto", "online_gesamt"]

    df_import = df_import.with_columns([pl.col(col).round(2).cast(pl.String).str.replace_all(r"\.", ",") for col in columns_to_reprocess])

    df_import = df_import.rename(
        {
            "rechnungsempfaenger_interne_id": "gegenkonto",
            "rechnungsempfaenger_vertragsname": "vertragsname",
            "rechnungsinformationen_rechnungsdatum": "datum",
            "rechnungsinformationen_rechnungsnummer": "belegfeld",
        }
    )

    df_import = df_import.with_columns(pl.when(pl.col("gegenkonto").str.len_chars() == 1).then(pl.concat_str([pl.lit("1000"), pl.col("gegenkonto")])).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(pl.when(pl.col("gegenkonto").str.len_chars() == 2).then(pl.concat_str([pl.lit("100"), pl.col("gegenkonto")])).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(pl.when(pl.col("gegenkonto").str.len_chars() == 3).then(pl.concat_str([pl.lit("10"), pl.col("gegenkonto")])).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(pl.when(pl.col("gegenkonto").str.len_chars() == 4).then(pl.concat_str([pl.lit("1"), pl.col("gegenkonto")])).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))

    df_import = df_import.with_columns(pl.col("datum").str.replace_all(r"\.", ""))
    df_import = df_import.with_columns(pl.col("datum").str.slice(0, 4))

    df_import = df_import.drop(
        "rechnungsempfaenger_land",
        "rechnungsinformationen_status",
        "rechnungsempfaenger_vorname",
        "rechnungsempfaenger_nachname",
        "19_steuer_betrag",
        "19_steuer_netto",
        "7_steuer_betrag",
        "7_steuer_netto",
        "lieferdienste_online_bezahlt_betrag",
        "lieferdienste_rueckerstattungen_betrag",
        "lieferdienste_trinkgeld_betrag",
    )

    df_import = df_import.unpivot(index=["gegenkonto", "vertragsname", "datum", "buchungstext", "belegfeld"], value_name="umsatz")

    df_import = df_import.with_columns(pl.lit("x").alias("konto"))

    df_import = df_import.with_columns(
        pl.when((pl.col("vertragsname").str.contains("(?i)happy buns|happy-buns|happybuns")) & (pl.col("variable") == "19_brutto")).then(pl.lit("4400")).otherwise(pl.col("konto")).alias("konto")
    )
    df_import = df_import.with_columns(
        pl.when((pl.col("vertragsname").str.contains("(?i)happy buns|happy-buns|happybuns")) & (pl.col("variable") == "7_brutto")).then(pl.lit("4300")).otherwise(pl.col("konto")).alias("konto")
    )

    df_import = df_import.with_columns(
        pl.when((pl.col("vertragsname").str.contains("(?i)pizza junge|pizza-junge|pizzajunge")) & (pl.col("variable") == "19_brutto")).then(pl.lit("4401")).otherwise(pl.col("konto")).alias("konto")
    )
    df_import = df_import.with_columns(
        pl.when((pl.col("vertragsname").str.contains("(?i)pizza junge|pizza-junge|pizzajunge")) & (pl.col("variable") == "7_brutto")).then(pl.lit("4301")).otherwise(pl.col("konto")).alias("konto")
    )

    df_import = df_import.with_columns(
        pl.when((pl.col("vertragsname").str.contains("(?i)justsmashed|just smashed|just-smashed|just smash")) & (pl.col("variable") == "19_brutto")).then(pl.lit("4402")).otherwise(pl.col("konto")).alias("konto")
    )
    df_import = df_import.with_columns(
        pl.when((pl.col("vertragsname").str.contains("(?i)justsmashed|just smashed|just-smashed|just smash")) & (pl.col("variable") == "7_brutto")).then(pl.lit("4302")).otherwise(pl.col("konto")).alias("konto")
    )

    df_import = df_import.with_columns(
        pl.when((pl.col("vertragsname").str.contains("(?i)mr. beast|mr beast|mrbeast|mr.beast")) & (pl.col("variable") == "19_brutto")).then(pl.lit("4403")).otherwise(pl.col("konto")).alias("konto")
    )
    df_import = df_import.with_columns(
        pl.when((pl.col("vertragsname").str.contains("(?i)mr. beast|mr beast|mrbeast|mr.beast")) & (pl.col("variable") == "7_brutto")).then(pl.lit("4303")).otherwise(pl.col("konto")).alias("konto")
    )

    df_import = df_import.with_columns(pl.when((pl.col("vertragsname").str.contains("(?i)pinsta")) & (pl.col("variable") == "19_brutto")).then(pl.lit("4404")).otherwise(pl.col("konto")).alias("konto"))
    df_import = df_import.with_columns(pl.when((pl.col("vertragsname").str.contains("(?i)pinsta")) & (pl.col("variable") == "7_brutto")).then(pl.lit("4304")).otherwise(pl.col("konto")).alias("konto"))

    df_import = df_import.with_columns(
        pl.when((pl.col("vertragsname").str.contains("(?i)happy pockets|happypockets|happy-pockets")) & (pl.col("variable") == "19_brutto")).then(pl.lit("4405")).otherwise(pl.col("konto")).alias("konto")
    )
    df_import = df_import.with_columns(
        pl.when((pl.col("vertragsname").str.contains("(?i)happy pockets|happypockets|happy-pockets")) & (pl.col("variable") == "7_brutto")).then(pl.lit("4305")).otherwise(pl.col("konto")).alias("konto")
    )

    df_import = df_import.with_columns(pl.when(pl.col("variable") == "online_gesamt").then(pl.lit("1371")).otherwise(pl.col("konto")).alias("konto"))

    df_import = df_import.with_columns(pl.when(pl.col("buchungstext").str.contains("(?i)pizza trento")).then(pl.lit("28022")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))

    df_import = df_import.with_columns(pl.lit("H").alias("sh"))
    df_import = df_import.with_columns(pl.when(pl.col("variable") == "online_gesamt").then(pl.lit("S")).otherwise(pl.col("sh")).alias("sh"))

    df_import = df_import.filter(pl.col("umsatz") != "0,0")

    df_import = df_import.drop("variable", "vertragsname")

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="JustVirtual",
        conversion="billings",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        datev_export_polars(
            df=df_import,
            month=month,
            year=year,
            buffer=buffer,
            bernr="85867",
            mdtnr="11030",
            skl="4",
            skr="4",
            text="Ghost Import Billings",
        )

        with open(output_path, "wb") as f:
            f.write(buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
