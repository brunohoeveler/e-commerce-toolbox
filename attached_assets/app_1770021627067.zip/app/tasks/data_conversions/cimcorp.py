from pathlib import Path
from typing import List

import openpyxl
from fastapi import UploadFile
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Border, Font, PatternFill, Side

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.file_utils import (
    delete_input_files,
    ensure_output_folder,
    generate_output_path,
    strip_task_id,
)


# Funktion zum Anwenden der Regeln auf ein einzelnes Tabellenblatt
def apply_rules(sheet):
    gray_fill = PatternFill(start_color="DDDDDD", end_color="DDDDDD", fill_type="solid")
    orange_fill = PatternFill(start_color="FFA500", end_color="FFA500", fill_type="solid")
    blue_fill = PatternFill(start_color="00BFFF", end_color="00BFFF", fill_type="solid")
    bold_underline_font = Font(bold=True, underline="single")

    # Regel 1: Wenn in Spalte A "=901", "=902", "=903" oder "=906" steht, färbe die ganze Zeile leicht grau
    for row in sheet.iter_rows(min_row=2, max_row=sheet.max_row, min_col=1, max_col=sheet.max_column):
        for cell in row:
            if cell.value in [
                "=901",
                "=902",
                "=903",
                "=904",
                "=906",
                901,
                902,
                903,
                904,
                906,
            ]:
                for row_cell in row:
                    row_cell.fill = gray_fill

    # Regel 2: Wenn in Spalte A "=100" oder "=200" steht, färbe in derselben Zeile die Zelle in Spalte I orange und trage "to allocate" in Spalte J ein
    for row in sheet.iter_rows(min_row=2, max_row=sheet.max_row, min_col=1, max_col=1):
        for cell in row:
            if cell.value == "=100":
                sheet.cell(row=cell.row, column=9).fill = orange_fill
                sheet.cell(row=cell.row, column=10).value = "to allocate"
            elif cell.value == "=200":
                sheet.cell(row=cell.row, column=9).fill = orange_fill
                sheet.cell(row=cell.row, column=10).value = "to allocate"
            elif cell.value == 100:
                sheet.cell(row=cell.row, column=9).fill = orange_fill
                sheet.cell(row=cell.row, column=10).value = "to allocate"
            elif cell.value == 200:
                sheet.cell(row=cell.row, column=9).fill = orange_fill
                sheet.cell(row=cell.row, column=10).value = "to allocate"

    # Regel 3: Schreibe bestimmte Werte in bestimmte Zellen
    sheet["J1"] = "Legend"
    sheet["M2"] = "Workdays"
    sheet["M2"].font = bold_underline_font
    sheet["M3"] = "WD GER"
    sheet["N3"] = 0
    sheet["M4"] = "WD Total"
    sheet["N4"] = 0
    sheet["M6"] = "Allocation of costs"
    sheet["M6"].font = bold_underline_font
    sheet["M7"] = "Telephone"
    sheet["M8"] = "Monthly salary"
    sheet["M9"] = "Fixed holiday pay"
    sheet["M10"] = "Total"
    sheet["M11"] = "Portion GER"
    sheet["M12"] = "Portion FIN"
    sheet["P6"] = "taxable GER"
    sheet["P6"].font = bold_underline_font
    sheet["Q6"] = "tax-free GER/ taxable FIN"
    sheet["Q6"].font = bold_underline_font
    sheet["R6"] = "Lump-sum check"
    sheet["R6"].font = bold_underline_font
    sheet["S6"] = "Difference"
    sheet["S6"].font = bold_underline_font
    sheet["T6"] = "Check"
    sheet["T6"].font = bold_underline_font

    sheet.column_dimensions["B"].width = 30
    sheet.column_dimensions["K"].width = 15
    sheet.column_dimensions["M"].width = 20
    sheet.column_dimensions["P"].width = 12
    sheet.column_dimensions["Q"].width = 24
    sheet.column_dimensions["R"].width = 16
    sheet.column_dimensions["S"].width = 10
    sheet.column_dimensions["N"].width = 15

    # Regel 4: Wenn "=100", "=200" oder "=501" vorhanden ist, schreibe den Wert in bestimmte Zellen
    for row in sheet.iter_rows(min_row=2, max_row=sheet.max_row, min_col=1, max_col=1):
        for cell in row:
            if cell.value == "=100":
                sheet["N7"] = sheet.cell(row=cell.row, column=9).value
            elif cell.value == "=200":
                sheet["N8"] = sheet.cell(row=cell.row, column=9).value
            elif cell.value == "=501":
                sheet["N9"] = sheet.cell(row=cell.row, column=9).value
            elif cell.value == 100:
                sheet["N7"] = sheet.cell(row=cell.row, column=9).value
            elif cell.value == 200:
                sheet["N8"] = sheet.cell(row=cell.row, column=9).value
            elif cell.value == 501:
                sheet["N9"] = sheet.cell(row=cell.row, column=9).value

    # Regel 5: Schreibe Summen und Berechnungen in bestimmte Zellen
    sheet["N10"] = "=SUM(N7:N9)"
    sheet["N11"] = "=N10/N4*N3"
    sheet["N12"] = "=N10-N11"
    sheet["P7"] = '=SUMIF(J:J,"GER",I:I)'
    sheet["R7"] = "=P7+Q7"
    sheet["S7"] = '=R7-SUMIF(A:A,"990",I:I)'

    # Regel 6: Bedingte Formatierung für GER
    rule_ger = FormulaRule(
        formula=['$J2="GER"'],
        fill=PatternFill(start_color="00BFFF", end_color="00BFFF", fill_type="solid"),
    )
    sheet.conditional_formatting.add("I2:I" + str(sheet.max_row), rule_ger)

    # Regel 7: Bedingte Formatierung für FIN
    rule_fin = FormulaRule(
        formula=['$J2="FIN"'],
        fill=PatternFill(start_color="E2E2E2", end_color="E2E2E2", fill_type="solid"),
    )
    sheet.conditional_formatting.add("I2:I" + str(sheet.max_row), rule_fin)
    allocation_start_row = None
    # Regel 8: Währungsformat hinzufügen
    for row in sheet.iter_rows(min_row=1, max_row=sheet.max_row, min_col=13, max_col=13):  # Spalte M = Index 13
        for cell in row:
            if cell.value == "Allocation of costs":
                allocation_start_row = cell.row + 1  # Zeile direkt unterhalb der Überschrift
                break

    # Währungsformat für Spalte N (Von Allocation of costs bis zur ersten darauffolgenden leeren Zelle)
    if allocation_start_row:
        for row in sheet.iter_rows(min_row=allocation_start_row, max_row=sheet.max_row, min_col=14, max_col=14):  # Spalte N = Index 14
            for cell in row:
                if cell.value is None:  # Stop, wenn eine leere Zelle gefunden wird
                    break
                cell.number_format = "#,##0.00€"

    # Währungsformat für Spalten P bis T (Erste Zeile unterhalb der Überschriften)
    if allocation_start_row:
        for row in sheet.iter_rows(
            min_row=allocation_start_row,
            max_row=allocation_start_row,
            min_col=16,
            max_col=20,
        ):  # Spalten P-T = Index 16-20
            for cell in row:
                cell.number_format = "#,##0.00€"

    # Regel 9: Summe SV anhand der Lohnarten berechnen
    sv_sum_position = None
    sv_sum_formula = "=SUMIF(A:A, 901, I:I) + SUMIF(A:A, 902, I:I) + SUMIF(A:A, 903, I:I) + SUMIF(A:A, 904, I:I) + SUMIF(A:A, 906, I:I)"
    for row in sheet.iter_rows(min_row=1, max_row=sheet.max_row, min_col=1, max_col=1):
        for cell in row:
            if cell.value in [
                "=901",
                "=902",
                "=903",
                "=904",
                "=906",
                901,
                902,
                903,
                904,
                906,
            ]:
                sv_sum_position = cell.row
                break

    # Schreibt die SV Summe immer an die letzte grau markierte Zeile der Lohnarten 901 bis 906
    sheet[f"J{str(sv_sum_position - 1)}"] = "SUMME SV"
    sheet[f"J{str(sv_sum_position)}"] = sv_sum_formula

    # Regel 10: Portion GER & Portion FIN färben
    position_of_portion_fin = None
    for row in sheet.iter_rows(min_row=1, max_row=sheet.max_row, min_col=13, max_col=13):  # Spalte M = Index 13
        for cell in row:
            if cell.value == "Portion GER":
                neighbour_cell = sheet.cell(row=cell.row, column=cell.column + 1)  # Zelle rechts daneben
                neighbour_cell.fill = blue_fill  # Blaue Füllung anwenden
            if cell.value == "Portion FIN":
                neighbour_cell = sheet.cell(row=cell.row, column=cell.column + 1)
                neighbour_cell.fill = gray_fill
                # Position wird benötigt um Regel 11 zu positionieren
                position_of_portion_fin = cell.row

                break

    for row in sheet.iter_rows(min_row=1, max_row=sheet.max_row, min_col=16, max_col=16):  # Spalte P = Index 16
        for cell in row:
            if cell.value == "taxable GER":
                sheet.cell(row=cell.row + 1, column=cell.column).fill = blue_fill
                break

    # Sucht nach "tax-free GER/ taxable FIN" und färbt die Zelle darunter grau
    for row in sheet.iter_rows(min_row=1, max_row=sheet.max_row, min_col=17, max_col=17):  # Spalte Q = Index 17
        for cell in row:
            if cell.value == "tax-free GER/ taxable FIN":
                sheet.cell(row=cell.row + 1, column=cell.column).fill = gray_fill
                sheet.cell(row=cell.row + 1, column=cell.column).value = sv_sum_formula
                break

    # Regel 11: GER zugeordnete Werte in Spalte J in separaten Bereich nach Lohnarten aufsummieren

    # Schleife fügt Formel hinzu, die dafür sorgt, dass GER Werte in separaten Bereich kopiert werden.
    position = None
    for i in range(1, sheet.max_row):
        position = i + position_of_portion_fin + 1
        sheet[f"N{position}"] = f'=IF(J{i} = "GER",I{i},"")'
        sheet[f"M{position}"] = f'=IF(J{i} = "GER",A{i},"")'
        sheet.cell(row=position, column=14).number_format = "#,##0.00€"
        sheet.cell(row=position, column=14).fill = blue_fill
        sheet.cell(row=position, column=13).fill = blue_fill

    # Summiert die GER Beträge
    sheet[f"N{position + 1}"] = f"=SUM(N{position_of_portion_fin + 1}:N{sheet.max_row - 1})"
    # Schwarzer oberer Rand für die Summe
    top_border = Border(top=Side(border_style="thin", color="000000"))
    sheet[f"N{position + 1}"].border = top_border

    sheet.cell(row=position + 1, column=14).number_format = "#,##0.00€"
    sheet.cell(row=position + 1, column=14).fill = blue_fill

    # Regel 12:  Anteil der Telefonkosten (Lohnart 100) und des Monthly Salary (Lohnart 200) in Spalte N
    # gemäß der Aufteilung der Workdays auf GER in Spalte O ausweisen
    sheet["O7"] = "=N7/(N4/N3)"
    sheet["O8"] = "=N8/(N4/N3)"


# Funktion zum Erstellen von Mitarbeiterdatensätzen aus einer Eingabedatei
@register_data_conversion(
    data_conversion="Cimcorp",
    conversion="employeeDatasets",
    description="Cimcorp employee datasets conversion",
    input_type={
        "files": (
            List[UploadFile],
            {
                "description": "Excel file containing employee data",
                "min_files": 1,
                "max_files": 1,
                "extensions": ["xlsx"],
            },
        ),
    },
    output_type="xlsx",
)
def create_employee_datasets(task, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file = files[0]

    # Öffnen der Eingabedatei
    wb = openpyxl.load_workbook(file)
    ws = wb.active

    # Zwischenspeichern der Überschriften aus der ersten Zeile
    headers = [cell.value for cell in ws[1]]

    # Initialisierung der Variablen
    employee_data = {}
    current_employee_name = None

    # Durchlaufen der Zeilen in der Eingabedatei
    for row in ws.iter_rows(min_row=4):
        employee_id = row[0].value  # Ändern Sie die Spaltenindexierung zu 0 für Spalte A

        # Überprüfen, ob eine neue Mitarbeiterdatensatz beginnt
        if isinstance(employee_id, str) and employee_id.strip() == "Maksunsaaja":
            employee_name = row[2].value if row[2].value else "Employee_" + str(employee_id)
            current_employee_name = employee_name
            employee_data[current_employee_name] = []

        # Füge Daten zum aktuellen Mitarbeiterdatensatz hinzu
        if current_employee_name is not None:
            employee_data[current_employee_name].append([cell.value for cell in row])

    # Lösche die Arbeitsblätter außer dem ersten
    for sheet_name in wb.sheetnames[1:]:
        del wb[sheet_name]

    # Schreiben der Daten in die Tabellenblätter
    for employee_name, data in employee_data.items():
        current_sheet = wb.create_sheet(title=employee_name)
        current_sheet.append(headers)  # Fügt die zwischengespeicherten Überschriften hinzu
        for data_row in data:
            current_sheet.append(data_row)

        # Anwenden der Regeln auf das Tabellenblatt
        apply_rules(current_sheet)

    # Build output path
    output_path = generate_output_path(
        user_id=user_id,
        data_conversion="Cimcorp",
        conversion="employeeDatasets",
        task_id=task.request.id,
        extension="xlsx",
    )

    ensure_output_folder(output_path)

    # Save output
    wb.save(output_path)

    # Clean up
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
