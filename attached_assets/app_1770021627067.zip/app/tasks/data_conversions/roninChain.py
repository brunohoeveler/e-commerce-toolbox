from pathlib import Path

import polars as pl
from fastapi import UploadFile

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_output_path, strip_task_id


@register_data_conversion(
    data_conversion="RoninChain",
    conversion="default",
    description="RoninChain default conversion",
    input_type={
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["csv"],
            },
        ),
    },
    output_type="csv",
)
def ronin_chain_import(task, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]

    df_import = pl.read_csv(file1, separator=",")

    df_import = df_import.rename(
        {
            df_import.columns[0]: "hash",
            df_import.columns[3]: "datum",
            df_import.columns[4]: "from",
            df_import.columns[5]: "to",
            df_import.columns[6]: "method",
            df_import.columns[7]: "wkz",
            df_import.columns[8]: "in",
            df_import.columns[9]: "out",
            df_import.columns[10]: "fee",
            df_import.columns[11]: "status",
        }
    ).select(["hash", "datum", "from", "to", "method", "wkz", "in", "out", "fee", "status"])

    df_import = df_import.filter(~pl.col("method").str.contains("(?i)approve"))
    df_import = df_import.filter(~pl.col("method").str.contains("(?i)delegate"))
    df_import = df_import.filter(~pl.col("method").str.contains("(?i)stake"))
    df_import = df_import.filter(pl.col("method").is_not_null())
    df_import = df_import.filter(~pl.col("status").str.contains("(?i)fail"))
    df_import = df_import.drop(["status"])

    df_import = df_import.with_columns(
        pl.col("in").str.replace_all(r"\.", ""),
        pl.col("out").str.replace_all(r"\.", ""),
    )

    df_import = df_import.with_columns(
        (pl.col("in").cast(pl.Int64) / 10000000).round(3).alias("in"),
        (pl.col("out").cast(pl.Int64) / 10000000).round(3).alias("out"),
        (pl.col("fee").cast(pl.Float64).round(3).alias("fee")),
    )

    df_import = df_import.with_columns(
        pl.col("in").cast(str).str.replace(r"\.", ",").alias("in"),
        pl.col("out").cast(str).str.replace(r"\.", ",").alias("out"),
        pl.col("fee").cast(str).str.replace(r"\.", ",").alias("fee"),
    )

    df_import = df_import.with_columns(
        pl.when(pl.col("wkz") == "Axie Infinity Shard").then(pl.lit("AXS")).otherwise(pl.col("wkz")).alias("wkz"),
    )
    df_import = df_import.with_columns(
        pl.when(pl.col("wkz") == "Axie Land").then(pl.lit("-")).otherwise(pl.col("wkz")).alias("wkz"),
    )
    df_import = df_import.with_columns(
        pl.when(pl.col("wkz") == "Banana").then(pl.lit("BANANA8")).otherwise(pl.col("wkz")).alias("wkz"),
    )
    df_import = df_import.with_columns(
        pl.when(pl.col("wkz") == "Banana - Wrapped Ronin").then(pl.lit("WRON")).otherwise(pl.col("wkz")).alias("wkz"),
    )
    df_import = df_import.with_columns(
        pl.when(pl.col("wkz") == "BERRY").then(pl.lit("BERRY2")).otherwise(pl.col("wkz")).alias("wkz"),
    )
    df_import = df_import.with_columns(
        pl.when(pl.col("wkz") == "cUSDC").then(pl.lit("CUSDC")).otherwise(pl.col("wkz")).alias("wkz"),
    )
    df_import = df_import.with_columns(
        pl.when(pl.col("wkz") == "CyberKongz VX").then(pl.lit("-")).otherwise(pl.col("wkz")).alias("wkz"),
    )
    df_import = df_import.with_columns(
        pl.when(pl.col("wkz") == "Farm Land").then(pl.lit("-")).otherwise(pl.col("wkz")).alias("wkz"),
    )
    df_import = df_import.with_columns(
        pl.when(pl.col("wkz") == "Kong Consumable").then(pl.lit("-")).otherwise(pl.col("wkz")).alias("wkz"),
    )
    df_import = df_import.with_columns(
        pl.when(pl.col("wkz") == "Kredits").then(pl.lit("-")).otherwise(pl.col("wkz")).alias("wkz"),
    )
    df_import = df_import.with_columns(
        pl.when(pl.col("wkz") == "PIXEL").then(pl.lit("PIXEL3")).otherwise(pl.col("wkz")).alias("wkz"),
    )
    df_import = df_import.with_columns(
        pl.when(pl.col("wkz") == "RON").then(pl.lit("RON4")).otherwise(pl.col("wkz")).alias("wkz"),
    )
    df_import = df_import.with_columns(
        pl.when(pl.col("wkz") == "Ronin Wrapped Ether").then(pl.lit("WETH")).otherwise(pl.col("wkz")).alias("wkz"),
    )
    df_import = df_import.with_columns(
        pl.when(pl.col("wkz") == "USD Coin").then(pl.lit("USDC")).otherwise(pl.col("wkz")).alias("wkz"),
    )
    try:
        chain_value = df_import.filter(pl.col("method").str.contains("claim")).select("to").get_column("to").item(0)
    except IndexError:
        chain_value = ""

    column = df_import["hash"].to_list()
    counter = 1
    counter_list = []
    last_value = column[0]

    for value in column:
        if value != last_value:
            counter = 1
            last_value = value
        counter_list.append(counter)
        counter += 1

    df_import = df_import.with_columns(pl.Series("count_actions", counter_list))

    df_import = df_import.with_columns(
        pl.when(pl.col("hash").is_in(df_import.group_by("hash").agg(pl.max("count_actions").alias("max_count")).filter(pl.col("max_count") == 2)["hash"]))
        .then(pl.lit("Trade"))
        .otherwise(pl.lit(""))
        .alias("type")
    )

    condition = (
        df_import.group_by("hash")
        .agg(
            max_count=pl.col("count_actions").max(),
            contains_method=pl.col("method").str.contains("addLiquidityRON").any(),
        )
        .filter((pl.col("max_count") == 3) & (pl.col("contains_method")))
        .select("hash")
    )

    df_import = df_import.with_columns(pl.when(pl.col("hash").is_in(condition["hash"])).then(pl.lit("Provide Liquidity")).otherwise(pl.col("type")).alias("type"))

    condition = (
        df_import.group_by("hash")
        .agg(
            max_count=pl.col("count_actions").max(),
            contains_method=pl.col("method").str.contains("removeLiquidityRON").any(),
        )
        .filter((pl.col("max_count") == 3) & (pl.col("contains_method")))
        .select("hash")
    )

    df_import = df_import.with_columns(pl.when(pl.col("hash").is_in(condition["hash"])).then(pl.lit("Remove Liquidity")).otherwise(pl.col("type")).alias("type"))

    df_import = df_import.with_columns(pl.when((pl.col("method").str.contains("claim")) & (pl.col("type") == "")).then(pl.lit("Staking")).otherwise(pl.col("type")).alias("type"))

    df_import = df_import.with_columns(pl.when((pl.col("method").str.contains("ithdraw")) & (pl.col("type") == "")).then(pl.lit("Withdrawal")).otherwise(pl.col("type")).alias("type"))

    df_import = df_import.with_columns(pl.when((pl.col("method").str.contains("eposit")) & (pl.col("type") == "")).then(pl.lit("Deposit")).otherwise(pl.col("type")).alias("type"))

    df_import = df_import.with_columns(pl.when((pl.col("method").str.contains("disperse")) & (pl.col("type") == "")).then(pl.lit("Airdrop")).otherwise(pl.col("type")).alias("type"))

    df_import = df_import.with_columns(
        pl.when((pl.col("method").str.contains("transfer")) & (pl.col("to") == chain_value) & (pl.col("type") == "")).then(pl.lit("Einzahlung")).otherwise(pl.col("type")).alias("type")
    )

    df_import = df_import.with_columns(
        pl.when((pl.col("method").str.contains("transfer")) & (pl.col("from") == chain_value) & (pl.col("type") == "")).then(pl.lit("Withdrawal")).otherwise(pl.col("type")).alias("type")
    )

    df_import = df_import.with_columns(pl.when(pl.col("type") == "").then(pl.lit("NO CATEGORY YET")).otherwise(pl.col("type")).alias("type"))

    df_import = df_import.with_columns(
        pl.lit("RoninChain").alias("Exchange"),
        pl.lit("").alias("Trade Group"),
        pl.lit("").alias("Comment"),
    )

    df_import = df_import.select(
        pl.col("type").alias("Type"),
        pl.col("in").alias("Buy Amount"),
        pl.col("wkz").alias("Buy Cur"),
        pl.col("out").alias("Sell Amount"),
        pl.col("wkz").alias("Sell Cur"),
        pl.col("fee").alias("Fee Amount"),
        pl.col("wkz").alias("Fee Cur"),
        pl.col("Exchange").alias("Exchange"),
        pl.col("Trade Group").alias("Trade Group"),
        pl.col("Comment").alias("Comment"),
        pl.col("datum").alias("Date"),
        pl.col("hash").alias("hash"),
        pl.col("count_actions").alias("count_actions"),
    )

    df_import = df_import.with_columns(
        pl.when(pl.col("Buy Amount") == "0.0").then(pl.lit("")).otherwise(pl.col("Buy Cur")).alias("Buy Cur"),
    )

    df_import = df_import.with_columns(
        pl.when(pl.col("Buy Amount") == "0.0").then(pl.lit("")).otherwise(pl.col("Buy Amount")).alias("Buy Amount"),
    )

    df_import = df_import.with_columns(
        pl.when(pl.col("Sell Amount") == "0.0").then(pl.lit("")).otherwise(pl.col("Sell Cur")).alias("Sell Cur"),
    )

    df_import = df_import.with_columns(
        pl.when(pl.col("Sell Amount") == "0.0").then(pl.lit("")).otherwise(pl.col("Sell Amount")).alias("Sell Amount"),
    )

    df_import = df_import.with_columns(
        pl.when(pl.col("Fee Amount") == "0.0").then(pl.lit("")).otherwise(pl.col("Fee Cur")).alias("Fee Cur"),
    )

    df_import = df_import.with_columns(
        pl.when(pl.col("Fee Amount") == "0.0").then(pl.lit("")).otherwise(pl.col("Fee Amount")).alias("Fee Amount"),
    )

    df_import = df_import.with_columns(pl.lit("").alias("Liquidity pool"))
    df_import = df_import.with_columns(pl.lit("").alias("Tx-ID"))
    df_import = df_import.with_columns(pl.lit("").alias("Buy Value in Account Currency"))
    df_import = df_import.with_columns(pl.lit("").alias("Sell Value in Account Currency"))

    trade_hashes = df_import.filter(pl.col("Type") == "Trade").select("hash").unique()
    trade_hashes = trade_hashes.get_column("hash").to_list()

    for hashValue in trade_hashes:
        trade_group = df_import.filter(pl.col("hash") == hashValue)

        if trade_group.shape[0] == 2:
            df_import = df_import.filter(pl.col("hash") != hashValue)
            merged_row = trade_group.select(
                [
                    # Handle Buy Amount and Buy Cur
                    pl.when(pl.col("Buy Amount").first() == "0,0").then(pl.col("Buy Amount").last()).otherwise(pl.col("Buy Amount").first()).alias("Buy Amount"),
                    pl.when(pl.col("Buy Amount").first() == "0,0").then(pl.col("Buy Cur").last()).otherwise(pl.col("Buy Cur").first()).alias("Buy Cur"),
                    # Handle Sell Amount and Sell Cur
                    pl.when(pl.col("Sell Amount").first() == "0,0").then(pl.col("Sell Amount").last()).otherwise(pl.col("Sell Amount").first()).alias("Sell Amount"),
                    pl.when(pl.col("Sell Amount").first() == "0,0").then(pl.col("Sell Cur").last()).otherwise(pl.col("Sell Cur").first()).alias("Sell Cur"),
                    # Handle Fee Amount and Fee Cur
                    pl.when(pl.col("Fee Amount").first() == "0,0").then(pl.col("Fee Amount").last()).otherwise(pl.col("Fee Amount").first()).alias("Fee Amount"),
                    pl.when(pl.col("Fee Amount").first() == "0,0")  # Tie Fee Cur to Fee Amount logic
                    .then(pl.col("Fee Cur").last())
                    .otherwise(pl.col("Fee Cur").first())
                    .alias("Fee Cur"),
                    # Include other columns as is
                    *[
                        pl.col(col).first().alias(col)
                        for col in trade_group.columns
                        if col
                        not in {
                            "Buy Amount",
                            "Buy Cur",
                            "Sell Amount",
                            "Sell Cur",
                            "Fee Amount",
                            "Fee Cur",
                        }
                    ],
                ]
            )

            merged_row = merged_row.with_columns(pl.lit("Trade").alias("Type"))
            merged_row = merged_row.select(["Type"] + [col for col in merged_row.columns if col != "Type"])

            df_import = pl.concat([df_import, merged_row])

    df_import = df_import.drop(["hash", "count_actions"]).sort("Type")

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path(
        user_id=user_id,
        data_conversion="RoninChain",
        conversion="default",
        task_id=task.request.id,
        extension="xlsx",
    )

    ensure_output_folder(output_path)

    df_import.write_excel(output_path)

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
