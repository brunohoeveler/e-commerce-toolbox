from pathlib import Path

import pandas as pd
from fastapi import UploadFile

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.datev_export import datev_format
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_output_path_datev, strip_task_id


@register_data_conversion(
    data_conversion="Emundo",
    conversion="GoforeBil",
    description="Gofore Bilanz",
    input_type={
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["xlsx", "xls"],
            },
        ),
    },
    output_type="csv",
)
def gofore_bil(task, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]

    # ============================= FASHIONETTE IMPORT ===============================
    try:
        df_import = pd.read_excel(file1, skiprows=6, dtype=str)
    except FileNotFoundError as e:
        raise Exception("Die Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_import.columns.values[0:] = ["account", "umsatz", "ly"]
    df_import = df_import[df_import["account"].str[0].str.isdigit()]
    df_import = df_import[~df_import["account"].str.contains("Total")]
    df_import = df_import[~df_import["account"].str.contains("Opening Balance")]
    df_import["mandant"] = df_import["account"].str[0:6]
    df_import["account"] = df_import["account"].str[9:]

    df_mapping = pd.read_excel("resources/gofore_mapping.xlsx", dtype=str)

    df_merge = pd.merge(df_import, df_mapping, how="left", on="mandant")
    df_merge.columns.values[0:] = ["buchungstext", "umsatz", "ly", "belegfeld", "konto"]
    df_merge["gegenkonto"] = "90900"
    df_merge["datum"] = "3112"

    df_merge["umsatz"] = df_merge["umsatz"].astype(str)

    df_merge["buchungstext"] = df_merge["buchungstext"].astype(str)
    df_merge.loc[
        (df_merge["belegfeld"].astype(int) > 120000) & (df_merge["belegfeld"].astype(int) < 260000),
        "umsatz",
    ] = df_merge["umsatz"].astype(float) - df_merge["ly"].astype(float)
    df_merge.loc[(df_merge["belegfeld"].astype(int) > 287000), "umsatz"] = df_merge["umsatz"].astype(float) - df_merge["ly"].astype(float)
    del df_merge["ly"]
    df_merge.loc[df_merge["belegfeld"].astype(int) > 260000, "umsatz"] = df_merge["umsatz"].astype(float) * (-1)

    df_merge["umsatz"] = df_merge["umsatz"].astype(str)
    df_merge["umsatz"] = df_merge["umsatz"].str.replace(".", ",")
    df_merge = df_merge[~df_merge["umsatz"].isin(["0", "0,0", "0,00", "0.0"])]
    df_merge.loc[df_merge["umsatz"].str.contains("-"), "sh"] = "H"
    df_merge.loc[df_merge["sh"].isnull(), "sh"] = "S"
    df_merge["umsatz"] = df_merge["umsatz"].str.replace("-", "")

    stapel_text = f"Import Jahresabschluss {year}"
    df_export = datev_format(
        df=df_merge,
        mdtnr="11025",
        bernr="12168",
        skr="3",
        skl="5",
        year=year,
        month=12,
        text=stapel_text,
    )

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Emundo",
        conversion="GoforeBil",
        month=12,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    df_export.to_csv(output_path, index=False, sep=";", encoding="latin_1")

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Emundo",
    conversion="GoforeGuV",
    description="Gofore GuV",
    input_type={
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["xlsx", "xls"],
            },
        ),
    },
    output_type="csv",
)
def gofore_guv(task, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]

    # ============================= FASHIONETTE IMPORT ===============================
    try:
        df_import = pd.read_excel(file1, skiprows=6, dtype=str)
    except FileNotFoundError as e:
        raise Exception("Die Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_import.columns.values[0:] = ["account", "S", "H"]
    df_import = df_import[df_import["account"].str[0].str.isdigit()]
    df_import = df_import[~df_import["account"].str.contains("Total")]
    df_import = df_import[~df_import["account"].str.contains("Opening Balance")]
    df_import["mandant"] = df_import["account"].str[0:6]
    df_import["account"] = df_import["account"].str[9:]

    df_mapping = pd.read_excel("resources/gofore_mapping.xlsx", dtype=str)

    df_merge = pd.merge(df_import, df_mapping, how="left", on="mandant")

    df_merge = pd.melt(
        df_merge,
        id_vars=["account", "mandant", "datev"],
        value_name="umsatz",
        var_name="SH",
        ignore_index=True,
    )
    df_merge = df_merge[~df_merge["umsatz"].isnull()]

    df_merge["umsatz"] = df_merge["umsatz"].astype(str)
    df_merge["umsatz"] = df_merge["umsatz"].str.replace(".", ",")
    df_merge = df_merge[~df_merge["umsatz"].isin(["0", "0,0", "0,00"])]

    df_merge.columns.values[0:] = ["buchungstext", "belegfeld", "konto", "sh", "umsatz"]
    df_merge["gegenkonto"] = "90901"
    df_merge["datum"] = "3112"
    df_merge = df_merge[df_merge["belegfeld"].astype(int) > 300000]

    stapel_text = f"Import Jahresabschluss GuV {year}"
    df_export = datev_format(
        df=df_merge,
        mdtnr="11025",
        bernr="12168",
        skr="3",
        skl="5",
        year=year,
        month=12,
        text=stapel_text,
    )

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Emundo",
        conversion="GoforeGuV",
        month=12,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    df_export.to_csv(output_path, index=False, sep=";")

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Emundo",
    conversion="EmundoBil",
    description="Emundo Bilanz",
    input_type={
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["xlsx", "xls"],
            },
        ),
    },
    output_type="csv",
)
def emundo_bil(task, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]

    # ============================= FASHIONETTE IMPORT ===============================
    try:
        df_import = pd.read_excel(file1, skiprows=6, dtype=str)
    except FileNotFoundError as e:
        raise Exception("Die Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_import.columns.values[0:] = ["account", "umsatz", "ly"]
    df_import = df_import[df_import["account"].str[0].str.isdigit()]
    df_import = df_import[~df_import["account"].str.contains("Total")]
    df_import = df_import[~df_import["account"].str.contains("Opening Balance")]
    df_import["mandant"] = df_import["account"].str[0:6]
    df_import["account"] = df_import["account"].str[9:]

    df_mapping = pd.read_excel("resources/emundo_mapping.xlsx", dtype=str)

    df_merge = pd.merge(df_import, df_mapping, how="left", on="mandant")
    df_merge.columns.values[0:] = ["buchungstext", "umsatz", "ly", "belegfeld", "konto"]
    df_merge["gegenkonto"] = "90900"
    df_merge["datum"] = "3112"

    df_merge["umsatz"] = df_merge["umsatz"].astype(str)

    df_merge["buchungstext"] = df_merge["buchungstext"].astype(str)
    df_merge.loc[
        (df_merge["belegfeld"].astype(int) > 120000) & (df_merge["belegfeld"].astype(int) < 260000),
        "umsatz",
    ] = df_merge["umsatz"].astype(float) - df_merge["ly"].astype(float)
    df_merge.loc[(df_merge["belegfeld"].astype(int) > 287000), "umsatz"] = df_merge["umsatz"].astype(float) - df_merge["ly"].astype(float)
    del df_merge["ly"]
    df_merge.loc[df_merge["belegfeld"].astype(int) > 260000, "umsatz"] = df_merge["umsatz"].astype(float) * (-1)

    df_merge["umsatz"] = df_merge["umsatz"].astype(str)
    df_merge["umsatz"] = df_merge["umsatz"].str.replace(".", ",")
    df_merge = df_merge[~df_merge["umsatz"].isin(["0", "0,0", "0,00", "0.0"])]
    df_merge.loc[df_merge["umsatz"].str.contains("-"), "sh"] = "H"
    df_merge.loc[df_merge["sh"].isnull(), "sh"] = "S"
    df_merge["umsatz"] = df_merge["umsatz"].str.replace("-", "")

    stapel_text = f"Import Jahresabschluss {year}"
    df_export = datev_format(
        df=df_merge,
        mdtnr="11016",
        bernr="12168",
        skr="4",
        skl="5",
        year=year,
        month=12,
        text=stapel_text,
    )

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Emundo",
        conversion="EmundoBil",
        month=12,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    df_export.to_csv(output_path, index=False, sep=";", encoding="latin_1")

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Emundo",
    conversion="EmundoGuV",
    description="Emundo GuV",
    input_type={
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["xlsx", "xls"],
            },
        ),
    },
    output_type="csv",
)
def emundo_guv(task, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]

    # ============================= FASHIONETTE IMPORT ===============================
    try:
        df_import = pd.read_excel(file1, skiprows=6, dtype=str)
    except FileNotFoundError as e:
        raise Exception("Die Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_import.columns.values[0:] = ["account", "S", "H"]
    df_import = df_import[df_import["account"].str[0].str.isdigit()]
    df_import = df_import[~df_import["account"].str.contains("Total")]
    df_import = df_import[~df_import["account"].str.contains("Opening Balance")]
    df_import["mandant"] = df_import["account"].str[0:6]
    df_import["account"] = df_import["account"].str[9:]

    df_mapping = pd.read_excel("resources/emundo_mapping.xlsx", dtype=str)

    df_merge = pd.merge(df_import, df_mapping, how="left", on="mandant")

    df_merge = pd.melt(
        df_merge,
        id_vars=["account", "mandant", "datev"],
        value_name="umsatz",
        var_name="SH",
        ignore_index=True,
    )
    df_merge = df_merge[~df_merge["umsatz"].isnull()]

    df_merge["umsatz"] = df_merge["umsatz"].astype(str)
    df_merge["umsatz"] = df_merge["umsatz"].str.replace(".", ",")
    df_merge = df_merge[~df_merge["umsatz"].isin(["0", "0,0", "0,00"])]

    df_merge.columns.values[0:] = ["buchungstext", "belegfeld", "konto", "sh", "umsatz"]
    df_merge["gegenkonto"] = "90901"
    df_merge["datum"] = "3112"
    df_merge = df_merge[df_merge["belegfeld"].astype(int) > 300000]

    stapel_text = f"Import Jahresabschluss GuV {year}"
    df_export = datev_format(
        df=df_merge,
        mdtnr="11016",
        bernr="12168",
        skr="4",
        skl="5",
        year=year,
        month=12,
        text=stapel_text,
    )

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Emundo",
        conversion="EmundoGuV",
        month=12,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    df_export.to_csv(output_path, index=False, sep=";")

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
