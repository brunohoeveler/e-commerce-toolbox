from pathlib import Path

import polars as pl
import polars.selectors as s
from fastapi import UploadFile

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_output_path, strip_task_id


@register_data_conversion(
    data_conversion="Stargroup",
    conversion="default",
    description="Stargroup default conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["xlsx", "xls"],
            },
        ),
    },
    output_type="csv",
)
def stargroup_import(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]

    try:
        df = pl.read_excel(file1)
        assert df.width == 22
    except FileNotFoundError as e:
        raise Exception("Die Stargroup Datei wurde nicht gefunden. Bitte ÜberprÜfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Fehler beim Lesen der Stargroup Datei, bitte ÜberprÜfen, ob die Struktur richtig ist!") from e

    # indexspalte hinzufÜgen (fÜr slice)
    df = df.with_row_index()
    falsche_headlines = df.columns
    erste_spalte = pl.col(df.columns[1])
    headline_df = df.filter(erste_spalte == "Resource number")

    # Findet den Index der Zeile in der "Gesamtergebnis steht" => Benoetigt um Überschriften anzupassen

    index_of_gesamtergebnis_zeile = headline_df.get_column("index")[0] - 2
    gesamtergebnis_spalte = list(df.filter(pl.col("index") == index_of_gesamtergebnis_zeile).rows()[0])

    index_of_gesamtergebnis_spalte = gesamtergebnis_spalte.index("Gesamtergebnis")

    # speichern der Überschriften fÜrs renaming
    headlines = headline_df.rows()

    # aendern des ersten Eintrags der headlines Zeile ansonsten waere der Spaltenname der indexspalte = headline_index
    headlines_list = list(headlines[0])
    headlines_list[0] = "index"
    headlines_list[3] = "Normalstunden"
    headlines_list[index_of_gesamtergebnis_spalte] = "Gesamtergebnis"
    # Der erste None Wert entspricht der Gesamtergebnis Spalte. "Gesamtergebnis" wird nicht mit in Liste aufgenommen,
    # da es sich in einer anderen befindet als die restlichen Überschriften

    # Entferne Übrige None-Typen aus der Überschriften Liste, damit Dict fÜrs renaming Übergeben werden kann
    ueberschuessige_spalten = []

    for i in range(0, len(headlines_list)):
        if headlines_list[i] is None:
            headlines_list[i] = f"#{i}"
            ueberschuessige_spalten.append(headlines_list[i])

    # index benoetigt um importierte zeilen zu beschraenken

    headline_index = headline_df.row(index=0)[0]

    df = df.slice(headline_index + 1, -1)

    headline_zuordnung_fuer_umbenennung = dict(zip(falsche_headlines, headlines_list))
    df = df.rename(headline_zuordnung_fuer_umbenennung)

    # Beschraenkt das Dataframe auf die vorhandenen Spalten bis zum Gesamtergebnis
    df = df.select(~s.by_name(ueberschuessige_spalten))

    df = df.with_columns(pl.lit(None).alias("Arbeitszeitmodell"))
    # enthaelt die spalten, deren datentyp geaendert werden muss
    numerische_spalten = df.columns[df.columns.index("Normalstunden") :]

    # dynamische aenderung des Datentyps
    df = df.with_columns(pl.col(col).cast(pl.Float64).alias(col) for col in numerische_spalten)

    # Platzhalter spalte

    def check_row_modulo(col_expression, zielspalte, dataframe):
        return dataframe.with_columns(
            # 6 und 8 haben gemeinsame Vielfache wie z.B. 24, um Eindeutigkeit zu gewaehrleisten mÜssen beide Bedingungen erfÜllt sein
            pl.when(
                col_expression % 8 == 0,
                col_expression % 6 != 0,
                col_expression % 7.5 != 0,
            )
            .then(pl.lit(173.33))
            .otherwise(
                pl.when(
                    col_expression % 7.5 == 0,
                    col_expression % 8 != 0,
                    col_expression % 6 != 0,
                )
                .then(pl.lit(162.5))
                .otherwise(
                    pl.when(
                        col_expression % 6 == 0,
                        col_expression % 8 != 0,
                        col_expression % 7.5 != 0,
                    )
                    .then(pl.lit(130.0))
                    .otherwise(zielspalte)
                )
            )
            .alias(zielspalte)
        )

    # ------- Spezialfaelle -----------------------------------------------------------------
    if "Gesetzlicher Feiertag" in df.columns:
        df = check_row_modulo(pl.col("Gesetzlicher Feiertag"), "Arbeitszeitmodell", df)

    df_bearbeitet = df.filter(~pl.col("Arbeitszeitmodell").is_null())
    df_unbearbeitet = df.filter(pl.col("Arbeitszeitmodell").is_null())

    if not df_unbearbeitet.is_empty():
        df_unbearbeitet = check_row_modulo(pl.col("Urlaub"), "Arbeitszeitmodell", df_unbearbeitet)

        df_bearbeitet = pl.concat(
            [
                df_bearbeitet,
                df_unbearbeitet.filter(pl.col("Arbeitszeitmodell").is_not_null()),
            ]
        )
        df_unbearbeitet = df_unbearbeitet.filter(pl.col("Arbeitszeitmodell").is_null())

    if not df_unbearbeitet.is_empty():
        if "Krankheit ohne Entgelt" in df.columns:
            df_unbearbeitet = check_row_modulo(pl.col("Krankheit ohne Entgelt"), "Arbeitszeitmodell", df_unbearbeitet)

            df_bearbeitet = pl.concat(
                [
                    df_bearbeitet,
                    df_unbearbeitet.filter(pl.col("Arbeitszeitmodell").is_not_null()),
                ]
            )
            df_unbearbeitet = df_unbearbeitet.filter(pl.col("Arbeitszeitmodell").is_null())

    if not df_unbearbeitet.is_empty():
        if "Krankheit" in df.columns:
            df_unbearbeitet = check_row_modulo(pl.col("Krankheit"), "Arbeitszeitmodell", df_unbearbeitet)
            df_bearbeitet = pl.concat(
                [
                    df_bearbeitet,
                    df_unbearbeitet.filter(pl.col("Arbeitszeitmodell").is_not_null()),
                ]
            )
            df_unbearbeitet = df_unbearbeitet.filter(pl.col("Arbeitszeitmodell").is_null())

    if not df_unbearbeitet.is_empty():
        if "Sonderurlaub" in df.columns:
            df_unbearbeitet = check_row_modulo(pl.col("Sonderurlaub"), "Arbeitszeitmodell", df_unbearbeitet)
            df_bearbeitet = pl.concat(
                [
                    df_bearbeitet,
                    df_unbearbeitet.filter(pl.col("Arbeitszeitmodell").is_not_null()),
                ]
            )
            df_unbearbeitet = df_unbearbeitet.filter(pl.col("Arbeitszeitmodell").is_null())

    # Falls keine Angaben Spezialfaelle zum Ergebnis fÜhren => PrÜfe ob die Überstunden Spalten Eintraege besitzen & ordne das Zeitmodell zu
    if not df_unbearbeitet.is_empty():
        df_unbearbeitet = df_unbearbeitet.with_columns(
            pl.when(pl.col("Überstunden (>8h)").is_not_null())
            .then(pl.lit(173.33))
            .otherwise(
                pl.when(pl.col("Überstunden (>40h/ Woche)").is_not_null())
                .then(pl.lit(173.33))
                .otherwise(pl.when(pl.col("Überstunden (>37,5h/Woche)").is_not_null()).then(pl.lit(162.5)).otherwise(pl.col("Arbeitszeitmodell")))
            )
            .alias("Arbeitszeitmodell")
        )

        df_bearbeitet = pl.concat(
            [
                df_bearbeitet,
                df_unbearbeitet.filter(pl.col("Arbeitszeitmodell").is_not_null()),
            ]
        )
        df_unbearbeitet = df_unbearbeitet.filter(pl.col("Arbeitszeitmodell").is_null())

    # --- ÜberprÜft ob man das Arbeitszeitmodell anhand der Urlaubsspalte bestimmen kann

    if not df_unbearbeitet.is_empty():
        # durch diese Regel priorisiert man den Standardfall eines 8h Tags, wenn das Gesamtergebnis durch 6 und 8 teilbar sind
        df_unbearbeitet = df_unbearbeitet.with_columns(
            pl.when(pl.col("Normalstunden") == pl.col("Gesamtergebnis"))
            .then(
                pl.when(
                    pl.col("Gesamtergebnis") % 8 == 0,
                    pl.col("Gesamtergebnis") % 7.5 != 0,
                    pl.col("Gesamtergebnis") % 6 != 0,
                )
                .then(pl.lit(173.33))
                .otherwise(
                    pl.when(
                        pl.col("Gesamtergebnis") % 7.5 == 0,
                        pl.col("Gesamtergebnis") % 8 != 0,
                        pl.col("Gesamtergebnis") % 6 != 0,
                    )
                    .then(pl.lit(162.5))
                    .otherwise(
                        pl.when(
                            pl.col("Gesamtergebnis") % 8 != 0,
                            pl.col("Gesamtergebnis") % 7.5 != 0,
                            pl.col("Gesamtergebnis") % 6 == 0,
                        )
                        .then(pl.lit(130.0))
                        .otherwise(pl.col("Arbeitszeitmodell"))
                    )
                )
            )
            .alias("Arbeitszeitmodell")
        )

        df_bearbeitet = pl.concat(
            [
                df_bearbeitet,
                df_unbearbeitet.filter(pl.col("Arbeitszeitmodell").is_not_null()),
            ]
        )
        df_unbearbeitet = df_unbearbeitet.filter(pl.col("Arbeitszeitmodell").is_null())

    if not df_unbearbeitet.is_empty():
        verfuegbare_spalten = df_unbearbeitet.columns
        verfuegbare_spalten.remove("Arbeitszeitmodell")

        # Ersetzt null Werte durch 0 fuer anstehende Berechnungen
        for spalte in verfuegbare_spalten:
            df_unbearbeitet = df_unbearbeitet.with_columns(pl.col(spalte).fill_null(strategy="zero"))

        df_unbearbeitet = df_unbearbeitet.with_columns(
            pl.when(
                (pl.col("Normalstunden") + pl.col("Urlaub") + pl.col("Aufnahme Zeitkonto")) % 8 == 0,
                (pl.col("Normalstunden") + pl.col("Urlaub") + pl.col("Aufnahme Zeitkonto")) % 7.5 != 0,
                (pl.col("Normalstunden") + pl.col("Urlaub") + pl.col("Aufnahme Zeitkonto")) % 6 != 0,
            )
            .then(pl.lit(173.33))
            .otherwise(
                pl.when(
                    (pl.col("Normalstunden") + pl.col("Urlaub") + pl.col("Aufnahme Zeitkonto")) % 8 != 0,
                    (pl.col("Normalstunden") + pl.col("Urlaub") + pl.col("Aufnahme Zeitkonto")) % 7.5 == 0,
                    (pl.col("Normalstunden") + pl.col("Urlaub") + pl.col("Aufnahme Zeitkonto")) % 6 != 0,
                )
                .then(pl.lit(162.5))
                .otherwise(
                    pl.when(
                        (pl.col("Normalstunden") + pl.col("Urlaub") + pl.col("Aufnahme Zeitkonto")) % 8 != 0,
                        (pl.col("Normalstunden") + pl.col("Urlaub") + pl.col("Aufnahme Zeitkonto")) % 7.5 != 0,
                        (pl.col("Normalstunden") + pl.col("Urlaub") + pl.col("Aufnahme Zeitkonto")) % 6 == 0,
                    )
                    .then(pl.lit(130.0))
                    .otherwise(pl.col("Arbeitszeitmodell"))
                )
            )
            .alias("Arbeitszeitmodell")
        )

        df_bearbeitet = pl.concat(
            [
                df_bearbeitet,
                df_unbearbeitet.filter(pl.col("Arbeitszeitmodell").is_not_null()),
            ]
        )
        df_unbearbeitet = df_unbearbeitet.filter(pl.col("Arbeitszeitmodell").is_null())

    if not df_unbearbeitet.is_empty():
        df_unbearbeitet = df_unbearbeitet.with_columns(
            pl.when(pl.col("Urlaub") == 0)
            .then(
                pl.when(
                    (pl.col("Gesamtergebnis") - pl.col("Aufnahme Zeitkonto")) % 8 == 0,
                    (pl.col("Gesamtergebnis") - pl.col("Aufnahme Zeitkonto")) % 7.5 != 0,
                    (pl.col("Gesamtergebnis") - pl.col("Aufnahme Zeitkonto")) % 6 != 0,
                )
                .then(pl.lit(173.33))
                .otherwise(
                    pl.when(
                        (pl.col("Gesamtergebnis") - pl.col("Aufnahme Zeitkonto")) % 8 != 0,
                        (pl.col("Gesamtergebnis") - pl.col("Aufnahme Zeitkonto")) % 7.5 == 0,
                        (pl.col("Gesamtergebnis") - pl.col("Aufnahme Zeitkonto")) % 6 != 0,
                    )
                    .then(pl.lit(162.5))
                    .otherwise(
                        (
                            pl.when(
                                (pl.col("Gesamtergebnis") - pl.col("Aufnahme Zeitkonto")) % 6 == 0,
                                (pl.col("Gesamtergebnis") - pl.col("Aufnahme Zeitkonto")) % 7.5 != 0,
                                (pl.col("Gesamtergebnis") - pl.col("Aufnahme Zeitkonto")) % 8 != 0,
                            )
                        ).then(pl.lit(130.0))
                    )
                )
            )
            .otherwise(pl.col("Arbeitszeitmodell"))
            .alias("Arbeitszeitmodell")
        )

        df_bearbeitet = pl.concat(
            [
                df_bearbeitet,
                df_unbearbeitet.filter(pl.col("Arbeitszeitmodell").is_not_null()),
            ]
        )
        df_unbearbeitet = df_unbearbeitet.filter(pl.col("Arbeitszeitmodell").is_null())

        # deckt die Faelle ab, die durch keine der Regeln erfasst werden
        df_unbearbeitet = df_unbearbeitet.with_columns(pl.lit(0.0).alias("Arbeitszeitmodell"))

        df_bearbeitet = pl.concat(
            [
                df_bearbeitet,
                df_unbearbeitet.filter(pl.col("Arbeitszeitmodell").is_not_null()),
            ]
        )

        # Sortieren
        df_bearbeitet = df_bearbeitet.sort("index")

        df_final = df_bearbeitet.drop("index")
        df_final = df_final.with_columns(df_final[col].cast(pl.String) for col in df_final.columns)
        # 0.0 durch leere werte
        df_final = df_final.with_columns(pl.col(column).replace("0.0", None) for column in df_final.columns)

        df = df_final

    # Umbenennen und Umformen
    df = df.rename(
        {
            "Resource name": "VornameName",
            "Aufnahme Zeitkonto": "TvT discrease (Entnahme AZK)",
            "Resource number": "PNR",
        }
    )
    if "Krankheit ohne Entgelt" in df.columns:
        df = df.cast({"Krankheit ohne Entgelt": pl.Float64})

    df = df.cast(
        {
            "Arbeitszeitmodell": pl.Float64,
            "Gesamtergebnis": pl.Float64,
            "TvT discrease (Entnahme AZK)": pl.Float64,
            "Krankheit": pl.Float64,
            "Urlaub": pl.Float64,
        }
    )

    df = df.with_columns(
        pl.lit("12168").alias("Berater"),
        pl.lit("11310").alias("Mandant"),
        pl.lit(month).alias("Satzart"),
        pl.col("PNR").str.slice(2, 5),
        pl.lit(0).alias("sick_taken_days"),
        pl.lit(0).alias("holidays_days"),
        pl.lit(0).alias("Overtime hours 25%"),
        pl.lit(0).alias("Overtime hours 100%"),
        pl.lit(0).alias("TvT balance (old - review only)"),
        pl.lit(0).alias("TvT balance (new - review only)"),
        pl.lit(0).alias("Overtime Hours hourly wage"),
    )

    df = df.with_columns(pl.when(pl.col.Gesamtergebnis <= 130).then(None).otherwise(pl.col.Arbeitszeitmodell).alias("Arbeitszeitmodell"))

    df = df.with_columns(pl.when(pl.col("Arbeitszeitmodell").is_not_null()).then((pl.col("Gesamtergebnis") - pl.col("Arbeitszeitmodell")).round(2)).otherwise(None).alias("tvt_increase"))

    def veraendere_tvt_wenn_mitarbeiter_ganzen_monat_krank(spalte, frame):
        spalte = spalte
        if spalte in frame.columns:
            frame = frame.with_columns(pl.when(pl.col(spalte) == pl.col.Gesamtergebnis).then(pl.lit(0.0)).otherwise(pl.col.tvt_increase).alias("tvt_increase"))
        return frame

    df = veraendere_tvt_wenn_mitarbeiter_ganzen_monat_krank("Krankheit ohne Entgelt", df)
    df = veraendere_tvt_wenn_mitarbeiter_ganzen_monat_krank("Krankheit", df)

    df = df.with_columns(negiert_tvt_increase=pl.col.tvt_increase * -1)
    # taucht in der Enddatei nicht auf, wird aber ggf fÜr Overtime Hours spalten benoetigt
    df = df.with_columns(decrease_minus_increase=pl.col("TvT discrease (Entnahme AZK)") - pl.col.tvt_increase)

    df = df.cast({"tvt_increase": pl.String, "TvT discrease (Entnahme AZK)": pl.String})

    df = df.with_columns(
        pl.when(pl.col("TvT discrease (Entnahme AZK)").is_not_null()).then(pl.col("TvT discrease (Entnahme AZK)") + "*").otherwise(pl.col("TvT discrease (Entnahme AZK)")).alias("TvT discrease (Entnahme AZK)")
    )

    df = df.with_columns(
        pl.when(
            pl.col("Arbeitszeitmodell").is_not_null(),
            pl.col("TvT discrease (Entnahme AZK)").is_null(),
        )
        .then(pl.col("tvt_increase"))
        .otherwise(pl.col("TvT discrease (Entnahme AZK)"))
        .alias("TvT discrease (Entnahme AZK)")
    )

    df = df.with_columns(pl.when(pl.col("Arbeitszeitmodell") < pl.col("Gesamtergebnis")).then(pl.col("tvt_increase") + "*").otherwise(pl.col("tvt_increase")).alias("tvt_increase"))

    df = df.with_columns(
        pl.when(
            ~pl.col("TvT discrease (Entnahme AZK)").str.contains(r"\*"),
            pl.col("tvt_increase").str.contains(r"\*"),
        )
        .then(pl.lit(""))
        .otherwise(pl.col("TvT discrease (Entnahme AZK)"))
        .alias("TvT discrease (Entnahme AZK)")
    )

    df = df.with_columns(
        pl.when(
            ~pl.col("TvT discrease (Entnahme AZK)").str.contains(r"\*"),
            ~pl.col("tvt_increase").str.contains(r"\*"),
        )
        .then(pl.lit("0"))
        .otherwise(pl.col("tvt_increase"))
        .alias("tvt_increase")
    )

    df = df.with_columns(
        pl.when(
            pl.col("TvT discrease (Entnahme AZK)").str.contains(r"\*"),
            ~pl.col("tvt_increase").str.contains(r"\*"),
            pl.col("tvt_increase").str.contains(r"\-"),
        )
        .then(None)
        .otherwise(pl.col("TvT discrease (Entnahme AZK)"))
        .alias("TvT discrease (Entnahme AZK)")
    )

    def fill_days_off(frame, datenspalte, zielspalte):
        frame = frame.with_columns(
            pl.when(pl.col.Arbeitszeitmodell == 173.33)
            .then(pl.col(f"{datenspalte}") / 8)
            .otherwise(
                pl.when(pl.col.Arbeitszeitmodell == 162.5)
                .then(pl.col(f"{datenspalte}") / 7.5)
                .otherwise(pl.when(pl.col.Arbeitszeitmodell == 130.0).then(pl.col(f"{datenspalte}") / 6).otherwise(pl.col(f"{zielspalte}")))
            )
            .alias(f"{zielspalte}")
        )

        return frame

    if "Krankheit ohne Entgelt" in df.columns and "Krankheit" in df.columns:
        df = df.with_columns(sum_krankheit=pl.sum_horizontal("Krankheit", "Krankheit ohne Entgelt"))

        df = fill_days_off(df, "sum_krankheit", "sick_taken_days")

    if "Krankheit" in df.columns:
        df = fill_days_off(df, "Krankheit", "sick_taken_days")

    df = fill_days_off(df, "Urlaub", "holidays_days")

    df = df.select(
        "Berater",
        "Mandant",
        "PNR",
        "VornameName",
        "Satzart",
        "Overtime hours 25%",
        "Overtime hours 100%",
        "TvT discrease (Entnahme AZK)",
        "tvt_increase",
        "negiert_tvt_increase",
        "TvT balance (old - review only)",
        "TvT balance (new - review only)",
        "Overtime Hours hourly wage",
        "sick_taken_days",
        "holidays_days",
    )
    df = df.with_columns(sick_taken_days=pl.col("sick_taken_days").replace(0.0, None))

    df = df.sort("PNR")

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path(
        user_id=user_id,
        data_conversion="Stargroup",
        conversion="default",
        task_id=task.request.id,
        extension="xlsx",
        month=month,
        year=year,
    )

    ensure_output_folder(output_path)

    df.write_excel(
        autofit=True,
        workbook=output_path,
        header_format={
            "bold": True,
            "bg_color": "#ff7f50",
        },
        conditional_formats={
            "tvt_increase": {
                "type": "blanks",
                "format": {"bg_color": "#FFC7CE", "font_color": "#9C0006"},
            },
            "negiert_tvt_increase": {
                "type": "cell",
                "criteria": "<",
                "value": 0.0,
                "format": {"font_color": "#000000"},
            },
        },
    )

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
