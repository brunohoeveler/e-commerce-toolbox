import io
from pathlib import Path

import polars as pl

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.datev_export import datev_export_polars
from app.utils.file_utils import (
    delete_input_files,
    ensure_output_folder,
    generate_output_path_datev,
    strip_task_id,
)


@register_data_conversion(
    data_conversion="Nomos",
    conversion="default",
    description="Nomos default conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000, "max": 2099}),
        "select": (
            str,
            {"description": "Choose a bank", "allowed": ["Vwbank", "Commerzbank"]},
        ),
        "files": (
            str,
            {"description": "CSV upload", "extensions": ["csv"], "min_files": 1},
        ),
    },
    output_type="csv",
)
def nomos_default(task, files: list[Path], month: int, year: int, select: str):
    user_id = task.request.headers.get("user_id")
    file = files[0]

    # ======================== DATA IMPORT ====================================

    df_import = pl.read_csv(file, separator="\t", infer_schema_length=0, encoding="UTF-16")

    df_import = df_import.select([col for i, col in enumerate(df_import.columns) if i in [1, 2, 4, 5]])

    df_import = df_import.rename(dict(zip(df_import.columns[0:], ["datum", "buchungstext", "H", "S"])))
    df_import = df_import.unpivot(index=["datum", "buchungstext"], value_name="umsatz", variable_name="sh")
    df_import = df_import.filter(pl.col("umsatz").is_not_null())
    df_import = df_import.filter(pl.col("umsatz") != "")

    df_import = df_import.with_columns(pl.lit(select).alias("konto"))

    df_import = df_import.with_columns(pl.when(pl.col("buchungstext").str.contains("Kapitalertragsteuer")).then(pl.lit("2213")).otherwise(pl.lit("")).alias("gegenkonto"))

    df_import = df_import.with_columns(pl.when(pl.col("buchungstext").str.contains("Solidaritätszuschlag")).then(pl.lit("2208")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))

    df_import = df_import.with_columns(pl.when(pl.col("buchungstext").str.contains("Habenzinsen")).then(pl.lit("2650")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))

    df_import = df_import.with_columns(pl.when(pl.col("buchungstext").str.contains("Gutschrift|Belastung")).then(pl.lit("1360")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))

    df_import = df_import.filter(pl.col("datum").str.contains(str(year)))
    df_import = df_import.with_columns(pl.col("datum").cast(str).str.replace_all(r"\.", "").str.slice(0, 4).alias("datum"))

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Cimcorp",
        conversion="employeeDatasets",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        datev_export_polars(
            buffer=buffer,
            df=df_import,
            bernr="85867",
            mdtnr="12103",
            skl="4",
            skr="3",
            text="Nomos Import",
            month=month,
            year=year,
        )

        with open(output_path, "wb") as f:
            f.write(buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
