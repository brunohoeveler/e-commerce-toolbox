import io
import re
from pathlib import Path
from zipfile import ZipFile

import pandas as pd
import polars as pl
from fastapi import UploadFile

from app.tasks.data_conversion_registry import register_data_conversion
from app.utils.datev_export import datev_export_polars, datev_format
from app.utils.file_utils import delete_input_files, ensure_output_folder, generate_output_path_datev, strip_task_id


@register_data_conversion(
    data_conversion="Ankerkraut",
    conversion="Paypal",
    description="Ankerkraut Paypal conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 2,
                "max_files": 2,
                "extensions": ["csv", "xlsx", "xls", "txt", "TXT"],
            },
        ),
    },
    output_type="csv",
)
def ankerkraut_paypal(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]

    # ========================== PAYPAL DATEI ==========================
    try:
        df_import = pl.read_csv(file1, separator="\t", infer_schema_length=0)
        assert df_import.width == 49
    except FileNotFoundError as e:
        raise Exception("Die Paypal Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Paypal Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_import = df_import.select(
        [
            col
            for i, col in enumerate(df_import.columns)
            if i
            not in [
                2,
                5,
                9,
                11,
                13,
                14,
                15,
                16,
                17,
                18,
                19,
                20,
                21,
                22,
                23,
                24,
                25,
                26,
                27,
                28,
            ]
        ]
    )
    df_import = df_import.drop(df_import.columns[11:])
    df_import = df_import.rename(
        dict(
            zip(
                df_import.columns[0:],
                [
                    "datum",
                    "uhrzeit",
                    "buchungstext",
                    "inhalt3",
                    "wkz",
                    "umsatz",
                    "umsatz2",
                    "absender",
                    "auftragsnummer",
                    "inhalt1",
                    "inhalt2",
                ],
            )
        )
    )

    df_import = df_import.with_columns(
        [
            pl.lit("Bezug PayPal ID").alias("info1"),
            pl.lit("Rechnungsnummer").alias("info2"),
            pl.lit("Transaktionstyp").alias("info3"),
            pl.lit("S").alias("sh"),
            pl.lit("13615").alias("konto"),
            pl.lit("13605").alias("gegenkonto"),
            pl.col("datum").str.slice(0, 5),
        ]
    )
    df_import = df_import.with_columns(pl.col("datum").str.replace_all(r"\.", ""))

    # ========================== KURSBERECHNUNG ==========================
    df_kurs = df_import[["datum", "inhalt3", "uhrzeit", "wkz", "umsatz"]].filter(pl.col("inhalt3").is_in(["Währungsumrechnung durch Nutzer", "Allgemeine Währungsumrechnung"])).drop("inhalt3")

    df_kurs = df_kurs.with_columns(pl.col("umsatz").str.replace_all(r"\.", "").str.replace_all(",", ".").cast(pl.Float64).abs())

    df_kurs = df_kurs.pivot(values="umsatz", index=["datum", "uhrzeit"], on="wkz")

    waehrungen = ["USD", "DKK", "CHF"]
    vorhandene_waehrungen = [w for w in waehrungen if w in df_kurs.columns]

    df_kurs = df_kurs.unpivot(
        index=["datum", "uhrzeit", "EUR"],
        on=vorhandene_waehrungen,
        variable_name="wkz",
        value_name="umsatz_wkz",
    )

    df_kurs = df_kurs.filter(pl.col("umsatz_wkz").is_not_null())

    df_kurs = df_kurs.with_columns((pl.col("umsatz_wkz") / pl.col("EUR")).cast(pl.Float64).round(4).cast(pl.Utf8).str.replace_all(r"\.", ",").alias("kurs"))

    df_kurs = df_kurs.select(["datum", "uhrzeit", "wkz", "kurs"]).unique(subset=["datum", "wkz"]).sort("datum")

    df_import = df_import.join(df_kurs, on=["datum", "wkz"], how="left").sort("kurs").drop("uhrzeit")

    # ========================== REGELN KONTENBESTIMMUNG ==========================
    revenue_key_words = [
        "Zahlung im Einzugsverfahren mit Zahlungsrechnung",
        "Rückzahlung",
        "Allgemeine Zahlung",
        "PayPal Express-Zahlung",
    ]

    df_import = df_import.with_columns(pl.when(pl.col("wkz") == "CHF").then(pl.lit("13623")).otherwise(pl.col("konto")).alias("konto"))
    df_import = df_import.with_columns(pl.when(pl.col("wkz") == "DKK").then(pl.lit("13626")).otherwise(pl.col("konto")).alias("konto"))
    df_import = df_import.with_columns(pl.when((pl.col("wkz") == "EUR") & (pl.col("inhalt3").is_in(revenue_key_words))).then(pl.lit("136200")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(pl.when((pl.col("wkz") == "CHF") & (pl.col("inhalt3").is_in(revenue_key_words))).then(pl.lit("300000")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(pl.when((pl.col("wkz") == "DKK") & (pl.col("inhalt3").is_in(revenue_key_words))).then(pl.lit("500000")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(
        pl.when(
            (pl.col("absender") == "lotse@ankerkraut.de")
            & (
                pl.col("inhalt3").is_in(
                    [
                        "Zahlung im Einzugsverfahren mit Zahlungsrechnung",
                        "PayPal Express-Zahlung",
                    ]
                )
            )
        )
        .then(pl.lit("13602"))
        .otherwise(pl.col("gegenkonto"))
        .alias("gegenkonto")
    )
    df_import = df_import.with_columns(pl.when(pl.col("inhalt3") == "Rückzahlung").then(pl.col("inhalt1")).otherwise(pl.col("auftragsnummer")).alias("auftragsnummer"))

    # ========================== FEE INTO DATAFRAME ==========================
    df_fee = df_import.filter(pl.col("umsatz2") != "0,00").drop("umsatz").rename({"umsatz2": "umsatz"})
    df_fee = df_fee.with_columns(pl.lit("49702").alias("gegenkonto"))
    df_import = df_import.drop("umsatz2")
    df_import = pl.concat([df_import, df_fee])

    # ========================== SH-LOGIC ==========================
    df_import = df_import.with_columns(pl.when(pl.col("umsatz").str.contains("-")).then(pl.lit("H")).otherwise(pl.col("sh")).alias("sh"))
    df_import = df_import.with_columns(pl.col("umsatz").str.replace_all(r"\-", "").alias("umsatz"))

    # ========================== RECHNUNGSDATEI ==========================
    try:
        df_rechnungen = pl.read_excel(file2, infer_schema_length=0)
        assert df_rechnungen.width == 9
    except FileNotFoundError as e:
        raise Exception("Die Rechnungsdatei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Rechnungsdatei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_rechnungen = df_rechnungen.select([col for i, col in enumerate(df_rechnungen.columns) if i in [0, 2, 6]])
    df_rechnungen = df_rechnungen.rename(dict(zip(df_rechnungen.columns[0:], ["belegfeld", "auftrag", "auftragsnummer"])))
    df_rechnungen = df_rechnungen.filter(~pl.col("auftragsnummer").is_null()).unique(subset="auftragsnummer", maintain_order=True)
    # ========================== MERGE ==========================
    df_import = df_import.join(df_rechnungen, on="auftragsnummer", how="left")
    df_import = df_import.with_columns(
        pl.when(~pl.col("auftrag").is_null()).then(pl.concat_str([pl.col("auftrag"), pl.lit(" "), pl.col("buchungstext")])).otherwise(pl.col("buchungstext")).alias("buchungstext")
    )
    df_import = df_import.with_columns(pl.when(pl.col("belegfeld").is_null()).then(pl.col("auftragsnummer")).otherwise(pl.col("belegfeld")).alias("belegfeld"))
    df_import = df_import.with_columns(pl.when(pl.col("belegfeld").is_null()).then(pl.col("inhalt3")).otherwise(pl.col("belegfeld")).alias("belegfeld"))
    df_import = df_import.drop(["absender", "auftrag"])
    df_import = df_import.with_columns(pl.col("umsatz").str.replace_all(r"\.", "").alias("umsatz"))
    df_import = df_import.with_columns(pl.col("kurs").str.replace_all(r"\-", "").alias("kurs"))

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Ankerkraut",
        conversion="Paypal",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        datev_export_polars(
            df=df_import,
            month=month,
            year=year,
            buffer=buffer,
            bernr="405312",
            mdtnr="10055",
            skl="5",
            skr="3",
            text="Ankerkraut Paypal",
        )

        with open(output_path, "wb") as f:
            f.write(buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Ankerkraut",
    conversion="JTL",
    description="Ankerkraut JTL conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "revision": (int, {"description": "Revision number", "min": 1, "max": 8}),
        "files": (
            list[UploadFile],
            {
                "min_files": 3,
                "max_files": 3,
                "extensions": ["csv", "xlsx", "xls"],
            },
        ),
    },
    output_type="zip",
)
def ankerkraut_jtl(task, month: int, year: int, revision: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]
    file3 = files[2]

    # ============================= RECHNUNGEN IMPORT ====================================
    df_rechnungen = pd.read_excel(file1, dtype=str)
    df_rechnungen.columns.values[0:4] = [
        "re_auftrnr",
        "re_shopbestnr",
        "re_renr",
        "re_datum",
    ]
    df_rechnungen.loc[
        df_rechnungen["re_auftrnr"].str.contains("edi", regex=True, flags=re.I),
        "re_auftrnr",
    ] = df_rechnungen["re_auftrnr"].str.replace("_", "-")

    # ============================= FEHLERPROTOKOLL IMPORT ================================
    df_fehlerprotokoll = pd.read_excel(file2, sheet_name="Tabelle2", dtype=str)
    df_fehlerprotokoll.columns.values[1] = "renr"
    df_fehlerprotokoll.columns.values[8] = "urspr"
    df_fehlerprotokoll["col21"] = df_fehlerprotokoll.iloc[:, 21].astype(float, errors="ignore")
    df_fehlerprotokoll["kurs"] = df_fehlerprotokoll.apply(lambda row: row["col21"] if row["col21"] != 1 else None, axis=1)
    df_fehlerprotokoll = df_fehlerprotokoll[["renr", "urspr", "kurs"]]

    # ============================== EXTF IMPORT ===========================================
    df_extf = pd.read_csv(file3, delimiter=";", skiprows=[0], encoding="latin_1", dtype=str)
    df_extf.columns.values[0:4] = ["umsatz", "sh", "wkz", "kurs"]
    df_extf.columns.values[6:14] = [
        "konto",
        "gegenkonto",
        "bu",
        "datum",
        "belegfeld",
        "belegfeld2",
        "skonto",
        "buchungstext",
    ]
    df_extf.columns.values[39:41] = ["eulandbest", "eusteuerbest"]
    df_extf.columns.values[91] = "veranlagungsjahr"
    df_extf.columns.values[118:120] = ["steuersatz", "land"]
    df_extf.columns.values[122] = "landhk"
    df_extf = df_extf[
        [
            "umsatz",
            "sh",
            "wkz",
            "kurs",
            "konto",
            "gegenkonto",
            "bu",
            "datum",
            "belegfeld",
            "belegfeld2",
            "buchungstext",
            "eulandbest",
            "eusteuerbest",
            "veranlagungsjahr",
            "steuersatz",
            "land",
            "landhk",
        ]
    ]

    # ============================== MERGE EXTF MIT RECHNUNGEN ===============================
    df_merge1 = pd.merge(df_extf, df_rechnungen, left_on="belegfeld", right_on="re_auftrnr", how="left")
    df_rest1 = df_merge1[df_merge1["re_datum"].isnull()].copy()
    df_merge1 = df_merge1[~df_merge1["re_datum"].isnull()]
    del df_rest1["re_auftrnr"]
    del df_rest1["re_shopbestnr"]
    del df_rest1["re_datum"]
    del df_rest1["re_renr"]
    df_merge1["belegfeld"] = df_merge1["re_auftrnr"]
    df_merge1["protocol"] = ""

    df_merge2 = pd.merge(
        df_rest1,
        df_rechnungen,
        left_on="belegfeld",
        right_on="re_shopbestnr",
        how="left",
    )
    df_rest2 = df_merge2[df_merge2["re_datum"].isnull()].copy()
    df_merge2 = df_merge2[~df_merge2["re_datum"].isnull()]
    del df_rest2["re_auftrnr"]
    del df_rest2["re_shopbestnr"]
    del df_rest2["re_datum"]
    del df_rest2["re_renr"]
    df_merge2["belegfeld"] = df_merge2["re_shopbestnr"]
    df_merge2["protocol"] = ""

    df_merge3 = pd.merge(df_rest2, df_rechnungen, left_on="belegfeld", right_on="re_renr", how="left")
    df_rest3 = df_merge3[df_merge3["re_datum"].isnull()].copy()
    df_merge3 = df_merge3[~df_merge3["re_datum"].isnull()]
    df_merge3["belegfeld"] = df_merge3["re_renr"]
    df_merge3["protocol"] = ""

    if not df_rest3.empty:
        df_rest3.loc[df_rest3["belegfeld"].str.len() != 5, "protocol"] = "inv-nr-not matched"
        df_rest3.loc[df_rest3["belegfeld"].str.len() == 5, "protocol"] = ""

    df_final = pd.concat([df_merge1, df_merge2, df_merge3, df_rest3])
    df_final.drop_duplicates(subset=["umsatz", "belegfeld"], ignore_index=True, inplace=True)
    df_protocol = df_final.copy()

    # ==================================== PROTOCOL =========================================
    df_protocol.loc[(df_protocol["konto"].isnull()) | (df_protocol["konto"].isin([""])), "protocol"] = "no account"
    df_protocol.loc[
        (df_protocol["gegenkonto"].isnull()) | (df_protocol["gegenkonto"].isin([""])),
        "protocol",
    ] = "no contra-account"
    df_protocol.loc[
        (df_protocol["umsatz"].isnull()) | (df_protocol["umsatz"].isin([""])),
        "protocol",
    ] = "no revenue"
    df_protocol.loc[(df_protocol["sh"].isnull()) | (df_protocol["sh"].isin([""])), "protocol"] = "no s/h clarification"
    df_protocol.loc[
        (df_protocol["gegenkonto"] == "83200") & ((df_protocol["bu"].isin(["", " "])) | (df_protocol["bu"].isnull())),
        "protocol",
    ] = "no posting key"
    df_protocol.loc[
        (df_protocol["gegenkonto"] == "83200") & (df_protocol["steuersatz"].isnull()) & (df_protocol["eusteuerbest"].isnull()),
        "protocol",
    ] = "no tax rate"
    df_protocol = df_protocol[["protocol"] + [col for col in df_protocol.columns if col != "protocol"]]
    df_protocol = df_protocol[~df_protocol["protocol"].isin([""])]

    # ============================== MERGE EXTF MIT FEHLERPROTOKOLL ===========================

    df_datev = pd.merge(df_final, df_fehlerprotokoll, left_on="belegfeld", right_on="renr", how="left")
    df_datev.drop_duplicates(subset=["umsatz", "belegfeld"], ignore_index=True, inplace=True)
    del df_datev["renr"]
    df_datev.loc[df_datev["urspr"] == "CZ", "landhk"] = "CZ684228098"
    df_datev.loc[df_datev["urspr"] == "PL", "landhk"] = "PL5263190070"
    df_datev.loc[df_datev["konto"] == "100000", "belegfeld"] = df_datev["re_shopbestnr"]
    df_datev.loc[
        (df_datev["belegfeld"].isnull()) | (df_datev["belegfeld"].str.contains("edi", flags=re.I, regex=True)),
        "belegfeld",
    ] = df_datev["re_renr"]
    df_datev.loc[df_datev["belegfeld"].isnull(), "belegfeld"] = df_datev["belegfeld2"]
    del df_datev["belegfeld2"]
    del df_datev["re_datum"]
    del df_datev["re_renr"]
    del df_datev["re_shopbestnr"]
    del df_datev["re_auftrnr"]
    del df_datev["protocol"]
    del df_datev["urspr"]
    del df_datev["kurs_x"]
    df_datev.loc[df_datev["gegenkonto"] == "17964", "bu"] = ""
    df_datev.insert(3, "kurs", df_datev.pop("kurs_y"))
    df_datev["kurs"] = df_datev["kurs"].apply(lambda x: str(x).replace(".", ",") if pd.notna(x) else x)

    df_export = datev_format(
        df=df_datev,
        month=month,
        year=year,
        bernr="405312",
        mdtnr="10055",
        skl="5",
        skr="3",
        text=f"Ankerkraut JTL Rev: {revision}",
    )

    df_export.columns.values[124:150] = "del"
    del df_export["del"]

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Ankerkraut",
        conversion="JTL",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="zip",
    )

    ensure_output_folder(output_path)

    # Use a ZipFile object to write multiple dataframes to the buffer
    with ZipFile(output_path, "w") as zf:
        # Convert df_export to a CSV and write it to a ZIP file in memory
        with zf.open(f"DTVF_Ankerkraut_JTL_{year}_{month}_{revision}.csv", "w") as f:
            f.write(df_export.to_csv(index=False, sep=";").encode("utf-8"))

        # Create a BytesIO stream for the Excel file
        excel_buffer = io.BytesIO()
        df_protocol.to_excel(excel_buffer, sheet_name="Protocol", index=False)
        excel_buffer.seek(0)  # Rewind the buffer
        zf.writestr(
            f"Protokoll_Ankerkraut_JTL_{year}_{month}_{revision}.xlsx",
            excel_buffer.read(),
        )

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Ankerkraut",
    conversion="Amazon",
    description="Ankerkraut Amazon conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 3,
                "max_files": 3,
                "extensions": ["csv", "xlsx", "xls"],
            },
        ),
    },
    output_type="csv",
)
def ankerkraut_amazon(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]
    file3 = files[2]

    # ========================== AMAZON DATEI ==========================
    try:
        df_import = pl.read_csv(file1, separator=",", skip_rows=7, infer_schema_length=0)
        assert df_import.width == 27
    except FileNotFoundError as e:
        raise Exception("Die Amazon Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Amazon Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e
    df_import = df_import.rename(dict(zip(df_import.columns[0:1], ["datum"])))
    df_import = df_import.rename(dict(zip(df_import.columns[2:6], ["typ", "auftragsnummer", "sku", "beschreibung"])))

    df_import = df_import.drop(df_import.columns[1])
    df_import = df_import.drop(df_import.columns[5:12])
    df_import = df_import.drop(df_import.columns[-1])

    df_import = df_import.with_columns(pl.when(pl.col("beschreibung").is_in(["Werbekosten"])).then(pl.col("beschreibung")).otherwise(pl.col("typ")).alias("typ"))
    df_import = df_import.with_columns(pl.when(pl.col("beschreibung").str.contains("Sparen Sie")).then(pl.lit("Gewuerzerabatt")).otherwise(pl.col("beschreibung")).alias("beschreibung"))
    df_import = df_import.with_columns(pl.when(pl.col("typ").is_null()).then(pl.col("beschreibung")).otherwise(pl.col("typ")).alias("typ"))

    df_import = df_import.unpivot(index=["datum", "typ", "auftragsnummer", "sku", "beschreibung"])
    df_import = df_import.filter(~pl.col("value").is_in(["0"]))
    df_import = df_import.filter(~pl.col("value").is_null())
    df_import = df_import.with_columns(pl.when(pl.col("value").str.contains("-")).then(pl.lit("H")).otherwise(pl.lit("S")).alias("sh"))
    df_import = df_import.with_columns(pl.col("value").str.replace_all("-", "").alias("value"))
    df_import = df_import.with_columns(pl.col("datum").str.replace_all(r"\.", "").str.slice(0, 4).alias("datum"))
    df_import = df_import.with_columns(pl.col("value").str.replace_all(r"\.", "").alias("value"))

    # ========================== RECHNUNGSDATEI ==========================
    try:
        df_rechnungen = pl.read_excel(file2, infer_schema_length=0)
        assert df_rechnungen.width == 9
    except FileNotFoundError as e:
        raise Exception("Die Rechnungsdatei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Rechnungsdatei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e
    df_rechnungen = df_rechnungen.drop(df_rechnungen.columns[3:7])
    df_rechnungen = df_rechnungen.drop(df_rechnungen.columns[4])
    df_rechnungen = df_rechnungen.rename(
        dict(
            zip(
                df_rechnungen.columns[0:4],
                ["belegfeld", "auftragsnummer", "renr", "name"],
            )
        )
    )
    df_rechnungen = df_rechnungen.filter(~pl.col("auftragsnummer").is_null())
    df_rechnungen = df_rechnungen.unique(subset=["auftragsnummer"])

    # ========================== MERGE ==========================
    df_import = df_import.join(df_rechnungen, on="auftragsnummer", how="left")
    df_import = df_import.with_columns(
        pl.concat_str(
            [
                pl.coalesce([pl.col("renr"), pl.col("auftragsnummer")]),
                pl.lit(" "),
                pl.coalesce([pl.col("name"), pl.lit("Unbekannt")]),
                pl.lit(": "),
                pl.col("typ"),
                pl.lit(" - "),
                pl.col("variable"),
            ]
        ).alias("buchungstext")
    )
    df_import = df_import.with_columns(pl.col("buchungstext").str.slice(0, 59))
    df_import = df_import.with_columns(pl.lit("13616").alias("konto"))

    # ========================== REGELN KONTENBESTIMMUNG ==========================
    df_import = df_import.with_columns(pl.when(pl.col("variable").is_in(["Verkaufsgebühren"])).then(pl.lit("47030")).otherwise(pl.lit("")).alias("gegenkonto"))
    df_import = df_import.with_columns(pl.when(pl.col("variable").is_in(["Gebühren zu Versand durch Amazon"])).then(pl.lit("47600")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(
        pl.when(
            pl.col("variable").is_in(
                [
                    "Gutschrift für Geschenkverpackung",
                    "Gutschrift für Versandkosten",
                    "Rabatte aus Werbeaktionen",
                    "Umsätze",
                    "Andere",
                ]
            )
        )
        .then(pl.lit("136300"))
        .otherwise(pl.col("gegenkonto"))
        .alias("gegenkonto")
    )
    df_import = df_import.with_columns(pl.when(pl.col("variable").is_in(["Andere Transaktionsgebühren"])).then(pl.lit("27420")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(pl.when(pl.col("typ").is_in(["Werbekosten", "Servicegebühr"])).then(pl.lit("46040")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(pl.when(pl.col("typ").is_in(["Versand durch Amazon Lagergebühr"])).then(pl.lit("42102")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(pl.when(pl.col("typ").is_in(["Übertrag"])).then(pl.lit("13601")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(pl.when(pl.col("buchungstext").str.contains("Gewuerzerabatt")).then(pl.lit("136300")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(pl.when(pl.col("buchungstext").str.contains("Versanddienst")).then(pl.lit("47030")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(pl.when(pl.col("buchungstext").str.contains("Anpassung")).then(pl.lit("42102")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))

    # ========================== REGELN BUCHUNGSSÄTZE ==========================
    df_import = df_import.with_columns(pl.when(pl.col("typ").is_in(["Werbekosten", "Servicegebühr"])).then(pl.lit("401")).otherwise(pl.lit("")).alias("bu"))
    df_import = df_import.with_columns(pl.when(pl.col("typ").is_in(["Versand durch Amazon Lagergebühr"])).then(pl.lit("506")).otherwise(pl.col("bu")).alias("bu"))
    df_import = df_import.with_columns(pl.when(pl.col("buchungstext").str.contains("Versanddienst")).then(pl.lit("506")).otherwise(pl.col("bu")).alias("bu"))
    df_import = df_import.with_columns(pl.when(pl.col("buchungstext").str.contains("Anpassung")).then(pl.lit("506")).otherwise(pl.col("bu")).alias("bu"))

    # ========================== GUTSCHRIFTEN DATEI ==========================
    try:
        df_gutschriften = pl.read_excel(file3, infer_schema_length=0)
        assert df_gutschriften.width == 8
    except FileNotFoundError as e:
        raise Exception("Die Gutschriften Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Gutschriften Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e
    df_gutschriften = df_gutschriften.drop(df_gutschriften.columns[2:])
    df_gutschriften = df_gutschriften.rename(dict(zip(df_gutschriften.columns[0:2], ["renr", "gutschrnr"])))
    df_gutschriften = df_gutschriften.with_columns(pl.lit("Erstattung").alias("typ"))
    df_gutschriften = df_gutschriften.unique(subset=["renr"])

    # ========================== MERGE ==========================
    df_import = df_import.join(df_gutschriften, on=["typ", "renr"], how="left")
    df_import = df_import.with_columns(pl.when(~pl.col("gutschrnr").is_null()).then(pl.col("gutschrnr")).otherwise(pl.col("belegfeld")).alias("belegfeld"))

    # ========================== BUCHUNGSTEXTE ERNEUERN ==========================
    df_import = df_import.with_columns(
        pl.concat_str(
            [
                pl.coalesce([pl.col("renr"), pl.col("auftragsnummer")]),
                pl.lit(" "),
                pl.coalesce([pl.col("name"), pl.lit("Unbekannt")]),
                pl.lit(": "),
                pl.col("typ"),
                pl.lit(" - "),
                pl.col("variable"),
            ]
        ).alias("buchungstext")
    )
    df_import = df_import.with_columns(pl.col("buchungstext").str.slice(0, 59))

    # ========================== INFO/INHALT SPALTEN ==========================
    df_import = df_import.with_columns(pl.lit("Name Kunde").alias("info1"))
    df_import = df_import.with_columns(pl.lit("Transaktionstyp").alias("info2"))
    df_import = df_import.with_columns(pl.lit("Rechnungsnummer").alias("info3"))
    df_import = df_import.with_columns(pl.col("name").alias("inhalt1"))
    df_import = df_import.with_columns(pl.concat_str([pl.col("typ"), pl.lit(" - "), pl.col("variable")]).alias("inhalt2"))
    df_import = df_import.with_columns(pl.col("renr").alias("inhalt3"))

    df_import = df_import[
        "datum",
        "auftragsnummer",
        "value",
        "sh",
        "belegfeld",
        "buchungstext",
        "konto",
        "gegenkonto",
        "bu",
        "info1",
        "inhalt1",
        "info2",
        "inhalt2",
        "info3",
        "inhalt3",
    ]
    df_import = df_import.rename({"value": "umsatz"})

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Ankerkraut",
        conversion="Amazon",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        datev_export_polars(
            df=df_import,
            month=month,
            year=year,
            buffer=buffer,
            bernr="405312",
            mdtnr="10055",
            skl="5",
            skr="3",
            text="Ankerkraut Amazon",
        )

        with open(output_path, "wb") as f:
            f.write(buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Ankerkraut",
    conversion="PWA",
    description="Ankerkraut PWA conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 3,
                "max_files": 3,
                "extensions": ["csv", "xlsx", "xls"],
            },
        ),
    },
    output_type="csv",
)
def ankerkraut_pwa(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]
    file3 = files[2]

    df_amazon = pd.read_csv(file1, dtype=str, sep=",")
    df_amazon.columns.values[0] = "datum"
    df_amazon.columns.values[2] = "auftragsnummer"
    df_amazon.columns.values[4] = "typ"

    df_amazon.drop(df_amazon.columns[1], axis=1, inplace=True)
    df_amazon.drop(df_amazon.columns[2], axis=1, inplace=True)
    df_amazon.drop(df_amazon.columns[3:8], axis=1, inplace=True)
    df_amazon.drop(df_amazon.columns[-1], axis=1, inplace=True)
    df_amazon.drop(df_amazon.columns[-1], axis=1, inplace=True)
    df_amazon.drop(df_amazon.columns[-1], axis=1, inplace=True)
    df_amazon["datum"] = df_amazon["datum"].str.replace("-", "")
    df_amazon["datum"] = df_amazon["datum"].str[6:8] + df_amazon["datum"].str[4:6]

    df_amazon = pd.melt(
        df_amazon,
        id_vars=["datum", "typ", "auftragsnummer"],
        value_name="umsatz",
        ignore_index=True,
    )
    df_amazon = df_amazon[~df_amazon["umsatz"].isin(["0"])]
    df_amazon["sh"] = "S"
    df_amazon["umsatz"] = df_amazon["umsatz"].str.replace(".", "")
    df_amazon.loc[df_amazon["umsatz"].str.contains("-"), "sh"] = "H"
    df_amazon.loc[df_amazon["umsatz"].str.contains("-"), "umsatz"] = df_amazon["umsatz"].str.replace("-", "")

    df_amazon["konto"] = "13617"
    df_amazon.loc[
        df_amazon["variable"].isin(["TransactionPercentageFee", "TransactionFixedFee"]),
        "gegenkonto",
    ] = "49703"
    df_amazon.loc[df_amazon["variable"].isin(["TransactionAmount"]), "gegenkonto"] = "136360"
    df_amazon.loc[df_amazon["typ"].isin(["Transfer"]), "gegenkonto"] = "13606"

    df_rechnungen = pd.read_excel(file2, dtype=str)
    df_rechnungen.columns.values[0:9] = [
        "belegfeld",
        "x",
        "renr",
        "x",
        "x",
        "x",
        "auftragsnummer",
        "name",
        "x",
    ]
    del df_rechnungen["x"]
    df_rechnungen = df_rechnungen[~df_rechnungen["auftragsnummer"].isnull()]
    df_rechnungen.drop_duplicates(subset="auftragsnummer", inplace=True)

    df_merge = pd.merge(df_amazon, df_rechnungen, how="left", on="auftragsnummer")
    df_merge["buchungstext"] = df_merge["renr"] + " " + df_merge["name"] + ": " + df_merge["typ"] + " - " + df_merge["variable"]
    df_merge["buchungstext"] = df_merge["buchungstext"].str[:59]
    df_merge.loc[df_merge["buchungstext"].isnull(), "buchungstext"] = df_merge["renr"] + ": " + df_merge["typ"] + " - " + df_merge["variable"]
    df_merge.loc[df_merge["buchungstext"].isnull(), "buchungstext"] = df_merge["renr"] + ": " + df_merge["name"] + " - " + df_merge["typ"]
    df_merge.loc[df_merge["buchungstext"].isnull(), "buchungstext"] = df_merge["name"] + " - " + df_merge["typ"]
    df_merge.loc[df_merge["buchungstext"].isnull(), "buchungstext"] = df_merge["typ"]
    df_merge.loc[df_merge["typ"].isin(["Transfer"]), "buchungstext"] = "Transferbuchung"
    df_merge.loc[df_merge["typ"].isin(["Transfer"]), "belegfeld"] = "Transferbuchung"
    df_merge.loc[df_merge["gegenkonto"].isin(["47030", "47600"]), "bu"] = "506"

    df_gutschriften = pd.read_excel(file3, dtype=str)
    df_gutschriften.columns.values[0:5] = ["renr", "gutschrnr", "x", "x", "x"]
    del df_gutschriften["x"]
    df_gutschriften["typ"] = "Refund"
    df_gutschriften.drop_duplicates(subset="renr", inplace=True)

    df_merge2 = pd.merge(df_merge, df_gutschriften, on=["typ", "renr"], how="left")
    df_merge2.loc[~df_merge2["gutschrnr"].isnull(), "belegfeld"] = df_merge2["gutschrnr"]
    df_merge2["info1"] = "Name Kunde"
    df_merge2["inhalt1"] = df_merge2["name"]
    df_merge2["info2"] = "Transaktionstyp"
    df_merge2["inhalt2"] = df_merge2["typ"] + " - " + df_merge2["variable"]
    df_merge2["info3"] = "Rechnungsnummer"
    df_merge2["inhalt3"] = df_merge2["renr"]
    del df_merge2["variable"]
    del df_merge2["typ"]
    del df_merge2["gutschrnr"]
    del df_merge2["renr"]
    del df_merge2["name"]

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Ankerkraut",
        conversion="PWA",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        datev_export_polars(
            df=df_merge2,
            month=month,
            year=year,
            buffer=buffer,
            bernr="405312",
            mdtnr="10055",
            skl="5",
            skr="3",
            text="Ankerkraut PWA",
        )

        with open(output_path, "wb") as f:
            f.write(buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Ankerkraut",
    conversion="Shopify",
    description="Ankerkraut Shopify conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 2,
                "extensions": ["csv", "xlsx", "xls"],
            },
        ),
    },
    output_type="csv",
)
def ankerkraut_shopify(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    files1 = [file for file in files if file.name.endswith(".csv")]
    files2 = [file for file in files if file.name.endswith(".xlsx")]

    # ========================== CSV TRANSACTIONS DATEIEN ==========================
    try:
        df_list = [pl.read_csv(file, separator=",", infer_schema_length=0, ignore_errors=True) for file in files1]
        df_transactions = pl.concat(df_list)
        assert df_transactions.width == 17
    except FileNotFoundError as e:
        raise Exception("Die Transaktionsdateien wurden nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Transaktionsdateien ist nicht korrekt. Bitte überprüfen Sie die Dateien.") from e

    df_transactions = df_transactions.select([col for i, col in enumerate(df_transactions.columns) if i in [0, 2, 8]])
    df_transactions = df_transactions.rename(dict(zip(df_transactions.columns[0:], ["datum", "auftragsnummer", "umsatz"])))

    df_transactions = df_transactions.with_columns(
        [
            pl.lit("136400").alias("konto"),
            pl.lit("13621").alias("gegenkonto"),
            pl.lit("H").alias("sh"),
            pl.concat_str([pl.col("datum").str.slice(8, 2), pl.col("datum").str.slice(5, 2)]).alias("datum"),
            pl.col("umsatz").str.replace_all(r"\.", ",").alias("umsatz"),
        ]
    )
    df_transactions = df_transactions.with_columns(
        [
            pl.when(pl.col("umsatz").str.contains("-")).then(pl.lit("S")).otherwise(pl.col("sh")).alias("sh"),
            pl.col("umsatz").str.replace_all(r"\-", "").alias("umsatz"),
        ]
    )
    df_transactions = df_transactions.with_columns(
        [
            pl.when(pl.col("auftragsnummer").str.slice(0, 2) == "CH").then(pl.lit("200000")).otherwise(pl.col("konto")).alias("konto"),
            pl.when(pl.col("auftragsnummer").str.slice(0, 2) == "CH").then(pl.lit("13622")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"),
        ]
    )
    df_transactions = df_transactions.with_columns(
        [
            pl.when(pl.col("auftragsnummer").str.slice(0, 2) == "DK").then(pl.lit("400000")).otherwise(pl.col("konto")).alias("konto"),
            pl.when(pl.col("auftragsnummer").str.slice(0, 2) == "DK").then(pl.lit("13625")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"),
        ]
    )

    # ========================== XLSX WAWI DATEIEN ==========================
    try:
        df_list = [pl.read_excel(file, infer_schema_length=0) for file in files2]
        df_wawis = pl.concat(df_list)
        assert df_wawis.width == 34
    except FileNotFoundError as e:
        raise Exception("Die WAWI Dateien wurden nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der WAWI Dateien ist nicht korrekt. Bitte überprüfen Sie die Dateien.") from e

    df_wawis = df_wawis.select([col for i, col in enumerate(df_wawis.columns) if i in [2, 3, 4, 13, 14]])
    df_wawis = df_wawis.rename(
        dict(
            zip(
                df_wawis.columns[0:],
                ["belegfeld", "auftragsnummer", "renr", "nachname", "vorname"],
            )
        )
    )
    df_wawis = df_wawis.with_columns(
        pl.concat_str(
            [
                pl.coalesce(pl.col("renr"), pl.col("belegfeld"), pl.col("auftragsnummer")),
                pl.lit(": "),
                pl.coalesce(pl.col("vorname"), pl.lit("Vorname")),
                pl.lit(" "),
                pl.coalesce(pl.col("nachname"), pl.lit("Nachname")),
            ]
        ).alias("buchungstext")
    )
    df_wawis = df_wawis.drop(["renr", "vorname", "nachname"])

    df_import = df_transactions.join(df_wawis, on="auftragsnummer", how="left")

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Ankerkraut",
        conversion="Shopify",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        datev_export_polars(
            df=df_import,
            month=month,
            year=year,
            buffer=buffer,
            bernr="405312",
            mdtnr="10055",
            skl="5",
            skr="3",
            text="Ankerkraut Shopify",
        )

        with open(output_path, "wb") as f:
            f.write(buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Ankerkraut",
    conversion="Mollie",
    description="Ankerkraut Mollie conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 2,
                "max_files": 2,
                "extensions": ["csv", "xlsx", "xls"],
            },
        ),
    },
    output_type="csv",
)
def ankerkraut_mollie(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]

    # ========================== MOLLIE DATEI ==========================
    try:
        df_import = pl.read_csv(file1, separator=",", infer_schema_length=0)
        assert df_import.width == 14
    except FileNotFoundError as e:
        raise Exception("Die Mollie Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Mollie Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_import = df_import.select([col for i, col in enumerate(df_import.columns) if i not in [1, 5, 7, 8, 9, 10, 12, 13]])
    df_import = df_import.rename(
        dict(
            zip(
                df_import.columns[0:],
                ["datum", "wkz", "umsatz", "filter", "auftragsnummer", "eur"],
            )
        )
    )

    df_import = df_import.with_columns(
        [
            pl.lit("13627").alias("konto"),
            pl.lit("200500").alias("gegenkonto"),
            pl.lit("S").alias("sh"),
        ]
    )
    df_import = df_import.with_columns(pl.concat_str([pl.col("datum").str.slice(8, 2), pl.col("datum").str.slice(5, 2)]).alias("datum"))
    df_import = df_import.filter(~pl.col("filter").str.contains("(?i)cancel"))

    # ========================== RECHNUNGEN DATEI ==========================
    try:
        df_rechnungen = pl.read_excel(file2)
        assert df_rechnungen.width == 9
    except FileNotFoundError as e:
        raise Exception("Die Rechnungsdatei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Rechnungsdatei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_rechnungen = df_rechnungen.select([col for i, col in enumerate(df_rechnungen.columns) if i not in [1, 3, 4, 5, 7, 8]])
    df_rechnungen = df_rechnungen.rename(dict(zip(df_rechnungen.columns[0:], ["belegfeld", "renr", "auftragsnummer"])))

    # ========================== MERGE ==========================
    df_import = df_import.join(df_rechnungen, on="auftragsnummer", how="left")
    df_import = df_import.with_columns(
        pl.concat_str(
            [
                pl.coalesce([pl.col("renr"), pl.col("belegfeld"), pl.col("auftragsnummer")]),
                pl.lit(" - Mollie"),
            ]
        ).alias("buchungstext")
    )

    # ========================== WÄHRUNGSKURS BERECHNEN ==========================
    df_import = df_import.with_columns([pl.col("umsatz").cast(pl.Float64), pl.col("eur").cast(pl.Float64)])
    df_import = df_import.with_columns((pl.col("umsatz") / pl.col("eur")).round(4).alias("kurs"))
    df_import = df_import.with_columns(
        [
            pl.col("umsatz").cast(pl.String),
            pl.col("eur").cast(pl.String),
            pl.col("kurs").cast(pl.String),
        ]
    )
    df_import = df_import.with_columns(
        [
            pl.col("umsatz").str.replace_all(r"\.", ","),
            pl.col("kurs").str.replace_all(r"\.", ","),
        ]
    )

    df_import = df_import.select([col for i, col in enumerate(df_import.columns) if i not in [3, 5, 10]])

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Ankerkraut",
        conversion="Mollie",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        datev_export_polars(
            df=df_import,
            month=month,
            year=year,
            buffer=buffer,
            bernr="405312",
            mdtnr="10055",
            skl="5",
            skr="3",
            text="Ankerkraut Mollie",
        )

        with open(output_path, "wb") as f:
            f.write(buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Ankerkraut",
    conversion="Giftcard",
    description="Ankerkraut Giftcard conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 1,
                "max_files": 1,
                "extensions": ["xlsx", "xls"],
            },
        ),
    },
    output_type="csv",
)
def ankerkraut_giftcard(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]

    # ========================== GIFTCARDS DATEI ==========================
    try:
        df_import = pl.read_excel(file1)
        assert df_import.width == 16
    except FileNotFoundError as e:
        raise Exception("Die Giftcards Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Giftcards Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_import = df_import.drop(df_import.columns[2])
    df_import = df_import.drop(df_import.columns[5:6])
    df_import = df_import.drop(df_import.columns[7:14])
    df_import = df_import.rename(
        dict(
            zip(
                df_import.columns[0:],
                [
                    "belegfeld",
                    "auftragsnummer",
                    "bt2",
                    "datum",
                    "umsatz",
                    "transid",
                    "bt1",
                ],
            )
        )
    )

    df_import = df_import.with_columns(pl.lit("17964").alias("konto"))
    df_import = df_import.with_columns(pl.lit("").alias("gegenkonto"))
    df_import = df_import.with_columns(pl.lit("").alias("buchungstext"))
    df_import = df_import.with_columns(pl.when(pl.col("bt2").str.contains("(?i)shopify")).then(pl.lit("136400")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(pl.when(pl.col("bt2").str.contains("(?i)paypal")).then(pl.lit("136200")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(pl.when(pl.col("bt2").str.contains("(?i)amazon")).then(pl.lit("136360")).otherwise(pl.col("gegenkonto")).alias("gegenkonto"))
    df_import = df_import.with_columns(
        pl.concat_str(
            [
                pl.coalesce([pl.col("bt1"), pl.col("transid")]),
                pl.lit(" - "),
                pl.coalesce([pl.col("bt2"), pl.lit("unbekannte Zahlart")]),
            ]
        ).alias("buchungstext")
    )
    df_import = df_import.with_columns(pl.col("datum").cast(str).str.replace_all(r"\.", "").str.slice(0, 4).alias("datum"))

    # ========================== SUM DATAFRAME ==========================
    df_sum = df_import
    df_sum = df_sum.filter(pl.col("bt2").str.contains("(?i)gift_card"))
    df_sum = df_sum.drop(df_import.columns[1:4])
    df_sum = df_sum.drop(df_import.columns[5:])
    df_sum = df_sum.with_columns(pl.col("umsatz").cast(pl.Float64))
    df_sum = df_sum.group_by("belegfeld").agg(pl.col("umsatz").sum())
    df_sum = df_sum.with_columns(pl.col("umsatz").cast(pl.String))

    df_import = df_import.filter(~pl.col("bt2").str.contains("(?i)gift_card"))
    df_import = df_import.drop(
        df_import.columns[2],
        df_import.columns[4],
        df_import.columns[5],
        df_import.columns[6],
    )

    df_import = df_import.join(df_sum, on="belegfeld", how="left")
    df_import = df_import.with_columns(pl.col("umsatz").str.replace_all(r"\.", ",").alias("umsatz"))
    df_import = df_import.with_columns(pl.col("belegfeld").cast(str))

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Ankerkraut",
        conversion="Giftcard",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        datev_export_polars(
            df=df_import,
            month=month,
            year=year,
            buffer=buffer,
            bernr="405312",
            mdtnr="10055",
            skl="5",
            skr="3",
            text="Ankerkraut Giftcard",
        )

        with open(output_path, "wb") as f:
            f.write(buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}


@register_data_conversion(
    data_conversion="Ankerkraut",
    conversion="Kaufland",
    description="Ankerkraut Kaufland conversion",
    input_type={
        "month": (int, {"description": "Month in MM format", "min": 1, "max": 12}),
        "year": (int, {"description": "Year in YYYY format", "min": 2000}),
        "files": (
            list[UploadFile],
            {
                "min_files": 2,
                "max_files": 2,
                "extensions": ["csv", "xlsx", "xls"],
            },
        ),
    },
    output_type="csv",
)
def ankerkraut_kaufland(task, month: int, year: int, files: list[Path]):
    user_id = task.request.headers.get("user_id")
    file1 = files[0]
    file2 = files[1]

    # ========================== MOLLIE DATEI ==========================
    try:
        df_import = pl.read_csv(file1, separator=";", infer_schema_length=0)
        assert df_import.width == 15
    except FileNotFoundError as e:
        raise Exception("Die Kaufland Datei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Kaufland Datei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_import = df_import.select([
        col for i, col in enumerate(df_import.columns) if i in [0, 2, 5, 11, 12, 13]])

    df_import = df_import.rename(dict(zip(df_import.columns[0:], ['order', 'auftragsnummer',
                                                                  'text', 'fee1', 'fee2', 'gross'])))

    df_import = df_import.with_columns(pl.lit('13628').alias('konto'))
    df_import = df_import.with_columns(pl.lit('136380').alias('gegenkonto'))
    df_import = df_import.with_columns(pl.col('fee1').str.replace_all(r'\,', '.').alias('fee1'))
    df_import = df_import.with_columns(pl.col('fee2').str.replace_all(r'\,', '.').alias('fee2'))
    df_import = df_import.with_columns(pl.col('gross').str.replace_all(r'\,', '.').alias('gross'))
    df_import = df_import.cast({'fee1': pl.Float64, 'fee2': pl.Float64, 'gross': pl.Float64})
    df_import = df_import.with_columns((pl.col('fee1') + pl.col('fee2') + pl.col('gross')).alias('umsatz'))
    df_import = df_import.with_columns((pl.col('fee1') + pl.col('fee2')).alias('fee'))
    df_import = df_import.drop(['fee1', 'fee2', 'gross'])
    df_import = df_import.with_columns(pl.col('umsatz').round(2))
    df_import = df_import.with_columns(pl.col('fee').round(2))
    df_import = df_import.cast({'umsatz': pl.String, 'fee': pl.String})
    df_import = df_import.with_columns(pl.col('umsatz').str.replace_all(r'\.', ',').alias('umsatz'))
    df_import = df_import.with_columns(pl.col('fee').str.replace_all(r'\.', ',').alias('fee'))

    # ========================== RECHNUNGEN DATEI ==========================
    try:
        df_rechnungen = pl.read_excel(file2)
        assert df_rechnungen.width == 9
    except FileNotFoundError as e:
        raise Exception("Die Rechnungsdatei wurde nicht gefunden. Bitte überprüfen Sie den Dateipfad.") from e
    except AssertionError as e:
        raise Exception("Die Struktur der Rechnungsdatei ist nicht korrekt. Bitte überprüfen Sie die Datei.") from e

    df_rechnungen = df_rechnungen.select([
        col for i, col in enumerate(df_rechnungen.columns) if i in [0, 1, 2, 4, 7]])
    df_rechnungen = df_rechnungen.rename(dict(zip(df_rechnungen.columns[0:], ['belegfeld', 'auftragsnummer', 'renr',
                                                                              'datum', 'name'])))

    # ========================== MERGE ==========================
    df_import = df_import.join(df_rechnungen, on=['auftragsnummer'], how="left")

    df_import = df_import.with_columns(pl.when(pl.col('text').str.contains('(?i)Grundgebühr')).then(pl.col('order'))
                                       .otherwise(pl.col('datum')).alias('datum'))
    df_import = df_import.with_columns(
        pl.when(pl.col('text').str.contains('(?i)Grundgebühr')).then(pl.lit('Grundgebühr'))
        .otherwise(pl.col('auftragsnummer')).alias('auftragsnummer'))

    df_import = df_import.filter(pl.col('text').str.contains('(?i)freigabe|grundgebühr'))

    df_import = df_import.with_columns(pl.concat_str([
        pl.col('renr'),
        pl.lit(' - '),
        pl.col('name')])
                                       .alias('buchungstext'))

    df_import = df_import.with_columns(pl.when(pl.col('text').str.contains('(?i)Grundgebühr')).then(pl.col('text'))
                                       .otherwise(pl.col('buchungstext')).alias('buchungstext'))

    df_import = df_import.with_columns(pl.col('datum').str.slice(0, 5).str.replace_all(r'\.', '')
                                       .alias('datum'))

    df_import = df_import.with_columns(
        pl.when(pl.col('text').str.contains('(?i)Grundgebühr')).then(pl.concat_str([pl.lit('GG '), pl.col('datum')]))
        .otherwise(pl.col('belegfeld')).alias('belegfeld'))
    df_import = df_import.with_columns(pl.when(pl.col('text').str.contains('(?i)Grundgebühr')).then(pl.lit('49722'))
                                       .otherwise(pl.col('gegenkonto')).alias('gegenkonto'))
    df_import = df_import.with_columns(pl.when(pl.col('text').str.contains('(?i)Grundgebühr')).then(pl.lit('401'))
                                       .alias('bu'))
    df_import = df_import.with_columns(pl.lit('S').alias('sh'))
    df_import = df_import.with_columns(pl.when(pl.col('umsatz').str.contains('-')).then(pl.lit('H'))
                                       .otherwise(pl.col('sh')).alias('sh'))
    df_import = df_import.with_columns(pl.col('umsatz').str.replace_all(r'\-', ''))

    df_import = df_import.drop('order', 'renr', 'name', 'text')
    df_import = df_import.unpivot(index=['auftragsnummer', 'konto', 'gegenkonto', 'belegfeld', 'datum',
                                         'buchungstext', 'sh', 'bu'])

    df_import = df_import.with_columns(pl.when(pl.col('variable') == 'fee').
                                       then(pl.concat_str([pl.col('buchungstext'), pl.lit(' - Gebühren')]))
                                       .otherwise(pl.col('buchungstext')).alias('buchungstext'))
    df_import = df_import.with_columns(pl.when(pl.col('variable') == 'fee').
                                       then(pl.lit('49722'))
                                       .otherwise(pl.col('gegenkonto')).alias('gegenkonto'))
    df_import = df_import.with_columns(pl.when(pl.col('variable') == 'fee').
                                       then(pl.lit('401')).otherwise(pl.col('bu')).alias('bu'))
    df_import = df_import.with_columns(pl.when(pl.col('variable') == 'fee').
                                       then(pl.lit('H'))
                                       .otherwise(pl.col('sh')).alias('sh'))

    df_import = df_import.drop('variable')
    df_import = df_import.rename({'value': 'umsatz'})
    df_import = df_import.filter(pl.col('umsatz') != '0,0')

    # ========================== SPEICHERN ==========================
    output_path = generate_output_path_datev(
        user_id=user_id,
        data_conversion="Ankerkraut",
        conversion="Kaufland",
        month=month,
        year=year,
        task_id=task.request.id,
        extension="csv",
    )

    ensure_output_folder(output_path)

    with io.BytesIO() as buffer:
        datev_export_polars(
            df=df_import,
            month=month,
            year=year,
            buffer=buffer,
            bernr="405312",
            mdtnr="10055",
            skl="5",
            skr="3",
            text="Ankerkraut Kaufland",
        )

        with open(output_path, "wb") as f:
            f.write(buffer.getvalue())

    # ========================== CLEANUP ==========================
    delete_input_files(files)

    return {"file_path": str(output_path), "file_name": strip_task_id(output_path.name), "user_id": user_id}
