import importlib
import pkgutil

from app.core.logger import logger
from app.tasks import data_conversions, tools


def auto_import_data_conversions():
    for _, module_name, _ in pkgutil.iter_modules(data_conversions.__path__):
        logger.debug(f"🔌 Imported data conversion module: {module_name}")
        full_module = f"app.tasks.data_conversions.{module_name}"
        importlib.import_module(full_module)


def auto_import_tools():
    for _, module_name, _ in pkgutil.iter_modules(tools.__path__):
        logger.debug(f"🔌 Imported tool module: {module_name}")
        full_module = f"app.tasks.tools.{module_name}"
        importlib.import_module(full_module)


auto_import_data_conversions()
auto_import_tools()
