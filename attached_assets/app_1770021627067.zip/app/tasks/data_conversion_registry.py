import inspect
from typing import Any, Callable, Dict


class DataConversionRegistry:
    _registry: Dict[str, Dict[str, Dict[str, Any]]] = {}

    @classmethod
    def register(
        cls,
        data_conversion: str,
        conversion: str,
        func: Callable,
        description: str,
        input_type: Dict[str, Any],
        output_type: str,
    ) -> None:
        cls._registry.setdefault(data_conversion, {})[conversion] = {
            "function": func,
            "signature": inspect.signature(func),
            "metadata": {
                "description": description,
                "input_type": input_type,
                "output_type": output_type,
                "input_schema": cls._build_input_schema(input_type),
            },
        }

    @staticmethod
    def _build_input_schema(input_type: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
        schema = {}
        for key, val in input_type.items():
            if isinstance(val, tuple):
                type_, desc = val
            else:
                type_, desc = val, None

            schema[key] = {
                "type": getattr(type_, "__name__", str(type_)),
                "description": desc,
            }
        return schema

    @classmethod
    def get_function(cls, data_conversion: str, conversion: str) -> Callable:
        return cls._registry[data_conversion][conversion]["function"]

    @classmethod
    def get_signature(cls, data_conversion: str, conversion: str):
        return cls._registry[data_conversion][conversion]["signature"]

    @classmethod
    def get_metadata(cls, data_conversion: str, conversion: str) -> Dict[str, Any]:
        return cls._registry[data_conversion][conversion]["metadata"]

    @classmethod
    def get_all(cls) -> Dict[str, Dict[str, Any]]:
        return {
            dc: {
                conv: {
                    "description": meta["metadata"]["description"],
                    "input_schema": meta["metadata"].get("input_schema", {}),
                    "output_type": meta["metadata"].get("output_type"),
                }
                for conv, meta in conversions.items()
            }
            for dc, conversions in cls._registry.items()
        }


def register_data_conversion(data_conversion, conversion, description, input_type, output_type):
    def decorator(func):
        DataConversionRegistry.register(
            data_conversion=data_conversion,
            conversion=conversion,
            func=func,
            description=description,
            input_type=input_type,
            output_type=output_type,
        )
        return func

    return decorator
