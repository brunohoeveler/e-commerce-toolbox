import os
import sys

from loguru import logger

LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

logger.remove()
logger.add(sys.stdout, level=LOG_LEVEL, format="{time} {level} {message}")

# Optional: add file logging
logger.add("logs/app.log", rotation="5 MB", level="DEBUG")
