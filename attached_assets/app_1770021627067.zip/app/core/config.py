from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent.parent


class Settings(BaseSettings):
    PROJECT_NAME: str = "FastAPI Celery Tools"

    # Celery
    CELERY_BROKER_URL: str = "redis://redis:6379/0"
    CELERY_RESULT_BACKEND: str = "redis://redis:6379/0"

    LOG_LEVEL: str = "INFO"

    UPLOAD_DIR: Path = BASE_DIR / "storage" / "uploads"
    RESULT_DIR: Path = BASE_DIR / "storage" / "results"
    ERROR_DIR: Path = BASE_DIR / "storage" / "errors"
    RESOURCE_DIR: Path = BASE_DIR / "resources"

    model_config = SettingsConfigDict(
        env_file=".env",
        extra="ignore",
    )


settings = Settings()
