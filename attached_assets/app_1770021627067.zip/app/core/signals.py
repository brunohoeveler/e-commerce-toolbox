import os
from datetime import datetime, timezone

from celery import signals
from slack_sdk import WebClient

# Use your Bot Token, not an old webhook URL
SLACK_TOKEN = os.environ["SLACK_BOT_TOKEN"]
slack = WebClient(token=SLACK_TOKEN)


@signals.task_failure.connect
def notify_slack_on_failure(sender=None, task_id=None, exception=None, args=None, kwargs=None, einfo=None, **extras):
    # 1) grab the pieces you want
    func_name = sender.name
    data_conversion = args[0] if args and len(args) > 0 else "N/A"
    conversion = args[1] if args and len(args) > 1 else "N/A"
    tb = einfo or "No traceback available"
    timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds")

    # 2) build the Block Kit payload
    blocks = [
        # HEADER with red “X” emoji and function name
        {"type": "section", "text": {"type": "mrkdwn", "text": f":x: *Task Failed:* `{func_name}`"}},
        # FIELDS for your two args
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": f"*Data Conversion:*\n{data_conversion}"},
                {"type": "mrkdwn", "text": f"*Conversion:*\n{conversion}"},
                {"type": "mrkdwn", "text": f"*Task ID:*\n{task_id}"},
                {"type": "mrkdwn", "text": f"*Exception:*\n{exception.__class__.__name__}: {exception}"},
            ],
        },
        # TRACEBACK as a code block
        {"type": "section", "text": {"type": "mrkdwn", "text": f"```{tb}```"}},
        # CONTEXT with full ISO-timestamp
        {"type": "context", "elements": [{"type": "mrkdwn", "text": f"Occurred at: `{timestamp}`"}]},
    ]

    # 3) send it
    slack.chat_postMessage(
        channel="#fastapi-tech-website",  # replace with your channel ID
        text=f"Task Failed: {func_name}",  # fallback for notifications
        blocks=blocks,
    )
